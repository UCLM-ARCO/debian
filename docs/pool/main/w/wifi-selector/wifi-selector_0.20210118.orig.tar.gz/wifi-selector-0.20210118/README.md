# wifi-selector

Web service to choose wifi credentials in a Raspberry Pi. This server is listening in the port 8181. 
Once introduced the credentials that you want, the must restart the system.

## Installation

```shell
$ sudo apt-get install wifi-selector
```

