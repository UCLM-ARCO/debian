#!/usr/bin/python3
# -*- coding: utf-8; mode: python -*-

from flask import Flask, render_template, url_for, request, flash
from forms import WifiForm
import os
import subprocess

app = Flask(__name__)
SECRET_KEY = os.urandom(32)
app.config['SECRET_KEY'] = SECRET_KEY

static_ip_config = [
    'interface wlan0\n',
    '  static ip_address=192.168.4.1/24\n',
    '  nohook wpa_supplicant\n'
]

first_request = True

@app.route('/', methods=["GET", "POST"])
def index():
    global first_request
    form = WifiForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            ssid = form.ssid.data
            passw = form.password.data
            update_credentials(ssid, passw)
            
            flash('The credentials have been saved correctly')

            if first_request:
                configure_system_to_auto_connect()
                first_request = False

    return render_template("credentials.html", form=form)

def update_credentials(ssid, passw):
    get_encoded_psk_cmd = "wpa_passphrase {} {} | grep psk".format(ssid, passw)
    psk = subprocess.check_output(get_encoded_psk_cmd, shell=True)
    psk = psk.decode().split("\n")[1]

    with open('/etc/wpa_supplicant/wpa_supplicant.conf', 'a') as f:
        f.write('\nnetwork={\n')
        f.write('\tssid="{}"\n'.format(ssid))
        f.write(psk + '\n')
        f.write('\tkey_mgmt=WPA-PSK\n')
        f.write('}\n')

def configure_system_to_auto_connect():
    os.system('sudo systemctl disable hostapd.service')
    os.system('sudo systemctl disable dnsmasq.service')
    os.system('sudo systemctl disable wifi-selector.service')
    
    with open('/etc/dhcpcd.conf', 'r') as f:
        lines = f.readlines()

    with open('/etc/dhcpcd.conf', 'w') as f:
        for line in lines:
            if line not in static_ip_config:
                f.write(line)