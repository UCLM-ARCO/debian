0.20141202
==========

* updated move-line-or-region.cfg.el for emacs 24.3
* tabbar keybindings changed (Fixes https://bitbucket.org/DavidVilla/emacs-pills/issue/4)

0.20140305
==========

* removing projectile pill due to performance issues

0.20131127
==========

* "package" customization and auto-install for package dependencies.
* NEW projectile pill
* NEW multiple-cursors pill
* highlight-changes temporally disabled
* paren-autoclose temporally disabled

0.20130517
==========

* recompile while a compilation is running interrupt it and compile-again. It mark it setting
  modeline to DeepBlue.

0.20130327
==========

* compile-bookmarks.cfg and compilation.cfg
* module compile-bookmark.el
* module epy-nose.el

0.20120904
==========

* auto-fill-mode for latex

0.20120619
==========

* [NEW] move-line-or-region.cfg: using M-up/down keystrokes (eclipse way)
* [NEW] rst.cfg: load rst-mode for *.rst files

0.20120523
==========

* latex.cfg changes auto-local prefix
* generated template.el as .emacs example

0.20120326
==========

* date-version yasnippet


.. Local Variables:
..  coding: utf-8
..  mode: rst
..  mode: flyspell
..  ispell-local-dictionary: "american"
.. fill-column: 90
.. End:
