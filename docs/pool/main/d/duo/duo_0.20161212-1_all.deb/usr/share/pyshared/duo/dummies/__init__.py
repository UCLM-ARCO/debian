# -*- mode: python; coding: utf-8 -*-

from dummy_base import Dummy, MetaDummy
from dummy_gui import GUI
