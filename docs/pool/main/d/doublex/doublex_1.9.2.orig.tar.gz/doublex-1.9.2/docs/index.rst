:orphan:

=======
doublex
=======

.. include :: README.rst.inc
.. include :: contents.rst.inc
