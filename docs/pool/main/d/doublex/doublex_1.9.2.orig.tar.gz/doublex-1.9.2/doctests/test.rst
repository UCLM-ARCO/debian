:orphan:

.. include :: doubles.rst.inc
.. include :: reference.rst.inc
.. include :: methods.rst.inc
.. include :: properties.rst.inc
.. include :: delegates.rst.inc
.. include :: observers.rst.inc
.. include :: mimics.rst.inc
.. include :: async-spies.rst.inc
.. include :: calls.rst.inc
