#!/usr/bin/env python3

import os
import sys
from pathlib import Path
import random
import logging
import argparse
from lxml import etree

LAST_TEX = 'last.tex'
logging.getLogger().setLevel(logging.DEBUG)
random.seed(os.getpid())
ns = etree.FunctionNamespace('http://arco.esi.uclm.es/commodity')
ns.prefix = 'commodity'


def resolve_path(fname, paths, find_all=False):
    '''
    Search 'fname' in the given paths and return the first full path
    that has the file. If 'find_all' is True it returns all matching paths.
    It always returns a list.

    >>> resolve_path('config', ['/home/user/brook', '/etc/brook'])
    ['/etc/brook/config']
    '''
    retval = []
    for p in paths:
        path = os.path.join(p, fname)
        if os.path.exists(path):
            if not find_all:
                return [path]

            retval.append(path)

    return retval


XSL_DIR = resolve_path('xsl',
                       [os.path.dirname(os.path.normpath(__file__)), '/usr/lib/graf'])[0]

logging.info("graf xsl: %s", XSL_DIR)


def xslt_register(func):
    name = func.__name__[2:].replace('_', '-')
    ns[name] = func

    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper


@xslt_register
def f_random(ctx):
    return str(random.randint(1, 1000))


@xslt_register
def f_file_exists(ctx, fname):
    return os.path.exists(fname)


@xslt_register
def f_max_len(ctx, items):
    print("MAX_LEN", items)
    item0 = items[0]
    print(dir(item0))
    print(str(item0))
    return "no"


def generate_exam(exam_fname, exam_part, is_solution=False):
    exam_path = Path(sys.argv[1])
    rootdir = f'"{exam_path.parent.absolute()}/"'

    exam_tree = etree.parse(exam_fname)
    xslt_tree = etree.parse(os.path.join(XSL_DIR, 'exam_gen.xsl'))
    xslt = etree.XSLT(xslt_tree)

    try:
        return xslt(exam_tree, rootdir=rootdir, part=str(exam_part))
    except Exception as e:
        print(f"Error: {e} or parse error.")
        log = e.error_log.filter_from_level(etree.ErrorLevels.FATAL)
        for entry in log[:len(log)//2]:
            filename = Path(entry.filename).relative_to(Path.cwd())
            print(f"  file:'{filename}' [{entry.line},{entry.column}] {entry.message}")
        exit(1)


def generate_latex_view(exam_tree):
    exam_path = Path(sys.argv[1])
    rootdir = '"' + str(exam_path.parent.absolute()) + '/"'

    xslt_tree = etree.parse(os.path.join(XSL_DIR, 'latex_view.xsl'))
    xslt = etree.XSLT(xslt_tree)

    return xslt(exam_tree, rootdir=rootdir)


def get_parts(fname):

    retval = []
    fd = open(fname)
    for line in fd:
        if '<part' in line:
            try:
                n = line.index('name') + 6
                title = line[n:]
                n = title.index('"')
                title = title[:n].replace(' ', '_')
                retval.append(title)

            except ValueError:
                retval.append('')
    fd.close()
    return retval


def string_before(cad, sub):
    n = cad.find(sub)
    if n == -1:
        return cad
    return cad[:n]


def process_parts(exam, is_solution):
    base = string_before(exam, '.')
    exam_parts = get_parts(exam)

    tex_filenames = []
    for p, part in enumerate(exam_parts):

        xml_exam = generate_exam(exam, p + 1, is_solution)

        with open('temp', 'wt') as fd:
            fd.write(str(xml_exam))

        latex_exam = generate_latex_view(xml_exam)

        fname = os.path.basename(base)
        if part:
            fname += '-%s' % part
        if is_solution:
            fname += '.solved'

        fname += '.tex'

        tex_filenames.append(fname)

        if os.path.exists(LAST_TEX):
            os.remove(LAST_TEX)

        os.symlink(fname, LAST_TEX)

        logging.info('rendering %s (%s)...', exam, part)
        with open(fname, 'wt') as fd:
            fd.write(str(latex_exam))

    for fname in tex_filenames:
        retval = os.system('MAIN=%s make -f /usr/include/arco/latex.mk' % fname)
        if retval:
            print(' [== ERROR ==] ')

    logging.info('done')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '-s', '--solution', action='store_true',
                        help='Generate solved exam')
    parser.add_argument('-c', '--clean', action='store_true',
                        help='remove generated files')
    parser.add_argument('exam', nargs='?',
                        help='your-file.exam.xml')

    config = parser.parse_args()

    if config.clean:
        logging.info("Cleaning previously generated files")
        os.system('rm -v *.tex *.aux *.log *.pdf *.out *~ 2> /dev/null')

        if not config.exam:
            return 0

    if not config.exam:
        parser.print_help()
        return 1

    if not os.path.exists(config.exam):
        logging.error("ERROR: No existe el fichero '%s'" % config.exam)
        return 1

    process_parts(config.exam, False)
    if config.solution:
        logging.info("Generating solution")
        process_parts(config.exam, True)


main()
