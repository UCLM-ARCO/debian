#!/usr/bin/env python3

import os
from pathlib import Path
import random
import logging
import argparse
import subprocess
from lxml import etree

CWD = Path.cwd()
LAST_TEX = 'last.tex'

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.INFO)
random.seed(os.getpid())
ns = etree.FunctionNamespace('http://arco.esi.uclm.es/commodity')
ns.prefix = 'commodity'


def resolve_path(fname, paths, find_all=False):
    '''
    Search 'fname' in the given paths and return the first full path
    that has the file. If 'find_all' is True it returns all matching paths.
    It always returns a list.

    >>> resolve_path('config', ['/home/user/brook', '/etc/brook'])
    ['/etc/brook/config']
    '''
    retval = []
    for p in paths:
        path = os.path.join(p, fname)
        if os.path.exists(path):
            if not find_all:
                return [path]

            retval.append(path)

    return retval


XSL_DIR = resolve_path(
    'xsl', [os.path.dirname(os.path.normpath(__file__)), '/usr/lib/graf'])[0]

logging.debug("xsl dir: %s", XSL_DIR)


def xslt_register(func):
    name = func.__name__[2:].replace('_', '-')
    ns[name] = func

    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper


@xslt_register
def f_random(ctx):
    return str(random.randint(1, 1000))


@xslt_register
def f_file_exists(ctx, fname):
    return Path(fname).exists()


def show_errors(e):
    logging.error(f"{e} or parse error.")
    log = e.error_log.filter_from_level(etree.ErrorLevels.FATAL)
    for entry in log[:len(log)//2]:
        filename = Path(entry.filename)
        logging.error(f"  file:'{filename}' [{entry.line},{entry.column}] {entry.message}")
    exit(1)


def generate_exam(exam_fname, exam_part, is_solution=False):
    exam_path = Path(exam_fname)
    rootdir = f'"{exam_path.parent.absolute()}/"'

    try:
        exam_tree = etree.parse(exam_fname)
        xslt_tree = etree.parse(os.path.join(XSL_DIR, 'exam_gen.xsl'))
        xslt = etree.XSLT(xslt_tree)
        return xslt(exam_tree, rootdir=rootdir, part=str(exam_part))
    except etree.XMLSyntaxError as e:
        show_errors(e)


def generate_latex_view(exam_fname, exam_tree):
    exam_path = Path(exam_fname)
    rootdir = f'"{exam_path.parent.absolute().relative_to(CWD)}/"'

    xslt_tree = etree.parse(os.path.join(XSL_DIR, 'latex_view.xsl'))
    xslt = etree.XSLT(xslt_tree)

    return xslt(exam_tree, rootdir=rootdir)


def get_parts(fname):
    try:
        root = etree.parse(fname)
    except etree.XMLSyntaxError as e:
        show_errors(e)

    part_elements = root.xpath('//exam/part')
    part_names = [part.get('name') for part in part_elements]
    part_names = [part.replace(' ', '_') if part else '' for part in part_names]
    return part_names


def string_before(cad, sub):
    n = cad.find(sub)
    if n == -1:
        return cad
    return cad[:n]


def process_parts(exam_path, is_solution):
    stem = string_before(exam_path, '.')
    exam_parts = get_parts(exam_path)

    all_generated = []
    fname = os.path.basename(stem)
    for p, part in enumerate(exam_parts):
        xml_exam = generate_exam(exam_path, p + 1, is_solution)

        with open(f'{fname}.temp.xml', 'wt') as fd:
            fd.write(str(xml_exam))

        latex_exam = generate_latex_view(exam_path, xml_exam)

        generated = fname
        if part:
            generated += '-%s' % part
        if is_solution:
            generated += '.solved'

        generated += '.tex'

        all_generated.append(generated)

        if os.path.exists(LAST_TEX):
            os.remove(LAST_TEX)

        os.symlink(generated, LAST_TEX)

        part = f'({part})' if part else ''
        logging.info("rendering '%s' %s...", generated, part)

        with open(generated, 'wt') as fd:
            fd.write(str(latex_exam))

    latex_compile_exams(all_generated)


def latex_compile_exams(filenames):
    for fname in filenames:
        command = f'MAIN={fname} make -f /usr/include/arco/latex.mk'
        try:
            subprocess.check_output(
                command, stderr=subprocess.STDOUT, shell=True, universal_newlines=True)
        except subprocess.CalledProcessError as e:
            logging.error('latex compile')
            logging.error(e.output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '-s', '--solution', action='store_true',
                        help='Generate solved exam')
    parser.add_argument('-c', '--clean', action='store_true',
                        help='remove generated files')
    parser.add_argument('exam', nargs='?',
                        help='your-file.exam.xml')

    config = parser.parse_args()

    if config.clean:
        logging.info("Cleaning previously generated files")
        os.system('rm -v *.tex *.aux *.log *.pdf *.out *~ *.temp.xml 2> /dev/null')

        if not config.exam:
            return 0

    if not config.exam:
        parser.print_help()
        return 1

    if not os.path.exists(config.exam):
        logging.error("ERROR: No existe el fichero '%s'" % config.exam)
        return 1

    process_parts(config.exam, False)
    if config.solution:
        process_parts(config.exam, True)


if __name__ == '__main__':
    main()
