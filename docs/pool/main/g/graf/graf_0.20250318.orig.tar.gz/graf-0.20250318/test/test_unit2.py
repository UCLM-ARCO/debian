from unittest import TestCase
from mkexam2 import Exam


class PartTests(TestCase):
    def setUp(self):
        self.map = Exam('fixtures/parts.exam.xml')

    def test_part_names(self):
        names = self.map.part_names
        self.assertEqual(names, ['P1', 'P2'])

    def test_part_fnames(self):
        self.map.gen_parts()
        part_names = [part.basename for part in self.map.parts]
        self.assertEqual(part_names, ['parts_P1_es', 'parts_P2_es'])

    def test_tex_fnames(self):
        self.map.gen_parts()
        self.map.gen_tex()
        self.assertEqual(
            self.map.get_tex_fnames(),
            ['parts_P1_es.tex', 'parts_P2_es.tex'])


class SimpleExamTests(TestCase):
    def setUp(self):
        self.map = Exam('demo/demo.exam.xml')

    def test_part_names(self):
        names = self.map.part_names
        self.assertEqual(names, [''])

    def test_part_xml_fnames(self):
        self.map.gen_parts()
        part_names = [part.basename for part in self.map.parts]
        self.assertEqual(part_names, ['demo_es'])

    def test_tex_fnames(self):
        self.map.gen_parts()
        self.map.gen_tex()
        self.assertEqual(
            self.map.get_tex_fnames(),
            ['demo_es.tex'])


class SimpleExamWithSolution(TestCase):
    def setUp(self):
        self.map = Exam('demo/demo.exam.xml', show_solution=True)

    def test_tex_fnames(self):
        self.map.gen_parts()
        self.map.gen_tex()
        self.assertEqual(
            self.map.get_tex_fnames(),
            ['demo_es.tex', 'demo_es.solved.tex'])

    def test_pdf_fnames(self):
        self.map.gen_parts()
        self.map.gen_tex()
        self.map.gen_pdf()
        self.assertEqual(
            self.map.get_pdf_fnames(),
            ['demo_es.pdf', 'demo_es.solved.pdf'])
