#!/usr/bin/env python3

import os
import sys
import logging
import random
import subprocess
import argparse
from functools import cached_property
from pathlib import Path
from lxml import etree

CWD = Path.cwd()
LAST_TEX = 'last.tex'

logger = logging.getLogger(__name__)


def resolve_path(fname, paths, find_all=False):
    '''
    Search 'fname' in the given paths and return the first full path
    that has the file. If 'find_all' is True it returns all matching paths.
    It always returns a list.

    >>> resolve_path('config', ['/home/user/brook', '/etc/brook'])
    ['/etc/brook/config']
    '''
    retval = []
    for p in paths:
        path = os.path.join(p, fname)
        if os.path.exists(path):
            if not find_all:
                return [path]

            retval.append(path)

    return retval


def shell_run(command):
    try:
        subprocess.run(command, shell=True, check=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            universal_newlines=True)

    except subprocess.CalledProcessError as e:
        logger.error(f"Command '{command}' failed: {e.stderr}")


XSL_DIR = resolve_path(
    'xsl', [os.path.dirname(os.path.normpath(__file__)), '/usr/lib/graf'])[0]

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.INFO)
random.seed(os.getpid())
ns = etree.FunctionNamespace('http://arco.esi.uclm.es/commodity')
ns.prefix = 'commodity'

def string_before(cad, sub):
    n = cad.find(sub)
    if n == -1:
        return cad
    return cad[:n]


def xslt_register(func):
    name = func.__name__[2:].replace('_', '-')
    ns[name] = func

    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper


@xslt_register
def f_random(ctx):
    return str(random.randint(1, 1000))


@xslt_register
def f_file_exists(ctx, fname):
    return Path(fname).exists()


def show_errors(e):
    logger.error(f"{e} or parse error.")
    log = e.error_log.filter_from_level(etree.ErrorLevels.FATAL)
    for entry in log[:len(log)//2]:
        filename = Path(entry.filename)
        logger.error(f"  file:'{filename}' [{entry.line},{entry.column}]     {entry.message}")
    exit(1)


def generate_exam(exam_fname, exam_part, is_solution=False):
    exam_path = Path(exam_fname)
    rootdir = f'"{exam_path.parent.absolute()}/"'

    try:
        exam_tree = etree.parse(exam_fname)
        xslt_tree = etree.parse(os.path.join(XSL_DIR, 'exam_gen.xsl'))
        xslt = etree.XSLT(xslt_tree)

        return xslt(
            exam_tree, rootdir=rootdir, part=str(exam_part),
            is_solution=str(int(is_solution)))
    except etree.XMLSyntaxError as e:
        show_errors(e)


def generate_latex_view(exam_fname, exam_tree):
    exam_path = Path(exam_fname)
    # rootdir = f'"{exam_path.parent.absolute().relative_to(CWD)}/"'

    xslt_tree = etree.parse(os.path.join(XSL_DIR, 'latex_view.xsl'))
    xslt = etree.XSLT(xslt_tree)

    return xslt(exam_tree)  #, rootdir=rootdir)


def exam_type(fname):
    tree = etree.parse(fname)
    root = tree.getroot()
    return root.tag


class Exam:
    def __init__(self, fname, show_solution=False):
        stem = string_before(fname, '.')
        self.fname = fname
        self.show_solution = show_solution
        self.basename = os.path.basename(stem)

    @cached_property
    def part_names(self):
        try:
            tree = etree.parse(self.fname)
        except etree.XMLSyntaxError as e:
            show_errors(e)

        part_elements = tree.xpath('//exam/part')
        retval = [part.get('name') for part in part_elements]
        retval = [part.replace(' ', '_') if part
                        else '' for part in retval]
        return retval

    def gen_parts(self):
        self.parts = []
        for i, name in enumerate(self.part_names, start=1):
            self.parts.append(
                ExamPart(self, i, name))
            if self.show_solution:
                self.parts.append(
                    ExamPart(self, i, name, show_solution=True))

    def gen_tex(self):
        for part in self.parts:
            part.gen_tex()

    def gen_pdf(self):
        for part in self.parts:
            part.gen_pdf()

    def get_tex_fnames(self):
        return [part.tex_fname for part in self.parts]

    def get_pdf_fnames(self):
        return [part.pdf_fname for part in self.parts]


class ExamPart:
    def __init__(self, emap, part_number, part_name, show_solution=False):
        self.emap = emap
        self.part_number = part_number
        self.part_name = part_name
        self.show_solution = show_solution
        self.tex_name = None
        self.pdf_name = None

        self.xml_full_tree = generate_exam(
            self.emap.fname, self.part_number, show_solution)
        self.load_xml_attributes()
        self.save_full_xml()

    @cached_property
    def basename(self):
        part_name = self.emap.basename
        if self.part_name:
            part_name += '_' + self.part_name
        if self.lang:
            part_name += '_' + self.lang
        if self.show_solution:
            part_name += '.solved'

        return part_name

    def load_xml_attributes(self):
        for name, value in self.xml_full_tree.getroot().attrib.items():
            setattr(self, name, value)

    def save_full_xml(self):
        fname = self.basename + '.full.xml'

        with open(fname, 'wt') as fd:
            fd.write(str(self.xml_full_tree))

    def gen_tex(self):
        tex_content = generate_latex_view(self.emap.fname, self.xml_full_tree)

        self.tex_fname = self.basename + '.tex'
        with open(self.tex_fname, 'wt') as fd:
            fd.write(str(tex_content))

        logger.info(f"updated '{self.tex_fname}'")

    def gen_pdf(self):
        command = f'MAIN={self.tex_fname} make -f /usr/include/arco/latex.mk'
        try:
            subprocess.check_output(
                command, stderr=subprocess.STDOUT, shell=True,
                universal_newlines=True)
            self.pdf_fname = self.tex_fname.replace('.tex', '.pdf')
            logger.info(f"updated '{self.pdf_fname}'")

        except subprocess.CalledProcessError as e:
            logger.error('latex compile')
            logger.error(e.output)


class SinglePartExam(Exam):
    def part_names(self):
        return ['']

    def gen_parts(self):
        self.parts = [DummyPart(self, 1, '')]


class DummyPart(ExamPart):
    def __init__(self, emap, part_number, part_name, show_solution=False):
        self.emap = emap
        self.part_name = part_name
        self.show_solution = show_solution
        with open(emap.fname, 'rt') as fd:
            self.xml_full_tree = etree.parse(fd)
        self.load_xml_attributes()

    @cached_property
    def basename(self):
        part_name = self.emap.basename
        if self.show_solution:
            part_name += '.solved'

        return part_name


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '-s', '--solution', action='store_true',
                        help='Generate solved exam')
    parser.add_argument('-c', '--clean', action='store_true',
                        help='remove generated files')
    parser.add_argument('exam', nargs='?',
                        help='your-file.exam.xml')
    parser.add_argument('-o', '--open', action='store_true',
                        help='open generated file with this program')
    parser.add_argument('-n', '--nup', action='store_true',
                        help='Generate 2 pages per sheet version')
    parser.add_argument('-p', '--ps', action='store_true',
                        help='Convert to postscript, then to pdf')
    parser.add_argument('-v', '--verbosity', action='count', default=0,
                        help='Increase output verbosity (use -v for INFO, -vv for DEBUG)')

    config = parser.parse_args()

    logger.setLevel(level={2: logging.DEBUG, 1: logging.INFO}.get(
        config.verbosity, logging.ERROR))
    # print("verbosity: {}".format(logging.getLevelName(logger.level)))
    logger.debug("xsl dir: %s", XSL_DIR)

    if config.clean:
        logging.info("Cleaning previously generated files")
        shell_run('rm -fv *.tex *.aux *.log *.pdf *.out *~ *.temp.xml 2> /dev/null')

        if not config.exam:
            return 0

    if not config.exam:
        parser.print_help()
        return 1

    if not os.path.exists(config.exam):
        logging.error("ERROR: Not found '%s'" % config.exam)
        return 1

    if exam_type(config.exam) == 'exam':
        exam = Exam(config.exam, config.solution)
    else:
        exam = SinglePartExam(config.exam)

    exam.gen_parts()
    exam.gen_tex()
    exam.gen_pdf()

    if config.nup:
        for pdf in exam.get_pdf_fnames():
            logging.info(f'generating 2 pages per sheet version of {pdf}')
            shell_run(f'pdfnup {pdf} --nup 2x1 --outfile {pdf}')

    if config.open:
        pdf = exam.get_pdf_fnames()[-1]
        os.system(f'xdg-open {pdf} &')


if __name__ == '__main__':
    main()
