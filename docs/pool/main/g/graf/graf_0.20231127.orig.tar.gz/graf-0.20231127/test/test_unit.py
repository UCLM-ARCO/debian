from unittest import TestCase
from mkexam import get_parts


class PartTests(TestCase):
    def test_parts(self):
        names = get_parts('fixtures/parts.xml')
        self.assertEqual(names, ['part-1', 'part-2'])
