#!/usr/bin/env python3

import os
from pathlib import Path
import random
import logging
import argparse
import subprocess
from lxml import etree
import string
import subprocess


CWD = Path.cwd()
LAST_TEX = 'last.tex'

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.INFO)
random.seed(os.getpid())
ns = etree.FunctionNamespace('http://arco.esi.uclm.es/commodity')
ns.prefix = 'commodity'


def resolve_path(fname, paths, find_all=False):
    '''
    Search 'fname' in the given paths and return the first full path
    that has the file. If 'find_all' is True it returns all matching paths.
    It always returns a list.

    >>> resolve_path('config', ['/home/user/brook', '/etc/brook'])
    ['/etc/brook/config']
    '''
    retval = []
    for p in paths:
        path = os.path.join(p, fname)
        if os.path.exists(path):
            if not find_all:
                return [path]

            retval.append(path)

    return retval


def shell_run(command):
    try:
        subprocess.run(command, shell=True, check=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            universal_newlines=True)

    except subprocess.CalledProcessError as e:
        logging.error(f"Command '{command}' failed: {e.stderr}")


XSL_DIR = resolve_path(
    'xsl', [os.path.dirname(os.path.normpath(__file__)), '/usr/lib/graf'])[0]

logging.debug("xsl dir: %s", XSL_DIR)


def xslt_register(func):
    name = func.__name__[2:].replace('_', '-')
    ns[name] = func

    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper


@xslt_register
def f_random(ctx):
    return str(random.randint(1, 1000))


@xslt_register
def f_file_exists(ctx, fname):
    return Path(fname).exists()


def show_errors(e):
    logging.error(f"{e} or parse error.")
    log = e.error_log.filter_from_level(etree.ErrorLevels.FATAL)
    for entry in log[:len(log)//2]:
        filename = Path(entry.filename)
        logging.error(f"  file:'{filename}' [{entry.line},{entry.column}] {entry.message}")
    exit(1)


def generate_exam(exam_fname, exam_part, is_solution=False):
    exam_path = Path(exam_fname)
    rootdir = f'"{exam_path.parent.absolute()}/"'

    try:
        exam_tree = etree.parse(exam_fname)
        xslt_tree = etree.parse(os.path.join(XSL_DIR, 'exam_gen.xsl'))
        xslt = etree.XSLT(xslt_tree)
        return xslt(
            exam_tree, rootdir=rootdir, part=str(exam_part),
            is_solution=str(int(is_solution)))
    except etree.XMLSyntaxError as e:
        show_errors(e)


def generate_latex_view(exam_fname, exam_tree):
    exam_path = Path(exam_fname)
    rootdir = f'"{exam_path.parent.absolute().relative_to(CWD)}/"'

    xslt_tree = etree.parse(os.path.join(XSL_DIR, 'latex_view.xsl'))
    xslt = etree.XSLT(xslt_tree)

    return xslt(exam_tree, rootdir=rootdir)


def get_parts(fname):
    try:
        root = etree.parse(fname)
    except etree.XMLSyntaxError as e:
        show_errors(e)

    part_elements = root.xpath('//exam/part')
    part_names = [part.get('name') for part in part_elements]
    part_names = [part.replace(' ', '_') if part else '' for part in part_names]
    return part_names


def string_before(cad, sub):
    n = cad.find(sub)
    if n == -1:
        return cad
    return cad[:n]


class Exam:
    def __init__(self, exam_path):
        self.exam_path = exam_path
        self.exam_parts = get_parts(exam_path)

        stem = string_before(exam_path, '.')
        self.fname = os.path.basename(stem)

    def xml_parts(self, is_solution):
        products = []
        for p, part in enumerate(self.exam_parts):
            xml_content = generate_exam(self.exam_path, p + 1, is_solution)

            product_name = self.fname
            if part:
                product_name += '-%s' % part
            if is_solution:
                product_name += '.solved'

            products.append((product_name, xml_content))

            if is_solution:
                logging.info(f"Scoring '{product_name}':")
                show_correct_options(xml_content)

        return products

    def latex_parts(self, is_solution):
        products = []
        for name, xml_content in self.xml_parts(is_solution):
            latex_content = generate_latex_view(self.exam_path, xml_content)

            product_name = name + '.tex'
            products.append(product_name)

            with open(product_name, 'wt') as fd:
                fd.write(str(latex_content))

            if os.path.exists(LAST_TEX):
                os.remove(LAST_TEX)

            os.symlink(product_name, LAST_TEX)

        return products


def latex_compile_files(filenames):
    products = []
    for fname in filenames:
        command = f'MAIN={fname} make -f /usr/include/arco/latex.mk'
        try:
            subprocess.check_output(
                command, stderr=subprocess.STDOUT, shell=True,
                universal_newlines=True)
            pdf = fname.replace('.tex', '.pdf')
            logging.info(f"updated '{pdf}'")
            products.append(pdf)

        except subprocess.CalledProcessError as e:
            logging.error('latex compile')
            logging.error(e.output)

    return products


def show_correct_options(xml_content):
    def question_solution(q):
        # print('   ', n, '  -', q.find('p').text)
        if not q.xpath('count(item)'):
            return '-'

        letters = ''
        for item in q.xpath('item[@value]'):
            pos = item.xpath('count(preceding-sibling::item)')
            letters += string.ascii_uppercase[int(pos)]

        if not letters:
            letters = '-'

        return letters

    retval = []

    root = xml_content.getroot()
    for q in root.xpath('//exam_view//question'):
        if not q.xpath('count(subquestion)'):
            retval.append(question_solution(q))
            continue

        for q in q.xpath('subquestion'):
            retval.append(question_solution(q))

    # for i, s in enumerate(retval):
    #     print(i+1, s)

    indexes = ','.join(str(n) for n in range(1, len(retval)+1))

    print('question,' + indexes)
    print('solution,' + ','.join(retval))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '-s', '--solution', action='store_true',
                        help='Generate solved exam')
    parser.add_argument('-c', '--clean', action='store_true',
                        help='remove generated files')
    parser.add_argument('exam', nargs='?',
                        help='your-file.exam.xml')
    parser.add_argument('-o', '--open', action='store_true',
                        help='open generated file with this program')
    parser.add_argument('-n', '--nup', action='store_true',
                        help='Generate 2 pages per sheet version')
    parser.add_argument('-p', '--ps', action='store_true',
                        help='Convert to postscript, then to pdf')

    config = parser.parse_args()

    if config.clean:
        logging.info("Cleaning previously generated files")
        shell_run('rm -fv *.tex *.aux *.log *.pdf *.out *~ *.temp.xml 2> /dev/null')

        if not config.exam:
            return 0

    if not config.exam:
        parser.print_help()
        return 1

    if not os.path.exists(config.exam):
        logging.error("ERROR: Not found '%s'" % config.exam)
        return 1

    exam = Exam(config.exam)
    tex_statements = exam.latex_parts(False)
    pdf_statements = latex_compile_files(tex_statements)

    tex_solutions = []
    pdf_solutions = []
    if config.solution:
        tex_solutions = exam.latex_parts(True)
        pdf_solutions = latex_compile_files(tex_solutions)

    if config.nup:
        for pdf in pdf_statements:
            logging.info(f'generating 2 pages per sheet version of {pdf}')
            shell_run(f'pdfnup {pdf} --nup 2x1 --outfile {pdf}')

    if config.open:
        pdf = pdf_solutions[-1] if pdf_solutions else pdf_statements[-1]
        os.system(f'xdg-open {pdf} &')


if __name__ == '__main__':
    main()
