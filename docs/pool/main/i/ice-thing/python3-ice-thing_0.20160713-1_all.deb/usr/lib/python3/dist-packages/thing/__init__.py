#!/usr/bin/python
# -*- coding: utf-8; mode: python -*-

# RESTRICTIONS:
# - Seq len limit:             2^16
# - String and byteseq limite: 2^8


import struct
import collections


#  FIXME: migrate to py3: from commodity.path import resolve_path
import os


def pbytes(s):
    return [ord(x) for x in s]


def resolve_path(fname, paths, find_all=False):
    '''
    Search 'fname' in the given paths and return the first full path
    that has the file. If 'find_all' is True it returns all matching paths.
    It always returns a list.

    >>> resolve_path('config', ['/home/user/brook', '/etc/brook'])
    ['/etc/brook/config']
    '''
    retval = []
    for p in paths:
        path = os.path.join(p, fname)
        if os.path.exists(path):
            if not find_all:
                return [path]

            retval.append(path)

    return retval


slice_file = resolve_path('thing.ice', ['.', '/usr/share/slice/thing'])[0]

import Ice
Ice.loadSlice(slice_file)
import ThingSlice as Thing
from ThingSlice import TypeCode


def Thing__repr__(self):
    return "<Thing tc:{} value:{}>".format(self.tc, repr(self.value))

Thing.T.__repr__ = Thing__repr__

TCinfo = collections.namedtuple('TCinfo', ['code', 'size'])


casters = {
    TypeCode.boolT:     TCinfo('<?', 1),
    TypeCode.byteT:     TCinfo('<B', 1),
    TypeCode.shortT:    TCinfo('<h', 2),
    TypeCode.intT:      TCinfo('<i', 4),
    TypeCode.longT:     TCinfo('<q', 8),
    TypeCode.floatT:    TCinfo('<f', 4),
    TypeCode.doubleT:   TCinfo('<d', 8),
    TypeCode.byteSeqT:  TCinfo('<s', 0),
    TypeCode.stringT:   TCinfo('<s', 0),
}


class Stream(object):
    def __init__(self, data):
        self.data = data
        self.size = len(data)
        self.it = 0

    def read_tc(self, increment=True):
        assert self.it + 1 <= self.size

        tc = TypeCode.valueOf(struct.unpack('B', self.data[self.it])[0])
        if increment:
            self.it += 1
        return tc

    def read_nitems(self, increment=True):
        assert self.it + 1 <= self.size

        nitems = struct.unpack('B', self.data[self.it])[0]
        if increment:
            self.it += 1
        return nitems

    def read_as(self, tc):
        assert tc in casters

        info = casters[tc]
        size = info.size
        if size == 0:
            size = self.read_nitems()

        assert self.it + size <= self.size

        value = self.data[self.it:self.it + size]
        if tc != TypeCode.stringT:
            value = struct.unpack(info.code, value)[0]

        self.it += size
        return value

    def read_string(self):
        return self.read_as(TypeCode.stringT)


def unpack_byteseq(data):
    stream = Stream(data)
    return unpack_stream(stream)


def unpack_stream(stream):
    tc = stream.read_tc()

    if tc == TypeCode.thingSeqT:
        return unpack_sequence(stream)
    elif tc == TypeCode.thingDictT:
        return unpack_dictionary(stream)

    return stream.read_as(tc)


def unpack_sequence(stream):
    retval = []
    nitems = stream.read_nitems()
    for i in range(nitems):
        value = unpack_stream(stream)
        retval.append(value)
    return retval


def unpack_dictionary(stream):
    retval = {}
    nitems = stream.read_nitems()
    for i in range(nitems):
        key = stream.read_string()
        value = unpack_stream(stream)
        retval[key] = value
    return retval


def unpack(t):
    """Converts from Thing.T to ThingTuple objects, containing basic Python types"""
    assert isinstance(t, Thing.T)

    s = Stream(t.value)

    if t.tc == TypeCode.thingSeqT:
        return unpack_sequence(s)
    elif t.tc == TypeCode.thingDictT:
        return unpack_dictionary(s)

    return s.read_as(t.tc)


# -- packers

def _to_thing(tc, value):
    return Thing.T(tc, struct.pack(casters[tc].code, value))


def from_bool(value):
    return _to_thing(TypeCode.boolT, bool(value))


def from_byte(value):
    return _to_thing(TypeCode.byteT, int(value))


def from_short(value):
    return _to_thing(TypeCode.shortT, int(value))


def from_int(value):
    return _to_thing(TypeCode.intT, int(value))


def from_long(value):
    return _to_thing(TypeCode.longT, int(value))


def from_float(value):
    return _to_thing(TypeCode.floatT, float(value))


def from_double(value):
    return _to_thing(TypeCode.doubleT, float(value))


def from_string(value):
    size = struct.pack('<B', len(value))  # FIXE: ice-size
    return Thing.T(TypeCode.stringT, size + value)

from_byteseq = from_string


def _pack_thing_seq(seq):
    "create thing from a sequence of things"

    seq = list(seq)
    stream = struct.pack('<B', len(seq))
    for t in seq:
        stream += struct.pack('<B', t.tc.value)
        stream += t.value

    return Thing.T(TypeCode.thingSeqT, stream)


def from_bool_seq(seq):
    return _pack_thing_seq(from_bool(x) for x in seq)


def from_short_seq(seq):
    return _pack_thing_seq(from_short(x) for x in seq)


def from_int_seq(seq):
    return _pack_thing_seq(from_int(x) for x in seq)


def from_long_seq(seq):
    return _pack_thing_seq(from_long(x) for x in seq)


def from_float_seq(seq):
    return _pack_thing_seq(from_float(x) for x in seq)


def from_double_seq(seq):
    return _pack_thing_seq(from_double(x) for x in seq)


def from_string_seq(seq):
    return _pack_thing_seq(from_string(x) for x in seq)


def from_dict(d):
    byteseq = struct.pack('<B', len(d))
    for k, v in list(d.items()):
        if type(k) is str:
            k = k.encode("utf-8")
        byteseq += struct.pack('<B', len(k))
        byteseq += k

        v = from_(v)

        byteseq += struct.pack('<B', v.tc.value)
        v = v.value
        if type(v) is str:
            v = v.encode("utf-8")
        byteseq += v

    return Thing.T(TypeCode.thingDictT, byteseq)


def _coerce_int_type(val):
    if 0 < val < 256:
        return from_byte(val)

    if -2 ** 15 < val < (2 ** 15) - 1:
        return from_short(val)

    if -2 ** 31 < val < (2 ** 31) - 1:
        return from_int(val)

    if -2 ** 63 < val < (2 ** 63) - 1:
        return from_long(val)


def _coerce_float_type(val):
    if 1.18e-38 <= abs(val) <= 3.4e38:
        return from_float(val)

    return from_double(val)


def from_seq_(val):
    if isinstance(val, Thing.T):
        return val

    if not isinstance(val, (tuple, list)):
        raise ValueError("Value {} of type {} is not a list".format(val, type(val)))

    things = []
    for i in val:
        things.append(from_(i))

    return _pack_thing_seq(things)


coercers = {
    bool: from_bool,
    int: _coerce_int_type,
    float: _coerce_float_type,
    str: from_string,
    str: from_string,
    list: from_seq_,
    dict: from_dict,
}


def from_(val):
    if isinstance(val, Thing.T):
        return val

    try:
        return coercers[type(val)](val)
    except KeyError:
        raise KeyError("Value {} of type {} can not be coerced to Thing.T".format(val, type(val)))
