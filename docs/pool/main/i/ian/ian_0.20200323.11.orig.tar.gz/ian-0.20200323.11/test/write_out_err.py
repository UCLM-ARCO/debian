#!/usr/bin/python -u
# -*- coding: utf-8; mode: python -*-

import sys
sys.stdout.write("stdout-write\n")
sys.stderr.write("stderr-write\n")
