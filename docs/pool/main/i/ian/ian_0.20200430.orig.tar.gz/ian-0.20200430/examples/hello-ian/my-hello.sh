#!/bin/bash --
# -*- coding: utf-8; mode: shell-script; tab-width: 4 -*-

echo "hello world from my very first debian package"
