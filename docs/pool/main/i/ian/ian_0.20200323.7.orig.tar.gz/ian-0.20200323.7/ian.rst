===
ian
===

---------------
ian description
---------------

:Author: David Villa Alises
:date:   2015-10-02
:Manual section: 1

SYNOPSIS
========

``ian`` [options]

This manual page documents briefly the ``ian`` command.

This manual page was written for the Debian(TM) distribution because
the original program does not have a manual page.

See https://bitbucket.org/DavidVilla/ian/src/tip/README.rst


COPYRIGHT
=========

Copyright © 2012-2016 David Villa Alises

This manual page was written for the Debian system (and may be used by
others).

Permission is granted to copy, distribute and/or modify this document
under the terms of the GNU General Public License, Version 2 or (at
your option) any later version published by the Free Software
Foundation.

On Debian systems, the complete text of the GNU General Public License
can be found in /usr/share/common-licenses/GPL.
