0.20200908
==========

* DEBREPO_URL and DEBREPO_LOCAL_DIR are now same variable: DEBPOOL


0.20140321
==========

* ian-debvars-luser command

0.20130621
==========

* ian commands as symbolic links

* ian aliases: ian-cbi

0.20121210
==========

* _ian-assure-builddeps

0.20120913
==========

* ian-help-variable-examples exit fixed.

0.20120910
==========

* ian: ian-version-to-pysetup
* ian: orig is not build if exists

0.20120905
==========

* ian: better _ian-uses-quilt

0.20120903
==========

* typo in (sc-)retcode2bool

0.20120605
==========

* ian: ignore whole commented debian/watch

0.20120601
==========

* common: arco-step-trap/arco-clear/trap functions
* common: logging colors
* ian: refactoring
* ian: get-orig-source sample (need test)
* ian: remove .diff.gz on ian-clean
* ian: ian-orig does not remove previous orig
* ian: DEBREPO_URL replaces DEBREPOACCOUNT and DEBREPOPATH env variables
* ian: DEBSIGN_KEYID replaces GPGKEYID
* ian: [NEW] ian-new-release-date-version
* ian: [NEW] _ian-build-dir
* ian: [NEW] _ian-orig-dir
* ian: [NEW] _ian-quilt-pop




.. Local Variables:
..  mode: rest
..  coding: utf-8
..  mode: flyspell
..  ispell-local-dictionary: "american"
.. End:
