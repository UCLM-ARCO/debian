# -*- mode: sh; coding: utf-8 -*-

BASE=$(cd ../.. && pwd)

export PYTHONPATH=$BASE

