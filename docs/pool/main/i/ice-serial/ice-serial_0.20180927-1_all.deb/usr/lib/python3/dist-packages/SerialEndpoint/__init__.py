# -*- mode: python3; coding: utf-8 -*-

import uuid
import pyendpoint as pe
import socket
import errno
import logging
import Ice


pe.log.activated = False
ICE_SERIAL_TYPE = 32


def show_trace(fn):
    def deco(*args, **kwargs):
        if pe.log.activated:
            # try:
            #     c = sys._getframe(1).f_code
            #     print("PYTHON: {}:{} {}".format(c.co_filename, c.co_firstlineno, c.co_name))
            # except ValueError:
            #     print " - No enough info for stack trace: ", fn.__name__
            print(fn.__name__)

        return fn(*args, **kwargs)
    return deco


class EndpointInfo:
    @show_trace
    def __init__(self, strEndpoint):
        self.host = "127.0.0.1"
        self.port = 1793

        fields = strEndpoint.split()

        try:
            i = fields.index("-h")
            if len(fields) > i:
                self.host = fields[i + 1]
        except ValueError:
            pass

        try:
            i = fields.index("-p")
            if len(fields) > i:
                try:
                    self.port = int(fields[i + 1])
                except ValueError:
                    raise Ice.EndpointParseException(strEndpoint)
        except ValueError:
            pass

    @show_trace
    def __del__(self):
        pass

    @show_trace
    def __str__(self):
        return " -h {} -p {}".format(self.host, self.port)


class EndpointFactoryI(pe.EndpointFactoryI):
    @show_trace
    def __init__(self, communicator):
        pe.EndpointFactoryI.__init__(self, communicator)
        self._type = ICE_SERIAL_TYPE
        self._protocol = "serial"

    @show_trace
    def __del__(self):
        pass

    @show_trace
    def create(self):
        return EndpointI(self._communicator, self._protocol)

    @show_trace
    def read(self, stream):
        # NOTE: stream does not contain encapsulation
        host = stream.readString()

        # port = stream.readShort()
        # FIXME: there is not readShort, so...
        port = ord(stream.readByte()) << 8
        port += ord(stream.readByte())

        strEndpoint = "-h {} -p {}".format(host, port)
        endp = self.create()
        endp.initWithOptions(strEndpoint.split(), False)
        return endp


class EndpointI(pe.EndpointI):
    @show_trace
    def __init__(self, communicator, protocol):
        pe.EndpointI.__init__(self, communicator, protocol)
        self._info = None
        self._type = ICE_SERIAL_TYPE

    @show_trace
    def __del__(self):
        pass

    @show_trace
    def initWithOptions(self, args, oaEndpoint):
        self._info = EndpointInfo(" ".join(args))
        self._oaEndpoint = oaEndpoint

    @show_trace
    def options(self):
        return str(self._info)

    @show_trace
    def datagram(self):
        return True

    @show_trace
    def type(self):
        return self._type

    # required by IceGrid
    @show_trace
    def streamWrite(self, stream):
        stream.startWriteEncaps()
        stream.writeString(self._info.host)

        # stream.writeShort(self._info.port)
        # FIXME: there is no writeShort, so...
        stream.writeByte((self._info.port >> 8) & 0xff)
        stream.writeByte(self._info.port & 0xff)

        stream.endWriteEncaps()

    @show_trace
    def transceiver(self):
        return ServiceTransceiverI(self._communicator, self._protocol, self._info)

    @show_trace
    def endpoint(self, trans):
        args = str(self._info).split()
        endp = EndpointI(self._communicator, self._protocol)
        endp.initWithOptions(args, self._oaEndpoint)
        return endp

    @show_trace
    def equivalent(self, other):
        # eq = (
        #     self._type == other._type and
        #     self._info.host == other._info.host and
        #     self._info.port == other._info.port
        # )

        # FIXME: this forces to create a new instance. Is it neccesary?
        return False

    @show_trace
    def connectors_async(self, callback):
        connectors = [ConnectorI(self._communicator, self._protocol, self._info)]
        callback.connectors(connectors)

    # required by IceGrid
    @show_trace
    def toString(self):
        return "{} {}".format(self._protocol, str(self._info)).strip()


class ConnectorI(pe.ConnectorI):
    @show_trace
    def __init__(self, communicator, protocol, info):
        pe.ConnectorI.__init__(self, communicator, protocol)
        self._info = info
        self._type = ICE_SERIAL_TYPE

    @show_trace
    def __del__(self):
        pass

    @show_trace
    def connect(self):
        return ServiceTransceiverI(self._communicator, self._protocol, self._info, True)

    @show_trace
    def toString(self):
        return str(self._info)


class ServiceTransceiverI(pe.TransceiverI):
    @show_trace
    def __init__(self, communicator, protocol, info, connect=False):
        pe.TransceiverI.__init__(self, communicator, protocol, connect)

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._fd = self._sock.fileno()
        self._incoming = not connect
        self._info = info
        self._connectionId = uuid.uuid4().hex

        self._connect_to_service()

        props = self._communicator.getProperties()
        try:
            self._maxSize = int(props.getPropertyWithDefault(
                "Ice.MessageSizeMax", "256"))
        except TypeError:
            logging.error("invalid property value for Ice.MessageSizeMax!")
            logging.error(" - using default: 256")
            self._maxSize = 256

    def _connect_to_service(self):
        try:
            self._sock.connect((self._info.host, self._info.port))
        except socket.error as e:
            if e.errno == errno.ECONNREFUSED:
                raise Ice.ConnectionRefusedException(e.errno)
            raise e

    @show_trace
    def __del__(self):
        pass

    @show_trace
    def bind(self):
        pass

    # NOTE: this is needed by Ice.Admin object adapter, used in IceGrid
    @show_trace
    def getInfo(self):
        adapterName = ""
        return pe.ConnectionInfo(
            self._incoming, adapterName, self._connectionId)

    @show_trace
    def getMaxPaquetSize(self):
        return self._maxSize

    @show_trace
    def toString(self):
        return "{} {}".format(self._protocol, str(self._info)).strip()

    @show_trace
    def toDetailedString(self):
        return self.toString()

    @show_trace
    def write(self, buff):
        self._sock.sendall(buff)
        return len(buff)

    @show_trace
    def read(self, buff):
        size = self._sock.recv_into(buff, len(buff))

        # client is disconnected
        if size == 0:
            logging.error("tcp socket is closed!")
            self._sock.close()

        return True, size

    @show_trace
    def close(self):
        self._sock.close()


# class DeviceTransceiverI(pe.TransceiverI):
#     @show_trace
#     def __init__(self, communicator, protocol, info, connect=False):
#         pe.TransceiverI.__init__(self, communicator, protocol, connect)

#         self._path = communicator.getProperties().getProperty("SerialEndpoint.Device")
#         if not self._path:
#             raise ValueError("Invalid endpoint: SerialEndpoint.Device not defined")

#         if not os.path.exists(self._path):
#             raise ValueError("Invalid endpoint: device '{}' does not exist".format(self._path))

#         self._device = serial.Serial(self._path, 115200)
#         self._fd = self._device.fileno()

#         self._incoming = not connect
#         self._info = info
#         self._connectionId = uuid.uuid4().get_hex()

#     @show_trace
#     def __del__(self):
#         pass

#     @show_trace
#     def bind(self):
#         pass

#     # NOTE: this is needed by Ice.Admin object adapter, used in IceGrid
#     @show_trace
#     def getInfo(self):
#         adapterName = ""
#         return pe.ConnectionInfo(self._incoming, adapterName, self._connectionId)

#     @show_trace
#     def toString(self):
#         return "{}{}".format(self._protocol, str(self._info)).strip()

#     @show_trace
#     def toDetailedString(self):
#         return self.toString()

#     @show_trace
#     def write(self, buff):
#         return self._device.write(buff)

#     @show_trace
#     def read(self, buff):
#         message = self.read_message()
#         buff[:len(message)] = message[:]
#         return True, len(message)

#     @show_trace
#     def close(self):
#         os.close(self._fd)

#     def read_message(self):
#         data = ""
#         while True:
#             c = self._device.read()
#             data += c
#             if len(data) < 14:
#                 continue

#             header = "IceP\1\0\1"
#             if data.startswith(header):
#                 break

#             data = data[1:]

#         size = ord(data[10])
#         size += ord(data[11]) << 8
#         size += ord(data[11]) << 16
#         size += ord(data[11]) << 24

#         data += self._device.read(size - 14)
#         return data
