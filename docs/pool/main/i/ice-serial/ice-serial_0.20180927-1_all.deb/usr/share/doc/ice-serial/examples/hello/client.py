#!/usr/bin/python3 -u
# -*- mode: python; coding: utf-8 -*-

import sys
import Ice

Ice.loadSlice("hello.ice")
import Example  # noqa


class Client(Ice.Application):
    def run(self, args):
        if len(args) < 2:
            return self.usage()

        ic = self.communicator()
        server = ic.stringToProxy(args[1])
        server = server.ice_encodingVersion(Ice.Encoding_1_0)
        server = Example.HelloPrx.uncheckedCast(server)
        print(server)

        server.sayHello()
        print("Done.")

    def usage(self):
        print("USAGE: {0} <proxy> [config]".format(sys.argv[0]))


if __name__ == '__main__':
    config = "config"
    if len(sys.argv) > 2:
        config = sys.argv[2]

    Client().main(sys.argv, config)
