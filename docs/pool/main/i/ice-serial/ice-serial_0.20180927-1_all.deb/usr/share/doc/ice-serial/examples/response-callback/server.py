#!/usr/bin/python -u
# -*- mode: python; coding: utf-8 -*-

import sys
import Ice

Ice.loadSlice("hello.ice")
import Example


class HelloI(Example.Hello):
    def sayHello(self, cb, current):
        print("cb received: " + str(cb))
        cb.hello()

        # print("Hello!")
        # sys.stdout.flush()
        # current.adapter.getCommunicator().shutdown()


class Server(Ice.Application):
    def run(self, args):
        ic = self.communicator()
        adapter = ic.createObjectAdapterWithEndpoints(
            "Adapter", "serial -h 127.0.0.1 -p 1793")
        adapter.activate()

        oid = ic.stringToIdentity("Server")
        proxy = adapter.add(HelloI(), oid).ice_datagram()

        print "Proxy ready: '{0}'".format(proxy)
        self.shutdownOnInterrupt()
        ic.waitForShutdown()


if __name__ == '__main__':
    config = "config"
    if len(sys.argv) > 1:
        config = sys.argv[1]

    Server().main(sys.argv, config)
