#!/usr/bin/python -u
# -*- mode: python; coding: utf-8 -*-

import sys
import Ice

Ice.loadSlice("hello.ice")
import Example


class HelloCbI(Example.HelloCb):
    def hello(self, current):
        print("Hello said!")
        # sys.stdout.flush()
        # current.adapter.getCommunicator().shutdown()


class Client(Ice.Application):
    def run(self, args):
        if len(args) < 2:
            return self.usage()

        ic = self.communicator()

        adapter = ic.createObjectAdapterWithEndpoints("Adapter", "serial")
        adapter.activate()
        cb_proxy = adapter.addWithUUID(HelloCbI()).ice_datagram()
        cb_proxy = Example.HelloCbPrx.uncheckedCast(cb_proxy)

        server = ic.stringToProxy(args[1])
        server = server.ice_datagram()
        server = Example.HelloPrx.uncheckedCast(server)

        server.sayHello(cb_proxy)
        # server.sayHello(None)

        print("'sayHello' sent, waiting response...")
        self.shutdownOnInterrupt()
        ic.waitForShutdown()

    def usage(self):
        print "USAGE: {0} <proxy> [config]".format(sys.argv[0])


if __name__ == '__main__':
    config = "config"
    if len(sys.argv) > 2:
        config = sys.argv[2]

    Client().main(sys.argv, config)
