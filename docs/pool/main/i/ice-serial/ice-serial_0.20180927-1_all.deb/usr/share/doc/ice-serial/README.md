Description
===========

This is an endpoint for ZeroC Ice using a serial port (usually
``/dev/ttyS0`` or ``/dev/ttyUSB0``). The endpoint type is `serial`,
and it has a single parameter, `-p`, which is the path of the
device. Thus, a stringfied proxy should look like the following:

    Light -e 1.0 -d:fifo -p /dev/ttyUSB0

See `example` dir for an example of its usage and configuration
sample files.
