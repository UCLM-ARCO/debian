# -*- mode: python; coding: utf-8 -*-

# fake pyserial library for testing purposes

import socket


class Serial(object):
    def __init__(self, path, baudrate, *args, **kwargs):
        print("s: serial")

        port = 5588
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        try:
            s.connect(("127.0.0.1", port))
            self._device = s
        except IOError:
            print("Creating conection point...")
            s.bind(("127.0.0.1", port))
            s.listen(10)
            conn, addr = s.accept()
            self._device = conn

    def __del__(self):
        try:
            self._device.close()
        except IOError:
            # this FD may be closed by Ice
            pass

    def fileno(self):
        print("s: fileno")
        return self._device.fileno()

    def write(self, data):
        print("s: write")

        print("s: - size: " + str(len(data)))
        print("s: - device: " + str(self._device))
        self._device.send(data)
        return len(data)

    def readinto(self, buffer):
        print("s: readinto")
        try:
            data = self._device.read(len(buffer))
        except OSError:
            return 0

        buffer[:len(data)] = data[:]
        return len(data)

    def read(self, size=1):
        print("s: read")
        try:
            data = self._device.recv(size)
            if not data:
                self._device.close()

            print ("s: - read {} bytes".format(len(data)))
            from hexdump import hexdump
            hexdump(data)
            return data
        except OSError:
            print ("s: - os error)")
            return ""

    def flush(self):
        print("s: flush")
