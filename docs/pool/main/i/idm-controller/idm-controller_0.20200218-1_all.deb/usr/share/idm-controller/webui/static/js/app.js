// -*- mode: js; coding: utf-8; truncate-lines: true -*-

_ = console.info.bind(console);

var app = angular.module(
    'ControllerUI', ['ngRoute', 'ngAnimate'], function($interpolateProvider) {
        $interpolateProvider.startSymbol('[[');
        $interpolateProvider.endSymbol(']]');
    }
);

app.controller("MainCtrl", function($scope, $timeout) {
    // setup basic scene
    $scope.paper = setup_scene($scope);
    $scope.graph = $scope.paper.model;
    $scope.routers = {};
    $scope.enable_edit = false;
    $scope.has_changes = false;

    $scope.on_deploy = function() {
	var model = JSON.stringify($scope.graph.toJSON());
	$.ajax({
	    type: "POST",
	    url: "/deploy",
	    data: model,
	    contentType: "application/json",
	    success: function() {
		$scope.has_changes = false;
		$scope.$apply();
	    },
	    failure: function(error) {
		console.error("deploy failed: ", error);
	    }
	});
    };

    $scope.on_export = function() {
	window.location = "/export";
    };

    $scope.on_import = function() {
	if (!window.File || !window.FileReader) {
	    alertify.delay(5000).error(
		'The File APIs are not fully supported in this browser.');
	    return;
	}

	var input = $('<input type="file" name="import-path" accept=".json">');
	input.on('change', function(evt) {
	    var reader = new FileReader();
	    reader.onerror = function(error) {
		console.error(reader.error);
		alertify.delay(5000).error("Error: could not load file!");
	    }
	    reader.onload = function(file) {
		try {
		    var network = JSON.parse(reader.result);
		    update_whole_network($scope, network);
		}
		catch (error) {
		    console.error(error);
		    alertify.delay(5000).error("Error: invalid file format!");
		}
	    }
	    reader.readAsText(evt.target.files[0])
	});
	input.click();
    };

    $scope.$watch("enable_edit", function(value) {
	var style = ".link-tools .tool-remove, " +
	    ".marker-vertex, .marker-vertex-remove, .marker-vertex-remove-area, " +
	    ".connection-wrap, .marker-arrowheads { " +
	    "    visibility: " + (value ? "auto" : "hidden")  + "; " +
	    "} ";
	set_style(style);
    });

    // load initial network
    $.ajax({
        url: "/network",
        success: function(data) {
            update_whole_network($scope, data);
	    $scope.has_changes = false;
	    $scope.$apply();

	    $scope.graph.on('change', function() {
		$timeout(function() {
		    $scope.has_changes = true;
		}, 0);
	    });
        },
    });

    // listen for incoming updates
    new EventSource("/updates").onmessage = function(event) {
        update_whole_network($scope, JSON.parse(event.data));
    }
});

function update_whole_network($scope, network) {
    update_router_nodes($scope, network);
    update_router_links($scope, network);
}

function update_router_nodes($scope, network) {
    for (var router_addr in network) {
        var router = network[router_addr];
        var node = $scope.routers[router_addr];

        if (node == undefined) {
	    node = $scope.graph.add_router(router);
            $scope.routers[router_addr] = node;
        }

        node.set_managed(router.managed);
	node.set_position(router.ui_options.position);
	node.set_name(router.ui_options.name);
    }
}

function update_router_links($scope, network) {
    for (var router_addr in network) {
        var router = network[router_addr];
        var node = $scope.routers[router_addr];

        for (var net_addr in router.flows) {
            var flow = router.flows[net_addr];
            var dst_node = $scope.routers[flow.next_hop];
            if (dst_node == undefined) {
                console.warn("there is a referece to an unknown router: " + flow.next_hop);
                continue;
            }
            node.connect_to(flow.net, flow.netmask, dst_node, flow.ui_options);
        }
    }
}

// Canvas things ------------------------------------------------------------

joint.shapes.idm = {};
joint.shapes.idm.RouterShape = joint.shapes.basic.Generic.extend({
    markup: '<g class="rotatable"><g class="scalable"><rect rx="8" ry="8"/>' +
	'<circle class="left-out-handler" fill="green" fill-opacity="0.4" r="5" cx="0" cy="30" />' +
	'<circle class="left-in-handler" fill="red" fill-opacity="0.4" r="5" cx="0" cy="50" />' +
	'<circle class="right-in-handler" fill="red" fill-opacity="0.4" r="5" cx="80" cy="30" />' +
	'<circle class="right-out-handler" fill="green" fill-opacity="0.4" r="5" cx="80" cy="50" />' +
	'<circle class="top-in-handler" fill="red" fill-opacity="0.4" r="5" cx="30" cy="0" />' +
	'<circle class="top-out-handler" fill="green" fill-opacity="0.4" r="5" cx="50" cy="0" />' +
	'<circle class="bottom-out-handler" fill="green" fill-opacity="0.4" r="5" cx="30" cy="80" />' +
	'<circle class="bottom-in-handler" fill="red" fill-opacity="0.4" r="5" cx="50" cy="80" />' +
	'</g></g>'+
	'<text class="router-name"/>'+
	'<text class="router-address"/>',

    defaults: joint.util.deepSupplement({
        type: 'idm.RouterShape',
        attrs: {
	    'rect': {
		fill: 'white', stroke: 'black',
		'follow-scale': true, width: 80, height: 80
	    },

	    'text.router-address': {
		fill: "#1565C0", 'font-size': 14, 'ref-x': .5, 'ref-dy': 20,
		ref: 'g.rotatable', 'y-alignment': 'bottom', 'x-alignment': 'middle'
	    },

	    'text.router-name': {
		fill: "black", 'font-size': 14, 'font-weight': 'bold', 'ref-x': .5, 'ref-dy': 37,
		ref: 'g.rotatable', 'y-alignment': 'bottom', 'x-alignment': 'middle'
	    },

	    '.left-in-handler': {magnet: 'passive', type: "input"},
	    '.left-out-handler': {magnet: true, type: "output"},
	    '.top-in-handler': {magnet: 'passive', type: "input"},
	    '.top-out-handler': {magnet: true, type: "output"},
	    '.right-in-handler': {magnet: 'passive', type: "input"},
	    '.right-out-handler': {magnet: true, type: "output"},
	    '.bottom-in-handler': {magnet: 'passive', type: "input"},
	    '.bottom-out-handler': {magnet: true, type: "output"},
        }
    }, joint.shapes.basic.Generic.prototype.defaults)
});

function set_style(css) {
    $("#custom-css").remove();
    $("<style id='custom-css'>" + css + "</style>").appendTo("head");
};

function create_link(net, netmask) {
    if (net === undefined)
	net = "0";
    if (netmask === undefined)
	netmask = "128";

    var link = new joint.shapes.devs.Link()
    link.set('connector', {name: 'smooth'});
    set_link_info(link, net, netmask);
    return link;
};

function set_link_info(link, net, netmask) {
    net = net.toString();
    netmask = netmask.toString();

    var color = ((net == "0" && netmask == "0") ? '#D84315' : '#888');
    link.attr({
	'.connection': {stroke: color, 'stroke-width': 1},
	'.marker-target': {stroke: color, fill: color, d: 'M 10 0 L 0 5 L 10 10 z'},
    });

    link.label(0, {
	position: 0.25,
	attrs: {
	    text: {text: net, fill: '#eee'},
	    rect: {fill: color },
	}
    });

    var cw = 7.78125;
    var addr_width = (10 - cw) + (net.length * cw);
    var mask_width = (10 - cw) + (netmask.length * cw);
    var x_offset = addr_width / 2 + mask_width / 2 + 2;
    link.label(1, {
    	position: {
	    distance: 0.25,
	    offset: {x: x_offset},
	},
    	attrs: {
    	    text: {text: netmask, fill: '#eee'},
    	    rect: {fill: "#216CC9"},
    	}
    });
    link.prop('matcher', {net: net, netmask: netmask});
};

function setup_scene($scope) {
    var canvas = $('#diagram-holder');
    var graph = new joint.dia.Graph;
    var paper = new joint.dia.Paper({
        el: canvas,
        model: graph,
        gridSize: 1,
        height: canvas.height(),
        width: canvas.width(),
        snapLinks: {radius: 25},
        defaultLink: function (s, el) { return create_link(); },

	linkView: joint.dia.LinkView.extend({
            pointerdblclick: function(evt, x, y) {
		var target = V(evt.target);

		// target is a connection, add vertex
		if (target.hasClass('connection') || target.hasClass('connection-wrap')) {
                    this.addVertex({ x: x, y: y });
		    return;
		}

		// target is a label, edit it
		if (V(target.node.parentElement).hasClass("label")) {
		    var link = this.model;
		    var net = link.label(0).attrs.text.text;
		    var netmask = link.label(1).attrs.text.text;
		    var value = net + "/" + netmask;

		    var bbox = target.bbox();
		    var elid = target.node.id + "_editor";
		    var el = $('<div id="' + elid + '">' + value + '</div>');
		    el.css({position: 'absolute', top: bbox.y + 50, left: bbox.x,
			    visibility: 'hidden'});
		    $('body').append(el);

    		    var ed = el.editable({
		     	type: 'text',
			title: "Matcher for this flow:",
			toggle: "manual",
			display: false,
			onblur: "submit",
			savenochange: true,
			success: function(response, newValue) {
			    var net = newValue.split("/")[0];
			    var netmask = newValue.split("/")[1];
			    var nm_i = parseInt(netmask);
			    if (!net || !netmask || isNaN(nm_i) || nm_i < 0 || nm_i > 128)
				alertify
				  .delay(5000)
				  .error("Invalid params for flow info, ignoring changes!")
			    else
				set_link_info(link, net, netmask);
			    ed.remove();
			},
		    });
		    el.editable('toggle');
		}
            }
	}),

	interactive: function(cellview) {
            if (cellview.model instanceof joint.dia.Link) {
		// disable some interactive functionality
		return {vertexAdd: false, labelMove: false};
            }
            return true;
	},

	validateConnection: function(cellViewS, magnetS, cellViewT, magnetT) {
	    if (magnetS && magnetS.getAttribute('type') === 'input')
		return false;
            if (cellViewS === cellViewT)
	     	return false;
            return magnetT && magnetT.getAttribute('type') === 'input';
	},
    });

    var win = $(window);
    var update_paper_size = function() {
	paper.setDimensions(win.width(), win.height());
    }
    update_paper_size();
    win.resize(update_paper_size);

    // remove dangling links, or links to itself
    paper.on('cell:pointerup', function(cv) {
	if (cv.model.isLink() &&
	    (! cv.sourceView || ! cv.targetView || cv.sourceView == cv.targetView))
	   cv.remove();
    });

    // update new links with dst address info
    paper.on('link:connect', function(link, event, view, magnet, type) {
	var target = link.targetView.model;
	var net = target.attr("address").text;
	set_link_info(link.model, net, "128");
    });

    // show router info popup
    paper.on('cell:pointerdblclick', function(cv, evt, x, y) {
	if (cv.model.attr('text.router-address') === undefined)
	    return;

	// currently InfoWin is shown, do nothing
	if (cv.model.attr('info-win'))
	    return;

	var box = $('#' + cv.el.id);
	var pos = box.position();
	var b = $('<a tabindex="0" style="position:absolute; visibility: hidden; top:' +
		  (pos.top + 40) + 'px; left:' + (pos.left + 30) +'px;">·</a>');
	$('body').append(b);

	var header = 'Router Information '+
	    '<button style="margin-left: 20px; margin-right: -5px" '+
	    '        class="close-popover btn btn-default btn-xs">'+
	    '  <i class="fa fa-times"></i></button>';

	var name = cv.model.attr('name');
	if (!name) name = "<i>&lt;not set&gt;</i>";
	else name = name.text;

	var status = cv.model.attr('managed').value;
	var addr_items = cv.model.attr('address-list').items;
	var other_address = "<br>";
	for (var i in addr_items)
	    other_address += '<i style="padding-left: 20px"> ' + addr_items[i] + '</i><br>';
	other_address = other_address.slice(0, -4);

	var body = '' +
	    'Name: <b>' + name + '</b><br>' +
	    "Main Address: " + cv.model.attr('address').text + '<br>' +
	    'Other Addresses: ' + other_address + '<br>' +
	    'Status: <span class="' + (status ? 'r-managed' : 'r-unmanaged') + '">' +
	    (status ? 'active' : 'unknown') + '</span>';

	var popOverSettings = {
	    placement: 'bottom',
	    html: true,
	    title: header,
	    content: body,
	};

	var win = b.popover(popOverSettings);
	win.popover('show');
	cv.model.attr({'info-win': {win: win, anchor: b}})

	// setup window close handler
	var po = $(win[0].nextSibling);
	po.find("button.close-popover").on("click", function() {
	    $(win).remove();
	    $(po).remove();
	    cv.model.attr({'info-win': null});
	});
    });

    graph.auto_layout = function() {
        joint.layout.DirectedGraph.layout(graph, {
            rankDir: "LR",
            marginX: 50, marginY: 30,
            nodeSep: 120, rankSep: 120,
        });
    };

    graph.connect = function(source, target, net, netmask, options) {
        var link = create_link(net, netmask);
        link.set('source', source);
        link.set('target', target);
	if (options && options.vertices)
	    link.set('vertices', options.vertices);

        link.addTo(graph).reparent();
        return link;
    };

    graph.add_router = function(info) {
        return new RouterNode(graph, info);
    };

    return paper;
}

RouterNode = function(graph, info) {
    this.graph = graph;
    this.info = info;
    this.links = [];

    var color_managed = "#555";
    var color_unmanaged = "#f00";

    this.atomic = new joint.shapes.idm.RouterShape({
	size: {width: 60, height: 60},
	attrs: {
	    rect: {fill: '#fff', stroke: info.managed ? color_managed : color_unmanaged},
	    'text.router-address': {text: info.address},
	    address: {text: info.address},
	    'address-list': {items: info.address_list},
	    managed: {value: info.managed},
	}
    });

    // update InfoWindow position
    this.atomic.on('change:position', function(evt, newPos) {
	var info = this.attr('info-win');
	if (!info)
	    return;

	var po = $(info.win[0].nextSibling);
	po.css({top: newPos.y + 105, left: newPos.x - 68});
	info.anchor.css({top: newPos.y + 85, left: newPos.x + 24});
    });

    graph.addCell(this.atomic);

    // class methods --------------------------------------------------
    RouterNode.prototype.set_managed = function(managed) {
        this.atomic.attr({'rect': {stroke: managed ? color_managed : color_unmanaged}});
    };

    RouterNode.prototype.connect_to = function(net, netmask, dst, ui_options) {
        if (this.links[net] !== undefined)
            return;

	var src = {id: this.atomic.id, selector: ui_options.source_selector || '.right-out-handler'};
	var dst = {id: dst.atomic.id, selector: ui_options.target_selector || '.right-in-handler'};
        var link = this.graph.connect(src, dst, net, netmask, ui_options);
        this.links[net] = link;
    };

    RouterNode.prototype.set_position = function(pos) {
	if (pos == undefined)
	    return;
	this.atomic.position(pos[0], pos[1]);
    };

    RouterNode.prototype.set_name = function(name) {
	if (!name)
	    return;
	this.atomic.attr({'text.router-name': {text: name}});  // used in HTML layout
	this.atomic.attr({'name': {text: name}});              // used on export/deploy
    };
}
