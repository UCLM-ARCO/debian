# -*- mode: python; coding: utf-8 -*-

#
# Copyright (c) 2012-2016 Oscar Aceña. All rights reserved.
#
# This file is part of ice-remoteio
#
# ice-remoteio is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# ice-remoteio is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with ice-remoteio.  If not, see <http://www.gnu.org/licenses/>.
#

import sys
import os
import pyendpoint as pe
import Ice
from collections import deque

pwd = os.path.dirname(__file__)
sys.path.append(os.path.abspath(pwd))
import modules

slice_path = os.path.join(pwd, "../src/remoteio.ice")
if not os.path.exists(slice_path):
    slice_path = "/usr/share/slice/remoteio.ice"
Ice.loadSlice(slice_path)
import RemoteIO

# pe.log.activated = True

ICE_P2P_TYPE_NAME = "p2p"
ICE_P2P_TYPE = 14


class EndpointInfo(object):
    def __init__(self, output, input):
        pe.trace()

        self.module = ""
        self.args = {}
        self.output = output
        self.input = input

    def parseEndpoint(self, endp):
        pe.trace()

        error_msg = "Invalid endpoint format"
        fields = map(str.strip, endp.split())

        for i, f in enumerate(fields[:]):
            if f == "-m":
                assert (i + 1) < len(fields), error_msg
                self.module = fields[i + 1]
            else:
                if not f.startswith("-"):
                    continue

                assert (i + 1) < len(fields), error_msg
                self.args[f] = fields[i + 1]

    def copy(self):
        info = EndpointInfo(self.input, self.output)
        info.module = self.module
        info.args = self.args.copy()
        return info

    def __repr__(self):
        pe.trace()

        retval = ""
        if self.module:
            retval = " -m " + self.module

        for k, v in self.args.items():
            retval += " {} {}".format(k, v)
        return retval


class RemoteIOInput(RemoteIO.Output):
    def __init__(self):
        pe.trace()

        self.fd = -1
        self.messages = deque(maxlen=50)

    def setFD(self, fd):
        pe.trace()

        assert self.fd == -1, "Device already used"
        self.fd = fd

    def send(self, data, current):
        pe.trace()

        self.messages.appendleft(data)
        if self.fd != -1:
            os.write(self.fd, b"sync")


class EndpointFactoryI(pe.EndpointFactoryI):
    def __init__(self, communicator):
        pe.trace()

        pe.EndpointFactoryI.__init__(self, communicator)
        self._type = ICE_P2P_TYPE
        self._protocol = ICE_P2P_TYPE_NAME

        self._output = None
        self._input = None

    def create(self):
        pe.trace()

        if self._output is None:
            self._setupRemoteIO()

        info = EndpointInfo(self._output, self._input)
        return EndpointI(self._communicator, self._protocol, info)

    def _setupRemoteIO(self):
        pe.trace()

        self._output = self._communicator.propertyToProxy("RemoteIO.Device.Proxy")
        self._output = RemoteIO.IOPrx.checkedCast(self._output)
        self._adapter = self._communicator.createObjectAdapter("RemoteIO.Adapter")
        self._adapter.activate()

        self._input = RemoteIOInput()
        peer = self._adapter.addWithUUID(self._input)
        peer = RemoteIO.OutputPrx.uncheckedCast(peer)
        self._output.register(peer)


class EndpointI(pe.EndpointI):
    def __init__(self, communicator, protocol, info):
        pe.trace()
        pe.EndpointI.__init__(self, communicator, protocol)

        self._info = info
        self._type = ICE_P2P_TYPE

    def initWithOptions(self, args, oaEndpoint):
        self.oaEndpoint = oaEndpoint

        assert args[0] == "-m" and len(args) > 1, "Invalid endpoint '{}'".format(" ".join(args))
        self._info.module = args[1]

        if len(args) > 2:
            self._info.args = dict(zip(args[2::2], args[3::2]))

    def options(self):
        retval = " -m {}".format(self._info.module)
        for k, v in self._info.args.items():
            retval += " {} {}".format(k, v)
        return retval

    def datagram(self):
        return True

    # required by IceGrid
    def streamWrite(self, stream):
        pe.trace()

        stream.startWriteEncaps()

        info = self._info
        if isinstance(info, str):
            info = EndpointInfo(info, None, None)

        # module: string
        stream.writeString(info.module)

        # args: dict(string, string) [ size + pairs (key, value)]
        stream.writeByte(len(info.args))
        for k, v in info.args.items():
            stream.writeString(k)
            stream.writeString(v)

        stream.endWriteEncaps()

    def transceiver(self):
        pe.trace()
        return TransceiverI(self._communicator, self._protocol, self._info, False)

    def equivalent(self, other):
        """Return True if self and other are equivalent endpoints. Otherwise, return False."""

        if not hasattr(other._info, "module"):
            return False

        if self._type != other._type or self._info.module != other._info.module:
            return False

        if len(self._info.args) != len(other._info.args):
            return False

        for k, v in self._info.args.items():
            if other._info.args.get(k) != v:
                return False

        return True

    def endpoint(self, trans):
        pe.trace()

        info = self._info.copy()
        endp = EndpointI(self._communicator, self._protocol, info)
        args = ["-m", self._info.module]
        [args.extend(x) for x in self._info.args.items()]

        endp.initWithOptions(args, self.oaEndpoint)
        return endp

    def connectors_async(self, callback):
        pe.trace()

        connectors = [ConnectorI(self._communicator, self._protocol, self._info)]
        callback.connectors(connectors)

    # required by IceGrid (and for printing proxies)
    # def toString(self):
    #     pe.trace()

    #     info = self._info
    #     if isinstance(info, str):
    #         info = EndpointInfo(info, None, None)

    #     retval = "{} -m {}".format(self._protocol, info.module)
    #     for k, v in info.args.items():
    #         retval += " {} {}".format(k, v)
    #     return retval


class ConnectorI(pe.ConnectorI):
    def __init__(self, communicator, protocol, info):
        pe.trace()

        pe.ConnectorI.__init__(self, communicator, protocol)
        self._info = info
        self._type = ICE_P2P_TYPE

    def connect(self):
        pe.trace()
        return TransceiverI(self._communicator, self._protocol, self._info, True)

    def toString(self):
        pe.trace()
        return str(self._info)


class TransceiverI(pe.TransceiverI):
    def __init__(self, communicator, protocol, info, connect):
        pe.trace()

        pe.TransceiverI.__init__(self, communicator, protocol, connect)
        self._info = info
        self._output = info.output
        self._input = info.input

        self.incoming = not connect
        self.setupFD()
        self.setupRemoteIO()

    def setupFD(self):
        pe.trace()

        self._pipes = os.pipe()
        if self.incoming:
            self._input.setFD(self._pipes[1])

    def setupRemoteIO(self):
        pe.trace()

        self._p2p_modules = []
        if self._info.module == "rrp":
            self._p2p_modules.append(modules.RRP())

    def toString(self):
        pe.trace()
        return ICE_P2P_TYPE_NAME + " " + str(self._info)

    def getInfo(self):
        pe.trace()

        adapterName = ""
        connectionId = ""
        return pe.ConnectionInfo(self.incoming, adapterName, connectionId)

    def bind(self):
        pe.trace()

    def fd(self):
        pe.trace()
        return self._pipes[0]

    def write(self, buff):
        pe.trace()

        payload = bytes(buff)
        for m in reversed(self._p2p_modules):
            payload = m.marshall(self._info, payload)

        self._output.send(payload)
        return True

    def read(self, buff):
        pe.trace()

        os.read(self._pipes[0], 10)

        msg = self._input.messages.pop()
        for m in self._p2p_modules:
            msg = m.unmarshall(self._info, msg)
            if msg is None:
                return True, 0

        buff[:len(msg)] = msg[:]
        return True, len(msg)

    def close(self):
        pe.trace()
