# -*- mode: python; coding: utf-8 -*-

TYPE_DISCOVER = 0
TYPE_SYN = 1
TYPE_OK = 2
TYPE_TOKEN = 3
TYPE_REQUEST = 4
TYPE_RESPONSE = 5


class RRP(object):
    magic = b"RRP"

    def marshall(self, info, payload):
        source = b'\x00'
        destination = bytes([int(info.args['-a'])])
        type = bytes([TYPE_REQUEST])
        assert len(payload) <= 255, "Too big message, it must be less than 256 bytes"

        retval = self.magic + source + destination + type + bytes([len(payload)])
        retval += payload
        return retval

    def unmarshall(self, info, msg):
        error_msg = "Invalid message format"
        assert len(msg) >= 6, error_msg

        magic = msg[:3]
        assert magic == self.magic, error_msg

        myaddr = int(info.args['-a'])
        if not msg[4] in [255, myaddr]:
            return None

        type = msg[5]
        if type not in [TYPE_REQUEST, TYPE_RESPONSE]:
            return msg[6:]

        assert len(msg) >= 7, error_msg
        size = msg[6]
        assert len(msg) == (7 + size), error_msg
        return msg[7:]
