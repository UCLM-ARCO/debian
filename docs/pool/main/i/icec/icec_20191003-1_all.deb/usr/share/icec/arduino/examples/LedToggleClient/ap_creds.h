// -*- mode: c++; coding: utf-8 -*-

#define SSID "myWIFI"
#define KEY "myPassword"
