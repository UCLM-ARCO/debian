public: IceStorm and ISBidir are in a public network
private: ISBidir subscribers are in a private network, use Vagrant here to simulate it.
