// This is the Shapes call service module for MagicMirror2

var modname = "callservice";
var static = `/modules/${modname}`;

function tpApply(template, fields) {
   const names = Object.keys(fields);
   const vals = Object.values(fields);
   return new Function(...names, `return \`${template}\`;`)(...vals);
}

Module.register(modname, {

	getDom: async function() {
      let content = await fetch(`${static}/partials/content.html`);
		let wrapper = document.createElement("div");
      let template = await content.text();
      let context = {
         static: static
      };
      wrapper.innerHTML = tpApply(template, context);
      return wrapper;
   },

   getStyles: function() {
      return [
         this.file('css/animate.min.css'),
         this.file('css/mm2-style.css'),
         this.file('css/common.css')
      ];
   },

   getScripts: function() {
      return [
         this.file('js/jquery-3.5.1.min.js'),
         this.file('js/Ice-3.7.min.js'),
         this.file('js/call-service-iface.js'),
         this.file('js/call-service.js'),
         this.file('js/rfid-service-iface.js'),
         this.file('js/rfid-service.js'),
         this.file('js/app.js'),
      ];
   },

});

