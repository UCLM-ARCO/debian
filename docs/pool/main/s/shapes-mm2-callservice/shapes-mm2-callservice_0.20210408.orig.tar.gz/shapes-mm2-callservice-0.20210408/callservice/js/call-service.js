
class VideoRenderer {
   constructor() {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
         $('#cs-content')
            .empty()
            .append("<br><h2>Sorry, mediaDevices not supported here!</h2>");
         this.disabled = true;
         return;
      }

      this.devs = {};
   }

   async get_media_permissions() {
      await navigator.mediaDevices.getUserMedia({ audio: false, video: true },
         () => { // on ok
            this.disabled = false;
         },
         () => { // on error
            $('#cs-content')
               .empty()
               .append("<br><h2>Sorry, permission denied.</h2>");
            this.disabled = true;
         }
      );
   }

   async setup(devname) {
      if (this.devs[devname])
         return true;

      // NOTE: media devices will only work on 'localhost'
      // (or with a valid SSL cert), not 127.0.0.1 !!
      // https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
      let perms = await navigator.permissions.query({name: "camera"});
      if (perms.state == "prompt")
         await this.get_media_permissions();
      else if(perms.state == "denied")
         this.disabled = true;

      if (this.disabled)
         return false;

      _("Listing devices...");
      const devices = await navigator.mediaDevices.enumerateDevices();
      const video_devs = devices.filter(device => device.kind === 'videoinput');
      video_devs.forEach(dev => {
         _(`- device label: ${dev.label}, id: ${dev.deviceId}`);
         if (dev.label.startsWith("Telegram")) {
            this.devs[dev.label] = dev;
         }
      });

      return this.devs[devname] !== undefined;
   }

   async start(devpath) {
      if (this.disabled) {
         return;
      }

      var devname = {
         "/dev/video5": "Telegram-tpc1",
         "/dev/video6": "Telegram-tpc2"
      }[devpath];

      if (! await this.setup(devname)) {
         _("ERROR: there is no telegram device available!");
         return;
      }

      var dev = this.devs[devname];

      try {
         let video = $('video')[0];
         this.stream = await navigator.mediaDevices.getUserMedia(
            { video: { deviceId: { exact: dev.deviceId } } }
         );
         video.srcObject = this.stream;
         video.play();
      } catch (err) {
         _("ERROR: " + err);
         console.error(err);
      }

      _(`Video streaming started for ${dev.label} device`);
   }

   stop() {
      let video = $('video')[0];
      video.pause();
      video.srcObject = null;
      video.src = "";

      if (this.stream) {
         this.stream.getTracks().forEach(track => track.stop());
         this.stream = null;
      }

      const devices = navigator.mediaDevices.enumerateDevices();
      _("Video streaming stopped");
   }
}

class EventObserverI extends Shapes.CallService.EventObserver {
   constructor(renderer, manager) {
      super();
      this.renderer = renderer;
      this.manager = manager;
   }

   videoStopAndCloseRequest() {
      _("stopAndCloseRequest received");
      this.renderer.stop();
   }

   videoReady(device) {
      _(`videoReady received, device: ${device}`);
      plaza.notify("callReady");
      this.renderer.start(device);
   }

   dataRequest(fieldName) {
      _(`dataRequest received, field: ${fieldName}`);
      plaza.request(fieldName, (name, value) => {
         _(`providing requested field: ${fieldName} with ${value}`);
         this.manager.dataProvide(fieldName, value);
      });
   }

   notify(event) {
      _(`notify received, event: ${event}`);
      plaza.notify(event);
   }
}

class CallServiceClient {
   constructor(icecom, usessl=true) {
      this.ice = icecom;
      this.video_renderer = new VideoRenderer();

      var hostname = document.location.hostname || "127.0.0.1";
      var proto = "wss";
      var port = 2648;
      if (!usessl) {
         proto = "ws";
         port = 2649;
      }

      this.call_service = Shapes.CallService.ManagerPrx.uncheckedCast(
         this.ice.stringToProxy(`CallServiceManager -t:${proto} -h ${hostname} -p ${port}`)
      );
   }

   async setup() {
      // create adapter and register servant as callback
      this.adapter = await this.ice.createObjectAdapter("");
      const cbprx = Shapes.CallService.EventObserverPrx.uncheckedCast(
         this.adapter.addWithUUID(
            new EventObserverI(this.video_renderer, this.call_service))
      );

      var conn = this.call_service.ice_getCachedConnection()
      if (!conn) {
         await this.call_service.ice_ping();
         conn = this.call_service.ice_getCachedConnection();
      }
      conn.setAdapter(this.adapter);
      await this.call_service.setObserver(cbprx);
   }

   call_user(user) {
      _(`Calling to ${user.id}...`);
      this.call_service.callUser(user.id);
   }

   end_call() {
      _(`Ending current call...`);
      this.call_service.endCall();
   }

   async list_users() {
      return await this.call_service.listUsers();
   }

   async search_user(username) {
      return await this.call_service.searchUser(username);
   }

   async get_server_ip() {
      var info = await this.call_service.getServerInfo();
      return info.ipAddress;
   }
	
}
