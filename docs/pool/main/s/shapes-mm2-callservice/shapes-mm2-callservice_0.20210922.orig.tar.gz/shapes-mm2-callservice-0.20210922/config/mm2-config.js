var config = {
	address: "localhost",
	port: 8080,
	basePath: "/",
	ipWhitelist: ["127.0.0.1", "::ffff:127.0.0.1", "::1"],

   useHttps: false,
	httpsPrivateKey: "",
   httpsCertificate: "",

	language: "en",
	logLevel: ["INFO", "LOG", "WARN", "ERROR"],
	timeFormat: 24,
	units: "metric",

	modules: [
		{
			module: "callservice",
			position: "top_right"
		},
      {
         // Note: this depends on mm2-dynamic-modules
         module: "MMM-Dynamic-Modules",
      },
	]
};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== "undefined") {module.exports = config;}
