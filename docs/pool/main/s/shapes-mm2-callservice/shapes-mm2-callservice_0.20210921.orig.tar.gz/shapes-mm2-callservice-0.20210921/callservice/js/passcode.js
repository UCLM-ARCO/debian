_ = console.info.bind(console);

async function on_confirm_click() {
   let code = $("#code").val().trim();
   if (!code) {
      alert("Please, insert a valid code.");
      return;
   }

   await call_service.dataProvide("authCode", code);
   $("#cs-screen-passcode .cs-right").html(
      "<h2>Thank you!</h2>" +
      "Code sent successfully."
   );
}

window.onload = async function () {

   try {
      // create proxy to call service
      ice = Ice.initialize();
      var hostname = document.location.hostname || "127.0.0.1";
      var proto = "wss";
      var port = 2648;
      if (location.protocol !== "https:") {
         proto = "ws";
         port = 2649;
      }

      call_service = Shapes.CallService.ManagerPrx.uncheckedCast(
         ice.stringToProxy(`CallServiceManager -t:${proto} -h ${hostname} -p ${port}`)
      );

      // setup handlers
      $("#cs-screen-passcode button").click(on_confirm_click);
   }
   catch (err) {
      var reason = err;
      if (err.ice_id)
         reason = err.ice_id();
      _("Error creating service proxy: " + reason);
      console.error(err);
   }
};