
class EventObserverI extends Shapes.CallService.EventObserver {
   constructor(manager) {
      super();
      this.manager = manager;
   }

   dataRequest(fieldName) {
      _(`cs[events]: dataRequest received, field: ${fieldName}`);
      plaza.request(fieldName, (name, value) => {
         _(`cs[events]: providing requested field: ${fieldName} with ${value}`);
         this.manager.dataProvide(fieldName, value);
      });
   }

   notify(event) {
      _(`cs[events]: notify received, event: ${event}`);
      plaza.notify(event);
   }
}

class CallServiceClient {
   constructor(icecom, usessl=true) {
      this.ice = icecom;

      var hostname = document.location.hostname || "127.0.0.1";
      var proto = "wss";
      var port = 2648;
      if (!usessl) {
         proto = "ws";
         port = 2649;
      }

      this.call_service = Shapes.CallService.ManagerPrx.uncheckedCast(
         this.ice.stringToProxy(`CallServiceManager -t:${proto} -h ${hostname} -p ${port}`)
      );
   }

   get_name () { return "CallService Client"; }
   get_proxy() { return this.call_service; }

   async setup() {
      _("cs[client]: setup...");

      // create adapter and servant
      this.adapter = await this.ice.createObjectAdapter("");
      this.cbprx = Shapes.CallService.EventObserverPrx.uncheckedCast(
         this.adapter.addWithUUID(
            new EventObserverI(this.call_service))
      );

      await this.connect();
   }

   async connect() {
      _("cs[client]: connect...");

      try {
         var conn = this.call_service.ice_getCachedConnection()
         if (!conn) {
            await this.call_service.ice_ping();
            conn = this.call_service.ice_getCachedConnection();
         }
         conn.setAdapter(this.adapter);
         await this.call_service.setObserver(this.cbprx);
         return true;
      }
      catch (err) {
         var reason = err;
         if (err.ice_id)
            reason = err.ice_id();
         console.error("CallServiceClient: could not register servant, reason: " + reason);
         return false;
      }
   }

   call_user(user) {
      _(`cs[client]: Calling to ${user.id}...`);
      this.call_service.callUser(user.id);
   }

   end_call() {
      _(`cs[client]: Ending current call...`);
      this.call_service.endCall();
   }

   async list_users() {
      return await this.call_service.listUsers();
   }

   async search_user(username) {
      return await this.call_service.searchUser(username);
   }

   async get_server_ip() {
      var info = await this.call_service.getServerInfo();
      return info.ipAddress;
   }

   async signout() {
      return await this.call_service.signout();
   }
}
