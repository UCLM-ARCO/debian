_ = console.info.bind(console);

function prx2ws(prx) {
   let epinfo = prx.ice_getEndpoints()[0].getInfo();
   let sockurl = epinfo.secure() ? "wss://" : "ws://";
   sockurl += `${epinfo.underlying.host}:${epinfo.underlying.port}`;
   return sockurl;
}

class ServicePlaza {
   EV_ALL = "*";

   constructor() {
      this.requests = {};
      this.request_obs = {};
      this.events = {};
      this.provided = {};
   }

   request(field, cb) {
      // if already provided, call hanlder; otherwise, add to pool of requests
      if (field in this.provided)
         cb(field, this.provided[field]);
      else
         this._add_to(this.requests, field, cb);

      // then call observers of this request
      this._send_to(this.request_obs, field);
   }

   cancel_request(field, cb) {
      if (!field in this.requests)
         return;
      this.requests[field] = this.requests[field].filter(it => it != cb);
   }

   observe_request(field, cb) {
      // if requested, call handler and return if returns True
      if (field in this.requests)
         if (cb(field))
            return;

      // otherwise, add to pool of observers for future requests
      this._add_to(this.request_obs, field, cb);
   }

   notify(event) {
      // notify specific event listeners and generic listeners
      // note: events are not stored

      // event may be:
      // - single word: event name
      // - two or more words: [1] event name, [2...], event params
      let fields = event.split(" ");
      let event_name = fields.shift();
      let value = null;
      if (fields.length)
         value = fields.join(" ");

      this._send_to(this.events, event_name, value);
      this._send_to(this.events, this.EV_ALL, {name: event_name, value: value});
   }

   observe_notifications(filter, cb) {
      if (!filter)
         filter = this.EV_ALL;
      this._add_to(this.events, filter, cb);
   }

   provide(field, value) {
      _(`cs[plaza]: provide ${field} with ${value}`);
      this.provided[field] = value;
      this._send_to(this.requests, field, value, true);
   }

   clean_provide(field) {
      delete this.provided[field];
   }

   _add_to(collection, field, cb) {
      let cb_list = collection[field];
      if (!cb_list) {
         cb_list = [];
         collection[field] = cb_list;
      }
      cb_list.push(cb);
   }

   _send_to(collection, field, value, remove = false) {
      let cb_list = collection[field];
      if (cb_list) {
         for (var i in cb_list) {
            cb_list[i](field, value);
         }
         if (remove)
            collection[field] = [];
      }
   }
}

class Timer {
   constructor(elem) {
      this.elem = elem;
      this.start_ts = null;
      this.timer_id = null;
      this.start();
   }

   tick() {
      let elapsed = Math.round((Date.now() - this.start_ts) / 1000);
      let hours = Math.floor(elapsed / 3600).toString().padStart(2, "0");
      elapsed = elapsed % 3600;
      let mins = Math.floor(elapsed / 60).toString().padStart(2, "0");
      let secs = (elapsed % 60).toString().padStart(2, "0");
      let str = `${mins}:${secs}`;
      if (hours !== "00")
         str = `${hours}:${str}`;
      this.elem.text(str);
   }

   start() {
      this.start_ts = Date.now();
      this.timer_id = setInterval(this.tick.bind(this), 1000);
   }

   stop() {
      if (this.timer_id != null) {
         clearInterval(this.timer_id);
         this.timer_id = null;
      }
   }

   reset() {
      this.stop();
      this.start_ts = null;
      this.elem.text("00:00");
   }

   set_start_ts(ts) {
      this.start_ts = ts;
   }
}

class UserInterface {
   ST_INIT = 0;
   ST_WAIT_CODE = 2;
   ST_READY = 3;
   ST_CALL_START = 4;
   ST_CALL_READY = 5;
   ST_CALL_END = 6;

   constructor() {
      this.state = this.ST_INIT;
      this.screen_show("login");

      plaza.observe_request("authCode", this.on_authcode_requested.bind(this))
      plaza.observe_notifications("loginOk", this.on_login_ok.bind(this));
      plaza.observe_notifications("invalidCode", this.on_invalid_code.bind(this));
      plaza.observe_notifications("callStartTo", this.on_call_startto.bind(this));
      plaza.observe_notifications("callStartTime", this.on_call_start_time.bind(this));
      plaza.observe_notifications("videoReady", this.on_video_ready.bind(this));
      plaza.observe_notifications("callEnded", this.on_call_ended.bind(this));

      // NOTE: just to speed development...
      // this.simulate_call("oscar", 3000)
      // this.simulate_auth_code_request(3000);
   }

   simulate_call(user, tout) {
      setTimeout(() => {
         _("--->>> simulating call to", user);
         this.on_new_card();
         this.on_contact_call_handler("emergencyContact", user);
      }, tout);
   }

   simulate_auth_code_request(tout) {
      setTimeout(() => {
         _("--->>> simulating auth code request");
         this.on_authcode_requested();
      }, tout);
   }

   screen_hide(name) {
      if (!name)
         name = this.current_screen;
      $(`#cs-screen-${name}`).hide();
   }

   screen_show(name) {
      _("cs[ui]: screen show of:", name);
      if (this.current_screen)
         this.screen_hide();
      let scr = $(`#cs-screen-${name}`);
      // set_position(scr.attr('mm2-pos'));
      scr.show();
      this.current_screen = name;
   }

   show_message(type, msg, tout=0) {
      $('#cs-messages')
         .empty()
         .append(`<span class="msg-${type}"></span> ${msg}`)
         .show();

      if (tout) {
         setTimeout(()=>{
            this.hide_message();
         }, tout);
      }
   }

   hide_message() {
      $('#cs-messages').empty().hide();
   }

   show_module() {
      $('.module.callservice').show();
   }

   hide_module() {
      $('.module.callservice').hide();
   }

   create_timer() {
      this.timer = new Timer($(".cs-call-time"));
   }

   async on_authcode_requested() {
      this.screen_show("qr-code");

      if ([this.ST_INIT].includes(this.state)) {
         this.state = this.ST_WAIT_CODE;

         external_ip = await calls.get_server_ip();
         $("#cs-passcode-qr").empty();
         var qrcode = new QRCode("cs-passcode-qr", {
            text: "http://" + external_ip + ":8011/external/passcode.html",
            width: 512,
            height: 512,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.L,  // choices: L,M,Q,H
         });
         $("#cs-passcode-qr").show();
      }
   }

   async on_login_ok() {
      if ([this.ST_CALL_START,
           this.ST_CALL_READY,
           this.ST_CALL_END].includes(this.state))
         return;

      this.screen_show("login-ok");
      this.state = this.ST_READY;

      setTimeout(() => {
         this.screen_show("main");
      }, 1500);
   }

   async on_invalid_code() {
      this.show_message('error', "Invalid auth code provided, please try again", 4000);
   }

   async on_signout() {
      calls.signout();
      this.state = this.ST_INIT;
      this.screen_show("login");
   }

   async on_contact_call(username) {
      this.screen_show("calling");
      $(".cs-name-to-call").text(username);

      let user = await calls.search_user(username);
      if (user.id == "0") {
         this.screen_show("bad-user");

         setTimeout(() => {
            this.state = this.ST_READY;
            this.screen_show("main");
         }, 2000);
         return;
      }
      calls.call_user(user);
      this.state = this.ST_CALL_START;
   }

   on_call_startto(evname, username) {
      $(".cs-name-to-call").text(username);
      this.screen_show("calling");
      this.state = this.ST_CALL_START;
   }

   on_call_start_time(evname, ts) {
      if (!this.timer)
         this.create_timer();

      this.timer.set_start_ts(parseInt(ts) * 1000);
   }

   on_video_ready() {
      this.screen_show("videocall");
      this.state = this.ST_CALL_READY;

      if (!this.timer)
         this.create_timer();
   }

   on_call_ended() {
      if ([this.ST_CALL_START, this.ST_CALL_READY].includes(this.state)) {
         this.screen_show("endcall");

         if (this.timer) {
            this.timer.stop();
            this.timer = null;
         }

         setTimeout(() => {
            this.state = this.ST_CALL_END;
            this.screen_show("main");
         }, 5000);
      }
   }
}

function set_position(pos) {
   let modname = "callservice";
   let module = MM.getModules().withClass(modname)[0];
   module.sendNotification(
      'CHANGE_POSITIONS',
      modules = {
         [modname]: {visible: 'true', position: pos}
      }
   );
   _(`cs[ui]: Set position of ${modname} to ${pos}`);
}


class ConnectionKeeper {
   constructor(client, timeout=2000) {
      this._client = client;
      this._timeout = timeout;
      this._wsurl = prx2ws(client.get_proxy());
      this._create_guard_ws();
   }

   _create_guard_ws() {
      if (this._sock != undefined)
         delete this._sock;
      this._sock = new WebSocket(this._wsurl);

      // if WS is open, then we can connect client
      this._sock.addEventListener('open', async ev => {
         _("cs[keeper]: service seems ready, try to connect");
         if (! await this._client.connect()) {
            this._sock.close();
            _("cs[keeper]: client could not connect, try again later");
            return;
         }
         this.ui_feedback(true);
         _("cs[keeper]: client connected successfully!");
      });

      // if WS is closed, then setup a timeout to try connection again later
      this._sock.addEventListener('close', ev => {
         _(`cs[keeper]: service seems down, will try to connect later (ts=${this._timeout} ms)`);
         this.ui_feedback(false);
         setTimeout(this._create_guard_ws.bind(this), this._timeout);
      });
   }

   ui_feedback(alive) {
      if (!alive)
         ui.show_message(
            'error',
            `${this._client.get_name()} not ready, trying to reconnect...`,
         );
      else
         ui.hide_message();
   }
}


class NotificationHandler {
   handle(notification, payload, sender) {
      _("cs[inotif]: notification arrived:", notification);

      switch (notification) {
         case "USER_LOGGED_IN":
            plaza.provide("userId", payload[0]);
            plaza.provide("phoneNumber", payload[1]);
            break;

         case "START_CALL_TO":
            ui.on_contact_call(payload[0]);
            break;

         case "USER_LOGGED_OUT":
            plaza.clean_provide("userId");
            plaza.clean_provide("phoneNumber");
            ui.on_signout();
            break;

         case "SHOW":
            ui.show_module();
            break;

         case "HIDE":
            ui.hide_module();
            break;
      }
   }
}

async function call_service_start() {
   // note: this will be updated later...
   external_ip = "magicmirror";

   try {
      var idata = new Ice.InitializationData();
      idata.properties = Ice.createProperties();
      // idata.properties.setProperty("Ice.ACM.Client.Heartbeat", "3");
      idata.properties.setProperty("Ice.ACM.Close", "0");
      ice = Ice.initialize(idata);

      let usessl = true;
      if (location.protocol !== "https:")
         usessl = false;

      _("cs[main]: creating call-service objects...");
      plaza = new ServicePlaza();
      _("cs[main]: - plaza ready");
      calls = new CallServiceClient(ice, usessl);
      _("cs[main]: - cs client ready");
      ui = new UserInterface();
      _("cs[main]: - ui ready");
      inotif = new NotificationHandler();
      _("cs[main]: - inotif ready");
      await calls.setup();
      _("cs[main]: - cs.setup() done");

      lifekeep = new ConnectionKeeper(calls);
      _("cs[main]: all objects created and running.");
   }
   catch (err) {
      var reason = err;
      if (err.ice_id)
         reason = err.ice_id();
      console.error("Error creating service clients: " + reason);
   }
}
