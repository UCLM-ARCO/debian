_ = console.info.bind(console);

class ServicePlaza {
   EV_ALL = "*";

   constructor() {
      this.requests = {};
      this.request_obs = {};
      this.events = {};
      this.provided = {};
   }

   request(field, cb) {
      // if already provided, call hanlder; otherwise, add to pool of requests
      if (field in this.provided)
         cb(field, this.provided[field]);
      else
         this._add_to(this.requests, field, cb);

      // then call observers of this request
      this._send_to(this.request_obs, field);
   }

   cancel_request(field, cb) {
      if (!field in this.requests)
         return;
      this.requests[field] = this.requests[field].filter(it => it != cb);
   }

   observe_request(field, cb) {
      // if requested, call handler and return if returns True
      if (field in this.requests)
         if (cb(field))
            return;

      // otherwise, add to pool of observers for future requests
      this._add_to(this.request_obs, field, cb);
   }

   notify(event) {
      // notify specific event listeners and generic listeners
      // note: events are not stored

      // event may be:
      // - single word: event name
      // - two or more words: [1] event name, [2...], event params
      let fields = event.split(" ");
      let event_name = fields.shift();
      let value = null;
      if (fields.length)
         value = fields.join(" ");

      this._send_to(this.events, event_name, value);
      this._send_to(this.events, this.EV_ALL, {name: event_name, value: value});
   }

   observe_notifications(filter, cb) {
      if (!filter)
         filter = this.EV_ALL;
      this._add_to(this.events, filter, cb);
   }

   provide(field, value) {
      _(`plaza: provide ${field} with ${value}`);
      this.provided[field] = value;
      this._send_to(this.requests, field, value, true);
   }

   clean_provide(field) {
      delete this.provided[field];
   }

   _add_to(collection, field, cb) {
      let cb_list = collection[field];
      if (!cb_list) {
         cb_list = [];
         collection[field] = cb_list;
      }
      cb_list.push(cb);
   }

   _send_to(collection, field, value, remove = false) {
      let cb_list = collection[field];
      if (cb_list) {
         for (var i in cb_list) {
            cb_list[i](field, value);
         }
         if (remove)
            collection[field] = [];
      }
   }
}

class Timer {
   constructor(elem) {
      this.elem = elem;
      this.start_ts = null;
      this.timer_id = null;
      this.start();
   }

   tick() {
      let elapsed = Math.round((Date.now() - this.start_ts) / 1000);
      let hours = Math.floor(elapsed / 3600).toString().padStart(2, "0");
      elapsed = elapsed % 3600;
      let mins = Math.floor(elapsed / 60).toString().padStart(2, "0");
      let secs = (elapsed % 60).toString().padStart(2, "0");
      let str = `${mins}:${secs}`;
      if (hours !== "00")
         str = `${hours}:${str}`;
      this.elem.text(str);
   }

   start() {
      this.start_ts = Date.now();
      this.timer_id = setInterval(this.tick.bind(this), 1000);
   }

   stop() {
      if (this.timer_id != null) {
         clearInterval(this.timer_id);
         this.timer_id = null;
      }
   }

   reset() {
      this.stop();
      this.start_ts = null;
      this.elem.text("00:00");
   }

   set_start_ts(ts) {
      this.start_ts = ts;
   }
}

class UserInterface {
   ST_INIT = 0;
   ST_NEW_CARD = 1;
   ST_WAIT_CODE = 2;
   ST_READY = 3;
   ST_WAIT_CONTACT = 3.5;
   ST_CALL_START = 4;
   ST_CALL_READY = 5;
   ST_CALL_END = 6;

   constructor() {
      this.state = this.ST_INIT;
      this.screen_show("login");

      rfid.servant.on_new_card(this.on_new_card.bind(this));
      rfid.servant.on_remove_card(this.on_remove_card.bind(this));
      plaza.observe_request("authCode", this.on_authcode_requested.bind(this))
      plaza.observe_notifications("loginOk", this.on_login_ok.bind(this));
      plaza.observe_notifications("callStartTo", this.on_call_startto.bind(this));
      plaza.observe_notifications("callStartTime", this.on_call_start_time.bind(this));
      plaza.observe_notifications("videoReady", this.on_video_ready.bind(this));
      plaza.observe_notifications("callEnded", this.on_call_ended.bind(this));

      // NOTE: just to speed development...
      // this.simulate_call("oscar", 3000)
      // this.simulate_auth_code_request(3000);
   }

   simulate_call(user, tout) {
      setTimeout(() => {
         _("--->>> simulating call to", user);
         this.on_new_card();
         this.on_emergency_call_handler("emergencyContact", user);
      }, tout);
   }

   simulate_auth_code_request(tout) {
      setTimeout(() => {
         _("--->>> simulating auth code request");         
         this.on_authcode_requested();
      }, tout);
   }

   screen_hide(name) {
      if (!name)
         name = this.current_screen;
      $(`#cs-screen-${name}`).hide();
   }

   screen_show(name) {
      if (this.current_screen)
         this.screen_hide();
      let scr = $(`#cs-screen-${name}`);
      set_position(scr.attr('mm2-pos'));
      scr.show();
      this.current_screen = name;
   }

   show_message(type, msg) {
      $('#cs-messages')
         .empty()
         .append(`<span class="msg-${type}"></span> ${msg}`)
         .show();
   }

   hide_message() {
      $('#cs-messages').empty().hide();
   }

   create_timer() {
      this.timer = new Timer($(".cs-call-time"));
   }

   on_new_card() {
      // new card on init, set reading message
      if ([this.ST_INIT].includes(this.state)) {
         // FIXME: $("#cs-screen-login .cs-msg").html("Reading card...");
         this.state = this.ST_NEW_CARD;
      }
      // new card on ready, request contact to call
      else if ([this.ST_READY, this.ST_CALL_END].includes(this.state)) {
         this.state = this.ST_WAIT_CONTACT;
         // FIXME: $("#cs-screen-main .cs-msg").html("Reading card...");
         plaza.request("emergencyContact", this.on_emergency_call_handler.bind(this));
      }
      // new card when call ready, stop call
      else if ([this.ST_CALL_READY].includes(this.state)) {
         calls.end_call();
      }
   }

   on_remove_card() {
      // remove card but login not ok, so go back
      if ([this.ST_NEW_CARD].includes(this.state)) {
         // FIXME: notify error to user (use messages)
         // FIXME: don't overwrite html, hide/show it
         // $("#cs-screen-login .cs-msg").html("Please, use your <b>band</b> to login!");
         this.state = this.ST_INIT;
      }
   }

   async on_authcode_requested() {
      this.screen_show("qr-code");

      if ([this.ST_INIT, this.ST_NEW_CARD].includes(this.state)) {
         $("#cs-screen-login .cs-msg").html("Scan this QR to enter the <b>code</b>...");
         this.state = this.ST_WAIT_CODE;

         external_ip = await calls.get_server_ip();
         var qrcode = new QRCode("cs-passcode-qr", {
            text: "http://" + external_ip + ":8011/external/passcode.html",
            width: 512,
            height: 512,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.L,  // choices: L,M,Q,H
         });
         $("#cs-passcode-qr").show();
      }
   }

   async on_login_ok() {
      if ([this.ST_CALL_START,
           this.ST_CALL_READY,
           this.ST_CALL_END].includes(this.state))
         return;

      $("#cs-screen-login .cs-msg").html("Login is <b>ok</b>! Starting app...");
      this.state = this.ST_READY;

      setTimeout(() => {
         this.screen_show("main");
      }, 1500);
   }

   async on_emergency_call_handler(field, username) {
      this.screen_show("calling");
      if ([this.ST_WAIT_CONTACT].includes(this.state)) {
         $(".cs-name-to-call").text(username);

         let user = await calls.search_user(username);
         if (user.id == "0") {
            this.screen_show("bad-user");

            setTimeout(() => {
               this.state = this.ST_READY;
               this.screen_show("main");
            }, 2000);
            return;
         }
         calls.call_user(user);
         this.state = this.ST_CALL_START;
      }
   }

   on_call_startto(evname, username) {
      $(".cs-name-to-call").text(username);
      this.screen_show("calling");
      this.state = this.ST_CALL_START;
   }

   on_call_start_time(evname, ts) {
      if (!this.timer)
         this.create_timer();

      this.timer.set_start_ts(parseInt(ts) * 1000);
   }

   on_video_ready() {
      this.screen_show("videocall");
      this.state = this.ST_CALL_READY;

      if (!this.timer)
         this.create_timer();
   }

   on_call_ended() {
      if ([this.ST_CALL_START, this.ST_CALL_READY].includes(this.state)) {
         this.screen_show("endcall");

         if (this.timer) {
            this.timer.stop();
            this.timer = null;
         }

         setTimeout(() => {
            this.state = this.ST_CALL_END;
            this.screen_show("main");
         }, 5000);
      }
   }
}

function set_position(pos) {
   let modname = "callservice";
   let module = MM.getModules().withClass(modname)[0];
   module.sendNotification(
      'CHANGE_POSITIONS',
      modules = {
         [modname]: {visible: 'true', position: pos}
      }
   );
   _(`Set position of ${modname} to ${pos}`);
}

class ClientLifeKeeper {
   constructor(client, timeout=10000) {
      this.client = client;
      this.alive = Boolean(client.get_proxy());

      this.check();
      setInterval(this.check.bind(this), timeout);
   }

   async check() {
      if (!this.is_alive()) {
         this.alive = await this.client.connect();
         this.ui_feedback();
      }
   }

   is_alive() {
      if (!this.alive)
         return false;

      // if it was alive, but connection is lost (server may have restarted)
      var conn = this.client.get_proxy().ice_getCachedConnection();
      if (!conn || conn._communicator == null) {
         this.alive = false;
         this.ui_feedback();
      }

      return this.alive;
   }

   ui_feedback() {
      if (!this.alive)
         ui.show_message(
            'error',
            `${this.client.get_name()} not ready, trying to reconnect...`,
         );
      else
         ui.hide_message();
   }
}

// FIXME: for some reason, this does not work on current mm2
// $(window).on("load", async function () {
// - could we use the start() method of MM2 module (callservice.js)??
setTimeout(async function () {
   external_ip = "magicmirror";

   try {
      var idata = new Ice.InitializationData();
      idata.properties = Ice.createProperties();
      idata.properties.setProperty("Ice.ACM.Client.Heartbeat", "3");
      ice = Ice.initialize(idata);

      let usessl = true;
      if (location.protocol !== "https:")
         usessl = false;

      plaza = new ServicePlaza();
      calls = new CallServiceClient(ice, usessl);
      rfid = new RFIDServiceClient(ice, usessl);
      ui = new UserInterface();
      await calls.setup();
      await rfid.setup();

      new ClientLifeKeeper(calls);
      new ClientLifeKeeper(rfid);
   }
   catch (err) {
      var reason = err;
      if (err.ice_id)
         reason = err.ice_id();
      console.error("Error creating service clients: " + reason);
   }

 }, 500);
