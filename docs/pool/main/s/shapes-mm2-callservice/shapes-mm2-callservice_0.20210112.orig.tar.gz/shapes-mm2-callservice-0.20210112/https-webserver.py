#!/usr/bin/python3

from http.server import HTTPServer, SimpleHTTPRequestHandler
import ssl


class RequestHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/static/"):
            self.path = "/callservice/" + self.path[8:]
        return super().do_GET()


httpd = HTTPServer(('127.0.0.1', 4443), RequestHandler)
httpd.socket = ssl.wrap_socket(
    httpd.socket,
    keyfile="certs/127.0.0.1/key.pem",
    certfile='certs/127.0.0.1/cert.pem',
    server_side=True)

try:
    print("Server ready, open: https://localhost:4443/index.html")
    print("NOTE: You would need to allow the auto-generated cert!")
    httpd.serve_forever()
except KeyboardInterrupt:
    pass
