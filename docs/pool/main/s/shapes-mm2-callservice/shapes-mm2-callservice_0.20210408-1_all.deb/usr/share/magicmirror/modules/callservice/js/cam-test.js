function _(msg) {
   $('#cs-messages').append("<div>" + msg + "</div>");
   console.info.apply(null, arguments);
}

window.onload = async function () {
   if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      $('#cs-content').append("<h2>Sorry, mediaDevices not supported here!</h2>");
      return;
   }

   // enumerate available devices
   const devices = await navigator.mediaDevices.enumerateDevices();
   devices.forEach(dev => {
      _(`device: ${dev.kind}, id: ${dev.deviceId}`);
   });

   // update selector with device list
   let select = $('#cs-content select');
   const video_devs = devices.filter(device => device.kind === 'videoinput');
   video_devs.forEach(dev => {
      select.append(`<option value="${dev.deviceId}">${dev.label}</option>`);
   });

   // called handler when user changes device input
   select.change(async () => {
      let video = $('video')[0];
      let option = select.find("option:selected");
      let devid = option.attr('value');

      if (!devid) {
         _('media changed to <b>nothing</b>; removing current');
         video.srcObject = null;
         return;
      }

      _(`media changed to <b>"${option.text()}"</b>`);
      let constraints = { video: { deviceId: { exact: devid } } };
      try {
         const stream = await navigator.mediaDevices.getUserMedia(constraints);
         video.srcObject = stream;
         video.play();
      } catch (err) {
         _("<div class='error'>ERROR: " + err + "</div>");
      }
   });
};