
class CardObserverI extends Shapes.RFIDService.CardObserver {
   constructor(manager) {
      super();
      this.manager = manager;
      this._on_new_card_handler = null;
      this._on_remove_card_handler = null;
   }

   async newCardPresent(cardId) {
      _("newCardPresent received: " + cardId);

      // remove old providad data before calling handler
      plaza.clean_provide("userId");
      plaza.clean_provide("phoneNumber");
      plaza.clean_provide("emergencyContact");

      if (this._on_new_card_handler) {
         try {
            this._on_new_card_handler(cardId);
         } catch (err) {
            _(`ERROR: on new card handler, ${err}`)
         }
      }

      // FIXME: don't provide data unless all are read and correct!
      this._provideField("userId", 16, /^[A-Za-z0-9]{16}$/);
      this._provideField("phoneNumber", 12, /^\+34\d{9}$/);
      this._provideField("emergencyContact", 16, /^@[A-Za-z0-9]+$/);
   }

   cardRemoved(cardId) {
      _("cardRemoved received: " + cardId);
      if (this._on_remove_card_handler) {
         try {
            this._on_remove_card_handler(cardId);
         } catch (err) {
            _(`ERROR: on remove card handler, ${err}`)
         }
      }
   }

   on_new_card(handler) {
      this._on_new_card_handler = handler;
   }

   on_remove_card(handler) {
      this._on_remove_card_handler = handler;
   }

   async _provideField(fieldName, size, format, clean=true) {
      try {
         let decoder = new TextDecoder("utf-8");
         let value = await this.manager.read(fieldName);
         value = decoder.decode(value);
         value = value.substring(0, size);
         if (clean)
            value = value.replace(/\0/g, "");

         if (format.test(value))
            plaza.provide(fieldName, value);
         else
            _(`invalid ${fieldName} format received, ignored (value ${value})`);
      } catch (error) {
         _(error);
      }
   }
};

class RFIDServiceClient {
   constructor(icecom, usessl=true) {
      this.ice = icecom;

      var hostname = document.location.hostname || "127.0.0.1";
      var proto = "wss";
      var port = 2650;
      if (!usessl) {
         proto = "ws";
         port = 2651;
      }

      this.manager_prx = Shapes.RFIDService.ManagerPrx.uncheckedCast(
         this.ice.stringToProxy(`RFIDServiceManager -t:${proto} -h ${hostname} -p ${port}`)
      );
      this.servant = new CardObserverI(this.manager_prx);
   }

   async setup() {
      // create adapter and register servant as callback
      this.adapter = await this.ice.createObjectAdapter("");
      const cbprx = Shapes.RFIDService.CardObserverPrx.uncheckedCast(
         this.adapter.addWithUUID(this.servant)
      );

      var conn = this.manager_prx.ice_getCachedConnection()
      if (!conn) {
         await this.manager_prx.ice_ping();
         conn = this.manager_prx.ice_getCachedConnection();
      }
      conn.setAdapter(this.adapter);
      await this.manager_prx.registerObserver(cbprx);
   }
}

