_ = console.info.bind(console);

class ServicePlaza {
   EV_ALL = "*";

   constructor() {
      this.requests = {};
      this.request_obs = {};
      this.events = {};
      this.provided = {};
   }

   request(field, cb) {
      // if already provided, call hanlder, otherwise, add to pool of requests
      if (field in this.provided)
         cb(field, this.provided[field]);
      else
         this._add_to(this.requests, field, cb);

      // then call observers of this request
      this._send_to(this.request_obs, field);
   }

   cancel_request(field, cb) {
      if (! field in this.requests)
         return;
      this.requests[field] = this.requests[field].filter(it => it != cb);
   }

   observe_request(field, cb) {
      // if requested, call handler and return if returns True
      if (field in this.requests)
         if (cb(field))
            return;

      // otherwise, add to pool of observers for future requests
      this._add_to(this.request_obs, field, cb);
   }

   notify(event) {
      // notify specific event listeners and generic listeners
      this._send_to(this.events, event);
      this._send_to(this.events, this.EV_ALL);
   }

   observe_notifications(filter, cb) {
      // if filtered notfy, otherwise set filter as EV_ALL
      if (filter)
         this._send_to(this.events, filter);
      else
         filter = this.EV_ALL;

      this._add_to(this.events, filter, cb);
   }

   provide(field, value) {
      _(`plaza: provide ${field} with ${value}`);
      this.provided[field] = value;
      this._send_to(this.requests, field, value, true);
   }

   clean_provide(field) {
      delete this.provided[field];
   }

   _add_to(collection, field, cb) {
      let cb_list = collection[field];
      if (!cb_list) {
         cb_list = [];
         collection[field] = cb_list;
      }
      cb_list.push(cb);
   }

   _send_to(collection, field, value, remove=false) {
      let cb_list = collection[field];
      if (cb_list) {
         for (var i in cb_list) {
            cb_list[i](field, value);
         }
         if (remove)
            collection[field] = [];
      }
   }
}

class Timer {
   constructor(elem) {
      this.elem = elem;
      this.start_ts = null;
      this.timer_id = null;
      this.start();
   }

   tick() {
      let elapsed = Math.round((performance.now() - this.start_ts) / 1000);
      let hours = Math.floor(elapsed / 3600).toString().padStart(2, "0");
      elapsed = elapsed % 3600;
      let mins = Math.floor(elapsed / 60).toString().padStart(2, "0");
      let secs = (elapsed % 60).toString().padStart(2, "0");
      let str = `${mins}:${secs}`;
      if (hours !== "00")
         str = `${hours}:${str}`;
      this.elem.text(str);
   }

   start() {
      this.start_ts = performance.now();
      this.timer_id = setInterval(this.tick.bind(this), 1000);
   }

   stop() {
      if (this.timer_id != null) {
         clearInterval(this.timer_id);
         this.timer_id = null;
      }
   }

   reset() {
      this.stop();
      this.start_ts = null;
      this.elem.text("00:00");
   }
}

class UserInterface {
   ST_INIT = 0;
   ST_NEW_CARD = 1;
   ST_WAIT_CODE = 2;
   ST_READY = 3;
   ST_WAIT_CONTACT = 3.5;
   ST_CALL_START = 4;
   ST_CALL_READY = 5;
   ST_CALL_END = 6;

   constructor() {
      this.state = this.ST_INIT;

      rfid.servant.on_new_card(this.on_new_card_handler.bind(this));
      rfid.servant.on_remove_card(this.on_remove_card_handler.bind(this));
      plaza.observe_request("authCode", this.on_authcode_requested.bind(this))
      plaza.observe_notifications("loginOk", this.on_login_ok_handler.bind(this));
      plaza.observe_notifications("callReady", this.on_call_ready_handler.bind(this));
      plaza.observe_notifications("callEnded", this.on_call_ended_handler.bind(this));
   }

   screen_hide(name) {
      if (!name)
         name = this.current_screen;
      $(`#cs-screen-${name}`).hide();
   }

   screen_show(name) {
      if (this.current_screen)
         this.screen_hide();
      $(`#cs-screen-${name}`).show();
      this.current_screen = name;
   }

   on_new_card_handler() {
      // new card on init, set reading message
      if ([this.ST_INIT].includes(this.state)) {
         $("#cs-screen-login .cs-msg").html("Reading card...");
         this.state = this.ST_NEW_CARD;
      }
      // new card on ready, request contact to call
      else if ([this.ST_READY, this.ST_CALL_END].includes(this.state)) {
         this.state = this.ST_WAIT_CONTACT;
         plaza.request("emergencyContact", this.on_emergency_call_handler.bind(this));
      }
      // new card when call ready, stop call
      else if ([this.ST_CALL_READY].includes(this.state)) {
         calls.end_call();
      }
   }

   on_remove_card_handler() {
      // remove card but login not ok, so go back
      if ([this.ST_NEW_CARD].includes(this.state)) {
         // FIXME: notify error to user
         // FIXME: don't overwrite html, hide/show it
         $("#cs-screen-login .cs-msg").html("Please, use your <b>band</b> to login");
         this.state = this.ST_INIT;
      }
   }

   async on_authcode_requested() {
      if ([this.ST_INIT, this.ST_NEW_CARD].includes(this.state)) {
         $("#cs-screen-login .cs-msg").html("Scan this QR to enter the <b>code</b>...");
         this.state = this.ST_WAIT_CODE;

         $("#cs-login-image").hide();
         $("#cs-passcode-qr").show();
	  external_ip = await calls.get_server_ip();
         var qrcode = new QRCode("cs-passcode-qr", {
            text: "http://" + external_ip + ":8011/external/passcode.html",
            width: 512,
            height: 512,
            colorDark : "#000000",
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.H
         });
      }
   }

   async on_login_ok_handler() {
      $("#cs-screen-login .cs-msg").html("Login is <b>ok</b>! <br>Starting app...");
      this.state = this.ST_READY;

      setTimeout(() => {
         this.screen_show("main");
      }, 1500);
   }

   async on_emergency_call_handler(field, username) {
      if ([this.ST_WAIT_CONTACT].includes(this.state)) {
         $(".cs-name-to-call").text(username);
         $("#cs-main-tip").hide();
         $("#cs-main-endcall").hide();
         $("#cs-main-calling").show();

         let user = await calls.search_user(username);
         calls.call_user(user);
         this.state = this.ST_CALL_START;
      }
   }

   on_call_ready_handler() {
      this.screen_show("videocall");
      this.state = this.ST_CALL_READY;

      if (!this.timer)
         this.timer = new Timer($(".cs-call-time"));
   }

   on_call_ended_handler() {
      if ([this.ST_CALL_START, this.ST_CALL_READY].includes(this.state)) {
         this.screen_show("main");
         $("#cs-main-calling").hide();
         $("#cs-main-endcall").show();

         if (this.timer) {
            this.timer.stop();
            this.timer = null;
         }

         setTimeout(() => {
            $("#cs-main-endcall").hide();
            $("#cs-main-tip").show();
            this.state = this.ST_CALL_END;
         }, 2000);
      }
   }
}

// FIXME: for some reason, this does not work on current mm2
// $(window).on("load", async function () {

setTimeout(async function() {
   console.clear();
   external_ip = "magicmirror";

   try {
      var idata = new Ice.InitializationData();
      idata.properties = Ice.createProperties();
      idata.properties.setProperty("Ice.ACM.Client.Heartbeat", "3");
      ice = Ice.initialize(idata);

      let usessl = true;
      if (location.protocol !== "https:")
         usessl = false;

      plaza = new ServicePlaza();
      calls = new CallServiceClient(ice, usessl);
      rfid = new RFIDServiceClient(ice, usessl);
      ui = new UserInterface();
      await calls.setup();
      await rfid.setup();
   }
   catch (err) {
      var reason = err;
      if (err.ice_id)
         reason = err.ice_id();
      _("Error creating service clients: " + reason);
      console.error(err);
   }
}, 500);
