# SCONE Server #

To install `scone-server` just:
  
* Add [pike repository](http://pike.esi.uclm.es/)
* sudo apt install scone

To run it just:

    $ scone-server
    Config: port: 6517, xml: nil, host=0.0.0.0

    All error and log messages will be printed to "SCONE-SERVER.LOG")...
    Server started. Press C-c to stop
    ...


See [README.legacy](https://bitbucket.org/arco_group/scone-server/raw/tip/README.legacy) for a description.