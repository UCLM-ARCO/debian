

rm -f */*.fasl
rm -f */*/*.fasl
rm -f */*/*/*.fasl