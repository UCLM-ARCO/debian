# SCONE Server #

To install `scone-server` just:
  
* Add [arco repository](https://uclm-arco.github.io/debian/)
* sudo apt install scone-server

To run it just:

    $ scone-server
    Config: port: 6517, xml: nil, host=0.0.0.0

    All error and log messages will be printed to "SCONE-SERVER.LOG")...
    Server started. Press C-c to stop
    ...


See [README.legacy](https://github.com/UCLM-ARCO/scone-server/blob/master/README.legacy) for a description.
