
import logging
from functools import lru_cache

from smartcard import System
from smartcard.util import toHexString
from smartcard.ATR import ATR
from smartcard.CardType import AnyCardType
from smartcard.CardRequest import CardRequest
from smartcard.sw.ErrorCheckingChain import ErrorCheckingChain
from smartcard.sw.SWExceptions import SWException
from smartcard.sw.ISO7816_4ErrorChecker import ISO7816_4ErrorChecker
from smartcard.sw.ISO7816_8ErrorChecker import ISO7816_8ErrorChecker
from smartcard.sw.ISO7816_9ErrorChecker import ISO7816_9ErrorChecker
from smartcard.Exceptions import (
    SmartcardException, CardRequestTimeoutException, CardConnectionException
)
from smartcard.CardMonitoring import CardMonitor, CardObserver

# This is a refactor of the following repo:
# - https://github.com/Flowtter/py-acr122u

log = logging.getLogger(__file__)
log.setLevel(logging.INFO)


class Device:
    def __init__(self, model="ACR122U"):
        """create an ACR122U object
        doc available here:
        - http://downloads.acs.com.hk/drivers/en/API-ACR122U-2.02.pdf
        - https://www.nxp.com/docs/en/nxp/user-guides/UM10463.pdf"""

        assert model in ["ACR122U", "PR533"], "Invalid model type"
        self.model = model

        readers = System.readers()
        if len(readers) == 0:
            raise NoDevice("No device available")

        self.reader = readers[0]

        self._current_card_id = None
        self._on_new_card_handler = None
        self._on_remove_card_handler = None

        observer = CardObserver()
        observer.update = self._on_card_update
        monitor = CardMonitor()
        monitor.addObserver(observer)

    def _on_card_update(self, monitor, actions):
        added, removed = actions

        # handle only one card
        card = added[0] if added else None
        if card:
            try:
                card.connection = card.createConnection()
                card_obj = self.connect(card.connection)
                self._current_card_id = bytes(card_obj.get_uid()).hex()
                log.info(f" new card connected: {self._current_card_id}")
                if self._on_new_card_handler is not None:
                    self._on_new_card_handler(card_obj)
            except InstructionFailed as err:
                log.error(f" could not read card: {err}")

        # handle only one card
        card = removed[0] if removed else None
        if card:
            log.info(f" card removed: {self._current_card_id}")
            try:
                if self._on_remove_card_handler is not None:
                    self._on_remove_card_handler(self._current_card_id)
            finally:
                self._current_card_id = None

    def on_remove_card(self, cb):
        self._on_remove_card_handler = cb

    def on_new_card(self, cb):
        self._on_new_card_handler = cb

    def connect(self, con=None):
        """connect to card"""

        try:
            if con is None:
                con = self.reader.createConnection()

            errorchain = []
            errorchain = [ErrorCheckingChain(errorchain, ISO7816_9ErrorChecker())]
            errorchain = [ErrorCheckingChain(errorchain, ISO7816_8ErrorChecker())]
            errorchain = [ErrorCheckingChain(errorchain, ISO7816_4ErrorChecker())]
            con.setErrorCheckingChain(errorchain)

            con.connect()
            return Card(con)
        except:
            raise NoCommunication(
                "The reader has been deleted and no communication is now possible. "
                "Smartcard error code : 0x7FEFFF97"
                "\nHint: try to connect a card to the reader")


class Card:
    def __init__(self, conn):
        self.connection = conn

    def command(self, mode, arguments=None):
        """send a payload to the reader

        Format:
            CLA INS P1 P2 P3 Lc Data Le

        The Le field (optional) indicates the maximum length of the response.
        The Lc field indicates the length of the outgoing data.

        Mandatory:
            CLA INS P1 P2

        Attributes:
            mode: key value of option.command or option.alias
            arguments: replace `-1` in the payload by arguments

        Returns:
            return the data or sw1 sw2 depending on the request"""
        mode = Const.alias.get(mode) or mode
        payload = Const.commands.get(mode)

        if not payload:
            raise OptionOutOfRange(
                "Option do not exist\nHint: try to call help(Device().command)"
                " to see all options")

        try:
            payload = self._replace_arguments(payload, arguments)
            result = self.connection.transmit(payload)
        except SWException as e:
            raise InstructionFailed(e.message)
        except CardConnectionException as e:
            raise InstructionFailed(str(e))
        except Exception as e:
            raise InstructionFailed(f"General exception: {e}")

        if len(result) == 3:
            data, sw1, sw2 = result
        else:
            data, n, sw1, sw2 = result

        if [sw1, sw2] == Const.answers.get("fail"):
            raise InstructionFailed(f"Instruction {mode} failed")
        if data:
            return data
        if [sw1, sw2] != Const.answers.get("success"):
            return sw1, sw2

    def custom(self, payload):
        """send a custom payload to the reader

        Format:
            CLA INS P1 P2 P3 Lc Data Le"""
        result = self.connection.transmit(payload)

        if len(result) == 3:
            data, sw1, sw2 = result
        else:
            data, n, sw1, sw2 = result

        if [sw1, sw2] == Const.answers.get("fail"):
            raise InstructionFailed(f"Payload {payload} failed")

    @lru_cache(maxsize=None)
    def get_uid(self):
        """get the uid of the card"""
        return self.command("get_uid")

    # FIXME: move this to Device class
    def firmware_version(self):
        """get the firmware version of the reader"""
        return self.command("firmware_version")

    def load_authentication_data(self, key_location, key_value):
        """load the authentication key

        Attributes:
            key location : 0x00 ~ 0x01
            key value : 6 bytes

        Example:
            E.g. 0x01, [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]"""
        self.command("load_authentication_data", [key_location, key_value])

    def authenticate_sector(self, block_number, key_type, key_location):
        """authentication with the key in `load_authentication_data`

        Attributes:
            block number : 1 byte
            key type A/B : 0x60 ~ 0x61
            key location : 0x00 ~ 0x01

        Example:
            E.g. 0x00, 0x61, 0x01"""

        cmd = "authentication-"
        cmd += "acr122u" if self.model == "ACR122U" else "pr533"
        self.command(cmd, [block_number, key_type, key_location])

    def read(self, block_number, size=16):
        """read n bytes in the card at the block_number index

        Attributes:
            block number : 1 byte
            number of Bytes to read : 1

        Example:
            E.g. 0x00, 0x02"""
        return self.command("read_binary_blocks", [block_number, size])

    def write(self, block_number, data):
        """update n bytes in the card with data at the block_number index

        Attributes:
            block number : 1 byte
            data : 4-16 bytes

        Examples:
            0x01, 0x10, [0x00, 0x01, 0x02, 0x03, 0x04, 0x05
            0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15]"""

        if isinstance(data, str):
            data = list(data.encode())
        data += [0 for _ in range(16 - len(data))]
        self.command("update_binary_blocks", [block_number, 16, data])

    # FIXME: move this to Device class
    def led_control(self, led_state, t1, t2, number_of_repetition, link_to_buzzer):
        """control led state

        Attributes:
            led state control : 0x00 - 0x0F
            T1 led Duration
            T2 led Duration
            number of repetition
            link to buzzer

        Example:
            0x05, 0x01, 0x01, 0x01, 0x01"""
        self.command("led_control", [led_state, t1, t2, number_of_repetition, link_to_buzzer])

    # FIXME: move this to Device class
    def get_picc_version(self):
        """get the PICC version of the reader"""
        return self.command("get_picc_version")

    # FIXME: move this to Device class
    def set_picc_version(self, picc_value):
        """set the PICC version of the reader

        Attributes:
            PICC value: 1 byte, default is 0xFF

        Example:
            0xFF"""
        self.command("set_picc_version", [picc_value])

    # FIXME: move this to Device class
    def buzzer_sound(self, poll_buzzer_status):
        """set the buzzer sound state

        Attributes:
            poll buzz status : 0x00 ~ 0xFF

        Example:
            0x00"""
        self.command("buzzer_sound", [poll_buzzer_status])

    # FIXME: move this to Device class
    def set_timeout(self, timeout_parameter):
        """set the timeout of the reader

        Attributes:
            timeout parameter : 0x00 ~ 0x01 - 0xFE ~ 0xFF : (0,  5 second unit, infinite),
            default is 0xFF

        Example:
            0x01"""
        self.command("set_timeout", [timeout_parameter])

    def info(self):
        """print the type of the card on the reader"""
        atr = ATR(self.connection.getATR())
        historical_byte = toHexString(atr.getHistoricalBytes(), 0)
        print(historical_byte)
        print(historical_byte[-17:-12])
        card_name = historical_byte[-17:-12]
        name = Const.cards.get(card_name, "")
        print(f"Card Name: {name}\n\tT0 {atr.isT0Supported()}\n"
              f"\tT1 {atr.isT1Supported()}\n\tT15 {atr.isT15Supported()}")

    def print_data(self, data):
        print(f"data:\n\t{data}"
              f"\n\t{self._int_list_to_hexadecimal_list(data)}"
              f"\n\t{self._int_list_to_string_list(data)}")

    @staticmethod
    def _print_sw1_sw2(sw1, sw2):
        print(f"sw1 : {sw1} {hex(sw1)}\n"
              f"sw2 : {sw2} {hex(sw2)}")

    @staticmethod
    def _int_list_to_hexadecimal_list(data):
        return [hex(e) for e in data]

    @staticmethod
    def _int_list_to_string_list(data):
        return ''.join([chr(e) for e in data])

    @staticmethod
    def _replace_arguments(data, arguments):
        if not arguments:
            return data

        result = []
        j = 0
        j_max = len(arguments)

        for b in data:
            if b != -1:
                result.append(b)
                continue

            if j < j_max:
                arg = arguments[j]
                if isinstance(arg, int):
                    result.append(arg)
                else:
                    for e in arg:
                        result.append(e)
                j += 1
        return result


class Const:
    commands = {
        "get_uid": [0xFF, 0xCA, 0x00, 0x00, 0x00],
        "firmware_version": [0xFF, 0x00, 0x48, 0x00, 0x00],
        "load_authentication_data": [0xFF, 0x82, 0x00, -1, 0x06, -1],
        "authentication-acr122u": [0xFF, 0x88, 0x00, -1, -1, -1],
        "authentication-pr533": [0xFF, 0x86, 0x00, 0x00, 0x05, 0x01, 0x00, -1, -1, -1],
        "read_binary_blocks": [0xFF, 0xB0, 0x00, -1, -1],
        "update_binary_blocks": [0xFF, 0xD6, 0x00, -1, -1, -1],
        "led-control": [0xFF, 0x00, 0x40, -1, -0x04, -1, -1, -1, -1],
        "get_picc_version": [0xFF, 0x00, 0x50, 0x00, 0x00],
        "set_picc_version": [0xFF, 0x00, 0x51, -1, 0x00],
        "buzzer_sound": [0xFF, 0x00, 0x52, -1, 0x00],
        "set_timeout": [0xFF, 0x00, 0x41, -1, 0x00],
    }

    alias = {
        "gu": "get_uid",
        "fv": "firmware_version",
        "lad": "load_authentication_data",
        "auth": "authentication",
        "rbb": "read_binary_blocks",
        "ubb": "update_binary_blocks",
        "ld": "led-control",
        "gpv": "get_picc_version",
        "spv": "set_picc_version",
        "b": "buzzer_sound_mute",
        "st": "set_timeout",
    }

    answers = {
        "success": [0x90, 0x0],
        "fail": [0x63, 0x0]
    }

    cards = {
        "00 01": "MIFARE Classic 1K",
        "00 02": "MIFARE Classic 4K",
        "00 03": "MIFARE Ultralight",
        "00 26": "MIFARE Mini",
        "F0 04": "Topaz and Jewel",
        "F0 11": "FeliCa 212K",
        "F0 12": "FeliCa 424K"
    }


class Error(SmartcardException):
    """Base class for exceptions in this module."""

    def __init__(self, message):
        super().__init__()
        self.message = message


class NoDevice(Error):
    """Exception raised when no readers are plug to the computer.

    Attributes:
        message -- explanation of the error
    """


class NoCommunication(Error):
    """Exception raised when the communication can't be established.

    Attributes:
        message -- explanation of the error
    """


class OptionOutOfRange(Error):
    """Exception raised when you try to access an element not in the `option.options` dictionary

    Attributes:
        message -- explanation of the error
    """


class InstructionFailed(Error):
    """Exception raised when the instruction failed

    Attributes:
        message -- explanation of the error
    """
