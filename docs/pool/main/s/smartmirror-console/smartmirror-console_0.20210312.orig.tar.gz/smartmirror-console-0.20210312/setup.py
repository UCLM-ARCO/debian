import re

from setuptools import find_packages, setup


def get_version():
    with open('debian/changelog') as fr:
        retval = re.search(r'\((.*)-\d*\)', fr.read()).group(1)
    return retval


def get_short_description():
    with open('debian/control') as fr:
        retval = re.search(
            r'^Description:(.*)$',
            fr.read(),
            re.MULTILINE).group(1).strip()
    return retval


def get_long_description():
    with open('README.md') as fr:
        retval = fr.read()
    return retval


setup(
    name='smartmirror_console',
    packages=find_packages(),
    version=get_version(),
    description=get_short_description(),
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    author="Cristina Bolaños Peño",
    author_email="Cristina.Bolanos@uclm.es",
    license='Apache-2.0',
    install_requires=[
        'flask',
        'flask-security',
        'flask-restful',
        'python-apt'],
    include_package_data=True,
    data_files=[
        ('uwsgi/apps-available', ['config/uwsgi/smartmirror-console.ini']),
        ('nginx/sites-available', ['config/nginx/smartmirror-console'])
    ]
)
