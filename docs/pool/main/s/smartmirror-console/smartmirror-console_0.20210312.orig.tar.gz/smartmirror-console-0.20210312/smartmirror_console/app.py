#!/usr/bin/python3

import functools
import os.path

import flask_wtf
import peewee
from flask import (Flask, abort, flash, jsonify, make_response, redirect,
                   render_template, request, session, url_for)
from flask_peewee.db import Database
from flask_restful import Api
from flask_security import (PeeweeUserDatastore, RoleMixin, Security,
                            UserMixin, login_required)
from markupsafe import escape

from smartmirror_console.backend.miband_dc import MiBand_DataCollector, get_active_device

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(32)
app.config['DATABASE'] = {
    'name': os.path.dirname(os.path.abspath(__file__)) + '/smartmirror-console.db',
    'engine': 'peewee.SqliteDatabase',
}

flask_wtf.CSRFProtect(app)
miband_dc = MiBand_DataCollector()

api = Api(app)
api.add_resource(MiBand_DataCollector, '/api/miband-dc')

db = Database(app)


class Role(db.Model, RoleMixin):
    name = peewee.CharField(unique=True)
    description = peewee.TextField(null=True)


class User(db.Model, UserMixin):
    email = peewee.TextField()
    password = peewee.TextField()
    active = peewee.BooleanField(default=True)
    confirmed_at = peewee.DateTimeField(null=True)


class UserRoles(db.Model):
    # Because peewee does not come with built-in many-to-many
    # relationships, we need this intermediary class to link
    # user to roles.
    user = peewee.ForeignKeyField(User, related_name='roles')
    role = peewee.ForeignKeyField(Role, related_name='users')
    name = property(lambda self: self.role.name)
    description = property(lambda self: self.role.description)


# Setup Flask-Security
user_datastore = PeeweeUserDatastore(db, User, Role, UserRoles)
security = Security(app, user_datastore)

for model in (User, Role, UserRoles):
    model.create_table(safe=True, fail_silently=True)
if not user_datastore.find_user(email='admin'):
    user_datastore.create_user(email='admin', password='admin')
if not db.database.is_closed():
    db.database.close()

@app.route("/")
@login_required
def index():
    packages = {}
    for package in [miband_dc]:
        packages[package.name] = {
            'installed': package.installed,
            'upgradable': package.upgradable,
            'version': package.version
        }

    services = {}
    for service in [miband_dc]:
        services[service.name] = {
            'running': service.running,
            'enabled': service.enabled
        }

    return render_template(
        'home.html',
        devices=miband_dc.devices,
        packages=packages,
        services=services
    )


@app.route("/save-devices", methods=['POST'])
@login_required
def save_devices():
    errors = []
    for mac, token in request.form.items():
        if mac == 'csrf_token':
            continue
        token = token.strip()
        if token == "deleted":
            if not miband_dc.remove_device(mac):
                errors.append(mac)
        elif len(token) > 0:
            miband_dc.add_device(mac, token)

    miband_dc.save_devices()
    miband_dc.restart()

    if len(errors) > 0:
        flash(
            f"The following devices were not found: {errors}",
            'save-devices-error')
    else:
        flash("Saved devices configuration", 'save-devices-success')
    return redirect(url_for('index'))


@app.route("/get-token", methods=['POST'])
@login_required
def get_token():
    data = request.get_json()
    if data is None or 'email' not in data or 'password' not in data:
        abort(400)
    try:
        mac, token = get_active_device(
            data['email'], data['password']
        )
    except ValueError as err:
        return make_response((
            jsonify({'msg': str(err)}), 400
        ))
    return jsonify({
        'mac': mac,
        'token': token
    })


@app.errorhandler(404)
def error_not_found(error):
    return "<p>Ooops! We don't know that page. Sorry!</p>"
