import abc
import os
import queue
import subprocess
import time
from datetime import datetime, timedelta
from functools import wraps
from threading import Thread

from apt import Cache
from flask_babel import gettext


class AptTask:
    def __init__(self, cache: Cache, package: str):
        self.name = self.__class__.__name__
        self.cache = cache
        self.package = package

    def run(self):
        print(f'{self.name}\tRunning on {self.package}...')


class InstallTask(AptTask):
    def run(self):
        super().run()
        if self.package in self.cache:
            self.cache[self.package].mark_install()
            self.cache.commit()
            return True
        return False


class UninstallTask(AptTask):
    def run(self):
        super().run()
        if self.package in self.cache:
            self.cache[self.package].mark_delete()
            self.cache.commit()
            return True
        return False


class UpgradeTask(AptTask):
    def run(self):
        super().run()
        if self.package in self.cache:
            self.cache[self.package].mark_upgrade()
            self.cache.commit()
            return True
        return False


class UpdateTask(AptTask):
    def __init__(self, cache: Cache):
        self.name = self.__class__.__name__
        self.cache = cache

    def run(self):
        print(f'{self.name}\tRunning...')
        try:
            self.cache.update()
        except Exception as err:
            print(f'{self.name}\tFailed: {err}')
            return False
        else:
            self.cache.open(None)
            return True


class AptManager(Thread):
    def __init__(self):
        super().__init__(name=self.__class__.__name__)
        self.cache = Cache()
        self.tasks = queue.Queue()
        self.__stop = False
        self.__last_task_result = True

    def stop(self):
        self.__stop = True

    def get_version(self, name: str):
        if self.is_installed(name):
            return self.cache[name].installed.version
        return None

    def is_available(self, name: str):
        return name in self.cache

    def is_installed(self, name: str):
        if self.is_available(name):
            return self.cache[name].is_installed
        return False

    def is_upgradable(self, name: str):
        if self.is_available(name):
            return self.cache[name].is_upgradable
        return False

    def install(self, name: str):
        if not self.is_available(name):
            return False
        self.tasks.put(InstallTask(self.cache, name))
        self.tasks.join()
        retval = self.__last_task_result

        self.tasks.put(UpdateTask(self.cache))
        self.tasks.join()
        return retval

    def upgrade(self, name: str):
        if not self.is_available(name):
            return False
        self.tasks.put(UpgradeTask(self.cache, name))
        self.tasks.join()
        retval = self.__last_task_result

        self.tasks.put(UpdateTask(self.cache))
        self.tasks.join()
        return retval

    def uninstall(self, name: str):
        if not self.is_available(name):
            return False
        self.tasks.put(UninstallTask(self.cache, name))
        self.tasks.join()
        retval = self.__last_task_result

        self.tasks.put(UpdateTask(self.cache))
        self.tasks.join()
        return retval

    def update(self):
        self.tasks.put(UpdateTask(self.cache))
        self.tasks.join()
        return self.__last_task_result

    def run(self):
        print(f'{self.name}\tRunning...')
        while not self.__stop:
            task = self.tasks.get()
            self.__last_task_result = task.run()
            self.tasks.task_done()
            time.sleep(1)
        print(f'{self.name}\tStopping...')


class AptUpdater(Thread):
    def __init__(self, manager: AptManager):
        super().__init__(name=self.__class__.__name__)
        self.manager = manager
        self.last_updated = None
        self.__stop = False

    def stop(self):
        self.__stop = True

    def shall_run(self):
        if self.last_updated == None:
            return True
        elif datetime.now() - self.last_updated >= timedelta(days=1):
            return True
        return False

    def run(self):
        print(f'{self.name}\tRunning...')
        while not self.__stop:
            if self.shall_run():
                if self.manager.update():
                    self.last_updated = datetime.now()
            time.sleep(1)
        print(f'{self.name}\tStopping...')


APT_MANAGER = AptManager()
APT_UPDATER = AptUpdater(APT_MANAGER)


def is_superuser(fn):
    @wraps(fn)
    def _deco(self, *args, **kwargs):
        if os.getuid() != 0:
            raise RuntimeError('Not running as superuser')
        return fn(self, *args, **kwargs)
    return _deco


class ServiceResource(abc.ABC):
    ACTIONS = ['start', 'restart', 'stop', 'enable', 'disable', 'status']

    @abc.abstractproperty
    def name(self) -> str:
        return 'invalid'

    @property
    def running(self) -> bool:
        return subprocess.run(
            args=['systemctl', '--quiet', 'is-active', self.name]
        ).returncode == 0

    @property
    def enabled(self) -> bool:
        return subprocess.run(
            args=['systemctl', '--quiet', 'is-enabled', self.name]
        ).returncode == 0

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        return hash(self) == hash(other)

    def status(self) -> str:
        result = subprocess.run(
            args=['systemctl', 'status', self.name],
            capture_output=True,
            encoding='utf-8')
        if result.returncode != 4:  # service dont exists
            return result.stdout
        return result.stdout

    def journal(
            self,
            since: datetime = datetime.now() -
            timedelta(
            days=1)) -> str:
        result = subprocess.run(
            args=[
                'journalctl',
                '-u',
                self.name,
                '--since={}'.format(since.strftime('%Y-%m-%d %H:%M:%S'))],
            capture_output=True,
            encoding='utf-8')
        if result.returncode == 0:
            return result.stdout
        return result.stderr

    @is_superuser
    def start(self) -> tuple:
        result = subprocess.run(
            args=['sudo', 'systemctl', 'start', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    @is_superuser
    def stop(self):
        result = subprocess.run(
            args=['sudo', 'systemctl', 'stop', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    @is_superuser
    def restart(self):
        result = subprocess.run(
            args=['sudo', 'systemctl', 'restart', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    @is_superuser
    def enable(self):
        result = subprocess.run(
            args=['sudo', 'systemctl', 'enable', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    @is_superuser
    def disable(self):
        result = subprocess.run(
            args=['sudo', 'systemctl', 'disable', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    def to_dict(self):
        return {
            'running': self.running,
            'enabled': self.enabled
        }


class PackageResource(abc.ABC):
    ACTIONS = ['install', 'uninstall', 'upgrade']
    
    @abc.abstractproperty
    def name(self) -> str:
        return 'invalid'

    @property
    def version(self) -> str:
        return APT_MANAGER.get_version(self.name)

    @property
    def available(self) -> bool:
        return APT_MANAGER.is_available(self.name)

    @property
    def installed(self) -> bool:
        return APT_MANAGER.is_installed(self.name)

    @property
    def upgradable(self) -> bool:
        return APT_MANAGER.is_upgradable(self.name)

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        return hash(self) == hash(other)

    def install(self):
        if not self.available:
            return (False, None, gettext(u'Package %(name)s does not exist', name=self.name))
        elif self.installed:
            return (False, None, gettext(u'Package %(name)s is already installed', name=self.name))
        APT_MANAGER.install(self.name)
        return (True, gettext(u'Package succesfully installed'), None)

    def upgrade(self):
        if not self.available:
            return (False, None, gettext(u'Package %(name)s does not exist', name=self.name))
        elif not self.upgradable:
            return (False, None, gettext(u'Package %(name)s cannot be upgraded', name=self.name))
        APT_MANAGER.upgrade(self.name)
        return (True, gettext(u'Package succesfully upgraded'), None)

    def uninstall(self):
        if not self.available:
            return (False, None, gettext(u'Package %(name)s does not exist', name=self.name))
        if not self.installed:
            return (False, None, gettext(u'Package %(name)s is not installed', name=self.name))
        APT_MANAGER.uninstall(self.name)
        return (True, gettext(u'Package succesfully uninstalled'), None)

    def to_dict(self):
        return {
            'version': self.version,
            'installed': self.installed,
            'upgradable': self.upgradable
        }


class PackageWithServiceResource(ServiceResource, PackageResource):
    ACTIONS = ServiceResource.ACTIONS + PackageResource.ACTIONS

    def to_dict(self):
        retval = {}
        retval.update(ServiceResource.to_dict(self))
        retval.update(PackageResource.to_dict(self))
        return retval

    def install(self):
        retval = super().install()
        if retval[0] and not self.enabled:
            self.enable()
        return retval

    def upgrade(self):
        retval = super().upgrade()
        if retval[0] and not self.enabled:
            self.enable()
        return retval