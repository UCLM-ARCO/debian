#!/usr/bin/python3

import flask_wtf
from flask import Flask, request
from flask_babel import Babel
from flask_security import Security

from .backend import get_packages, user_preferences
from .backend.utils import APT_MANAGER, APT_UPDATER
from .blueprints import change_default_password_page, home_page, miband_dc_page
from .config import DevelopmentConfig, ProductionConfig
from .security import db, user_datastore

BABEL = Babel()
SECURITY = Security()
THREADS = [APT_MANAGER, APT_UPDATER]


def init_db():
    db.create_all()


def init_miband_dc():
    packages = get_packages()
    miband_dc = packages.get('miband-dc')

    if miband_dc != None:
        if miband_dc.update_state_email != None:
            if user_preferences.notification_email == None:
                del miband_dc.update_state_email
            else:
                miband_dc.update_state_email = {
                    'address': user_preferences.notification_email,
                    'timeout': user_preferences.notification_timeout
                }

        mm_bandupdater = packages.get('mm-bandupdater')
        if mm_bandupdater == None and miband_dc.update_state_mm != None:
            del miband_dc.update_state_mm
        elif mm_bandupdater != None:
            if mm_bandupdater.installed and miband_dc.update_state_mm == None:
                miband_dc.update_state_mm = {
                    'address': 'localhost:{}'.format(mm_bandupdater.config['port']),
                    'timeout': '5m'
                }
            elif not mm_bandupdater.installed and miband_dc.update_state_mm != None:
                del miband_dc.update_state_mm

        miband_dc.save_settings()


@BABEL.localeselector
def get_locale():
    if user_preferences.locale != None:
        return user_preferences.locale

    return request.accept_languages.best_match(['es', 'en'])


def create_app(env: str = 'prod'):
    app = Flask(__name__)
    if env == 'prod' and app.config['ENV'] != 'development':
        app.config.from_object(ProductionConfig)
    else:
        app.config.from_object(DevelopmentConfig)

    flask_wtf.CSRFProtect(app)

    app.register_blueprint(home_page)
    app.register_blueprint(miband_dc_page, url_prefix='/miband-dc')
    app.register_blueprint(change_default_password_page,
                           url_prefix='/change-default')

    app.before_first_request(init_db)
    app.before_first_request(init_miband_dc)

    db.init_app(app)
    BABEL.init_app(app)
    SECURITY.init_app(app, user_datastore)
    user_preferences.init_app(app)

    for thread in THREADS:
        if not thread.is_alive():
            thread.start()

    return app
