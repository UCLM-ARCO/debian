from .home import home_page
from .miband import miband_dc_page
from .auth import change_default_password_page