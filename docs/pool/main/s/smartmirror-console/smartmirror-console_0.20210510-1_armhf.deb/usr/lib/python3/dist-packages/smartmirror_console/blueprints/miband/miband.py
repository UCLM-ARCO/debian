from flask import (Blueprint, abort, flash, jsonify, make_response, redirect,
                   render_template, request, url_for)
from flask_babel import gettext
from smartmirror_console.backend import (get_linked_devices, get_packages,
                                         user_preferences)

from ..utils import check_language, login_and_change_password_required

miband_dc_page = Blueprint('miband_dc', __name__,
                           template_folder='templates', static_folder='static')
miband_dc = get_packages().get('miband-dc')


@miband_dc_page.route('/<string:action>', methods=['GET'])
@login_and_change_password_required
def execute(action):
    if miband_dc == None:
        abort(500)
    elif action == 'status':
        return '<pre>{}</pre>'.format(
            miband_dc.journal().replace('\n', '</br>')
        )
    elif action == 'install':
        result = miband_dc.install()
    elif action == 'uninstall':
        result = miband_dc.uninstall()
    elif action == 'upgrade':
        result = miband_dc.upgrade()
    elif action == 'start':
        result = miband_dc.restart()
    elif action == 'stop':
        result = miband_dc.stop()
    else:
        abort(404)  # TODO Show available options

    if result[0]:
        flash(gettext(u'Executed %(action)s on %(name)s',
                      action=action, name='miband-dc'), 'success')
    else:
        flash(gettext(u'Error on %(action)s: %(error)s',
                      action=action, error=result[2]), 'failure')

    if request.environ.get('HTTP_REFERER') != None:
        return redirect(request.environ.get('HTTP_REFERER'))
    return redirect(url_for('home'))


@miband_dc_page.route('/get-token', methods=['POST'])
@login_and_change_password_required
def get_token():
    data = request.get_json()
    if data == None or 'email' not in data or 'password' not in data:
        abort(400)
    retval = {}
    try:
        index = 0
        for mac, token in get_linked_devices(data['email'], data['password']).items():
            retval[index] = {
                'mac': mac,
                'token': token
            }
            index += 1
        retval['length'] = index
    except ValueError as err:
        return make_response((
            jsonify({'msg': str(err)}), 400
        ))
    return jsonify(retval)


@miband_dc_page.route('/', methods=['GET'])
@miband_dc_page.route('/settings', methods=['GET'])
@login_and_change_password_required
def redirect_to_settings():
    return redirect(url_for('miband_dc.settings', section='database'))


@miband_dc_page.route('/settings/<string:section>', methods=['GET', 'POST'])
@login_and_change_password_required
@check_language
def settings(section):
    if miband_dc == None:
        abort(500)  # TODO Show more info when package is not installed
    elif section == 'database':
        return database_settings()
    elif section == 'charging-station':
        return charging_station_settings()
    elif section == 'notifications':
        return notifications_settings()
    elif section == 'hooks':
        return hooks_settings()
    elif section == 'devices':
        return devices_settings()
    else:
        abort(404)


def database_settings():
    if request.method == 'GET':
        lang = user_preferences.locale
        if user_preferences.locale == None:
            lang = request.accept_languages.best_match(['es', 'en'])

        return render_template(
            'database_settings.html',
            lang=lang,
            version=miband_dc.version,
            installed=miband_dc.installed,
            upgradable=miband_dc.upgradable,
            running=miband_dc.running,
            db_name=miband_dc.db_name,
            db_host=miband_dc.db_host,
            db_user=miband_dc.db_user,
            db_passwd=miband_dc.db_passwd
        )

    miband_dc.db_name = request.form['db_name']
    miband_dc.db_host = request.form['db_host']
    miband_dc.db_user = request.form['db_user']
    miband_dc.db_passwd = request.form['db_passwd']
    miband_dc.save_settings()
    flash(gettext(u'Saved database settings'), 'success')
    return redirect(url_for('miband_dc.settings', section='database'))


def charging_station_settings():
    if request.method == 'GET':
        lang = user_preferences.locale
        if user_preferences.locale == None:
            lang = request.accept_languages.best_match(['es', 'en'])

        return render_template(
            'charging_station_settings.html',
            lang=lang,
            version=miband_dc.version,
            installed=miband_dc.installed,
            upgradable=miband_dc.upgradable,
            running=miband_dc.running,
            update_mode=miband_dc.update_mode
        )

    if request.form['charging_station'] == 'enabled':
        miband_dc.update_mode = 'charging'
    else:
        del miband_dc.update_mode
    miband_dc.save_settings()
    flash(gettext(u'Saved charging station settings'), 'success')
    return redirect(url_for('miband_dc.settings', section='charging-station'))


def notifications_settings():
    if request.method == 'GET':
        lang = user_preferences.locale
        if user_preferences.locale == None:
            lang = request.accept_languages.best_match(['es', 'en'])

        return render_template(
            'notifications_settings.html',
            lang=lang,
            version=miband_dc.version,
            installed=miband_dc.installed,
            upgradable=miband_dc.upgradable,
            running=miband_dc.running,
            update_state_email=miband_dc.update_state_email,
            email_preferences={
                'address': user_preferences.notification_email,
                'timeout': user_preferences.notification_timeout
            }
        )

    if 'notification_email' in request.form.keys():
        user_preferences.notification_email = request.form['notification_email']
        user_preferences.notification_timeout = '{}{}'.format(
            request.form['notification_timeout_number'],
            request.form['notification_timeout_timespan']
        )
        user_preferences.save()

        if miband_dc.update_state_email != None:
            miband_dc.update_state_email = {
                'address': request.form['notification_email'],
                'timeout': '{}{}'.format(
                    request.form['notification_timeout_number'],
                    request.form['notification_timeout_timespan']
                )
            }
            miband_dc.save_settings()

        flash(gettext(u'Saved notifications email preferences'), 'success')
    else:
        if request.form['update_state_email'] == 'enabled':
            if user_preferences.notification_email == None:
                flash(gettext(u'Cannot enable if email preferences are not setted'),
                      'failure')
            else:
                miband_dc.update_state_email = {
                    'address': user_preferences.notification_email,
                    'timeout': user_preferences.notification_timeout
                }
                miband_dc.save_settings()
                flash(gettext(u'Saved notifications settings'), 'success')
        else:
            del miband_dc.update_state_email
            miband_dc.save_settings()
            flash(gettext(u'Saved notifications settings'), 'success')

    return redirect(url_for('miband_dc.settings', section='notifications'))


def hooks_settings():
    mm_bandupdater = get_packages().get('mm-bandupdater')

    if request.method == 'GET':
        lang = user_preferences.locale
        if user_preferences.locale == None:
            lang = request.accept_languages.best_match(['es', 'en'])

        return render_template(
            'hooks_settings.html',
            lang=lang,
            version=miband_dc.version,
            installed=miband_dc.installed,
            upgradable=miband_dc.upgradable,
            running=miband_dc.running,
            update_state_mm=miband_dc.update_state_mm,
            mm_modules={
                'mm-bandupdater': mm_bandupdater.installed if mm_bandupdater != None else False
            }
        )

    if request.form['update_state_mm'] == 'enabled':
        if mm_bandupdater == None:
            flash(gettext(u'Cannot enable if mm2-bandupdater is not installed'),
                  'failure')
        elif not mm_bandupdater.installed:
            flash(gettext(u'Cannot enable if mm2-bandupdater is not installed'),
                  'failure')
        else:
            miband_dc.update_state_mm = {
                'address': 'localhost:{}'.format(mm_bandupdater.config['port']),
                'timeout': '5m'
            }
    else:
        del miband_dc.update_state_mm

    miband_dc.save_settings()
    flash(gettext(u'Saved hooks settings'), 'success')
    return redirect(url_for('miband_dc.settings', section='hooks'))


def devices_settings():
    if request.method == 'GET':
        lang = user_preferences.locale
        if user_preferences.locale == None:
            lang = request.accept_languages.best_match(['es', 'en'])

        return render_template(
            'devices_settings.html',
            lang=lang,
            version=miband_dc.version,
            installed=miband_dc.installed,
            upgradable=miband_dc.upgradable,
            running=miband_dc.running,
            devices=miband_dc.devices
        )

    for attr, value in request.form.items():
        if attr == 'csrf_token':
            continue
        elif 'mac-' in attr:
            if attr.startswith('getted'):
                dev_id = attr.replace('getted-mac-', '')
            else:
                dev_id = attr.replace('mac-', '')

            token = request.form['getted-token-' + dev_id] if attr.startswith(
                'getted') else request.form['token-' + dev_id]
            if token == 'deleted':
                miband_dc.remove_device(value)
            else:
                miband_dc.add_device(value, token)
    miband_dc.save_devices()
    flash(gettext(u'Saved devices'), 'success')
    return redirect(url_for('miband_dc.settings', section='devices'))
