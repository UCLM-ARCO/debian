from .miband_dc import MiBandDataCollector, get_linked_devices
from .mm import MMBandUpdater
from .preferences import user_preferences

from functools import lru_cache


__packages = {}
__services = {}


@lru_cache()
def get_packages():
    if __packages.get('miband-dc') == None:
        if __services.get('miband-dc'):
            __packages['miband-dc'] = __services['miband-dc']
        else:
            try:
                __packages['miband-dc'] = MiBandDataCollector()
            except Exception as err:
                print(f'ERROR: Cannot init miband-dc due to: {err}')
            else:
                __services['miband-dc'] = __packages['miband-dc']

    if __packages.get('mm-bandupdater') == None:
        try:
            __packages['mm-bandupdater'] = MMBandUpdater()
        except Exception as err:
            print(f'ERROR: Cannot init mm-bandupdater due to: {err}')

    return __packages


@lru_cache()
def get_services():
    if __services.get('miband-dc') == None:
        if __packages.get('miband-dc'):
            __services['miband-dc'] = __packages['miband-dc']
        else:
            try:
                __services['miband-dc'] = MiBandDataCollector()
            except Exception as err:
                print(f'ERROR: Cannot init miband-dc due to: {err}')
            else:
                __packages['miband-dc'] = __services['miband-dc']
    
    return __services

def get_packages_status():
    if len(__packages) == 0:
        get_packages()

    retval = {}
    for name, obj in __packages.items():
        retval[name] = {
            'installed': obj.installed,
            'upgradable': obj.upgradable
        }

    return retval

def get_services_status():
    if len(__services) == 0:
        get_services()

    retval = {}
    for name, obj in __services.items():
        retval[name] = {
            'running': obj.running,
            'enabled': obj.enabled
        }

    return retval

