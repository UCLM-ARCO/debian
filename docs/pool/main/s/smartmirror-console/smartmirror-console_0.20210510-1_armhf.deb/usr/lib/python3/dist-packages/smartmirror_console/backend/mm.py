import abc
import os
import re
import sys

from slimit import ast, minify
from slimit.parser import Parser
from slimit.visitors import nodevisitor

from .utils import PackageResource

MM_CONFIGURATION = '/usr/share/magicmirror/config/config.js'
MM_MODULES = '/usr/share/magicmirror/modules'


def js2list(l: ast.Array):
    retval = []
    for item in l.items:
        if isinstance(item, ast.Object):
            retval.append(js2dict(item))
        elif isinstance(item, ast.Array):
            retval.append(js2list(item))
        elif isinstance(item, ast.Number):
            value = float(item.value)
            if value - int(value) == 0:
                value = int(value)
            retval.append(value)
        elif isinstance(item, ast.Boolean):
            retval.append(item.value == 'true')
        else:
            retval.append(item.value.strip('"'))
    return retval


def js2dict(obj: ast.Object):
    retval = {}
    for item in obj.properties:
        if isinstance(item, ast.Assign):
            key = item.left.value
            if isinstance(item.left, ast.Number):
                key = int(key)
            value = item.right

            if isinstance(value, ast.Object):
                retval[key] = js2dict(value)
            elif isinstance(value, ast.Array):
                retval[key] = js2list(value)
            elif isinstance(value, ast.Number):
                value = float(value.value)
                if value - int(value) == 0:
                    value = int(value)
                retval[key] = value
            elif isinstance(value, ast.Boolean):
                retval[key] = value.value == 'true'
            else:
                retval[key] = value.value.strip('"')
    return retval


class MMModule(PackageResource):
    def __init__(self, config_path: str = '/usr/share/magicmirror/config/config.js'):
        self.config_path = config_path
        self.position = None
        self.config = {}

        self.__load_config()

    def __load_config(self):
        with open(self.config_path) as fr:
            tree = Parser().parse(fr.read())

        for node in nodevisitor.visit(tree):
            if isinstance(node, ast.Assign) and node.left.value == 'modules':
                value = js2list(node.right)

                for module in value:
                    if module['module'] == self.name:
                        if 'position' in module.keys():
                            self.position = module['position']
                        if 'config' in module.keys():
                            self.config = module['config']
                        break
                break


class MMBandUpdater(MMModule):
    def __init__(self, config_path: str = '/usr/share/magicmirror/config/config.js'):
        super().__init__(config_path)

        if 'port' not in self.config:
            self.config['port'] = 8465
        if 'max_devices' not in self.config:
            self.config['max_devices'] = 10

    @property
    def name(self):
        return 'mm2-bandupdater'


# class MMConfiguration:
#     def __init__(self, filename: str):
#         self.filename = filename
#         self.config = {}
#         self.modules = []

#         self.__load()

#     def __load(self):
#         with open(self.filename) as fr:
#             tree = Parser().parse(fr.read())

#         for node in nodevisitor.visit(tree):
#             if isinstance(node, ast.Assign) and (
#                     isinstance(node.left, ast.Identifier) or isinstance(node.left, ast.Number)):
#                 key = node.left.value
#                 if isinstance(node.left, ast.Number):
#                     key = int(key)

#                 if isinstance(node.right, ast.Object):
#                     value = js2dict(node.right)
#                 elif isinstance(node.right, ast.Array):
#                     value = js2list(node.right)
#                 elif isinstance(node.right, ast.Number):
#                     value = float(node.right.value)
#                     if value - int(value) == 0:
#                         value = int(value)
#                 elif isinstance(node.right, ast.Boolean):
#                     value = node.right.value == 'true'
#                 else:
#                     value = node.right.value.strip('"')

#                 if value == None:
#                     continue
#                 elif key in ['address', 'port', 'basePath', 'ipWhitelist', 'useHttps', 'httpsPrivateKey',
#                              'httpsCertificate', 'language', 'logLevel', 'timeFormat', 'units', 'zoom'] and key not in self.config.keys():
#                     self.config[key] = value
#                 elif key == 'modules' and len(self.modules) == 0:
#                     self.modules = value

#     def save(self):
#         with open(self.filename) as fr:
#             tree = Parser().parse(fr.read())

#         for node in nodevisitor.visit(tree):
#             if isinstance(node, ast.Assign) and (
#                     isinstance(node.left, ast.Identifier) or isinstance(node.left, ast.Number)):
#                 left = node.left
#                 right = node.right

#                 if left.value == 'language':
#                     right.value = '"es"'

#                 node.right = right
