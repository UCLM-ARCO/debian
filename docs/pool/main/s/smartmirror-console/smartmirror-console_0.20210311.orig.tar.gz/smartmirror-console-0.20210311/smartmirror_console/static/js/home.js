function create_empty_device_row(device_id) {
    var template = document.createElement("template")
    template.innerHTML = `<tr id="row-` + device_id + `" class="devices-row tmp-row table-success">
        <th scope="row" class="col-1">` + device_id + `</th>
        <td class="col-2">
            <input id="mac-` + device_id + `" class="form-control form-control-sm devices-mac" type="text"
                placeholder="00:00:00:00:00:00" pattern="([A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2}"
                onchange="change_mac(this)" required>
        </td>
        <td class="col">
            <input id="token-` + device_id + `" class="form-control"
                placeholder="********************************"
                pattern="[A-Za-z0-9]{32}" required>
        </td>
        <td class="col-1">
            <button id="delete-device-` + device_id + `-btn"
                class="btn btn-danger delete-device-btn" type="button"
                onclick="row = this.parentNode.parentNode; row.parentNode.removeChild(row)">Delete</button>
        </td>
    </tr>`.trim()
    return template.content.firstChild
}

function create_device_row(device_id, mac, token) {
    var template = document.createElement("template")
    template.innerHTML = `<tr id="row-` + device_id + `" class="devices-row tmp-row table-success">
        <th scope="row" class="col-1">` + device_id + `</th>
        <td id="mac-` + device_id + `" class="col-2 devices-mac">` + mac + `</td>
        <td class="col">
            <input id="token-` + device_id + `" name="` + mac + `" class="form-control"
                placeholder="********************************" value="` + token + `"
                pattern="[A-Za-z0-9]{32}" readonly required>
        </td>
        <td class="col-1">
            <div class="btn-group" role="group">
                <button id="edit-token-` + device_id + `-btn"
                    class="btn btn-outline-secondary edit-token-btn" type="button"
                    data-bs-toggle="button"
                    onclick="input = document.getElementById('token-' + this.id.split('-')[2]); input.readOnly = !input.readOnly">Edit</button>
                <button id="delete-device-` + device_id + `-btn"
                    class="btn btn-danger delete-device-btn" type="button"
                    onclick="row = this.parentNode.parentNode.parentNode; row.parentNode.removeChild(row)">Delete</button>
            </div>
        </td>
    </tr>`.trim()
    return template.content.firstChild
}

function change_mac(input) {
    if (is_mac_duplicated(input.value, input.id) == "") {
        $('#token-' + input.id.split('-')[1]).attr('name', input.value)
        input.setCustomValidity('')
    } else {
        input.setCustomValidity('MAC address cannot be duplicated')
    }
}

function add_device(mac = undefined, token = undefined) {
    var table_body = document.getElementById("devices-table-body")
    var next_device = parseInt(table_body.lastElementChild.id.replace("row-", "")) + 1

    if (mac == undefined && token == undefined) {
        table_body.appendChild(create_empty_device_row(next_device))
    } else {
        found_id = is_mac_duplicated(mac)
        if (found_id !== "") {
            device_id = found_id.split('-')[1]
            if ($('#token-' + device_id).val() !== token) {
                $('#token-' + device_id).val(token)
                $('#edit-token-' + device_id + '-btn').attr("disabled", false)
                $('#delete-device-' + device_id + '-btn').attr("disabled", false)
                $('#row-' + device_id)
                    .removeClass('table-success table-danger table-warning')
                    .addClass('table-warning')
            }
        } else
            table_body.appendChild(create_device_row(next_device, mac, token))
    }
}

function is_mac_duplicated(mac, element_id = undefined) {
    var retval = ""
    $("td.devices-mac").each(function () {
        if (retval !== "")
            return false
        if (element_id !== undefined && this.id == element_id)
            return
        if (this.textContent == mac)
            retval = this.id
    })
    $("input.devices-mac").each(function () {
        if (retval !== "")
            return false
        if (element_id !== undefined && this.id == element_id)
            return
        if (this.value == mac)
            retval = this.id
    })
    return retval
}

function modify_package(name, action) {
    $('.action-btn').attr("disabled", true)
    $('#miband-dc-settings-spinner').removeClass('visually-hidden')
    $.ajax({
        url: '/api/' + name,
        data: JSON.stringify({
            action: action
        }),
        contentType: "application/json; charset=UTF-8",
        type: 'POST',
        dataType: 'json'
    }).done(function (json) {
        console.log(json)
        location.reload()
    }).fail(function (xhr) {
        console.dir(xhr)
    })
}

$('.delete-device-btn').click(function (event) {
    event.target.disabled = true
    var device_id = event.target.id.split('-')[2]
    $('#token-' + device_id).val('deleted')
    $('#edit-token-' + device_id + '-btn').attr("disabled", true)
    $('#row-' + device_id)
        .removeClass("table-success table-danger table-warning")
        .addClass("table-danger")
})

$("#generate-token-form").submit(function (event) {
    event.preventDefault()
    $("#generate-token-submit").attr("disabled", true)
    $("#generate-token-spinner").removeClass("visually-hidden")

    var result = document.getElementById("generate-token-result").querySelector("div[class='card card-body']")
    while (result.firstChild) {
        result.removeChild(result.firstChild)
    }

    var result_template = document.createElement("template")

    var collapse = new bootstrap.Collapse(
        document.getElementById("generate-token-result"),
        { toggle: false }
    )
    collapse.hide()

    $.ajax({
        url: '/get-token',
        data: JSON.stringify({
            email: $("#mifit-email").val(),
            password: $('#mifit-password').val()
        }),
        type: "POST",
        contentType: "application/json; charset=UTF-8",
        dataType: "json"
    }).done(function (json) {
        result.classList.add("text-dark")
        result_template.innerHTML = `<p>Your active device is:<br><br>
        MAC address: <b id="mifit-mac">`+ json['mac'] + `</b><br>
        Token: <b id="mifit-token">`+ json['token'] + `</b><br><br>

        <button class="btn btn-outline-secondary" type="button"
            onclick="add_device(document.getElementById('mifit-mac').textContent, document.getElementById('mifit-token').textContent)">Add to devices</button>
        </p>`.trim()
    }).fail(function (xhr, status, error) {
        result.classList.add("text-danger")
        result_template.innerHTML = `<p>An error ocurred:<br><br>` + xhr.responseJSON['msg'] + `</p>`.trim()
    }).always(function (xhr, status) {
        $("#generate-token-submit").attr("disabled", false)
        $("#generate-token-spinner").addClass("visually-hidden")
        result.appendChild(result_template.content.firstChild)
        collapse.show()
    })
})

$("#devices-form").on('reset', function (event) {
    $(".tmp-row").remove()
    $(".edit-token-btn").each(function () {
        this.disabled = false
        if (this.classList.contains('active'))
            $('#' + this.id).trigger('click')
    })
    
    $(".delete-device-btn").each(function () { this.disabled = false })
    $(".devices-row").removeClass("table-success table-danger table-warning")
})

$(document).ready(function () {
    $(".toast").each(function () {
        var toast = new bootstrap.Toast(this)
        toast.show()
    })
    $.ajaxSetup({
        beforeSend: function (xhr, settings) {
            if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type) && !this.crossDomain) {
                xhr.setRequestHeader("X-CSRFToken", csrf_token);
            }
        }
    });
})