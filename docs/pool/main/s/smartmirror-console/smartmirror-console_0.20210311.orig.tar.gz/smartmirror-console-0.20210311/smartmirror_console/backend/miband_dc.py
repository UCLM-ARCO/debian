import os.path

from .utils.linux import AptPackage, SystemCtlService
from .utils.huami_token.huami_token import HuamiAmazfit


def get_active_device(email: str, password: str):
    device = HuamiAmazfit(
        email=email,
        password=password
    )
    try:
        device.login()
    except ValueError as err:
        raise ValueError(
            f"error on login to account: {err}")

    try:
        wereable = device.get_wearables()[0]
    except ValueError as err:
        raise ValueError(
            f"error on getting device info: {err}")
    finally:
        device.logout()

    return (wereable['mac_address'], wereable['auth_key'][2:])


class MiBand_DataCollector(AptPackage, SystemCtlService):
    ACTIONS = AptPackage.ACTIONS + SystemCtlService.ACTIONS

    def __init__(self,
                 devices_path: str = '/etc/miband-dc/devices.csv'):
        AptPackage.__init__(self)
        SystemCtlService.__init__(self)

        self.devices_path = devices_path
        self.__load_devices()

    @property
    def name(self):
        return 'miband-dc'

    def __load_devices(self):
        self.devices = {}
        with open(self.devices_path) as fr:
            for line in fr:
                line = line.strip(' \n\t')
                if not line.startswith('#') and line != '':
                    values = line.split('|')
                    self.devices[values[1].strip(
                        ' \n\t')] = values[2].strip(' \n\t')

    def add_device(self, mac: str, token: str):
        self.devices[mac] = token

    def remove_device(self, mac: str):
        if mac not in self.devices.keys():
            return False
        self.devices.pop(mac)
        return True

    def save_devices(self):
        with open(self.devices_path, "w") as fw:
            index = 1
            for mac, token in self.devices.items():
                fw.write(f"{index} | {mac} | {token}\n")
                index += 1

    def get(self):
        retval = {}
        for k, v in AptPackage.get(self).items():
            retval[k] = v
        for k, v in SystemCtlService.get(self).items():
            retval[k] = v
        return retval
