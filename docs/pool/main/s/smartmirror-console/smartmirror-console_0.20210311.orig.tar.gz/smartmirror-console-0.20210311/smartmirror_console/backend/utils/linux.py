import abc
import os

from apt import Cache
from flask_restful import Resource, reqparse

apt_cache = Cache()


class AbstractResourceMeta(type(Resource), type(abc.ABC)):
    pass


class AptPackage(Resource, abc.ABC, metaclass=AbstractResourceMeta):
    ACTIONS = ['install', 'upgrade', 'uninstall']

    def __init__(self):
        try:
            self.package = apt_cache[self.name]
        except KeyError:
            raise RuntimeError(f"package '{self.name}' not found in apt cache")

    @abc.abstractproperty
    def name(self):
        return 'invalid'

    @property
    def version(self):
        if self.installed:
            return self.package.installed.version
        return None

    @property
    def installed(self):
        return self.package.is_installed

    @property
    def upgradable(self):
        return self.package.is_upgradable

    def __update_cache(self):
        retval = apt_cache.commit()
        apt_cache.update()
        apt_cache.open(None)
        return retval

    def install(self):
        if self.installed:
            return False
        self.package.mark_install()
        return self.__update_cache()

    def upgrade(self):
        if not self.upgradable:
            return False
        self.package.mark_upgrade()
        return self.__update_cache()

    def uninstall(self):
        if not self.installed:
            return False
        self.package.mark_delete()
        return self.__update_cache()

    def get(self):
        return {
            'package': {
                'name': self.name,
                'installed': self.installed,
                'upgradable': self.upgradable
            }
        }

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument(
            'action', required=True,
            type=str, choices=self.ACTIONS
        )
        args = parser.parse_args()
        return {
            'action': args.action,
            'success': eval(f'self.{args.action}()')
        }


class SystemCtlService(Resource, abc.ABC, metaclass=AbstractResourceMeta):
    ACTIONS = [
        'start', 'stop', 'restart', 'enable', 'disable'
    ]

    @abc.abstractproperty
    def name(self):
        return 'invalid'

    @property
    def running(self):
        return os.system(f'systemctl --quiet is-active {self.name}') == 0

    @property
    def enabled(self):
        return os.system(f'systemctl --quiet is-enabled {self.name}') == 0

    def start(self):
        return os.system(f'sudo systemctl start {self.name}') == 0

    def stop(self):
        return os.system(f'sudo systemctl stop {self.name}') == 0

    def restart(self):
        return os.system(f'sudo systemctl restart {self.name}') == 0

    def enable(self):
        return os.system(f'sudo systemctl enable {self.name}') == 0

    def disable(self):
        return os.system(f'sudo systemctl disable {self.name}') == 0

    def get(self):
        return {
            'service': {
                'name': self.name,
                'running': self.running,
                'enabled': self.enabled
            }
        }

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument(
            'action', required=True,
            type=str, choices=self.ACTIONS
        )
        args = parser.parse_args()
        return {
            'action': args.action,
            'success': eval(f'self.{args.action}()')
        }
