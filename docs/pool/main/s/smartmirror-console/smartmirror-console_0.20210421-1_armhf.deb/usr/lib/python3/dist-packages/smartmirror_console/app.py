#!/usr/bin/python3

import os.path
from datetime import datetime, timedelta
from functools import wraps

import flask_wtf
import peewee
from flask import (Flask, abort, flash, jsonify, make_response, redirect,
                   render_template, request, session, url_for)
from flask_peewee.db import Database
from flask_security import (PeeweeUserDatastore, RoleMixin, Security,
                            UserMixin, current_user, login_required)
from markupsafe import escape

from .backend.miband_dc import MiBandDataCollector, get_linked_devices

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(32)

if app.config['ENV'] == 'development':
    app.config['DATABASE'] = {
        'name': os.path.dirname(
            os.path.abspath(__file__)) +
        '/../smartmirror-console.db',
        'engine': 'peewee.SqliteDatabase'
    }
else:
    app.config['DATABASE'] = {
        'name': '/etc/smartmirror-console/smartmirror-console.db',
        'engine': 'peewee.SqliteDatabase',
    }

flask_wtf.CSRFProtect(app)

db = Database(app)

PACKAGES = []
SERVICES = []

MIBAND_DC = None
try:
    MIBAND_DC = MiBandDataCollector()
except IOError as err:
    print(f'ERROR: Could not initialise miband-dc info. {err}')
else:
    PACKAGES.append(MIBAND_DC)
    SERVICES.append(MIBAND_DC)


class Role(db.Model, RoleMixin):
    name = peewee.CharField(unique=True)
    description = peewee.TextField(null=True)


class User(db.Model, UserMixin):
    email = peewee.TextField()
    password = peewee.TextField()
    active = peewee.BooleanField(default=True)
    confirmed_at = peewee.DateTimeField(null=True)
    notifications_email = peewee.CharField(null=True, default=None)
    notifications_timeout = peewee.CharField(null=True, default=None)


class UserRoles(db.Model):
    user = peewee.ForeignKeyField(User, related_name='roles')
    role = peewee.ForeignKeyField(Role, related_name='users')
    name = property(lambda self: self.role.name)
    description = property(lambda self: self.role.description)


user_datastore = PeeweeUserDatastore(db, User, Role, UserRoles)
security = Security(app, user_datastore)


@app.before_first_request
def create_default_user():
    # FIXME Change default password after first login
    for model in (User, Role, UserRoles):
        model.create_table(safe=True, fail_silently=True)
    if not user_datastore.find_user(email='admin'):
        user_datastore.create_user(email='admin', password='admin')
    if not db.database.is_closed():
        db.database.close()


@app.route("/")
@login_required
def index():
    packages = {}
    for package in PACKAGES:
        packages[package.name] = {
            'installed': package.installed,
            'upgraded': package.upgradable
        }

    services = {}
    for service in SERVICES:
        services[service.name] = {
            'running': service.running,
            'enabled': service.enabled
        }

    return render_template(
        'home.html',
        packages=packages,
        services=services
    )


@app.route('/miband-dc', methods=['GET'])
@app.route('/miband-dc/settings', methods=['GET'])
@login_required
def miband_dc_settings_redirect():
    return redirect(url_for('miband_dc_settings', section='database'))


@app.route('/miband-dc/settings/<string:section>', methods=['GET', 'POST'])
@login_required
def miband_dc_settings(section):
    if MIBAND_DC == None:
        abort(500)
    elif section not in [
        'database',
        'charging-station',
        'notifications',
        'hooks',
            'devices']:
        abort(404)
    elif request.method == 'GET':
        return render_template(
            'miband_dc.html',
            section=section,
            **MIBAND_DC.to_dict(),
            email_config={
                'address': current_user.notifications_email,
                'timeout': current_user.notifications_timeout
            }
        )
    else:
        if section == 'database':
            MIBAND_DC.db_name = request.form['db_name']
            MIBAND_DC.db_host = request.form['db_host']
            MIBAND_DC.db_user = request.form['db_user']
            MIBAND_DC.db_passwd = request.form['db_passwd']
            MIBAND_DC.save_settings()
            flash('Saved database settings', 'success')
        elif section == 'charging-station':
            if request.form['charging_station'] == 'enabled':
                MIBAND_DC.update_mode = 'charging'
            else:
                del MIBAND_DC.update_mode
            MIBAND_DC.save_settings()
            flash('Saved charging station settings', 'success')
        elif section == 'notifications':
            if 'notification_email' in request.form.keys():
                current_user.notifications_email = request.form['notification_email']
                current_user.notifications_timeout = '{}{}'.format(
                    request.form['notification_timeout_number'],
                    request.form['notification_timeout_timespan']
                )
                user_datastore.put(current_user)

                if MIBAND_DC.update_state_email != None:
                    MIBAND_DC.update_state_email = {
                        'address': current_user.notifications_email,
                        'timeout': current_user.notifications_timeout
                    }
                    MIBAND_DC.save_settings()

                flash('Saved notifications email preferences', 'success')
            else:
                if request.form['update_state_mail'] == 'enabled':
                    if current_user.notifications_email == None:
                        flash(
                            'Cannot enable if email preferences are not setted',
                            'failure')
                    else:
                        MIBAND_DC.update_state_email = {
                            'address': current_user.notifications_email,
                            'timeout': current_user.notifications_timeout
                        }
                        MIBAND_DC.save_settings()
                        flash('Saved notifications settings', 'success')
                else:
                    del MIBAND_DC.update_state_email
                    MIBAND_DC.save_settings()
                    flash('Saved notifications settings', 'success')
        elif section == 'hooks':
            if request.form['update_state_mm'] == 'enabled':
                # FIXME Check config of Magic Mirror to do it automatically
                MIBAND_DC.update_state_mm = {
                    'address': 'localhost:8465',
                    'timeout': '5m'
                }
            else:
                del MIBAND_DC.update_state_mm
            MIBAND_DC.save_settings()
            flash('Saved hooks settings', 'success')
        elif section == 'devices':
            for attr, value in request.form.items():
                if attr == 'csrf_token':
                    continue
                elif 'mac-' in attr:
                    dev_id = attr.replace(
                        'getted-mac-',
                        '') if attr.startswith('getted') else attr.replace(
                        'mac-',
                        '')
                    token = request.form['getted-token-' + dev_id] if attr.startswith(
                        'getted') else request.form['token-' + dev_id]
                    if token == 'deleted':
                        MIBAND_DC.remove_device(value)
                    else:
                        MIBAND_DC.add_device(value, token)
            MIBAND_DC.save_devices()
            flash('Saved devices', 'success')

        # TODO MIBAND_DC.restart()

        return redirect(url_for('miband_dc_settings', section=section))


@app.route('/miband-dc/get-token', methods=['POST'])
@login_required
def get_token():
    data = request.get_json()
    if data == None or 'email' not in data or 'password' not in data:
        abort(400)
    retval = {}
    try:
        index = 0
        for mac, token in get_linked_devices(
            data['email'], data['password']
        ).items():
            retval[index] = {
                'mac': mac,
                'token': token
            }
            index += 1
        retval['length'] = index
    except ValueError as err:
        return make_response((
            jsonify({'msg': str(err)}), 400
        ))
    return jsonify(retval)


@app.route('/<string:name>/<string:action>', methods=['GET'])
@login_required
def do(name, action):
    target = None
    for package in PACKAGES:
        if package.name == name:
            target = package
            break

    for service in SERVICES:
        if target != None:
            break
        elif service.name == name:
            target = service
            break

    if target == None or action not in target.ACTIONS:
        abort(404)
    elif action == 'status':
        return '<pre>' + target.journal().replace('\n', '</br>') + '</pre>'

    success, output, error = eval(f'target.{action}()')

    if success:
        flash(f'Executed {action} on {name}', 'success')
    else:
        flash(f'Error on {action}: {error}', 'failure')

    return redirect(request.environ.get('HTTP_REFERER'))
