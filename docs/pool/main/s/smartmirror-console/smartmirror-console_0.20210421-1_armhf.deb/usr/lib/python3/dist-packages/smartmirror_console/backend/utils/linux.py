import abc
import os
import subprocess
from datetime import datetime, timedelta
from functools import wraps

from apt import Cache

APT_CACHE = Cache()


def is_superuser(fn):
    @wraps(fn)
    def _deco(self, *args, **kwargs):
        if os.getuid() != 0:
            raise RuntimeError('Not running as superuser')
        return fn(self, *args, **kwargs)
    return _deco


def commit_and_update(fn):
    @wraps(fn)
    def _deco(self, *args, **kwargs):
        retval = fn(self, *args, **kwargs)
        if retval[0]:
            APT_CACHE.commit()
            APT_CACHE.update()
            APT_CACHE.open(None)
        print(fn)
        print(self)
        print(retval)
        return retval
    return _deco


class ServiceResource(abc.ABC):
    ACTIONS = ['start', 'restart', 'stop', 'enable', 'disable', 'status']

    @abc.abstractproperty
    def name(self) -> str:
        return 'invalid'

    @property
    def running(self) -> bool:
        return subprocess.run(
            args=['systemctl', '--quiet', 'is-active', self.name]
        ).returncode == 0

    @property
    def enabled(self) -> bool:
        return subprocess.run(
            args=['systemctl', '--quiet', 'is-enabled', self.name]
        ).returncode == 0

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        return hash(self) == hash(other)

    def status(self) -> str:
        result = subprocess.run(
            args=['systemctl', 'status', self.name],
            capture_output=True,
            encoding='utf-8')
        if result.returncode != 4:  # service dont exists
            return result.stdout
        return result.stdout

    def journal(
            self,
            since: datetime = datetime.now() -
            timedelta(
            days=1)) -> str:
        result = subprocess.run(
            args=[
                'journalctl',
                '-u',
                self.name,
                '--since={}'.format(since.strftime('%Y-%m-%d %H:%M:%S'))],
            capture_output=True,
            encoding='utf-8')
        if result.returncode == 0:
            return result.stdout
        return result.stderr

    @is_superuser
    def start(self) -> tuple:
        result = subprocess.run(
            args=['sudo', 'systemctl', 'start', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    @is_superuser
    def stop(self):
        result = subprocess.run(
            args=['sudo', 'systemctl', 'stop', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    @is_superuser
    def restart(self):
        result = subprocess.run(
            args=['sudo', 'systemctl', 'restart', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    @is_superuser
    def enable(self):
        result = subprocess.run(
            args=['sudo', 'systemctl', 'enable', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    @is_superuser
    def disable(self):
        result = subprocess.run(
            args=['sudo', 'systemctl', 'disable', self.name],
            capture_output=True,
            encoding='utf-8')
        return (result.returncode == 0, result.stdout, result.stderr)

    def to_dict(self):
        return {
            'running': self.running,
            'enabled': self.enabled
        }


class PackageResource(abc.ABC):
    ACTIONS = ['install', 'uninstall', 'upgrade']

    @abc.abstractproperty
    def name(self) -> str:
        return 'invalid'

    @property
    def version(self) -> str:
        if self.name not in APT_CACHE or not self.installed:
            return None
        return APT_CACHE[self.name].installed.version

    @property
    def installed(self) -> bool:
        if self.name not in APT_CACHE:
            return False
        return APT_CACHE[self.name].is_installed

    @property
    def upgradable(self) -> bool:
        if self.name not in APT_CACHE:
            return False
        return APT_CACHE[self.name].is_upgradable

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        return hash(self) == hash(other)

    @commit_and_update
    def install(self):
        if self.name not in APT_CACHE:
            return (False, None, f'Package {self.name} does not exist')
        elif self.installed:
            return (False, None, f'Package {self.name} is already installed')
        APT_CACHE[self.name].mark_install()
        return (True, f'Package succesfully installed', None)

    @commit_and_update
    def upgrade(self):
        if self.name not in APT_CACHE:
            return (False, None, f'Package {self.name} does not exist')
        elif not self.upgradable:
            return (False, None, f'Package {self.name} cannot be upgraded')
        APT_CACHE[self.name].mark_upgrade()
        return (True, f'Package succesfully upgraded', None)

    @commit_and_update
    def uninstall(self):
        if self.name not in APT_CACHE:
            return (False, None, f'Package {self.name} does not exist')
        if not self.installed:
            return (False, None, f'Package {self.name} is not installed')
        APT_CACHE[self.name].mark_delete()
        return (True, f'Package succesfully uninstalled', None)

    def to_dict(self):
        return {
            'version': self.version,
            'installed': self.installed,
            'upgradable': self.upgradable
        }


class PackageWithServiceResource(ServiceResource, PackageResource):
    ACTIONS = ServiceResource.ACTIONS + PackageResource.ACTIONS

    def to_dict(self):
        retval = {}
        retval.update(ServiceResource.to_dict(self))
        retval.update(PackageResource.to_dict(self))
        return retval
