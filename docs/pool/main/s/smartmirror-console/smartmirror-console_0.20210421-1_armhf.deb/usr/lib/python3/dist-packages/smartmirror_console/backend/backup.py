import json
import os
import re
import subprocess
from shutil import which

import jsbeautifier
from apt import Cache, Package
from flask_restful import Resource, reqparse

from .utils.huami_token.huami_token import HuamiAmazfit

apt_cache = Cache()


class Settings:
    def __init__(self, path: str):
        self.path = path
        with open(path) as fr:
            for k, v in json.load(fr).items():
                setattr(self, k, v)


class MMConfiguration:
    LAYOUT_POSITIONS = [
        "top_bar", "top_left", "top_center",
        "top_right", "upper_third", "middle_center",
        "lower_third", "bottom_left", "bottom_center",
        "bottom_right", "bottom_bar", "fullscreen_above",
        "fullscreen_below"
    ]

    def __init__(self, path: str,
                 options: dict,
                 builtin_modules: list,
                 shapes_modules: dict):
        self.path = path
        self.options = {}
        self.default_options = options
        self.modules = {}
        self.module_packages = {}
        self.layout = {}

        content = self.get_raw()
        self.__load_options(options, content)
        self.__load_modules(builtin_modules, content)
        self.__load_modules(shapes_modules, content)
        self.__load_layout(content)

    def __load_options(self, options: dict,
                       content: str):
        for option, default_value in options.items():
            if isinstance(default_value, str):
                match = re.search(rf'{option}: "(.*)",?', content)
                self.options[option] = match.group(
                    1) if match else default_value
            elif isinstance(default_value, int):
                match = re.search(rf'{option}: (\d*),?', content)
                self.options[option] = int(
                    match.group(1)) if match else default_value
            elif isinstance(default_value, bool):
                match = re.search(rf'{option}: (false|true),?', content)
                self.options[option] = match.group(
                    1).lower() == "true" if match else default_value
            elif isinstance(default_value, list):
                match = re.search(rf'{option}: (\[\.*\]),?', content)
                self.options[option] = eval(
                    match.group(1)) if match else default_value
            else:
                raise TypeError(f"'{type(default_value)}' type not valid")

    def __load_modules(self, module_collection,
                       content: str):
        if isinstance(module_collection, dict):
            for name, package in module_collection.items():
                self.module_packages[name] = package
            module_collection = list(module_collection.keys())

        for name in module_collection:
            self.modules[name] = re.search(
                rf'module: "{name}"', content) is not None

    def __load_layout(self, content: str):
        for position in self.LAYOUT_POSITIONS:
            self.layout[position] = None
        for module_name, is_present in self.modules.items():
            if is_present:
                match = re.search(
                    rf'module: "{module_name}",\s*position: "(.*)",?',
                    content
                )
                if not match:
                    raise ValueError(f"module '{module_name}' has no position")
                elif match.group(1) not in self.LAYOUT_POSITIONS:
                    raise ValueError(f"invalid position '{match.group(1)}'")
                self.layout[match.group(1)] = module_name

    def __replace_options(self, content: str):
        init_of_options = 'var config = {'
        for option, value in self.options.items():
            if isinstance(value, str):
                match = re.search(rf'{option}: "(.*)"', content)
                replace = '{}: "{}"'.format(option, value)
                if match:
                    replace = f'{init_of_options} {replace}'
            elif isinstance(value, int):
                match = re.search(rf'{option}: (\d*)', content)
                replace = '{}: {}'.format(option, value)
                if match:
                    replace = f'{init_of_options} {replace}'
            elif isinstance(value, bool):
                match = re.search(rf'{option}: (false|true)', content)
                replace = '{}: {}'.format(option, "true" if value else "false")
                if match:
                    replace = f'{init_of_options} {replace}'
            elif isinstance(value, list):
                match = re.search(rf'{option}: (\[\.*\])', content)
                replace = '{}: {}'.format(
                    option, str(value).replace("'", "\""))
                if match:
                    replace = f'{init_of_options} {replace}'
            else:
                raise TypeError(f"'{type(value)}' type not valid")

            content = jsbeautifier.beautify(content.replace(
                match.group(0) if match else init_of_options,
                replace
            ))
        return content

    def __replace_modules(self, content: str):
        init_of_modules = 'modules: ['
        for name, is_present in self.modules.items():
            match = re.search(rf'module: "{name}"', content)
            if is_present and not match:
                content = content.replace(
                    init_of_modules,
                    '{}{{module: "{}"}},'.format(init_of_modules, name)
                )
            elif not is_present and match:
                start = content.rfind('{', 0, match.start())
                end = re.compile(r'\},?\s*').search(content, match.end()).end()
                content = content.replace(
                    content[start:end], ''
                )
            content = jsbeautifier.beautify(content)
        return content

    def __replace_layout(self, content: str):
        for position, module in self.layout.items():
            if module is not None:
                match = re.search(
                    rf'module: "{module}",\s*position: "(.*)"', content
                )
                if match:
                    if match.group(1) != position:
                        content = content.replace(
                            match.group(0),
                            f'module: "{module}", position: "{position}"'
                        )
                else:
                    content = content.replace(
                        f'module: "{module}"',
                        f'module: "{module}", position: "{position}"'
                    )
            content = jsbeautifier.beautify(content)
        return content

    def save(self):
        content = self.get_raw()
        content = self.__replace_options(content)
        content = self.__replace_modules(content)
        content = self.__replace_layout(content)
        with open(self.path, "w") as fw:
            fw.write(content)

    def get_raw(self):
        with open(self.path) as fr:
            retval = jsbeautifier.beautify(fr.read())
        return retval

    def get_option_value(self, name: str):
        return self.options[name]

    def get_default_option_value(self, name: str):
        return self.default_options[name]

    def is_module_present(self, name: str):
        return self.modules[name]

    def move_module(self, name: str, position: str):
        if not self.modules[name]:
            raise KeyError("module {name} is not present")
        elif position not in self.LAYOUT_POSITIONS:
            raise ValueError(f"invalid position {position}")
        for lposition, module in self.layout.items():
            if module == name:
                self.layout[lposition] = None
                break
        self.layout[position] = name

    def enable_module(self, name: str):
        self.modules[name] = True

    def disable_module(self, name: str):
        self.modules[name] = False

    # def install_module(self, name: str):
    #     pass

    # def uninstall_module(self, name: str):
    #     pass

    @staticmethod
    def from_settings(settings: Settings):
        return MMConfiguration(
            settings.mm2_config_path,
            settings.mm2_options,
            settings.mm2_modules_builtin,
            settings.mm2_modules_shapes
        )


class DataCollectorDevices(Resource):
    def __init__(self, path: str):
        self.path = path
        self.devices = {}

        self.__load_devices()

    def __load_devices(self):
        with open(self.path) as fr:
            for line in fr:
                line = line.strip(' \n\t')
                if not line.startswith('#') and line != '':
                    values = line.split('|')
                    self.devices[values[1].strip(
                        ' \n\t')] = values[2].strip(' \n\t')

    def get_raw(self):
        with open(self.path) as fr:
            retval = fr.read()
        return retval

    def add_device(self, mac: str, token: str):
        self.devices[mac] = token

    def delete_device(self, mac: str):
        if mac not in self.devices.keys():
            return False
        self.devices.pop(mac)
        return True

    def get_active_device(self, email: str,
                          password: str):
        device = HuamiAmazfit(
            email=email,
            password=password
        )
        try:
            device.login()
        except ValueError as err:
            raise ValueError(
                f"error on login to account: {err}")

        try:
            wereable = device.get_wearables()[0]
        except ValueError as err:
            raise ValueError(
                f"error on getting device info: {err}")
        finally:
            device.logout()

        return (wereable['mac_address'], wereable['auth_key'][2:])

    def save(self):
        with open(self.path, "w") as fw:
            index = 1
            for mac, token in self.devices.items():
                fw.write(f"{index} | {mac} | {token}\n")
                index += 1


class DataCollector(Resource):
    NAME = 'miband-dc'
    ACTIONS = [
        'install', 'uninstall',
        'start', 'stop',
        'restart', 'enable',
        'disable'
    ]
    SYSTEMCTL_FORMAT = 'sudo systemctl {action} ' + NAME

    PACKAGE = apt_cache[NAME]

    @property
    def name(self):
        return self.NAME

    @property
    def version(self):
        if self.installed:
            return self.PACKAGE.installed.version
        else:
            return self.PACKAGE.candidate.version

    @property
    def installed(self):
        return self.PACKAGE.is_installed

    @property
    def upgradable(self):
        return self.PACKAGE.is_upgradable

    @property
    def running(self):
        return os.system(f'systemctl --quiet is-active {self.NAME}') == 0

    @property
    def enabled(self):
        return os.system(f'systemctl --quiet is-enabled {self.NAME}') == 0

    def get(self):
        return {
            'name': self.NAME,
            'installed': self.installed,
            'upgradable': self.upgradable,
            'running': self.running,
            'enabled': self.enabled
        }

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument(
            'action',
            required=True,
            type=str,
            choices=self.ACTIONS,
            help="Action to perform"
        )
        args = parser.parse_args()

        return {
            'changed': eval(f'self.{args.action}()')
        }

    def install(self):
        if not self.installed:
            self.PACKAGE.mark_install()
        elif self.upgradable:
            self.PACKAGE.mark_upgrade()
        else:
            return False
        retval = apt_cache.commit()
        apt_cache.update()
        apt_cache.open(None)
        return retval

    def uninstall(self):
        if self.installed:
            self.PACKAGE.mark_delete()
        else:
            return False
        retval = apt_cache.commit()
        apt_cache.update()
        apt_cache.open(None)
        return retval

    def start(self):
        return os.system(self.SYSTEMCTL_FORMAT.format(action='start')) == 0

    def restart(self):
        return os.system(self.SYSTEMCTL_FORMAT.format(action='restart')) == 0

    def stop(self):
        return os.system(self.SYSTEMCTL_FORMAT.format(action='stop')) == 0

    def enable(self):
        return os.system(self.SYSTEMCTL_FORMAT.format(action='enable')) == 0

    def disable(self):
        return os.system(self.SYSTEMCTL_FORMAT.format(action='disable')) == 0
