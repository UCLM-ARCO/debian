from functools import lru_cache, wraps

from flask import redirect, request, url_for
from flask_babel import refresh
from flask_security import current_user, url_for_security
from flask_security.utils import verify_and_update_password
from smartmirror_console.backend.preferences import user_preferences


@lru_cache()
def has_default_password(user):
    return verify_and_update_password('admin', user)


def login_and_change_password_required(fn):
    @wraps(fn)
    def _deco(*args, **kwargs):
        change_default_ep = 'change_default_password_page.show'

        if not current_user.is_authenticated:
            if request.endpoint != change_default_ep:
                return redirect(url_for_security('login', next=url_for(request.endpoint, **request.view_args)))
            return redirect(url_for_security('login', next='/'))

        if has_default_password(current_user):
            if request.endpoint != change_default_ep:
                return redirect(url_for(change_default_ep, next=url_for(request.endpoint,**request.view_args)))
            return redirect(url_for(change_default_ep, next='/'))

        return fn(*args, **kwargs)
    return _deco

def check_language(fn):
    @wraps(fn)
    def _deco(*args, **kwargs):
        lang = request.args.get('lang')
        if lang != None and lang in user_preferences.AVAILABLE_LOCALE:
            user_preferences.locale = lang
            user_preferences.save()
            refresh()
        return fn(*args, **kwargs)
    return _deco
