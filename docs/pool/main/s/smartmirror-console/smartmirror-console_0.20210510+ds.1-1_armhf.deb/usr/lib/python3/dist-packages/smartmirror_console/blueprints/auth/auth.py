from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_security import current_user, login_required
from flask_security.core import current_app
from flask_security.forms import get_message
from flask_security.utils import verify_and_update_password, encrypt_password
from smartmirror_console.security import user_datastore

from ..utils import has_default_password

change_default_password_page = Blueprint(
    'change_default_password_page',
    __name__,
    template_folder='templates'
)

def reload_page(endpoint):
    if request.endpoint != endpoint:
        return redirect(url_for(endpoint, next=url_for(request.endpoint)))
    return redirect(url_for(endpoint, next='/'))


@change_default_password_page.route('/', methods=['GET', 'POST'])
@login_required
def show():
    this_endpoint = 'change_default_password_page.show'

    if request.method == 'GET':
        return render_template('change_default_password.html')

    if request.form['new_password'] != request.form['new_password_confirm']:
        flash(get_message('RETYPE_PASSWORD_MISMATCH')
              [0], 'new_password_confirm_error')
        return reload_page(this_endpoint)

    current_user.password = encrypt_password(request.form['new_password'])
    user_datastore.put(current_user)
    user_datastore.commit()

    if request.endpoint != this_endpoint:
        return redirect(url_for(request.endpoint))
    return redirect('/')
