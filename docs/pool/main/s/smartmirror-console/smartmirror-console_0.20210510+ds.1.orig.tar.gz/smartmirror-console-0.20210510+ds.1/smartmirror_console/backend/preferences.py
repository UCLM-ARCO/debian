import json


class UserPreferences:
    AVAILABLE_LOCALE = ['es', 'en']

    def __init__(self, filename: str = None):
        self.filename = filename
        self._config = {
            'notification_email': None,
            'notification_timeout': None,
            'locale': None
        }
        self.__dirty = False

        if self.filename != None:
            self.load()

    def init_app(self, app):
        self.filename = app.config['USER_PREFERENCES_PATH']
        self.load()

    @property
    def notification_email(self):
        return self._config.get('notification_email')

    @notification_email.setter
    def notification_email(self, value: str):
        self._config['notification_email'] = value
        self.__dirty = True

    @notification_email.deleter
    def notification_email(self):
        self._config['notification_email'] = None
        self.__dirty = True

    @property
    def notification_timeout(self):
        return self._config.get('notification_timeout')

    @notification_timeout.setter
    def notification_timeout(self, value: str):
        self._config['notification_timeout'] = value
        self.__dirty = True

    @notification_timeout.deleter
    def notification_timeout(self):
        self._config['notification_timeout'] = None
        self.__dirty = True

    @property
    def locale(self):
        return self._config.get('locale')

    @locale.setter
    def locale(self, value: str):
        if value not in self.AVAILABLE_LOCALE:
            return
        self._config['locale'] = value
        self.__dirty = True

    @locale.deleter
    def locale(self):
        self._config['locale'] = None
        self.__dirty = True

    def load(self):
        try:
            with open(self.filename) as fr:
                for k, v in json.load(fr).items():
                    setattr(self, k, v)
        except IOError as err:
            print(f'ERROR: Cannot load settings due to: {err}')
            return False
        else:
            self.save()
            return True

    def save(self):
        if self.__dirty:
            try:
                with open(self.filename, 'w') as fr:
                    fr.write(json.dumps(self._config, indent=4))
            except IOError as err:
                print(f'ERROR: Cannot save settings due to: {err}')
                return False
            else:
                self.__dirty = False
                return True


user_preferences = UserPreferences()
