function is_input_valid(input_id) {
    return document.getElementById(input_id).validity.valid
}

function is_form_valid(form_id) {
    var invalid = false
    $('#' + form_id + ' input:not([type="hidden"])').each(function () {
        invalid = invalid || (! is_input_valid(this.id))
    })
    return (! invalid)
}


$(document).ready(function () {
    $.ajaxSetup({
        beforeSend: function (xhr, settings) {
            if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type) && !this.crossDomain) {
                xhr.setRequestHeader("X-CSRFToken", csrf_token);
            }
        }
    })
    $(".toast").each(function () {
        var toast = new bootstrap.Toast(this)
        toast.show()
    })

    $('input:not([type="hidden"])').change(function () {
        if (!is_input_valid(this.id)) {
            $('#' + this.id).addClass('is-invalid')
        } else {
            $('#' + this.id).removeClass('is-invalid')
        }
    })

    $('.btn[type="submit"]').on('click tap', function () {
        $('#' + this.parentElement.id + ' input:not([type="hidden"])').each(function () {
            if (!is_input_valid(this.id)) {
                $('#' + this.id).addClass('is-invalid')
            } else {
                $('#' + this.id).removeClass('is-invalid')
            }
        })
    })

    $('#select-locale').change(function () {
        url = window.location.href
        if (url.indexOf('lang') > -1) {
            url = url.replace(/lang=\w{2}/, 'lang=' + this.value)
        } else if (url.indexOf('?') > -1) {
            url = url + '&lang=' + this.value
        } else {
            url = url + '?lang=' + this.value
        }
        window.location.href = url
    })

    $('.btn-action').on('click tap', function () {
        if (this.type == "submit" && !is_form_valid(this.parentElement.id)) {
            return
        }
        $('.btn-action').attr('disabled', true)
        $('.btn-action')
            .removeClass('disabled')
            .addClass('disabled')
        $('a[class~="btn-action"]').attr('tabindex', -1)
        $('.btn-action').attr('aria-disabled', true)
    })

    $('.section-title .btn-action').on('click tap', function () {
        $('#' + this.id.split('-btn')[0] + '-action-status')
            .removeClass('visually-hidden')
    })

    $('.btn-install, .btn-uninstall').on('click tap', function () {
        $(document).on('click tap', function () {
            return false
        })
        $('body > .container-lg').css('opacity', .5)
        $('#alert-wait').removeClass('invisible')
        window.location = this.href
    })

    $('.btn-with-spinner').on('click tap', function () {
        $('#' + this.id + ' .spinner-grow')
            .removeClass('visually-hidden')
            .attr('aria-hidden', false)
    })
})