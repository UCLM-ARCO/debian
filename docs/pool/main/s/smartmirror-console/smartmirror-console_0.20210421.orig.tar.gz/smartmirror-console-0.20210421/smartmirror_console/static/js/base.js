$(document).ready(function () {
    $(".toast").each(function () {
        var toast = new bootstrap.Toast(this)
        toast.show()
    })
    $('#miband-dc-install-btn').on('click tap', function () {
        $( this ).attr('disabled', true)
        $('#miband-dc-install-btn .spinner-grow')
            .removeClass('visually-hidden')
    })
})