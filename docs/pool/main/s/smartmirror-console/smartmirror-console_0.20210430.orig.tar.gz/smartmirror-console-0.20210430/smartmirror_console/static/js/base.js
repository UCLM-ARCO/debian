$(document).ready(function () {
    $.ajaxSetup({
        beforeSend: function (xhr, settings) {
            if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type) && !this.crossDomain) {
                xhr.setRequestHeader("X-CSRFToken", csrf_token);
            }
        }
    })
    $(".toast").each(function () {
        var toast = new bootstrap.Toast(this)
        toast.show()
    })
    $('#miband-dc-install-btn').on('click tap', function () {
        $(this)
            .attr('disabled', true)
            .removeClass('disabled')
            .addClass('disabled')
        $('#miband-dc-install-btn .spinner-grow')
            .removeClass('visually-hidden')
    })
    $('#miband-dc-uninstall-btn, #miband-dc-install-btn').on('click tap', function () {
        $(document).on('click tap', function () {
            return false
        })
        $('body > .container-lg').css('opacity', .5)
        $('#alert-wait').removeClass('invisible')
        window.location = this.href
    })
})