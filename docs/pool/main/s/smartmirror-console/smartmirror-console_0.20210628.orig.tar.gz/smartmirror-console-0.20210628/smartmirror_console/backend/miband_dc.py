import json
import os.path
import re

from flask_babel import gettext

from .utils import HuamiAmazfit, PackageWithServiceResource

DEVICES_PATH = '/etc/miband-dc/devices.csv'
SETTINGS_PATH = '/etc/miband-dc/settings.json'


def get_linked_devices(email: str, password: str):
    device = HuamiAmazfit(
        email=email,
        password=password
    )
    try:
        device.login()
    except ValueError as err:
        raise ValueError(
            gettext(u'error on login to account: %(err)s', err=err))

    retval = {}
    try:
        for wereable in device.get_wearables():
            retval[wereable['mac_address']] = wereable['auth_key'][2:]
    except ValueError as err:
        raise ValueError(
            gettext(u'error on getting device info: %(err)s', err=err))
    finally:
        device.logout()

    return retval


class MiBandDataCollector(PackageWithServiceResource):
    UPDATE_MODE_ALL = 'all'
    UPDATE_MODE_CHARGING = 'charging'

    def __init__(
            self,
            devices_path: str = '/etc/miband-dc/devices.csv',
            settings_path: str = '/etc/miband-dc/settings.json'):
        super().__init__()

        self.devices_path = devices_path
        self.devices = {}
        self.settings_path = settings_path
        self.settings = {}

        self.__dirty = False

        self.load_devices()
        self.load_settings()

    @property
    def name(self):
        return 'miband-dc'

    @property
    def db_name(self):
        return self.settings['db_name']

    @db_name.setter
    def db_name(self, value: str):
        self.settings['db_name'] = value
        self.__dirty = True

    @db_name.deleter
    def db_name(self):
        self.settings['db_name'] = 'miband-dc'
        self.__dirty = True

    @property
    def db_host(self):
        return '{}:{}'.format(
            self.settings['db_host'],
            self.settings['db_port']
        )

    @db_host.setter
    def db_host(self, value: str):
        if value.find(':') != -1:
            addr = value.split(':')
            if addr[1].isdigit():
                self.settings['db_port'] = int(addr[1])
            else:
                self.settings['db_port'] = 5432
            self.settings['db_host'] = addr[0]
        else:
            self.settings['db_host'] = value
            self.settings['db_port'] = 5432
        self.__dirty = True

    @db_host.deleter
    def db_host(self):
        self.settings['db_host'] = 'localhost'
        self.settings['db_port'] = 5432
        self.__dirty = True

    @property
    def db_user(self):
        return self.settings['db_user']

    @db_user.setter
    def db_user(self, value: str):
        self.settings['db_user'] = value
        self.__dirty = True

    @db_user.deleter
    def db_user(self):
        self.settings['db_user'] = 'root'
        self.__dirty = True

    @property
    def db_passwd(self):
        return self.settings['db_passwd']

    @db_passwd.setter
    def db_passwd(self, value: str):
        self.settings['db_passwd'] = value
        self.__dirty = True

    @db_passwd.deleter
    def db_passwd(self):
        self.settings['db_passwd'] = 'secret'
        self.__dirty = True

    @property
    def update_mode(self):
        return self.settings.get('update_mode', 'all')

    @update_mode.setter
    def update_mode(self, value: str):
        if value not in [self.UPDATE_MODE_ALL, self.UPDATE_MODE_CHARGING]:
            value = 'all'
        self.settings['update_mode'] = value
        self.__dirty = True

    @update_mode.deleter
    def update_mode(self):
        self.settings.pop('update_mode')
        self.__dirty = True

    @property
    def update_state_email(self):
        retval = None
        if 'notifications' not in self.settings.keys():
            self.settings['notifications'] = {
                'update_state': []
            }
        notifications = self.settings['notifications']

        if 'update_state' not in notifications.keys():
            notifications['update_state'] = []
        update_state = notifications['update_state']

        for hook in update_state:
            # console will only allow 1 admin email address
            if len(hook['address']) > 1:
                continue
            elif re.search(r'\S*@\S*\.\S*', hook['address'][0]):
                timeout = hook.get('timeout')
                if not timeout:
                    timeout = '1m'
                retval = {
                    'address': hook['address'][0],
                    'timeout': timeout
                }
                break

        return retval

    @update_state_email.setter
    def update_state_email(self, value: dict):
        if 'address' not in value.keys():
            return

        timeout = value.get('timeout')
        if not timeout:
            timeout = '1m'

        if 'notifications' not in self.settings.keys():
            self.settings['notifications'] = {
                'update_state': []
            }
        notifications = self.settings['notifications']

        if 'update_state' not in notifications.keys():
            notifications['update_state'] = []
        update_state = notifications['update_state']

        found = False
        for hook in update_state:
            # console will only allow 1 admin email address
            if len(hook['address']) > 1:
                continue
            elif re.search(r'\S*@\S*\.\S*', hook['address'][0]):
                hook.update({
                    'address': [value['address']],
                    'timeout': timeout
                })
                found = True
                break

        if not found:
            update_state.insert(0, {
                'address': [value['address']],
                'timeout': timeout
            })
        self.__dirty = True

    @update_state_email.deleter
    def update_state_email(self):
        if 'notifications' not in self.settings.keys():
            self.settings['notifications'] = {
                'update_state': []
            }
        notifications = self.settings['notifications']

        if 'update_state' not in notifications.keys():
            notifications['update_state'] = []
        update_state = notifications['update_state']

        for hook in update_state:
            # console will only allow 1 admin email address
            if len(hook['address']) > 1:
                continue
            elif re.search(r'\S*@\S*\.\S*', hook['address'][0]):
                update_state.pop(update_state.index(hook))
                break
        self.__dirty = True

    @property
    def update_state_mm(self):
        retval = None
        if 'notifications' not in self.settings.keys():
            self.settings['notifications'] = {
                'update_state': []
            }
        notifications = self.settings['notifications']

        if 'update_state' not in notifications.keys():
            notifications['update_state'] = []
        update_state = notifications['update_state']

        for hook in update_state:
            # console will only allow 1 admin email address
            if len(hook['address']) > 1:
                continue
            elif re.search(r'localhost:\d*', hook['address'][0]):
                timeout = hook.get('timeout')
                if not timeout:
                    timeout = '1m'
                retval = {
                    'address': hook['address'][0],
                    'timeout': timeout
                }
                break

        return retval

    @update_state_mm.setter
    def update_state_mm(self, value: dict):
        if 'address' not in value.keys():
            return

        timeout = value.get('timeout')
        if not timeout:
            timeout = '1m'

        if 'notifications' not in self.settings.keys():
            self.settings['notifications'] = {
                'update_state': []
            }
        notifications = self.settings['notifications']

        if 'update_state' not in notifications.keys():
            notifications['update_state'] = []
        update_state = notifications['update_state']

        found = False
        for hook in update_state:
            # console will only allow 1 admin email address
            if len(hook['address']) > 1:
                continue
            elif re.search(r'localhost:\d*', hook['address'][0]):
                hook.update({
                    'address': [value['address']],
                    'timeout': timeout
                })
                found = True
                break

        if not found:
            update_state.insert(0, {
                'address': [value['address']],
                'timeout': timeout
            })
        self.__dirty = True

    @update_state_mm.deleter
    def update_state_mm(self):
        if 'notifications' not in self.settings.keys():
            self.settings['notifications'] = {
                'update_state': []
            }
        notifications = self.settings['notifications']

        if 'update_state' not in notifications.keys():
            notifications['update_state'] = []
        update_state = notifications['update_state']

        for hook in update_state:
            # console will only allow 1 admin email address
            if len(hook['address']) > 1:
                continue
            elif re.search(r'localhost:\d*', hook['address'][0]):
                update_state.pop(update_state.index(hook))
                break
        self.__dirty = True

    @property
    def raw_devices(self):
        with open(self.devices_path) as fr:
            retval = fr.read()
        return retval

    @property
    def raw_settigns(self):
        with open(self.settings_path) as fr:
            retval = fr.read()
        return retval

    def load_devices(self):
        with open(self.devices_path) as fr:
            for line in fr:
                line = line.strip(' \n\t')
                if not line.startswith('#') and line != '':
                    values = line.split('|')
                    self.devices[values[1].strip(
                        ' \n\t')] = values[2].strip(' \n\t')

    def save_devices(self):
        if self.__dirty:
            with open(self.devices_path, 'w') as fw:
                index = 1
                for mac, token in self.devices.items():
                    fw.write(f"{index} | {mac} | {token}\n")
                    index += 1
            self.__dirty = False
            if self.running:
                self.restart()


    def load_settings(self):
        with open(self.settings_path) as fr:
            self.settings.update(json.load(fr))

    def save_settings(self):
        if self.__dirty:
            with open(self.settings_path, 'w') as fw:
                json.dump(self.settings, fw, indent=4)
            self.__dirty = False
            if self.running:
                self.restart()

    def add_device(self, mac: str, token: str):
        self.devices[mac] = token
        self.__dirty = True

    def remove_device(self, mac: str):
        if mac not in self.devices.keys():
            return
        self.devices.pop(mac)
        self.__dirty = True

    def to_dict(self):
        retval = PackageWithServiceResource.to_dict(self)
        retval.update({
            'db_name': self.db_name,
            'db_host': self.db_host,
            'db_user': self.db_user,
            'db_passwd': self.db_passwd,
            'update_mode': self.update_mode,
            'notifications': {
                'update_state': {
                    'email': self.update_state_email,
                    'mm': self.update_state_mm
                }
            },
            'devices': self.devices
        })
        return retval
