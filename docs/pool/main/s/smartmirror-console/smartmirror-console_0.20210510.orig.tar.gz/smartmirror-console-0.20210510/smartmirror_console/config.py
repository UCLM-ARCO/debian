import os

from flask_babel import lazy_gettext


class BaseConfig:
    SECRET_KEY = os.urandom(32)
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    SECURITY_PASSWORD_SALT = '7741d5c1341b40d4ac37744f508b9c0c'
    SECURITY_PASSWORD_HASH = 'sha512_crypt'
    SECURITY_PASSWORD_SINGLE_HASH = True

    SECURITY_MSG_PASSWORD_MISMATCH = (
        lazy_gettext('Password does not match'), 'error')
    SECURITY_MSG_RETYPE_PASSWORD_MISMATCH = (
        lazy_gettext('Passwords do not match'), 'error')
    SECURITY_MSG_INVALID_REDIRECT = (
        lazy_gettext('Redirections outside the domain are forbidden'), 'error')
    SECURITY_MSG_CONFIRMATION_REQUIRED = (
        lazy_gettext('Email requires confirmation.'), 'error')
    SECURITY_MSG_DISABLED_ACCOUNT = (
        lazy_gettext('Account is disabled.'), 'error')
    SECURITY_MSG_EMAIL_NOT_PROVIDED = (
        lazy_gettext('Email not provided'), 'error')
    SECURITY_MSG_PASSWORD_NOT_PROVIDED = (
        lazy_gettext('Password not provided'), 'error')
    SECURITY_MSG_PASSWORD_NOT_SET = (
        lazy_gettext('No password is set for this user'), 'error')
    SECURITY_MSG_USER_DOES_NOT_EXIST = (
        lazy_gettext('Specified user does not exist'), 'error')
    SECURITY_MSG_INVALID_PASSWORD = (
        lazy_gettext('Invalid password'), 'error')
    SECURITY_MSG_PASSWORD_IS_THE_SAME = (
        lazy_gettext('Your new password must be different than your previous password.'), 'error')


class DevelopmentConfig(BaseConfig):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///../smartmirror-console.db'
    USER_PREFERENCES_PATH = './preferences.json'


class ProductionConfig(BaseConfig):
    SQLALCHEMY_DATABASE_URI = 'sqlite:////etc/smartmirror-console/smartmirror-console.db'
    USER_PREFERENCES_PATH = '/etc/smartmirror-console/preferences.json'
