function find_mac(mac, except = undefined) {
    var retval = undefined
    $('.device-mac').each(function () {
        if (retval !== undefined)
            return false
        else if (except !== undefined && except == this.id)
            return
        else if (this.value == mac)
            retval = this.id
    })
    return retval
}

$(document).ready(function () {
    $('.btn-delete-device').on('click tap', function () {
        $('#' + this.id.replace('-delete', ''))
            .removeClass('box-bg-warning box-bg-danger')
            .addClass('box-bg-danger')
        $('#' + this.id.replace('device-delete', 'token'))
            .attr('readonly', true)
            .val('deleted')
        this.disabled = true
    })

    $('.device-token').change(function () {
        $('#device-' + this.id.replace('token-', ''))
            .removeClass('box-bg-warning box-bg-danger')
            .addClass('box-bg-warning')
    })

    $('#device-add').on('click tap', function () {
        var next_id = parseInt(
            $('#devices-box .box-group:last-of-type .box-item')
                .attr('id')
                .replace('device-', '')
        ) + 1
        $('#devices-box').append(`<div class="d-flex box-group">
            <div id="device-` + next_id + `" class="box-item flex-fill p-3 box-bg-success">
                <div class="d-flex align-items-center mb-3">
                    <label class="form-label px-3" for="mac-` + next_id + `">` + mac_label_tr + `</label>
                    <input id="mac-` + next_id + `" name="mac-` + next_id + `"
                        class="form-control device-mac"
                        pattern="([A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2}" required>
                </div>
                <div class="d-flex align-items-center">
                    <label class="form-label px-3" for="token-` + next_id + `">` + token_label_tr + `</label>
                    <input id="token-` + next_id + `" name="token-` + next_id + `"
                        class="form-control device-token"
                        pattern="[A-Za-z0-9]{32}" required>
                </div>
            </div>
            <div class="d-flex flex-column align-items-center justify-content-center">
                <button id="device-delete-` + next_id + `" class="btn bi-x-circle"
                    type="button" title="`+ delete_dev_btn_tr + `"
                    aria-label="`+ delete_dev_btn_tr + `"></button>
            </div>
        </div>`.trim())
        $('#device-delete-' + next_id).on('click tap', function () {
            var node = $('#device-' + next_id).parent().get(0)
            document.getElementById('devices-box').removeChild(node)
        })
        $('#mac-' + next_id).change(function () {
            var duplicated = find_mac(this.value, this.id)
            if (duplicated == undefined)
                this.setCustomValidity('')
            else
                this.setCustomValidity(validity_duplicated_mac_tr)
        })
    })

    $('#form-miband-dc-settings-get-token').submit(function (event) {
        event.preventDefault()
        form_id = this.id

        $('.btn-action').attr('disabled', true)
        $('.btn-action')
            .removeClass('disabled')
            .addClass('disabled')
        $('a[class~="btn-action"]').attr('tabindex', -1)
        $('.btn-action').attr('aria-disabled', true)

        $('#' + form_id + ' button[type=submit] .spinner-grow')
            .removeClass('visually-hidden')
        $('#get-token-result .card-body').remove('*')
        $('#get-token-result .list-group').remove('*')

        var collapse = new bootstrap.Collapse(
            document.getElementById('get-token-result'),
            { toggle: false }
        )
        collapse.hide()

        $.ajax({
            url: '/miband-dc/get-token',
            data: JSON.stringify({
                email: $('#get-token-email').val(),
                password: $('#get-token-passwd').val()
            }),
            type: 'POST',
            contentType: 'application/json; charset=UTF-8',
            dataType: 'json'
        }).done(function (json) {
            $('#get-token-result')
                .append(`<ul class="list-group list-group-flush"></ul>`)
                .append(`<div class="card-body text-center">
                    <form class="mb-4" method="POST">
                        <input type="hidden" name="csrf_token" value="`+ csrf_token + `" />
                    </form>
                </div>`)
            for (let i = 0; i < json['length']; i++) {
                $('#get-token-result .list-group').append(`<li class="list-group-item">
                        `+ mac_label_tr + `: ` + json[i]['mac'] + `<br>
                        `+ token_label_tr + `: ` + json[i]['token'] + `
                    </li>`)
                $('#get-token-result form').append(`
                    <input id="getted-mac-`+ (i + 1) + `" 
                        name="getted-mac-` + (i + 1) + `" 
                        value="` + json[i]['mac'] + `" type="hidden" />
                    <input id="getted-token-`+ (i + 1) + `" 
                        name="getted-token-` + (i + 1) + `" 
                        value="` + json[i]['token'] + `" type="hidden" />`)
            }
            $('#get-token-result form').append(`<button class="btn btn-success btn-action" 
                type="submit">`+ add_all_dev_btn_tr + `
            </button>`)
        }).fail(function (xhr) {
            $('#get-token-result')
                .append(`<div class="card-body text-danger">
                    `+ xhr.responseJSON['msg'] + `
                </div>`)
        }).always(function () {
            $('.btn-action').attr('disabled', false)
            $('.btn-action')
                .removeClass('disabled')
            $('a[class~="btn-action"]').removeAttr('tabindex')
            $('.btn-action').attr('aria-disabled', false)
            $('#' + form_id + ' button[type=submit] .spinner-grow')
                .addClass('visually-hidden')
            collapse.show()
        })
    })
})