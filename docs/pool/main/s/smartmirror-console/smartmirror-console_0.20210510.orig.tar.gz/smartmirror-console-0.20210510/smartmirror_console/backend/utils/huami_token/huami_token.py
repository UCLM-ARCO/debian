#!/usr/bin/env python3
# pylint: disable=too-many-instance-attributes
# pylint: disable=invalid-name

"""Main module"""

import argparse
import getpass
import json
import random
import shutil
import urllib
import uuid

import requests
from flask_babel import gettext

from .urls import PAYLOADS, URLS


class HuamiAmazfit:
    """Base class for logging in and receiving auth keys and GPS packs"""

    def __init__(self, email, password):
        self.method = "amazfit"
        self.email = email
        self.password = password
        self.access_token = None
        self.country_code = None

        self.app_token = None
        self.login_token = None
        self.user_id = None

        self.r = str(uuid.uuid4())

        # IMEI or something unique
        self.device_id = "02:00:00:%02x:%02x:%02x" % (random.randint(0, 255),
                                                      random.randint(0, 255),
                                                      random.randint(0, 255))

    def get_access_token(self):
        """Get access token for log in"""
        auth_url = URLS['tokens_amazfit'].format(
            user_email=urllib.parse.quote(self.email))

        data = PAYLOADS['tokens_amazfit']
        data['password'] = self.password

        response = requests.post(
            auth_url, data=data, allow_redirects=False)
        response.raise_for_status()

        # 'Location' parameter contains url with login status
        redirect_url = urllib.parse.urlparse(
            response.headers.get('Location'))
        redirect_url_parameters = urllib.parse.parse_qs(redirect_url.query)

        if 'error' in redirect_url_parameters:
            raise ValueError(gettext(u"Wrong E-mail or Password."))

        if 'access' not in redirect_url_parameters:
            raise ValueError(gettext(u"No 'access' parameter in login url."))

        if 'country_code' not in redirect_url_parameters:
            # Sometimes for no reason server does not return country_code
            # In this case we extract country_code from region, because it looks
            # like this: 'eu-central-1'
            region = redirect_url_parameters['region'][0]
            self.country_code = region[0:2].upper()

        else:
            self.country_code = redirect_url_parameters['country_code']

        self.access_token = redirect_url_parameters['access']

    def login(self):
        """Perform login and get app and login tokens"""
        self.get_access_token()
        login_url = URLS['login_amazfit']

        data = PAYLOADS['login_amazfit']
        data['country_code'] = self.country_code
        data['device_id'] = self.device_id
        data['third_name'] = 'huami' if self.method == 'amazfit' else 'mi-watch'
        data['code'] = self.access_token
        data['grant_type'] = 'access_token' if self.method == 'amazfit' else 'request_token'

        response = requests.post(login_url, data=data, allow_redirects=False)
        response.raise_for_status()
        login_result = response.json()

        if 'error_code' in login_result:
            raise ValueError(
                gettext(u"Login error (%(code)s)", code=login_result['error_code']))

        if 'token_info' not in login_result:
            raise ValueError(gettext(u"No 'token_info' parameter in login data."))
        # else
        # Do not need else, because raise breaks control flow
        token_info = login_result['token_info']
        if 'app_token' not in token_info:
            raise ValueError(gettext(u"No 'app_token' parameter in login data."))
        self.app_token = token_info['app_token']

        if 'login_token' not in token_info:
            raise ValueError(gettext(u"No 'login_token' parameter in login data."))
        self.login_token = token_info['login_token']

        if 'user_id' not in token_info:
            raise ValueError(gettext(u"No 'user_id' parameter in login data."))
        self.user_id = token_info['user_id']

    def get_wearables(self):
        """Request a list of linked devices"""
        devices_url = URLS['devices'].format(
            user_id=urllib.parse.quote(self.user_id))

        headers = PAYLOADS['devices']
        headers['apptoken'] = self.app_token
        params = {'enableMultiDevice': 'true'}

        response = requests.get(devices_url, params=params, headers=headers)
        response.raise_for_status()
        device_request = response.json()
        if 'items' not in device_request:
            raise ValueError(gettext(u"No 'items' parameter in devices data."))
        devices = device_request['items']

        _wearables = []

        for _wearable in devices:
            if 'macAddress' not in _wearable:
                raise ValueError(gettext(u"No 'macAddress' parameter in device data."))
            mac_address = _wearable['macAddress']

            if 'additionalInfo' not in _wearable:
                raise ValueError(
                    gettext(u"No 'additionalInfo' parameter in device data."))
            device_info = json.loads(_wearable['additionalInfo'])

            if 'auth_key' not in device_info:
                raise ValueError(gettext(u"No 'auth_key' parameter in device data."))
            key_str = device_info['auth_key']
            auth_key = '0x' + (key_str if key_str != '' else '00')

            _wearables.append(
                {
                    'active_status': str(
                        _wearable.get(
                            'activeStatus',
                            '-1')),
                    'mac_address': mac_address,
                    'auth_key': auth_key,
                    'device_source': str(
                        _wearable.get(
                            'deviceSource',
                            0)),
                    'firmware_version': _wearable.get(
                        'firmwareVersion',
                        'v-1'),
                    'hardware_version': device_info.get(
                        'hardwareVersion',
                        'v-1'),
                    'production_source': device_info.get(
                        'productVersion',
                        '0')})

        return _wearables

    def logout(self) -> None:
        """Log out from the current account"""
        logout_url = URLS['logout']

        data = PAYLOADS['logout']
        data['login_token'] = self.login_token

        return requests.post(logout_url, data=data)
