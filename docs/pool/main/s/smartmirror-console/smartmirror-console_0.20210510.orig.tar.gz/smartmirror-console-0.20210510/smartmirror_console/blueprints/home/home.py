from flask import Blueprint, render_template, request
from smartmirror_console.backend import (get_packages_status,
                                         get_services_status, user_preferences)

from ..utils import check_language, login_and_change_password_required

home_page = Blueprint('home', __name__, template_folder='templates')


@home_page.route('/', methods=['GET'])
@login_and_change_password_required
@check_language
def show():
    lang = user_preferences.locale
    if user_preferences.locale == None:
        lang = request.accept_languages.best_match(['es', 'en'])

    return render_template(
        'home.html',
        lang=lang,
        packages=get_packages_status(),
        services=get_services_status()
    )
