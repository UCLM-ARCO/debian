# Smartmirror Console

Web application to configure SHAPES Smart Mirror.

## Usage

Install `smartmirror-console` with `apt` and in a browser write: `ip-of-your-rpi:5000`.   
Access credentials are `admin`-`admin`.

## Functions

1. MiBand4 data collector (`miband-dc`):

   a. Install, upgrade and uninstall package.   
   b. Start and stop service.   
   c. Enable running service on boot.   
   d. Obtain active device information with MiFit account credentials.   
   e. Add, edit and delete devices information from configuration.