DROP TABLE IF EXISTS "role";
DROP TABLE IF EXISTS "user";
DROP TABLE IF EXISTS "roles_users";

CREATE TABLE IF NOT EXISTS "role" (
	"id" INTEGER NOT NULL, 
	"name" VARCHAR(80), 
	"description" VARCHAR(255), 
	PRIMARY KEY ("id"), 
	UNIQUE ("name")
);

CREATE TABLE IF NOT EXISTS "user" (
	"id" INTEGER NOT NULL, 
	"email" VARCHAR(255), 
	password VARCHAR(255), 
	"active" BOOLEAN, 
	"confirmed_at" DATETIME, 
	PRIMARY KEY ("id"), 
	UNIQUE ("email"), 
	CHECK ("active" IN (0, 1))
);

CREATE TABLE IF NOT EXISTS "roles_users" (
	"user_id" INTEGER, 
	"role_id" INTEGER, 
	FOREIGN KEY("user_id") REFERENCES "user" ("id"), 
	FOREIGN KEY("role_id") REFERENCES "role" ("id")
);

INSERT OR IGNORE INTO "user" (
    "email", "password", "active"
) VALUES (
    "admin", "$6$rounds=656000$G5eceB1UjZoTh8gg$.tvcWqi/WheX4l5X5Cdp/i4WmjIHjOb/yn6cRQrRsQxKNz2FRzV6YKMLH60OMCHhwJazqWzccijU7PlVxlIiL1", 1
);