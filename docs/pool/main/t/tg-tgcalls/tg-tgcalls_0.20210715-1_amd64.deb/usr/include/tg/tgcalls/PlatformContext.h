#ifndef TGCALLS_PLATFORM_CONTEXT_H
#define TGCALLS_PLATFORM_CONTEXT_H

namespace tgcalls {

class PlatformContext {

public:
    virtual ~PlatformContext() = default;

};

} // namespace tgcalls

#endif
