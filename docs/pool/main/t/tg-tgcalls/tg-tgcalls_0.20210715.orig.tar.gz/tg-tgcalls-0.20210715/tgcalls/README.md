# Telegram Calls Library

Copyright (c) 2020 The Telegram Calls Library Authors.

This code is published under the terms of the GNU Lesser General Public License version 3.
Full license text can be found here: [https://github.com/TelegramMessenger/tgcalls/blob/master/LICENSE](https://github.com/TelegramMessenger/tgcalls/blob/master/LICENSE)
