This source code is from Telegram Desktop application, it is not exported on
its own repository, so I copied it here.

To update, run `make update`, or clone the repo:

    * https://github.com/telegramdesktop/tdesktop

And copy the files in the folder:

    * `Telegram/SourceFiles/ffmpeg`
