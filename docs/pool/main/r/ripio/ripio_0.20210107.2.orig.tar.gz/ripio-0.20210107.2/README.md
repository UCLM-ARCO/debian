ripio is a CLI to manage hosted git repositories.

* code repository: https://bitbucket.org/DavidVilla/ripio
* see [documentation](https://bitbucket.org/DavidVilla/ripio/wiki)!
