ripio is a CLI to manage hosted git repositories, supporting github and bitbucket.

* code repository: https://github.com/davidvilla/ripio
