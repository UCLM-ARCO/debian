ripio is a CLI to manage hosted git repositories.

* code repository: https://github.com/davidvilla/ripio
