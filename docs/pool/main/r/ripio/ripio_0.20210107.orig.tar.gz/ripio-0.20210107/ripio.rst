=====
ripio
=====

-----------------
ripio description
-----------------

:Author: David Villa Alises
:date:   2020-05-01
:Manual section: 1

SYNOPSIS
========

``ripio`` [options]

This manual page documents briefly the ``ripio`` command.

This manual page was written for the Debian(TM) distribution because
the original program does not have a manual page.

COPYRIGHT
=========

Copyright © 2020 David Villa Alises

This manual page was written for the Debian system (and may be used by
others).

Permission is granted to copy, distribute and/or modify this document
under the terms of the GNU General Public License, Version 2 or (at
your option) any later version published by the Free Software
Foundation.

On Debian systems, the complete text of the GNU General Public License
can be found in /usr/share/common-licenses/GPL.

