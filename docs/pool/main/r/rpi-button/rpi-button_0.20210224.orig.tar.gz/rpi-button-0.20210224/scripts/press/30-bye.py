#!/usr/bin/env python3

print("Hello Python! I'm press 30")

