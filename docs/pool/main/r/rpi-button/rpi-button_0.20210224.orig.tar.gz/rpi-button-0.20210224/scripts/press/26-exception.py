#!/usr/bin/env python3

print("Hello Python! I'm press 26 with an exception")

raise RuntimeError("ERROR")
