#!/bin/bash

echo "Hello there! I'm long press 10"
