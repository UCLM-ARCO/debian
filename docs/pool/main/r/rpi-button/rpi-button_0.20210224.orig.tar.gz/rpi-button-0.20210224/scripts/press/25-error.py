#!/usr/bin/env python3

import sys

print("Hello Python! I'm press 25 with an error exit")

sys.exit(-1)
