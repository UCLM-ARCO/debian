#!/bin/bash

echo "Hello there! I'm double press 10"
