#!/bin/bash

echo "Hello there! I'm press 20"
