# Description

This is a service that handles the events for a Push Button.


# Connection

* button-pin-1: GND (RPi 40-pin-hader, pin 34)
* button-pin-2: GPIO 16 (RPi 40-pin-hader, pin 36)


# References

* https://pinout.xyz/
* https://www.raspberrypi.org/documentation/usage/gpio/python/README.md
* https://gpiozero.readthedocs.io/en/stable/
* https://gpiozero.readthedocs.io/en/stable/api_input.html

* https://docs.python.org/3/library/signal.html?highlight=pause#signal.pause
