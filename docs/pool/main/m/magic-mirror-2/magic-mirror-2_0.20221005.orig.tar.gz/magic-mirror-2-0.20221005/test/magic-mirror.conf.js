let config = {
    address: "localhost",
    port: 8080,
    basePath: "/",
    ipWhitelist: ["127.0.0.1", "::ffff:127.0.0.1", "::1"],

    useHttps: false,
    httpsPrivateKey: "",
    httpsCertificate: "",

    language: "en",
    locale: "en-UK",
    logLevel: ["INFO", "LOG", "WARN", "ERROR"],
    timeFormat: 24,
    units: "metric",

    modules: [
        {
            module: "ice"
        },
        {
            module: "clock",
            position: "top_left"
        },
        {
            module: "calendar",
            position: "top_left",
            config: {
                "maximumNumberOfDays": 30,
                "colored": true,
                "coloredSymbolOnly": true,
                "showLocation": true,
                "titleReplace": {
                    "#medication": "",
                    "#gym": "",
                    "#videocall": ""
                },
                "customEvents": [
                    {
                        "keyword": ".*#gym.*",
                        "symbol": "running",
                        "color": "#eb7434"
                    },
                    {
                        "keyword": ".*#medication.*",
                        "symbol": "pills",
                        "color": "#6b61ed"
                    },
                    {
                        "keyword": ".*#videocall.*",
                        "symbol": "video",
                        "color": "#db6a23"
                    }
                ],
                calendars: [
                    {
                        symbol: "calendar-check",
                        url: "webcal://www.calendarlabs.com/ical-calendar/ics/76/US_Holidays.ics"
                    }
                ]
            }
        },
        {
            module: "callservice",
            position: "top_left"
        },
        {
            module: "phyxio-connect",
            position: "top_left"
        },
        {
            module: "loginservice"
        }
    ]
};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== "undefined") { module.exports = config; }