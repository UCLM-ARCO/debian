Module.register('sound-selector', {
    defaults: {
        aliases: {}, // name: alias
        icons: {} // name or alias: icon 
    },
    icons: {
        // name or alias: icon 
        // https://fontawesome.com/v5.15/icons?m=free
        'jack': 'headphones-alt',
        'hdmi': 'tv'
    },

    selectDevice: function (name) {
        console.debug(this.name + ': Selecting ' + name)
        this.sendSocketNotification('SET_DEVICE', name)
    },

    start: function () {
        this.data.header = this.translate('header')
        this.devices = {}
        this.active = undefined
        for (const key of Object.keys(this.config.icons))
            this.icons[key] = this.config.icons[key]
    },

    notificationReceived: function (notification, payload, sender) {
        if (notification === 'ALL_MODULES_STARTED')
            this.sendSocketNotification(
                'SET_ALIASES', this.config.aliases)
    },

    socketNotificationReceived: function (notification, payload) {
        switch (notification) {
            case 'SET_ALIASES':
                this.sendSocketNotification('GET_DEVICES')
                break;
            case 'GET_DEVICES':
                this.devices = Object.keys(payload) // just names
                this.sendSocketNotification('GET_ACTIVE')
                break;
            case 'GET_ACTIVE':
                this.active = payload
                this.updateDom(1500)
                break;
            case 'SET_DEVICE':
                if (!payload)
                    console.error('TODO Inform unable to select device')
                else
                    this.sendSocketNotification('GET_ACTIVE')
                break;
            case 'UPDATE_DEVICES':
                if (!payload)
                    console.error('TODO Inform unable to update devices')
                else
                    this.sendSocketNotification('GET_DEVICES')
                break;
            default:
                break;
        }
    },

    getDom: function () {
        var self = this
        let wrapper = document.createElement('div')
        wrapper.className = 'root'
        if (Object.keys(this.devices).length == 0) {
            wrapper.textContent = this.translate('loading')
        } else {
            let selector = document.createElement('div')
            selector.className = 'selector'
            for (let device of this.devices) {
                let btn = document.createElement('button')
                btn.className = 'small'
                if (this.active === device)
                    btn.className += ' active'
                btn.textContent = device.toUpperCase()
                let icon = document.createElement('span')
                icon.className = 'fa fa-' + this.icons[device]
                btn.appendChild(icon)
                btn.addEventListener('click', (ev) => {
                    if (ev.currentTarget.classList
                        .contains('active'))
                        return
                    self.selectDevice(device)
                })
                selector.append(btn)
            }
            wrapper.appendChild(selector)
            let reloadBtn = document.createElement('button')
            reloadBtn.className = 'icon small'
            let reloadIcon = document.createElement('span')
            reloadIcon.className = 'fa fa-refresh'
            reloadBtn.appendChild(reloadIcon)
            reloadBtn.children
            reloadBtn.addEventListener('click', (ev) => {
                ev.currentTarget.children[0].className += ' fa-spin'
                self.sendSocketNotification('UPDATE_DEVICES')
            })
            wrapper.appendChild(reloadBtn)
        }
        return wrapper
    },

    getStyles: function () {
        return [this.file('sound-selector.css')]
    },

    getTranslations: function () {
        return {
            es: 'translations/es.json',
            en: 'translations/en.json'
        }
    },
})