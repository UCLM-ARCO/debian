const NodeHelper = require('node_helper')
const ChildProcess = require('child_process')
const execAsUser = function (cmd, _default = undefined) {
    let _cmd = 'XDG_RUNTIME_DIR=/run/user/$(id -u $USER) ' + cmd
    try {
        return ChildProcess.execSync(
            _cmd, { encoding: 'utf-8' }).trim()
    } catch (error) {
        console.error('ChildProcess.execSync error: '
            + 'command: "' + _cmd + '" ' +
            + 'error: "' + error + '"')
        if (_default !== undefined)
            return _default
        else
            throw error
    }
}

class PulseAudioManager {
    #sinks = {} // name: index
    #active = undefined

    constructor() {
        if (!execAsUser('which pulseaudio', '') === '')
            throw 'PulseAudio is not installed!'
        this.updateSinks()
    }

    isRunning() {
        let num = parseInt(execAsUser(
            'ps ax | grep pulseaudio | wc -l', '0'), 10)
        if (num == NaN)
            return false
        return num >= 2
    }
    assertRunning() {
        if (this.isRunning())
            return true
        console.error('PulseAudio is not running!! ' +
            'Daemon restart part is not implemented, try rebooting!')
        return false
    }

    getSinks() { return this.#sinks }
    updateSinks() {
        if (!this.assertRunning())
            return false
        const stdout = execAsUser('pacmd list-sinks | grep ' +
            '-e index -e alsa.name', null)
        if (!stdout)
            return false
        this.#sinks = {}
        this.#active = undefined
        const regex = /(\*?)\s*index:\s*(\d+)[\s\n]*alsa\.name\s*=\s*"(.*)"/gm
        do {
            let match = regex.exec(stdout)
            if (!match)
                break
            this.#sinks[match[3]] = parseInt(match[2], 10)
            if (match[1] !== '')
                this.#active = match[3]
        } while (true)
        return true
    }

    getActiveSink() { return this.#active }
    setActiveSink(index) {
        if (!this.assertRunning())
            return false
        let retval = true
        try {
            execAsUser('pactl set-default-sink ' +
                index.toString())
            this.updateSinks()
        } catch (error) {
            retval = false
        }
        return retval
    }
}

module.exports = NodeHelper.create({
    aliases: { // name: alias
        'bcm2835 Headphones': 'jack',
        'MAI PCM i2s-hifi-0': 'hdmi'
    },
    paManager: new PulseAudioManager(),

    socketNotificationReceived: function (notification, payload) {
        switch (notification) {
            case 'SET_ALIASES':
                this.sendSocketNotification(
                    notification, this.addAliases(payload))
                break;
            case 'GET_DEVICES':
                this.sendSocketNotification(
                    notification, this.getDevices())
                break;
            case 'GET_ACTIVE':
                let alias = this.paManager.getActiveSink()
                if (Object.keys(this.aliases).includes(alias))
                    alias = this.aliases[alias]
                this.sendSocketNotification(
                    notification, alias)
                break;
            case 'SET_DEVICE':
                this.sendSocketNotification(
                    notification, this.selectDevice(payload))
                break;
            case 'UPDATE_DEVICES':
                this.sendSocketNotification(
                    notification, this.paManager.updateSinks())
            default:
                break;
        }
    },

    addAliases: function (extraAliases) {
        for (let name of Object.keys(extraAliases))
            this.aliases[name] = extraAliases[name]
    },

    getDevices: function () { // alias: index
        let retval = {}
        const devices = this.paManager.getSinks()
        for (const name of Object.keys(devices)) {
            let index = devices[name]
            let alias = name
            if (!Object.keys(this.aliases).includes(name))
                console.warn('Device ' + name + ' does not have an alias')
            else
                alias = this.aliases[name]
            retval[alias] = index
        }
        return retval
    },

    selectDevice: function (alias) {
        const devices = this.getDevices()
        if (!Object.keys(devices).includes(alias)) {
            console.error(this.name + ': Unknown device ' + alias)
            return false
        }
        console.info(this.name + ': Selecting ' + alias +
            ' (sink ' + devices[alias] + ')')
        return this.paManager.setActiveSink(devices[alias])
    }
})