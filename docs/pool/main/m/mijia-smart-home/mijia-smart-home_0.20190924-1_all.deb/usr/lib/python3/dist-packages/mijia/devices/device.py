# -*- mode: python; coding: utf-8 -*-

import logging
import json
from time import time


class Device:
    type = "unsupported"
    heartbeat_period = 3600  # given in seconds

    def __init__(self, gw, info):
        data = json.loads(info["data"])
        self.gw = gw
        self.sid = info["sid"]
        self.voltage = data.get("voltage")

        # voltage given in mV
        if self.voltage is not None:
            self.voltage = float(self.voltage) / 1000

        self.handlers = {}
        self.last_event_ts = None

    def on(self, ev_name, cb):
        self.handlers[ev_name] = cb

    def on_heartbeat(self, cb):
        """
        Installs an **event handler** that will be called when this device sends a `heartbeat`
        message.

        **Parameters:**

        * `cb`: callback function to be called. It must **accept two** parameters: the event
          **name** (a string), and the **device** that produces the event (a `Device` or
          derived object).
        """

        self.on("heartbeat", cb)

    def parse_heartbeat(self, data):
        self.notify_event("heartbeat")

    def parse_event(self, data):
        logging.warn("event of an unsupported device! (sid: {}, data: {})".format(
            self.sid, data))

    def notify_event(self, name, args=[]):
        self.last_event_ts = time()

        cb = self.handlers.get(name)
        if cb is not None:
            try:
                cb(name, self, *args)
            except Exception as e:
                logging.error("exception on callback!")
                logging.error(" - {}: {}".format(type(e), e))

    @property
    def status(self):
        """
        A property that provides the status of this device, which could be:

        * `unknown`: there is **not enough** information to set a valid status. It receives
          this state when the object is first created.
        * `online`: some message arrived **recently** from the device, so it is up
          and running correctly.
        * `offline`: the device has **not sent** a heartbeat during its heartbeat period
         (which is variable, but usually 10 minutes on battery devices).
        """

        if self.last_event_ts is None:
            return "unknown"

        if time() - self.last_event_ts < self.heartbeat_period + 10:
            return "online"
        return "offline"

    def __repr__(self):
        return "<Unsupported Device, sid: {}, status: {}>".format(
            self.sid, self.status)

