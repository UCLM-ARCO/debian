# -*- mode: python; coding: utf-8 -*-

import json

from .device import Device


class Motion(Device):
    """
    This is the Aqara **PIR** (or motion) sensor. It emits an event when a
    **moving** object is detected, and some other events when the **elapsed**
    time from the last motion detected **reaches** some pre-established
    thresholds (in the sensor firmware or in the Gateway).
    """

    type = "motion"

    def __init__(self, gw, info):
        """"""  # private constructor, generate no doc
        super().__init__(gw, info)
        self.elapsed_no_motion = None

    @property
    def elapsed_no_motion(self):
        """
        Gives the amount of elapsed **time** (in seconds) between the last `motion`
        event and the last `no_motion` event. It is **provided** with the `no_motion`
        event from the sensor (not computed locally).
        """
        return self._elapsed_no_motion

    @elapsed_no_motion.setter
    def elapsed_no_motion(self, value):
        self._elapsed_no_motion = value

    def on_motion(self, cb):
        """
        Attach a callback handler for `motion` events, which are sent when a
        moving object passes through the field of view of the sensor. The
        attached callback should be in the form:

        `def callback([self,], event, device)`

        Where `event` is the name of this event, and `device` is the device
        object that produced the event.
        """
        self.on("motion", cb)

    def on_no_motion(self, cb):
        """
        Attach a callback handler for `no_motion` events, which are sent when the
        **elapsed time** from the last detected motion reaches certain
        thresholds (120 seconds, 300, 600, and so on). The elapsed time is
        provided in the event, so the attached callback should be in the form:

        `def callback([self,], event, device, elapsed)`

        Where `event` is the name of this event, and `device` is the device
        object that produced the event.
        """
        self.on("no_motion", cb)

    def parse_event(self, data):
        name = data.get("status")
        value = data.get("no_motion")
        args = []

        if name == "motion":
            self.elapsed_no_motion = 0
        elif value is not None:
            name = "no_motion"
            self.elapsed_no_motion = int(value)
            args.append(self.elapsed_no_motion)

        self.notify_event(name, args)

    def __repr__(self):
        return "<Motion, sid: {}, status: {}, elapsed: {}>".format(
            self.sid, self.status, self.elapsed_no_motion)
