#!/usr/bin/python3
# -*- mode: python; coding: utf-8 -*-

import socket
import struct
import json
import logging
import time
from Crypto.Cipher import AES
from binascii import hexlify, unhexlify
from threading import Thread

from .devices import device_list, Device

# some GW static settings
BUFFER_SIZE = 2014
MCAST_ADDRESS = "224.0.0.50"
MCAST_PORT = 4321
UNICAST_PORT = 9898
AES_KEY_IV = unhexlify('17996d093d28ddb3ba695a2e6f58562e')

logging.getLogger().setLevel(logging.DEBUG)


def log_error(msg):
    def _decorator(fn):
        def _catch_except(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except (KeyError, AssertionError) as e:
                logging.error(msg)
                logging.error("- error was: {}, {}".format(type(e), e))
        return _catch_except
    return _decorator


class LumiGateway(Device):
    """
    This class is used to access a ***Lumi Gateway device*** (provided by Xiaomi / Aqara).
    It will automatically try to discover devices on your network, using the *Lumi LAN
    protocol*. It installs a thread to listen for incomming events, and also allows you
    to change the device light color.
    """

    type = "gateway"

    def __init__(self, passwd=None, mcast_member=None, sid=None):
        """
        LumiGateway constructor. This is the **starting point** of the library. You will need
        to create an instance of this class, and use it access other devices.

        **Parameters:**

        * `password`, *[optional]* the Wireless communication protocol **password**, needed to
          change the state of any device (which performs a `write` on the device).
        * `mcast_member`, *[optional]* the IP address of the interface that will be used as
          the **multicast member**. This address is used to receive events from the Lumi Gateway.
          If not provided, it will try to **automatically** determine it.
        * `sid`, *[optional]* the ID of an specific gateway (to filter other messages). It is
          the gateway MAC address, lowercase and no colons.
        """

        super().__init__(None, {"sid": sid, "data": "{}"})

        self.mcast_member = mcast_member
        self.passwd = passwd

        self.key = None
        self.ip_address = None
        self.port = None
        self.devices = {}
        self.color = None
        self.illumination = None
        self.version = "unknown"

    @property
    def illumination(self):
        """
        [read only property] Stores the Gateway's provided value for its **light
        sensor**. It's updated when a *change* event arrives, and on start-up.
        """
        return self._illumination

    @illumination.setter
    def illumination(self, value):
        self._illumination = value

    def start(self):
        """
        Start the **discovery process**. It will search for an active gateway, and then list its
        linked devices. It also starts the *listening thread* to receive messages from
        the Gateway. You usually will **need** to call this method.
        """

        self.listen_on_mcast_socket(self.mcast_member)
        if not self.discover_gw():
            return
        self.read_gw_info()
        self.discover_device_list()

    def wait_until_break(self):
        """
        **Blocks** the calling thread execution until it receives a `KeyboardInterrupt` (Ctrl+C)
        Use it (or use instead an **event loop**) to keep the application **running** while
        you wait for incoming events.
        """

        while True:
            try:
                time.sleep(0.1)
            except KeyboardInterrupt:
                break

    def read_gw_info(self):
        response = json.loads(self.unicast_msg({"cmd": "read", "sid": self.sid}))
        data = json.loads(response["data"])

        self.color = data["rgb"]
        self.illumination = data["illumination"]
        self.version = data["proto_version"]

    def set_light_color(self, r=0, g=0, b=0, i=0):
        """
        Changes the Gateway's light to the given **color** (by RGB components)
        and **intensity**. Note that the provided values are **relative** to
        each other, so a value of (1, 0, 0) will produce the same result as
        (255, 0, 0).

        **Parameters:**

        * `r`: int in range [0, 255]; **red** component of the light's color.
        * `g`: int in range [0, 255]; **green** component of the light's color.
        * `b`: int in range [0, 255]; **blue** component of the light's color.
        * `i`: int in range [0, 100]; light **intensity**.
        """

        color = int("0x{}{}{}{}".format(
            *["{:02x}".format(x) for x in (i, r, g, b)]
        ), 16)
        data = json.dumps(dict(rgb=color, key=self.key))
        response = self.unicast_msg(dict(
            cmd='write',
            sid=self.sid,
            data=data
        ))

        response = json.loads(response)
        data = json.loads(response["data"])
        if "error" in data:
            logging.error(data['error'])

    def light_off(self):
        """
        Switch **off** Gateway's light. The same result could be achieved
        providing 0 as intensity on `set_light_color()`.
        """

        self.set_light_color(0, 0, 0, 0)

    def listen_on_mcast_socket(self, my_address):
        if my_address is None:
            my_address = self.get_local_addr()

        logging.info("using {} for multicast membership".format(my_address))
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, BUFFER_SIZE)
        self.sock.setsockopt(
            socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,
            struct.pack("4s4s", socket.inet_aton(MCAST_ADDRESS), socket.inet_aton(my_address)))
        self.sock.settimeout(20)
        self.sock.bind(("0.0.0.0", UNICAST_PORT))

        t = Thread(target=self.listen_for_events, daemon=True)
        t.start()

    def listen_for_events(self):
        while True:
            try:
                data, _ = self.sock.recvfrom(BUFFER_SIZE)
                self.process_event(data)
            except socket.timeout:
                continue
            except KeyboardInterrupt:
                break

    def process_event(self, data):
        data = json.loads(data.decode("utf-8"))
        if data["cmd"] == "heartbeat":
            self.process_heartbeat(data)
        elif data["cmd"] == "report":
            self.process_report(data)
        else:
            logging.info("unknown message command: {}, ignored".format(data["cmd"]))

    # this methid is inherited from device, used to parse GW's reports
    @log_error("invalid 'report' event, ignoring!")
    def parse_event(self, data):
        self.color = data["rgb"]
        self.illumination = data["illumination"]
        self.notify_event("change")

    def on_change(self, cb):
        """
        Stablish a callback to be called when the Gateway's light sensor
        changes. The callback signature should be as follows:

        `def callback([self,] event, device)`

        Where `event` is the **name** of this event (*change*), and `device` is
        the Gateway device. To retrieve the **current value** of the light sensor,
        use the property `illumination`.

        """

        self.on("change", cb)

    def parse_heartbeat(self, data):
        self.notify_event("heartbeat")

    def get_local_addr(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.connect(('<broadcast>', 0))
        return s.getsockname()[0]

    def discover_gw(self):
        responses = self.multicast_msg({"cmd": "whois"}, multiresponse=True)
        for r in responses:
            if self.process_whois_response(r):
                return True
        if self.sid is not None:
            logging.error("Invalid provided gateway ID: {}".format(self.sid))
            return False

    def discover_device_list(self):
        response = self.unicast_msg({"cmd": "get_id_list", "sid": self.sid})
        self.process_get_id_list_response(response)

        for sid in self.devices:
            response = self.unicast_msg({"cmd": "read", "sid": sid})
            self.process_read_response(response)

    def multicast_msg(self, msg, multiresponse=False):
        # FIXME: store socket for later usage
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 20)
        if not multiresponse:
            return self.retry_send(sock, msg, MCAST_ADDRESS, MCAST_PORT)
        return self.retry_send_multiple_response(
            sock, msg, MCAST_ADDRESS, MCAST_PORT)

    def unicast_msg(self, msg):
        # FIXME: store socket for later usage
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        return self.retry_send(sock, msg, self.ip_address, UNICAST_PORT)

    def retry_send(self, sock, msg, address, port):
        msg = json.dumps(msg).encode()

        for i in range(1, 5):
            sock.settimeout(i)
            sock.sendto(msg, (address, port))
            try:
                data, _ = sock.recvfrom(BUFFER_SIZE)
                return data.decode("utf-8")
            except socket.timeout:
                logging.info("no response from UDP message, retrying...")
                continue

        logging.error("did not receive response from message")

    def retry_send_multiple_response(self, sock, msg, address, port):
        msg = json.dumps(msg).encode()
        responses = []

        for i in range(1, 5):
            sock.settimeout(i)
            sock.sendto(msg, (address, port))
            while True:
                try:
                    data, _ = sock.recvfrom(BUFFER_SIZE)
                    responses.append(data.decode("utf-8"))
                except socket.timeout:
                    break

            if responses:
                return responses

            logging.info("no response from UDP message, retrying...")

        if not responses:
            logging.error("did not receive response from message")
        return responses

    def get_devices(self, filter=None):
        """
        Returns a **dictionary** (pairs of `sid` and `Device` objects) with the
        currently linked devices.

        **Parameters:**

        * `filter`: used to retrieve **only** devices of the given type. You
          could use the class of a `Device`, its `type` property or even the
          type value. For instance, to get only the `Switch` objects, you may
          use any of the following options:

        `gw.get_devices(filter=Switch)`<br>
        `gw.get_devices(filter=Switch.type)`<br>
        `gw.get_devices(filter="switch")`
        """

        if filter is None:
            return self.devices
        if issubclass(filter.__class__, Device):
            filter = filter.type
        return {sid: dev for sid, dev in self.devices.items() if dev.type == filter}

    @log_error("invalid 'iam' response, ignoring!")
    def process_whois_response(self, response):
        response = json.loads(response)

        assert response["cmd"] == "iam"
        if self.sid is None or self.sid == response["sid"]:
            self.sid = response["sid"]
            self.ip_address = response["ip"]
            self.port = response["port"]
            return True
        return False

    @log_error("invalid 'get_id_list_ack' response, ignoring!")
    def process_get_id_list_response(self, response):
        response = json.loads(response)
        self.key = self.encrypt(response["token"])

        assert response["cmd"] == "get_id_list_ack"
        for sid in json.loads(response["data"]):
            self.devices[sid] = None

    @log_error("invalid 'read_ack' response, ignoring!")
    def process_read_response(self, response):
        response = json.loads(response)

        assert response["cmd"] == "read_ack"
        if response["sid"] not in self.devices:
            return
        Plugin = device_list.get(response["model"], Device)
        self.devices[response["sid"]] = Plugin(self, response)

    @log_error("invalid 'report' event, ignoring!")
    def process_report(self, report):
        assert report["cmd"] == "report"

        sid = report["sid"]
        dev = self if sid == self.sid else self.devices.get(sid)
        if dev is None:
            return
        data = json.loads(report["data"])
        data['lgw:event_type'] = "report"
        dev.parse_event(data)

    @log_error("invalid 'heartbeat' event, ignoring!")
    def process_heartbeat(self, heartbeat):
        assert heartbeat["cmd"] == "heartbeat"

        sid = heartbeat["sid"]
        if sid == self.sid:
            self.key = self.encrypt(heartbeat["token"])
            dev = self
        else:
            dev = self.devices.get(sid)
            if dev is None:
                return
        dev.parse_heartbeat(json.loads(heartbeat["data"]))

    def encrypt(self, token):
        if self.passwd is None:
            logging.warning("using not ciphered key (password not provided)")
            self.passwd = ""

        if self.passwd == "":
            return ""

        try:
            cipher = AES.new(self.passwd, AES.MODE_CBC, IV=AES_KEY_IV)
            ciphertext = cipher.encrypt(token)
            return hexlify(ciphertext).decode()
        except ValueError as e:
            logging.error(str(e))
            return ""

    def __repr__(self):
        return "<LumiGW, sid: {}, ip: {}, status: {}, rgb: {}, illumination: {}, version: {}>"\
            .format(self.sid, self.ip_address, self.status, self.color,
            self.illumination, self.version)
