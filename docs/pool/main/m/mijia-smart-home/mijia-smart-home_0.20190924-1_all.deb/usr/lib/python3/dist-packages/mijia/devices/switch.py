# -*- mode: python; coding: utf-8 -*-

import json

from .device import Device

class Switch(Device):
    """
    This is the Aqara push button that emits **4** different events. All event
    callbacks **should met** the following signature:

    `def callback([self,], event, device)`

    Where `event` is the name of the event, and `device` is the device object
    that produced this event.
    """

    type = "switch"

    def __init__(self, gw, info):
        """"""  # private constructor, generate no doc

        super().__init__(gw, info)
        self.pressed = False

    @property
    def pressed(self):
        """
        Property to retrieve the **current state** of the push button: `true` is
        pressed, `false` is not pressed.
        """
        return self._pressed

    @pressed.setter
    def pressed(self, value):
        self._pressed = value

    def on_click(self, cb):
        """
        Attach callback handler for `click` events, which is a **single press** on
        the button.
        """
        self.on("click", cb)

    def on_double_click(self, cb):
        """
        Attach callback handler for `double_click` events, which is a **double press** on
        the button.
        """
        self.on("double_click", cb)

    def on_long_click_press(self, cb):
        """
        Attach callback handler for `long_click_press` events. These events are
        produced when the button is **pressed and maintained** for more that 1
        second. It is paired with the `long_click_release` event.
        """
        self.on("long_click_press", cb)

    def on_long_click_release(self, cb):
        """
        Attach callback handler for `long_click_release` events. These events
        are produced when the button is pressed, maintained for more that 1
        second and then **released**. It is paired with the `long_click_press`
        event.
        """
        self.on("long_click_release", cb)

    def parse_event(self, data):
        name = data["status"]

        if name == "long_click_press":
            self.pressed = True
        elif name == "long_click_release":
            self.pressed = False

        self.notify_event(name)

    def __repr__(self):
        return "<Switch, sid: {}, status: {}, pressed: {}>".format(
            self.sid, self.status, self.pressed)
