# -*- mode: python; coding: utf-8 -*-

import json
import logging

from .device import Device

class WeatherV1(Device):
    """
    Aqara weather sensor (version 1.0). It provides readings for
    **temperature**, **humidity** and air **pressure**. The latest provided
    values for these magnitudes **could be read** any time from the
    corresponding properties.

    All event callbacks **should met** the following signature:

    `def callback([self,], event, device, value)`

    Where `event` is the name of the event, `device` is the device object that
    produced this event, and `value` is the provided value (as **integer**) for that
    magnitude.
    """

    type = "weather.v1"

    def __init__(self, gw, info):
        """"""  # private constructor, generate no doc
        super().__init__(gw, info)
        data = json.loads(info["data"])

        # FIXME: convert to proper units
        self.temperature = int(data.get("temperature"))
        self.humidity = int(data.get("humidity"))
        self.pressure = int(data.get("pressure"))

    @property
    def temperature(self):
        """Last value provided on a **temperature event** (or retrieved on startup)."""
        return self._temperature

    @temperature.setter
    def temperature(self, value):
        self._temperature = int(value)

    @property
    def humidity(self):
        """Last value provided on a **humidity event** (or retrieved on startup)."""
        return self._humidity

    @humidity.setter
    def humidity(self, value):
        self._humidity = int(value)

    @property
    def pressure(self):
        """Last value provided on a **pressure event** (or retrieved on startup)."""
        return self._pressure

    @pressure.setter
    def pressure(self, value):
        self._pressure = int(value)

    def on_humidity(self, cb):
        """
        Attach callback handler for `humidity` events. Only sent when value
        **changes** from previous one.
        """
        self.on("humidity", cb)

    def on_temperature(self, cb):
        """
        Attach callback handler for `temperature` events. Only sent when value
        **changes** from previous one.
        """
        self.on("temperature", cb)

    def on_pressure(self, cb):
        """
        Attach callback handler for `pressure` events. Only sent when value
        **changes** from previous one.
        """
        self.on("pressure", cb)

    def parse_event(self, data):
        # FIXME: convert value to proper units
        for name in ("temperature", "humidity", "pressure"):
            value = data.get(name)
            if value is not None:
                break

        if value is None:
            logging.warn("unknown event received (sid: {}, data: {})".format(
            self.sid, data))
            return

        self.notify_event(name, [int(value)])

    def __repr__(self):
        return "<WeatherV1, sid: {}, status: {}, temp: {}, humi: {}, press: {}>".format(
            self.sid, self.status, self.temperature, self.humidity, self.pressure)
