# -*- mode: python; coding: utf-8 -*-

import json

from .device import Device


class Magnet(Device):
    """
    Aqara **reed sensor** (magnet) for detection of opening and close of doors
    and windows. It emits an `open` event when the two components of the sensor
    are separated, and a `close` event when they are joined together. Also,
    `no_close` events are sent when the **elapsed** time from the last `open`
    event **reaches** some pre-established thresholds (in the sensor firmware or
    in the Gateway).
    """

    type = "magnet"

    def __init__(self, gw, info):
        """"""  # private constructor, generate no doc
        super().__init__(gw, info)
        self.elapsed_no_close = None

        data = json.loads(info["data"])
        st = data["status"]
        self.open = None if st == "unknown" else st == "open"

    @property
    def open(self):
        """
        `True` if the sensor detects that the door/window is open (or the two
        components of the sensore are not together). `False` otherwise.
        """
        return self._open

    @open.setter
    def open(self, value):
        self._open = value

    @property
    def elapsed_no_close(self):
        """
        Gives the amount of elapsed **time** (in seconds) from the last `open`
        event. It is **provided** with the `no_close` event from the sensor (not
        computed locally).
        """
        return self._elpased_no_close

    @elapsed_no_close.setter
    def elapsed_no_close(self, value):
        self._elpased_no_close = value

    def on_open(self, cb):
        """
        Attach callback handler for `open` events, which are sent when the
        sensor detects the **opening** of the door/window. The attached callback
        should be in the form:

        `def callback([self,], event, device)`

        Where `event` is the name of this event, and `device` is the device
        object that produced the event.
        """
        self.on("open", cb)

    def on_close(self, cb):
        """
        Attach a callback handler for `close` events, which are sent when the
        sensor detects the **closing** of the door/window. The attached callback
        should be in the form:

        `def callback([self,], event, device)`

        Where `event` is the name of this event, and `device` is the device
        object that produced the event.
        """
        self.on("close", cb)

    def on_no_close(self, cb):
        """
        Attach a callback handler for `no_close` events, which are sent when the
        **elapsed time** from the last `open` event reaches certain
        thresholds (120 seconds, 300, 600, and so on). The elapsed time is
        provided in the event, so the attached callback should be in the form:

        `def callback([self,], event, device, elapsed)`

        Where `event` is the name of this event, and `device` is the device
        object that produced the event.
        """
        self.on("no_close", cb)

    def parse_event(self, data):
        name = data.get("status")
        value = data.get("no_close")
        args = []

        if name == "open":
            self.open = True
        elif name == "close":
            self.open = False
        elif value is not None:
            name = "no_close"
            self.elapsed_no_close = int(value)
            args.append(self.elapsed_no_close)

        self.notify_event(name, args)

    def __repr__(self):
        return "<Magnet, sid: {}, status: {}, open: {}>".format(
            self.sid, self.status, self.open)
