# -*- mode: python; coding: utf-8 -*-

from .device import Device
from .switch import Switch
from .magnet import Magnet
from .motion import Motion
from .weather_v1 import WeatherV1
from .plug import Plug
from .cube_aqgl01 import CubeAqgl01

# FIXME: load this list dynamically
device_list = {
    Switch.type: Switch,
    Magnet.type: Magnet,
    Motion.type: Motion,
    WeatherV1.type: WeatherV1,
    Plug.type: Plug,
    CubeAqgl01.type: CubeAqgl01
}