# -*- mode: python; coding: utf-8 -*-

import logging
import json

from .device import Device

class Plug(Device):
    """
    This is the Aqara plug controller. Emits **2** different events, to
    **notify** if someone enabled or disabled the plug. You can also **change
    the state** of the plug: enable or disable it. The properties `enabled` and
    `inuse` will give you **information** about the plug usage.

    All event callbacks **should met** the following signature:

    `def callback([self,], event, device)`

    Where `event` is the name of the event, and `device` is the device object
    that produced this event.
    """

    type = "plug"

    def __init__(self, gw, info):
        """"""  # private constructor, generate no doc
        super().__init__(gw, info)
        data = json.loads(info["data"])

        self.enabled = data['status'] == 'on'
        self.inuse = data['inuse'] != "0"

        self.power_consumed = int(data["power_consumed"]) \
            if "power_consumed" in data else 0
        self.load_power = float(data["load_power"]) \
            if "load_power" in data else 0

    @property
    def enabled(self):
        """
        `True` if the plug is enabled (provides energy to the connected
        appliance), `False` otherwise.
        """
        return self._enabled

    @enabled.setter
    def enabled(self, value):
        self._enabled = value

    @property
    def inuse(self):
        """
        `True` if there are a **connected** appliance, and it is currently **consuming**
        energy. `False` otherwise.
        """
        return self._inuse

    @inuse.setter
    def inuse(self, value):
        self._inuse = value

    @property
    def power_consumed(self):
        """
        The cumulative load **power consumption** since the product was used, in
        Wh.
        """
        return self._power_consumed

    @power_consumed.setter
    def power_consumed(self, value):
        self._power_consumed = value

    @property
    def load_power(self):
        """
        Connected appliance (load) power usage, in watts (W).
        """
        return self._load_power

    @load_power.setter
    def load_power(self, value):
        self._load_power = value

    def on_switch_off(self, cb):
        """
        Attach callback handler for `switch_off` events, which are sent when
        someone presses the **built-in** button of the plug (or otherwise
        changes the **enabled** state), and the state goes from `on` to `off`.
        """
        self.on("switch_off", cb)

    def on_switch_on(self, cb):
        """
        Attach callback handler for `switch_on` events, which are sent when
        someone presses the **built-in** button of the plug (or otherwise
        changes the **enabled** state), and the state goes from `off` to `on`.
        """
        self.on("switch_on", cb)

    def parse_heartbeat(self, data):
        super().parse_heartbeat(data)

        self.power_consumed = int(data["power_consumed"])
        self.load_power = float(data["load_power"])

    def parse_event(self, data):
        name = data["status"]

        if name == "on":
            self.enabled = True
        elif name == "off":
            self.enabled = False

        self.notify_event("switch_" + name)

    def switch(self, state):
        data = json.dumps(dict(status=state, key=self.gw.key))
        response = self.gw.unicast_msg(dict(
            cmd='write',
            sid=self.sid,
            data=data
        ))

        response = json.loads(response)
        data = json.loads(response["data"])
        if "error" in data:
            logging.error(data['error'])

    def switch_on(self):
        """
        Call this method to **enable** the plug (provide energy to connected
        appliance). Remember that you must provide a **password** on the Gateway
        construction for this method to work.
        """
        self.switch("on")

    def switch_off(self):
        """
        Call this method to **disable** the plug (does **not** provide energy to
        connected appliance). Remember that you must provide a **password** on
        the Gateway construction for this method to work.
        """
        self.switch("off")

    def __repr__(self):
        return "<Plug, sid: {}, status: {}, enabled: {}, inuse: {}, consumed: {}, load: {}>"\
            .format(self.sid, self.status, self.enabled, self.inuse,
                self.power_consumed, self.load_power)
