# -*- mode: python; coding: utf-8 -*-

import json

from .device import Device

class CubeAqgl01(Device):
    """
    Mi Cube Controller, which is a device that detects **different movements**
    or actions performed on itself: tap, double tap, flips of 90 and 180
    degrees, rotation, move, shake, swing and free fall. It also works as a
    **motion sensor**: when you touches it after a while, it will send an
    `alert` event.

    Except for the `rotate` event, all the attached callbacks should be in the
    form:

    `def callback([self,], event, device)`

    Where `event` is the name of this event, and `device` is the device object
    that produced the event.
    """

    type = "sensor_cube.aqgl01"

    def __init__(self, *args, **kwargs):
        """"""  # private constructor, generate no doc
        super().__init__(*args, **kwargs)

    def on_alert(self, cb):
        """
        Attach a callback handler for `alert` events. These events are sent when
        the cube is **moved after some time** of inactivity (no movement).
        """
        self.on("alert", cb)

    def on_tap_twice(self, cb):
        """
        Attach a callback handler for `tap_twice` events. These events are sent when
        the cube is **knocked twice** on an horizontal hard surface.
        """
        self.on("tap_twice", cb)

    def on_move(self, cb):
        """
        Attach a callback handler for `move` events, generated when you **displace
        the cube** some small distance on the horizontal plane.
        """
        self.on("move", cb)

    def on_flip90(self, cb):
        """
        Attach a callback handler for `flip90` events. These events are produced
        when the cube is **flipped 90 degrees** (i.e rotated on X and Y axis).
        """
        self.on("flip90", cb)

    def on_flip180(self, cb):
        """
        Attach a callback handler for `flip180` events. These events are produced
        when the cube is **flipped 180 degrees** (i.e rotated on X and Y axis).
        """
        self.on("flip180", cb)

    def on_shake_air(self, cb):
        """
        Attach a callback handler for `shake_air` events, which are sent when
        you take the cube and **shake it** on the air.
        """
        self.on("shake_air", cb)

    def on_rotate(self, cb):
        """
        Attach a callback handler for `rotate` events, which are sent when you
        **rotate** the cube along the vertical axis (Z axis).

        The attached callbacks should be in the form:

        `def callback([self,], event, device, degrees, time)`

        Where `event` is the name of this event, `device` is the device object
        that produced the event, `degrees` is the angle of the rotation, and
        `time` is the time that took the sensor to measure the angle.
        """
        self.on("rotate", cb)

    def on_free_fall(self, cb):
        """
        Attach a callback handler for `free_fall` events, which are sent when
        you **drop the cube** (or it experiments some acceleration on the vertical axis).
        """
        self.on("free_fall", cb)

    def on_swing(self, cb):
        """
        Attach a callback handler for `swing` events. These events are signaled
        when the cube makes a **fast swing** movement (one single shot is enough).
        Note that it is also a trigger for the `iam` event (used to link the
        cube to a Gateway).
        """
        self.on("swing", cb)

    def parse_event(self, data):
        args = []
        name = data.get("status")

        if name is None:
            name = "rotate"
            angle, detect_time = (int(x) for x in data[name].split(","))
            args.append(angle)
            args.append(detect_time)

        self.notify_event(name, args)

    def __repr__(self):
        return "<SensorCube, sid: {}, status: {}>".format(
            self.sid, self.status)
