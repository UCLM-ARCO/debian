class RFIDCardObserverI extends Shapes.RFIDService.CardObserver {
    /**
     * RFID card observer proxy
     * @param {*} manager Observer manager
     * @param {*} newCardCallback Callback for 'new card' event. Can be null.
     * @param {*} readCardCallback Callback for 'read' event. Can be null.
     * @param {*} removeCardCallback Callback for 'remove card' event. Can be null.
     */
    constructor(
        manager, newCardCallback = null,
        readCardCallback = null,
        removeCardCallback = null
    ) {
        super()
        this.manager = manager
        this.newCardCallback = newCardCallback
        this.readCardCallback = readCardCallback
        this.removeCardCallback = removeCardCallback
    }

    readField = function (name, format = /^.*$/g) {
        return this.manager.read(name)
            .then(value => {
                let decoder = new TextDecoder('utf-8')
                value = decoder.decode(value)
                    .replace(/\0/g, '')
                if (!format.test(value))
                    return undefined
                return value
            })
    }

    /**
     * Read user properties from RFID card.
     * @returns {User} Read user. Null if an error ocured.
     */
    readUser() {
        var self = this
        var userId = undefined
        var userPhone = undefined
        var userContact = undefined
        var userCalendar = undefined

        return self.readField('userId', /^\S{1,16}$/)
            .then(value => {
                userId = value
                return self.readField('phoneNumber', /^\+?\d{11,}$/)
            }).then(value => {
                userPhone = value
                return self.readField('emergencyContact', /^@?.+$|^#\+?\d{11,}$/)
            }).then(value => {
                userContact = value
                return self.readField('calendar', /^\d{1}\d{1}\d{3}\d{2}\S+$/)
            }).then(value => {
                if (value != undefined) {
                    try {
                        if (value.length < 11)
                            throw null

                        let is_personal = parseInt(value.substring(0, 1), 10); // 1
                        if (isNaN(is_personal))
                            throw null;
                        else if (is_personal < 0 && is_personal > 1)
                            throw null;
                        let cal_uri = is_personal ? "gmail.com" : "group.calendar.google.com";

                        let is_private = parseInt(value.substring(1, 2), 10); // 1
                        if (isNaN(is_private))
                            throw null;
                        else if (is_private < 0 && is_private > 1)
                            throw null;
                        let cal_privacy = is_private ? "private-" : "public";

                        let len1 = parseInt(value.substring(2, 5), 10); // 3
                        if (isNaN(len1))
                            throw null;
                        else if (len1 < 6 || len1 > 137)
                            throw null;

                        let len2 = parseInt(value.substring(5, 7), 10); // 2
                        if (isNaN(len2))
                            throw null;
                        else if (len2 > 64)
                            throw null;

                        let cal_id = value.substring(7, 7 + len1); // len1
                        let cal_token = value.substring(
                            7 + len1, 7 + len1 + len2); // len2
                        userCalendar = "https://calendar.google.com/calendar/ical/" +
                            `${cal_id}%40${cal_uri}/${cal_privacy}${cal_token}/basic.ics`;
                    } catch (err) {
                        userCalendar = undefined;
                    }
                }
                return new User(userId, userPhone, userContact, userCalendar)
            }).catch(reason => {
                _console.error('CardObserver: read user error: ' + reason)
                return null
            }).then(user => {
                if (this.readCardCallback != null)
                    this.readCardCallback(user)
                return user
            }).catch(reason => {
                _console.error('CardObserver: read card callback error: ' + reason)
                return null
            })
    }

    newCardPresent(_cardId) {
        try {
            if (this.newCardCallback != null)
                this.newCardCallback()
        } catch (err) {
            _console.error('CardObserver: new card callback error: ' + err)
        }
        this.readUser()
    }

    cardRemoved(_cardId) {
        try {
            if (this.removeCardCallback != null)
                this.removeCardCallback()
        } catch (err) {
            _console.error('CardObserver: remove card callback error: ' + err)
        }
    }
}

class RFIDClient {
    #managerPrx = undefined
    #observer = undefined
    #observerPrx = undefined
    #adapter = undefined

    constructor(communicator, onConnectCallback,
        onNewCardCallback,
        onReadCardCallback,
        onRemovedCardCallback,
        usessl = true, reconnectTimeout = 10 * 1000) {

        this.communicator = communicator
        this.connected = false
        this.onConnectCallback = onConnectCallback
        this.reconnectTimeout = reconnectTimeout

        this.#managerPrx = Shapes.RFIDService.ManagerPrx.uncheckedCast(
            this.communicator.stringToProxy('RFIDServiceManager -t:'
                + (usessl ? 'wss' : 'ws')
                + ' -h ' + (document.location.hostname || '127.0.0.1')
                + ' -p ' + (usessl ? 2650 : 2651)))
        this.#observer = new RFIDCardObserverI(
            this.#managerPrx, onNewCardCallback,
            onReadCardCallback, onRemovedCardCallback)
    }

    init() {
        var self = this
        this.communicator.createObjectAdapter('')
            .then(adapter => {
                self.#adapter = adapter
                self.#observerPrx = Shapes.RFIDService.CardObserverPrx.uncheckedCast(
                    self.#adapter.addWithUUID(self.#observer))

                return self.connect()
            }).then(() => {
                setInterval(() => {
                    if (self.connected) {
                        let conn = self.#managerPrx.ice_getCachedConnection()
                        if (conn != null)
                            if (conn._communicator != null)
                                return

                        self.connected = false
                    }
                    self.connect()
                }, self.reconnectTimeout)
            })
    }

    connect() {
        var self = this
        _console.log('RFIDClient: connect')
        return new Promise((resolve, reject) => {
            var conn = self.#managerPrx.ice_getCachedConnection()
            if (conn == null) {
                self.#managerPrx.ice_ping().then(() => {
                    conn = self.#managerPrx.ice_getCachedConnection()
                    if (conn == null)
                        reject('Cannot connect to manager proxy.')
                    resolve(conn)
                }).catch(reason => reject(reason))
            } else resolve(conn)
        }).then(conn => {
            conn.setAdapter(self.#adapter)
            return self.#managerPrx.registerObserver(self.#observerPrx)
        }).then(() => {
            self.connected = true
        }).catch(reason => {
            _console.error('RFIDClient: connect error: ' + reason)
            self.connected = false
        }).then(() => {
            self.onConnectCallback(self.connected)
        })
    }
}