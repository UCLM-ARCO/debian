Module.register('loginservice', {
    defaults: {
        fgColor: '#4287f5',
        bgColor: '#ffffff',
        onlyIcons: false,
        animateMenu: false,
        verbose: 1
    },

    onLogIn: function (user) {
        this.state.cardRead()
        if (this.state.id === this.state.STATE_PHYXIO_OPENED) {
            // Do not login while Phyxio is opened
            return
        } else if (this.state.id === this.state.STATE_LOGGED_IN
            && user !== null) {
            // Second card read (after login)
            this.user.contact = user.contact
            for (let m of Object.values(this.modules)) {
                if ('onCardRead' in m)
                    m.onCardRead()
            }
            return
        } else if (this.state.id !== this.state.STATE_LOGGING_IN) {
            // Incorrect status - Not executed onRFIDReading?
            _console.error(
                'onLogIn error: Incorrect state ' +
                'when trying to login. Expected ' +
                this.state.STATE_LOGGED_IN + ', actual ' +
                this.state.id)
            return
        } else if (user === null) {
            // Correct status - Null user
            this.state.loginErr()
            return
        }

        for (let f of this.required_card_fields) {
            if (user[f] == undefined) {
                _console.error(
                    'onLogIn error: Required user property ' +
                    f + ' is undefined in card')
                this.state.loginErrField(f)
                return
            }
        }

        this.user = user
        this.state.loginOk()

        for (let m of Object.values(this.modules)) {
            if ('onLogIn' in m)
                m.onLogIn()
        }

        _console.log('Logged as ' + this.user.id)
    },

    onLogOut: function () {
        if (this.state.id !== this.state.STATE_LOGGED_IN)
            return

        if (this.logOutTimeout !== undefined) {
            clearTimeout(this.logOutTimeout)
            this.logOutTimeout = undefined
        }

        for (let m of Object.values(this.modules))
            if ('onLogOut' in m)
                m.onLogOut()

        this.user = null
        this.state.loginTimeout()
    },

    onLogOutDelayed: function (timeout = 30 * 60 * 1000) {
        if (this.logOutTimeout !== undefined)
            clearTimeout(this.logOutTimeout)

        this.logOutTimeout = setTimeout(function () {
            this.logOutTimeout = undefined
            this.onLogOut()
        }.bind(this), timeout)
    },

    onRFIDConnect: function (connected) {
        if (connected) {
            this.state.rfidOk()
            return
        } else if (this.state.id == this.state.STATE_LOGGED_IN)
            this.onLogOut()
        else if (this.state.id == this.state.STATE_RFID_ERROR)
            return
        this.state.rfidErr()
    },

    onRFIDReading: function () {
        _console.log('Reading card...')
        this.state.cardDetected()
    },

    start: function () {
        this.id = this.data.identifier.split('_')[1]
        this.state = new LoginServiceState(this)
        this.modules = []
        this.required_card_fields = []
        this.user = null
        this.logOutTimeout = undefined

        if (this.data.position === undefined)
            this.data.position = 'bottom_right'

        let iceData = new Ice.InitializationData()
        iceData.properties = Ice.createProperties()
        iceData.properties.setProperty('Ice.ACM.Client.Heartbeat', '3')
        let iceComm = Ice.initialize(iceData)

        this.rfidClient = new RFIDClient(
            iceComm,
            this.onRFIDConnect.bind(this), // onConnectCallback
            this.onRFIDReading.bind(this), // onNewCardCallback
            this.onLogIn.bind(this), // onReadCardCallback
            this.onLogOutDelayed.bind(this), // onRemoveCardCAllback
            location.protocol === 'https:')

        // Autologing for testing
        // this.rfidClient = {
        //     connected: true,
        //     onConnectCallback: this.onRFIDConnect,
        //     init: function () {
        //         this.onConnectCallback(true)
        //     }
        // }

        _console = new Logger(this)
    },

    getDom: function () {
        let dom = document.createElement('span')

        if (this.modules.length == 0)
            dom.textContent = this.translate('loading-message')
        else {
            switch (this.state.id) {
                case this.state.STATE_RFID_ERROR:
                    dom.textContent = this.translate('connection-error-message')
                    break
                case this.state.STATE_LOGGED_OUT:
                    dom.textContent = this.translate('login-message')
                    break
                case this.state.STATE_LOGGING_ERROR:
                    if (this.state.error !== null)
                        dom.textContent = this.translate(
                            'login-error-field',
                            {'field': this.state.error})
                    else
                        dom.textContent = this.translate('login-error')
                    break
                case this.state.STATE_READING_CARD:
                    dom.textContent = this.translate('reading-card-message')
                    break
                case this.state.STATE_LOGGING_IN:
                    dom.textContent = this.translate('logging-in-message')
                    break
                case this.state.STATE_LOGGED_IN:
                    dom = createMenu()
                    break
                default:
                    break
            }
        }

        return dom
    },

    getStyles: function () {
        return [
            'font-awesome.css',
            this.file('css/menu.css')
        ]
    },

    getScripts: function () {
        return [
            this.file('js/logger.js'),
            this.file('js/state.js'),
            this.file('js/rfid-service-iface.js'),
            this.file('js/user-utils.js'),
            this.file('js/rfid-service.js'),
            this.file('js/mm-utils.js'),
            this.file('js/dom-utils.js')
        ]
    },

    getTranslations: function () {
        return {
            es: 'translations/es.json',
            en: 'translations/en.json'
        }
    },

    notificationReceived: function (notification, _payload) {
        if (notification === 'ALL_MODULES_STARTED')
            this.sendSocketNotification('READ_MODULES')
        else if (notification == 'PHYXIO_OPENED') {
            _console.log('Disabling loginservice...')
            this.state.phyxioOpened()
        }
        else if (notification == 'PHYXIO_CLOSED') {
            _console.log('Enabling loginservice...')
            this.state.phyxioClosed()
        }
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification === 'SET_MODULES') {
            let card_fields = []
            let filters = ['id!==' + this.id]
            for (let value of Array.from(payload)) {
                try {
                    let name = value.name
                    delete value

                    let mod = new AfterLoginModule(name, value)
                    this.modules.push(mod)
                    mod.onStartUp()

                    for (let f of mod.card_fields) {
                        if (card_fields.includes(f))
                            continue
                        card_fields.push(f)
                    }

                    if ('id' in value)
                        filters.push('id!==' + value.id)
                    else
                        filters.push('name!==' + name)
                } catch (err) {
                    _console.error('Load module from config error: ' + err)
                }
            }

            for (let m of getModulesByFilter(filters))
                this.modules.push(new BeforeLoginModule(m.name, {
                    id: m.data.identifier.split('_')[1],
                    config: m.config
                }))

            this.modules.push({
                name: 'logout',
                symbol: 'sign-out-alt',
                onClick: this.onLogOut.bind(this)
            })

            // Order required card fields for convinience
            for (let f of User.properties()) {
                if (card_fields.includes(f))
                    this.required_card_fields.push(f)
            }

            this.rfidClient.init()
            // Autologing for testing
            // this.onLogIn(new User(
            //     'anonymous', '+34666666666',
            //     'anonymous2',
            //     'webcal://localhost:8080/modules/loginservice/sample.ics'))

            setTimeout(this.updateDom.bind(this), 1000)
        }
    }
})