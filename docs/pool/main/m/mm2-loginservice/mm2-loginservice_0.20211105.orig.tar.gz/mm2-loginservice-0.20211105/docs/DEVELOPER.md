# Manual para desarrolladores

## JSON de configuración `modules.json`

Este archivo se compone de una lista de objetos. Cada objeto se corresponderá con un módulo de Magic Mirror que necesite algún dato del usuario autenticado. Estos objetos pueden tener las siguientes propiedades:

| Propiedad | Tipo | Valor por defecto | Descripción |
| - | - | - | - |
| name | Texto | REQUERIDO | Nombre del módulo a configurar. Debe estar presente en la configuración de Magic Mirror `config.js`. |
| symbol | Texto | Ninguno | Icono de *Font Awesome* que se mostrará en el menú para este módulo. Si no se proporciona, se entiende que no se quiere que el módulo se muestre como elemento en el menú. |
| onStartUp | Objeto o lista de objetos | Ninguno | *Callback(s)* a ejecutar cuando magic-mirror se inicie. |
| onLogIn | Objeto o lista de objetos | Ninguno | *Callback(s)* a ejecutar cuando el usuario inicie sesión con su pulsera RFID. |
| onLogOut | Objeto o lista de objetos | *Esconderse* | *Callback(s)* a ejecutar cuando el usuario cierre sesión, manualmente o por *timeout*. |
| onCardRead | Objeto o lista de objetos | Ninguno | *Callback(s)* a ejecutar cuando el usuario, una vez ya autenticado, pase una pulsera por el lector RFID. |
| onClick | Objeto o lista de objetos | *Alternar visibilidad* | *Callback(s)* a ejecutar cuando el usuario haga clic en el elemento del menú correspondiente al módulo. |

### *Callbacks*

Los *callbacks* se definen como objetos JSON y concretan una acción a ejecutar cuando ocurre un evento. Los tipos de *callback*, correspondiente a la propiedad `type`, están predefinidos y son:

- `notification`: Envia una notificación de Magic Mirror al módulo que corrresponda, el cual deberá implementar el proceso de dicha notificación. El *callback* puede tener las siguientes propiedades:

   | Propiedad | Tipo | Valor por defecto | Descripción |
   | - | - | - | - |
   | name | Texto | REQUERIDO | Nombre de la notificación a enviar. |
   | args | Lista | [] | Lista de argumentos a enviar con la notificación. |

   Por lo tanto, un *callback* de "notificación" puede definirse como:

   ```json
   {
        "type": "notification",
        "name": "MY_NOTIFICATION",
        "args": [ "arg1", "arg2", {"arg3": "any"} ]
   }
   ```

- `configuration`: Cambia los valores de configuración proporcionados del módulo correspondiente y reinicia el mismo, es decir, vuelve a ejecutar su método *start*.

   | Propiedad | Tipo | Valor por defecto | Descripción |
   | - | - | - | - |
   | config | Objeto | REQUERIDO | Contiene los valores de configuración a modificar y sus nuevos valores. |

   Por lo tanto, un *callback* de "configuración" puede definirse como:

   ```json
   {
        "type": "configuration",
        "config": {
            "propiedad1": "nuevo_valor",
            "propiedad2": {
                0: "propiedad2 será sustituido por este objeto"
            }
        }
   }
   ```

- `reset`: Restaura la configuración del módulo y reinicia el mismo, es decir, vuelve a ejecutar su método *start*.

   Por lo tanto, un *callback* de "restauración" puede definirse como:

   ```json
   {
        "type": "reset"
   }
   ```

- `show`: Muestra el módulo, si no estaba presente previamente, en la interfaz del usuario. 

   Por lo tanto, un *callback* de "mostrar" puede definirse como:

   ```json
   {
        "type": "show"
   }
   ```

- `hide`: Esconde el módulo, si estaba presente previamente, de la interfaz del usuario. 

   Por lo tanto, un *callback* de "esconder" puede definirse como:

   ```json
   {
        "type": "hide"
   }
   ```

Hay un *callback* que no puede llamarse desde la configuración del JSON, ya que se relaciona directamente con la IU y con el uso del menú, y es el *callback* de "alternar visibilidad" (`toggleVisibility`). Este *callback* esconde o muestra el módulo en la IU dependiendo de si está ya presente o no, respectivamente.

Para ciertos eventos hay *callbacks* por defecto que, si no expresa lo contrario, se ejecutarán además de los *callbacks* que se definan en el JSON. Si no queremos el comportamiento por defecto, debemos añadir la propiedad `executeDefault` a los *callbacks* con el valor `false`. Partiendo del ejemplo siguiente:

```json
"onClick": {
    "type": "notification",
    "executeDefault": false
    "name": "CLICK_NOTIFICATION"
},
"onLogOut": [
    {
        "type": "notification",
        "executeDefault": false
        "name": "LOGOUT_NOTIFICATION"
    },
    {
        "type": "reset"
    }
]
```

En el caso del evento `onClick` no se ejecutará el *callback* `toggleVisibility`, y para el evento `onLogOut` no se ejecutará el *callback* `hide`. Como puede observarse, en el caso de definir varios *callbacks* para un evento, basta con definir `executeDefault` como `false` en uno de ellos para omitit el *callback* por defecto.

### Utilizar los datos del usuario

Para poder transmitir los datos del usuario a los módulos configurados debemos escribir entre corchetes la propiedad del usuario que deseemos. Por ejemplo, un *callback* para enviar el id de Telegram a través de una notificación de Magic Mirror tendrá la sigiente forma:

```json
{
    "type": "notification",
    "name": "LOGGED_USER_ID",
    "args": [ "{id}" ]
}
```

El valor *{id}* será sustituido por el correspondiente del usuario autenticado.

Las propiedades de usuario disponibles son:

| Propiedad | Valor por defecto | Descripción |
| - | - | - |
| id | Texto | Id de Telegram |
| phone | Texto | Número de teléfono |
| contact | Texto | Id de Telegram de un contacto |
| calendar | Texto | Calendario de Google |