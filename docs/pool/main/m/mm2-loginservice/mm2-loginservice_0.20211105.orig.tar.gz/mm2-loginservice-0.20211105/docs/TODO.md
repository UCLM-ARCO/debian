# TODO list
## Bugs
1. *(Medium)* **Won't logout on exit**:   
   When magic-mirror-2 is stopped (systemctl), loginservice does 
   not log out the user, if logged in. Can affect other modules performance.
   Could be done by implementing stop function in node_helper.js, but 
   keep in mind that magic-mirror-2 forces exit after 3 seconds since a SIGTERM was 
   received...