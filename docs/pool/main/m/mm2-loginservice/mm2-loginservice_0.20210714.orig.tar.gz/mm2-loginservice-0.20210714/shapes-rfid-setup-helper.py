import argparse
import re
from math import ceil

def read_user(args):
    pass


def write_user(args):
    print(f'rfid-client -b 4 -w "{args.id}"')
    print(f'rfid-client -b 5 -w "{args.phone}"')
    print(f'rfid-client -b 6 -w "{args.emergency_contact}"')

    b = 8
    for i in range(ceil(len(args.calendar) / 16)):
        if b in [11, 15, 19]:
            b += 1
        print(f'rfid-client -b {b} -w "{args.calendar[i*16:i*16+16]}"')
        b += 1
    


def phone_number(value):
    if re.match(r'^(?:\+\d{2})\d{9}$', value) is None:
        raise argparse.ArgumentTypeError(f'"{value}" is not a phone number')
    return value


def telegram_user(value):
    if re.match(r'^\S{1,16}$', value) is None:
        raise argparse.ArgumentTypeError(f'"{value}" is not a telegram user id')
    return value


def google_calendar(value):
    cal_match = re.match(
        r'^.*calendar.google.com/calendar/ical/(\S*\.com)/private-(\S{32})/basic.ics$', value)
    if cal_match is None:
        raise argparse.ArgumentTypeError(f'"{value}" is not a private google calendar')

    id_match = re.match(r'^(\S{26})%40group.calendar.google.com$', cal_match.group(1))
    if id_match is None:
        raise argparse.ArgumentTypeError(f'Calendar cannot be the user default one. Please, create one specifically.')
    
    return id_match.group(1) + cal_match.group(2)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    action = parser.add_subparsers(metavar='ACTION')

    write = action.add_parser(
        name='write', help='Write user information into RFID card.')
    write.add_argument('id', metavar='USER_ID',
                       type=telegram_user, help='Telegram user id.')
    write.add_argument('phone', metavar='PHONE_NUMBER',
                       type=phone_number, help='User phone number.')
    write.add_argument('emergency_contact', metavar='EMERGENCY_CONTACT',
                       type=telegram_user, help='User emergency contact.')
    write.add_argument('calendar', metavar='CALENDAR_URL',
                       type=google_calendar, help='User google calendar private URL.')
    write.set_defaults(func=write_user)

    read = action.add_parser(name='read',
                             help='Read user information from RFID card.')
    read.set_defaults(func=read_user)

    args = parser.parse_args()
    args.func(args)
