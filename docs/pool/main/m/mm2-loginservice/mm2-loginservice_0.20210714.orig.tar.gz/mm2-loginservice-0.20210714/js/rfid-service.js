class RFIDCardObserverI extends Shapes.RFIDService.CardObserver {
    constructor(manager, newCardCallback, removeCardCallback) {
        super()
        this.manager = manager
        this.newCardCallback = newCardCallback
        this.removeCardCallback = removeCardCallback
    }

    readField = function (name, format = /^.*$/g) {
        return this.manager.read(name)
            .then(value => {
                let decoder = new TextDecoder('utf-8')
                value = decoder.decode(value)
                    .replace(/\0/g, '')

                if (!format.test(value))
                    throw `"${value}" does not match ${name} format`
                return value
            })
    }

    /**
     * Read user properties from RFID card.
     * @returns {User} Read user. Null if an error ocured.
     */
    readUser() {
        var self = this
        var userId = undefined
        var userPhone = undefined
        var userContact = undefined
        var userCalendar = undefined

        return self.readField('userId', /^\S{1,16}$/)
            .then(value => {
                userId = value
                return self.readField('phoneNumber', /^(?:\+\d{2})?\d{9}$/)
            }).then(value => {
                userPhone = value
                return self.readField('emergencyContact', /^\S{1,16}$/)
            }).then(value => {
                userContact = value
                return self.readField('calendar', /^\S{58}$/)
            }).then(value => {
                userCalendar = 'https://calendar.google.com/calendar/ical/'
                    + value.substring(0, 26) + '%40group.calendar.google.com/private-'
                    + value.substring(26, value.length) + '/basic.ics'
                return new User(userId, userPhone, userContact, userCalendar)
            }).catch(reason => {
                console.error('CardObserver: readUser error: ' + reason)
                return null
            })
    }

    newCardPresent(_cardId) {
        try {
            this.readUser().then(user => this.newCardCallback(user))
        } catch (err) {
            console.error('CardObserver: new card callback error: ' + err)
        }
    }

    cardRemoved(_cardId) {
        try {
            this.removeCardCallback()
        } catch (err) {
            console.error('CardObserver: remove card callback error: ' + err)
        }
    }
}

class RFIDClient {
    #managerPrx = undefined
    #observer = undefined
    #observerPrx = undefined
    #adapter = undefined

    constructor(communicator, onConnectCallback,
        onNewCardCallback, onRemovedCardCallback,
        usessl = true, reconnectTimeout = 30 * 1000) {

        this.communicator = communicator
        this.connected = false
        this.onConnectCallback = onConnectCallback
        this.reconnectTimeout = reconnectTimeout

        this.#managerPrx = Shapes.RFIDService.ManagerPrx.uncheckedCast(
            this.communicator.stringToProxy('RFIDServiceManager -t:'
                + (usessl ? 'wss' : 'ws')
                + ' -h ' + (document.location.hostname || '127.0.0.1')
                + ' -p ' + (usessl ? 2650 : 2651)))
        this.#observer = new RFIDCardObserverI(
            this.#managerPrx, onNewCardCallback, onRemovedCardCallback)
    }

    init() {
        var self = this
        this.communicator.createObjectAdapter('')
            .then(adapter => {
                self.#adapter = adapter
                self.#observerPrx = Shapes.RFIDService.CardObserverPrx.uncheckedCast(
                    self.#adapter.addWithUUID(self.#observer))

                return self.connect()
            }).then(() => {
                setInterval(() => {
                    if (self.connected) {
                        let conn = self.#managerPrx.ice_getCachedConnection()
                        if (conn != null)
                            if (conn._communicator != null)
                                return

                        self.connected = false
                    }
                    self.connect()
                }, self.reconnectTimeout)
            })
    }

    connect() {
        var self = this
        console.log('RFIDClient: connect')
        return new Promise((resolve, reject) => {
            var conn = self.#managerPrx.ice_getCachedConnection()
            if (conn == null) {
                self.#managerPrx.ice_ping().then(() => {
                    conn = self.#managerPrx.ice_getCachedConnection()
                    if (conn == null)
                        reject('Cannot connect to manager proxy.')
                    resolve(conn)
                }).catch(reason => reject(reason))
            } else resolve(conn)
        }).then(conn => {
            conn.setAdapter(self.#adapter)
            return self.#managerPrx.registerObserver(self.#observerPrx)
        }).then(() => {
            self.connected = true
        }).catch(reason => {
            console.error('RFIDClient: connect error: ' + reason)
            self.connected = false
        }).then(() => {
            self.onConnectCallback(self.connected)
        })
    }
}