
/**
 * Create a menu item. 
 * It is required to provide text and/or symbol. 
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {String} text Button text. Recommended for supporting assistive technologies.
 * @param {String} symbol Font Awesome icon name for button.
 * @param {String} id Button id. Recommended for supporting assistive technologies.
 * @param {String} description Button description (ARIA attributes). Recommended for supporting assistive technologies.
 * @returns {HTMLButtonElement} Created menu item.
 */
const createMenuItem = function (text = undefined, symbol = undefined,
    id = undefined, description = undefined) {
    var self = MM.getModules().withClass('loginservice')[0]

    if (text === undefined && symbol === undefined)
        throw 'Provide, at least, one of the following: text or symbol'

    let retval = document.createElement('button')
    retval.className = 'menu-item'
    retval.style = 'color: '
        + self.config.fgColor + '; background: '
        + self.config.bgColor + ';'

    if (id !== undefined)
        retval.id = 'menu-item-' + id

    if (description !== undefined) {
        let retvalDescription = document.createElement('p')
        if (id !== undefined) {
            retvalDescription.id = retval.id + '-description'
            retval.setAttribute('aria-describedby', retvalDescription.id)
        }
        retvalDescription.className = 'menu-item-description'
        retvalDescription.innerText = description
        retval.appendChild(retvalDescription)
    }

    if (symbol !== undefined) {
        let retvalIcon = document.createElement('i')
        retvalIcon.className = 'fa fa-' + symbol + ' menu-item-icon'
        if (id !== undefined)
            retvalIcon.id = retval.id + '-icon'
        retval.appendChild(retvalIcon)

        if (text !== undefined) {
            retvalIcon.style.marginRight = '.5rem'
        }
    }

    if (self.config.onlyIcons) {
        retval.classList.add('menu-item-just-icon')
    } else {
        if (text !== undefined) {
            let retvalText = document.createElement('span')
            retvalText.className = 'menu-item-text'
            retvalText.textContent = text
            if (id !== undefined) {
                retvalText.id = retval.id + '-text'
                retval.setAttribute('aria-labelledby', retvalText.id)
            } else
                retval.setAttribute('aria-label', text)
            retval.appendChild(retvalText)
        }
    }

    return retval
}

/**
 * Create a menu item which can be toggled on click. 
 * It is required to provide both default and toggle text and/or both default and toggle symbol. 
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {String} defaultText Button text when its not toggled. Recommended for supporting assistive technologies.
 * @param {String} toggledText Button text when its toggled. Recommended for supporting assistive technologies.
 * @param {String} defaultSymbol Font Awesome icon name for button when its not toggled.
 * @param {String} toggledSymbol Font Awesome icon name for button when its toggled.
 * @param {String} id Button id. Recommended for supporting assistive technologies.
 * @param {String} description Button description (ARIA attributes). Recommended for supporting assistive technologies.
 * @returns {HTMLButtonElement} Created menu item.
 */
const createToggleMenuItem = function (defaultText = undefined, toggledText = undefined,
    defaultSymbol = undefined, toggledSymbol = undefined,
    id = undefined, description = undefined) {
    var self = MM.getModules().withClass('loginservice')[0]

    if (defaultText === undefined
        && toggledText === undefined
        && defaultSymbol === undefined
        && toggledSymbol === undefined)
        throw 'Provide, at least, one of the following: texts or symbols'
    else if ((defaultText === undefined && toggledText !== undefined)
        || (defaultText !== undefined && toggledText === undefined))
        throw 'If text, provide both default_text and toggle_text'
    else if ((defaultSymbol === undefined && toggledSymbol !== undefined)
        || (defaultSymbol !== undefined && toggledSymbol === undefined))
        throw 'If text, provide both default_symbol and toggle_symbol'


    let retval = document.createElement('button')
    retval.className = 'menu-item menu-item-toggle'
    retval.style = 'color: '
        + self.config.fgColor + '; background: '
        + self.config.bgColor + ';'
    retval.setAttribute('aria-pressed', false)

    if (id !== undefined)
        retval.id = 'menu-item-' + id

    if (description !== undefined) {
        let retvalDescription = document.createElement('p')
        if (id !== undefined) {
            retvalDescription.id = retval.id + '-description'
            retval.setAttribute('aria-describedby', retvalDescription.id)
        }
        retvalDescription.className = 'menu-item-description'
        retvalDescription.innerText = description
        retval.appendChild(retvalDescription)
    }

    if (defaultSymbol !== undefined && toggledSymbol !== undefined) {
        let iconWrapper = document.createElement('div')
        iconWrapper.classList = 'menu-item-wrap'

        let retvalDefaultIcon = document.createElement('i')
        retvalDefaultIcon.className = 'fa fa-' + defaultSymbol + ' menu-item-icon default'
        if (id !== undefined)
            retvalDefaultIcon.id = retval.id + '-icon-default'
        iconWrapper.appendChild(retvalDefaultIcon)

        let retvalToggleIcon = document.createElement('i')
        retvalToggleIcon.className = 'fa fa-' + toggledSymbol + ' menu-item-icon toggle'
        if (id !== undefined)
            retvalToggleIcon.id = retval.id + '-icon-toggle'
        iconWrapper.appendChild(retvalToggleIcon)

        if (defaultText !== undefined && toggledText !== undefined) {
            iconWrapper.style.marginRight = '.5rem'
        }

        retval.appendChild(iconWrapper)
    }

    if (self.config.onlyIcons) {
        retval.classList.add('menu-item-just-icon')
    } else {
        if (defaultText !== undefined && toggledText !== undefined) {
            let textWrapper = document.createElement('div')
            textWrapper.classList = 'menu-item-wrap'

            let retvalDefaultText = document.createElement('i')
            retvalDefaultText.className = 'menu-item-text default'
            if (id !== undefined)
                retvalDefaultText.id = id + '-text-default'
            textWrapper.appendChild(retvalDefaultText)

            let retvalToggleText = document.createElement('i')
            retvalToggleText.className = 'menu-item-text toggle'
            if (id !== undefined)
                retvalToggleText.id = id + '-text-toggle'
            textWrapper.appendChild(retvalToggleText)

            retval.appendChild(textWrapper)
        }
    }

    retval.addEventListener('click', ev => {
        if (ev.currentTarget.classList.contains('toggled')) {
            ev.currentTarget.classList.remove('toggled')
            ev.currentTarget.setAttribute('aria-pressed', false)
            if (defaultText !== undefined) {
                if (id !== undefined)
                    ev.currentTarget.setAttribute('aria-labelledby', id + '-text-default')
                else
                    ev.currentTarget.setAttribute('aria-label', defaultText)
            }
        } else {
            ev.currentTarget.classList.add('toggled')
            ev.currentTarget.setAttribute('aria-pressed', true)
            if (toggledText !== undefined) {
                if (id !== undefined)
                    ev.currentTarget.setAttribute('aria-labelledby', id + '-text-toggle')
                else
                    ev.currentTarget.setAttribute('aria-label', toggledText)
            }
        }
    })

    return retval
}

/**
 * Create a menu item from ModuleWrapper properties.
 * It is required to provide text and/or symbol. 
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {ModuleWrapper} m Module wrapper to use.
 * @returns {HTMLButtonElement} Created menu item.
 */
const createMenuItemFromModuleWrapper = function (m) {
    var self = MM.getModules().withClass('loginservice')[0]
    let text = undefined
    if (!self.config.onlyIcons) {
        text = self.translate(m.name + '-label')
        if (text === m.name + '-label') // Unavailable translation
            text = m.name
    }

    let description = self.translate(
        'menu-service-button-description',
        { 'serviceName': m.name }
    )

    let item = createMenuItem(text, m.symbol, m.name, description)
    item.addEventListener('click', ev => {
        if (!ev.currentTarget.classList.contains('hidden')) {
            self.__proto__.onLogOutDelayed()
            m.onClick()
        }
    })

    return item
}

/**
 * Create a menu with loginservice "after-login" modules as menu items.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @returns {HTMLDivElement} Created menu
 */
const createMenu = function () {
    var self = MM.getModules().withClass('loginservice')[0]
    let menu = document.createElement('div')
    menu.className = 'menu menu-' + self.data.position.replace('_', '-')

    if (self.config.animateMenu) {
        let openMenuItem = createToggleMenuItem(
            undefined, undefined,
            'bars', 'times', 'open-menu-button',
            self.translate('open-menu-button')
        )
        openMenuItem.addEventListener('click', ev => {
            let menuItems = ev.currentTarget.parentElement.children
            for (let child of menuItems) {
                if (child === ev.currentTarget)
                    continue
                else if (!child.classList.contains('hidden')) {
                    child.classList.add('hidden')
                    child.setAttribute('aria-hidden', true)
                } else {
                    child.classList.remove('hidden')
                    child.setAttribute('aria-hidden', false)
                }
            }
        })
        menu.appendChild(openMenuItem)
    }

    let index = 0
    for (let m of self.modules) {
        if (m instanceof BeforeLoginModule)
            continue

        let item = createMenuItemFromModuleWrapper(m)
        if (self.config.animateMenu) {
            item.classList.add('hidden')
            item.setAttribute('aria-hidden', true)
            item.style.transitionDelay = 200 * (index++) + 'ms'
        }
        menu.appendChild(item)
    }

    return menu
}