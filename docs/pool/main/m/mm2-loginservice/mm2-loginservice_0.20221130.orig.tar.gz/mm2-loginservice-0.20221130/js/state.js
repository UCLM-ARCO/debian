class LoginServiceState {
    #states = ['CONNECTING_RFID', 'RFID_ERROR',
        'LOGGED_OUT', 'READING_CARD',
        'LOGGING_IN', 'LOGGING_ERROR',
        'LOGGED_IN', 'PHYXIO_OPENED']
    #current = 0 // CONNECTING_RFID
    #prev = 0

    constructor(_module) {
        this.module = _module
        this.error = null
        // State aliases
        let idx = 0
        for (let state of this.#states)
            this['STATE_' + state] = idx++
    }

    get id() {
        return this.#current
    }

    get name() {
        if (this.#current < 0 || this.#current >= this.#states.length)
            return 'UNKNOWN (id=' + this.#current + ')'
        return this.#states[this.#current]
    }

    #next(id, update_speed = 1500) {
        this.#prev = this.#current
        this.#current = id
        _console.log(
            'LoginServiceState: Changed ' +
            'state to ' + this.name)
        if (update_speed > 0) {
            this.module.updateDom(update_speed)
            this.error = null
        }
    }

    #undo(_default, update_speed = 1500) {
        let _current = this.#current
        if (this.#prev !== null)
            this.#current = this.#prev
        else {
            _console.warn(
                'LoginServiceState: Undo falling back ' +
                'to provided default')
            this.#current = _default
        }
        this.#prev = _current
        _console.log(
            'LoginServiceState: Changed ' +
            'state to ' + this.name)
        if (update_speed > 0) {
            this.module.updateDom(update_speed)
            this.error = null
        }
    }

    rfidOk() {
        if (this.#current == this.STATE_RFID_ERROR
            || this.#current == this.STATE_CONNECTING_RFID)
            this.#next(this.STATE_LOGGED_OUT)
        else
            _console.warn(
                'LoginServiceState: Ignoring ' +
                'rfid ok event on state ' +
                this.name)
    }

    rfidErr() {
        this.#next(this.STATE_RFID_ERROR)
    }

    cardDetected() {
        if (this.#current == this.STATE_LOGGED_OUT
            || this.#current == this.STATE_LOGGING_ERROR
            || this.#current == this.STATE_LOGGED_IN)
            this.#next(this.STATE_READING_CARD, 50)
        else
            _console.warn(
                'LoginServiceState: Ignoring ' +
                'card detected event on state ' +
                this.name)
    }

    cardRead() {
        if (this.#current == this.STATE_READING_CARD)
            this.#next(this.STATE_LOGGING_IN, 50)
        else
            _console.warn(
                'LoginServiceState: Ignoring ' +
                'card read event on state ' +
                this.name)
    }

    loginOk() {
        if (this.#current == this.STATE_LOGGING_IN)
            this.#next(this.STATE_LOGGED_IN)
        else
            _console.warn(
                'LoginServiceState: Ignoring ' +
                'login ok event on state ' +
                this.name)
    }

    loginErr() {
        if (this.#current == this.STATE_LOGGING_IN)
            this.#next(this.STATE_LOGGING_ERROR)
        else
            _console.warn(
                'LoginServiceState: Ignoring ' +
                'login error event on state ' +
                this.name)
    }

    loginErrField(field) {
        if (this.#current == this.STATE_LOGGING_IN)
            this.error = field
        this.loginErr()
    }

    loginTimeout() {
        if (this.#current == this.STATE_LOGGED_IN
            || this.#current == this.STATE_LOGGING_ERROR)
            this.#next(this.STATE_LOGGED_OUT)
        else
            _console.warn(
                'LoginServiceState: Ignoring ' +
                'timeout event on state ' +
                this.name)
    }

    phyxioOpened() {
        if (this.#current !== this.STATE_PHYXIO_OPENED)
            this.#next(this.STATE_PHYXIO_OPENED, 0)
        else
            _console.warn(
                'LoginServiceState: Ignoring ' +
                'phyxio opened event on state ' +
                this.name)
    }

    phyxioClosed() {
        if (this.#current == this.STATE_PHYXIO_OPENED)
            this.#undo(this.STATE_LOGGED_OUT, 0)
        else
            _console.warn(
                'LoginServiceState: Ignoring ' +
                'phyxio closed event on state ' +
                this.name)
    }
}