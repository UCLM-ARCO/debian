# Login module for Shapes SmartMirror

Using Shapes RFID service, this module allows an user to *log into* the mirror using a RFID band. After login in, a menu will be displayed with exclusive modules that use user data to customize its content or provide extra funcitonality.

## Usage

### Prepare your band

In order to use this module you have to record your personal data in a RFID card or band. 
Use `rfid-client` to do it:

| Field | Blocks | Format | Description |
|-|-|-|-|
| userId | 4 | Up to 16 non-space characters | User Telegram id |
| phoneNumber | 5 | 9 digits preceded, or not, by a country calling code (ex: +34) | User phone number |
| emergencyContact | 6 | Up to 16 non-space characters | User emergency contact Telegram id |
| calendar | 8, 9, 10, 12 | 58 alphanumeric characters (only 16 characters per block allowed) | Google Calendar URL ID. See [Appendix 1](#appendix-1-how-to-get-google-calendar-url-id).  |

You can use `rfid-client`, from the `shapes-rfid-service` package, to write your data into your RFID card. For example, for writing the `userId` field, put your RFID card in the RFID reader and execute:

```shell
$ rfid-client --block 4 --write "myUser"
```

### Customize

In Magic Mirror configuration file you can cusomize the menu appearance with the following config options:

| Option | Default | Type | Description |
|-|-|-|-|
| fgColor | #4287f5 | HTML Color | Foreground color of menu icons |
| bgColor | #ffffff | HTML Color | Background color of menu icons |
| onlyIcons | false | Boolean | Whether the menu items should display text with icons or just the latter |
| animateMenu | false | Boolean | If true, the user can open or close the menu, displaying an animation when it happens |
| logOutTimeout | 30 minutes | Integer | Timeout for auto-logout to occur (in milliseconds). If it is 0, auto-logout is disabled |

See [Magic Mirror documentation about configuring a module](https://docs.magicmirror.builders/modules/configuration.html) for more information.

## Appendix 1. How to get Google Calendar URL ID?

This module benefits from Google Calendar private URL generation, but be aware that those urls can be changed if the user resets them.

To it follow these steps:

1. Open [Google Calendar](https://calendar.google.com) on your browser.
2. Go under "My calendars" and click or hover over the calendar to use.
3. Click on the 3 dots that will appear on the right-hand side.
4. On the drop menu, select "Sharing and Settings".
5. Scroll all the way down and search for "Secret address in iCal format".
6. Click on the eye icon to show the address.
7. After confirming the security alert, you will see something like this: `https://calendar.google.com/calendar/ical/0a1b2c3d4e5f60a1b2c3d4e5f6%40group.calendar.google.com/private-abcd0123abcd0123abcd0123abcd0123/basic.ics`.
