Module.register('loginservice', {
    defaults: {
        fgColor: '#4287f5',
        bgColor: '#ffffff',
        onlyIcons: false,
        animateMenu: false,
        logOutTimeout: 30 * 60 * 1000,
        verbose: 1
    },

    onLogIn: function (user) {
        this.state.cardRead()
        if (this.state.id === this.state.STATE_PHYXIO_OPENED) {
            // Do not login while Phyxio is opened
            return
        } else if (this.state.id === this.state.STATE_LOGGING_IN
            && this.user !== null) {
            // Second card read (after login)
            if (user == null) {
                _console.error('Could not read card onCardRead event.')
                this.state.loginOk()
                return
            }
            for (let mod of this.modules) {
                if (mod.userFieldByEvent == undefined)
                    continue
                let ok = true
                for (let [ev, fields] of Object.entries(
                    mod.userFieldByEvent)) {
                    if (!ok)
                        break
                    if (ev !== 'onCardRead')
                        continue
                    for (let f of fields) {
                        if (user[f] == undefined) {
                            _console.warn('Field ' + f + ' undefined (or it ' +
                                'does not fit format) in user. ' +
                                'Disabling module ' + mod.name + ' menu item')
                            mod.disableOnlyMenuItem()
                            ok = false
                            break
                        } else {
                            _console.log('Enabling module ' + mod.name)
                            mod.enable()
                            this.user[f] = user[f]
                        }
                    }
                }
                if ('onCardRead' in mod && ok)
                    mod.onCardRead()
            }
            this.state.loginOk()
            return
        } else if (this.state.id !== this.state.STATE_LOGGING_IN) {
            // Incorrect status - Not executed onRFIDReading?
            _console.error(
                'onLogIn error: Incorrect state ' +
                'when trying to login. Expected ' +
                this.state.STATE_LOGGED_IN + ', actual ' +
                this.state.id)
            return
        } else if (user === null) {
            // Correct status - Null user
            this.state.loginErr()
            return
        }

        // Check required fields
        for (let mod of this.modules) {
            if (mod.userFieldByEvent == undefined)
                continue
            mod.enable()
            let ok = true
            for (let [ev, fields] of Object.entries(
                mod.userFieldByEvent)) {
                if (!ok)
                    break
                else if (ev == 'onCardRead')
                    continue
                for (let f of fields) {
                    if (user[f] == undefined) {
                        ok = false
                        if (ev == 'onClick') {
                            _console.warn('Field ' + f + ' undefined (or it ' +
                                'does not fit format) in user. ' +
                                'Disabling module ' + mod.name + ' menu item')
                            mod.disableOnlyMenuItem()
                        }
                        else {
                            _console.warn('Field ' + f + ' undefined (or it ' +
                                'does not fit format) in user. ' +
                                'Disabling module ' + mod.name)
                            mod.disable()
                        }
                        break
                    }
                }
            }
        }

        this.user = user
        this.state.loginOk()

        for (let m of Object.values(this.modules)) {
            if ('onLogIn' in m)
                m.onLogIn()
        }

        _console.log('Logged as ' + this.user.id)
    },

    onLogOut: function () {
        if (this.state.id !== this.state.STATE_LOGGED_IN)
            return

        if (this.logOutTimeout !== undefined) {
            clearTimeout(this.logOutTimeout)
            this.logOutTimeout = undefined
        }

        for (let m of Object.values(this.modules))
            if ('onLogOut' in m)
                m.onLogOut()

        this.user = null
        this.state.loginTimeout()
    },

    onLogOutDelayed: function () {
        if (this.logOutTimeout !== undefined)
            clearTimeout(this.logOutTimeout)

        if (this.config.logOutTimeout != 0) {
            _console.info(
                `Auto logout set in ${this.config.logOutTimeout} milliseconds`);
            this.logOutTimeout = setTimeout(function () {
                this.logOutTimeout = undefined;
                this.onLogOut();
            }.bind(this), this.config.logOutTimeout);
        } else _console.info('Autologin is disabled!')
    },

    onRFIDConnect: function (connected) {
        if (connected) {
            this.state.rfidOk()
            return
        } else if (this.state.id == this.state.STATE_LOGGED_IN)
            this.onLogOut()
        else if (this.state.id == this.state.STATE_RFID_ERROR)
            return
        this.state.rfidErr()
    },

    onRFIDReading: function () {
        _console.log('Reading card...')
        this.state.cardDetected()
    },

    start: function () {
        this.id = this.data.identifier.split('_')[1]
        this.state = new LoginServiceState(this)
        this.modules = []
        this.user = null
        this.logOutTimeout = undefined

        if (this.data.position === undefined)
            this.data.position = 'bottom_right'

        let iceData = new Ice.InitializationData()
        iceData.properties = Ice.createProperties()
        iceData.properties.setProperty('Ice.ACM.Client.Heartbeat', '3')
        let iceComm = Ice.initialize(iceData)

        this.rfidClient = new RFIDClient(
            iceComm,
            this.onRFIDConnect.bind(this), // onConnectCallback
            this.onRFIDReading.bind(this), // onNewCardCallback
            this.onLogIn.bind(this), // onReadCardCallback
            this.onLogOutDelayed.bind(this), // onRemoveCardCAllback
            location.protocol === 'https:')

        _console = new Logger(this)
    },

    getDom: function () {
        let dom = document.createElement('span')

        if (this.modules.length == 0)
            dom.textContent = this.translate('loading-message')
        else {
            switch (this.state.id) {
                case this.state.STATE_RFID_ERROR:
                    dom.textContent = this.translate('connection-error-message')
                    break
                case this.state.STATE_LOGGED_OUT:
                    dom.textContent = this.translate('login-message')
                    break
                case this.state.STATE_LOGGING_ERROR:
                    if (this.state.error !== null)
                        dom.textContent = this.translate(
                            'login-error-field',
                            { 'field': this.state.error })
                    else
                        dom.textContent = this.translate('login-error')
                    break
                case this.state.STATE_READING_CARD:
                    dom.textContent = this.translate('reading-card-message')
                    break
                case this.state.STATE_LOGGING_IN:
                    dom.textContent = this.translate('logging-in-message')
                    break
                case this.state.STATE_LOGGED_IN:
                    dom = createMenu()
                    break
                default:
                    break
            }
        }

        return dom
    },

    getStyles: function () {
        return [
            'font-awesome.css',
            this.file('css/menu.css')
        ]
    },

    getScripts: function () {
        return [
            this.file('js/logger.js'),
            this.file('js/state.js'),
            this.file('js/rfid-service-iface.js'),
            this.file('js/user-utils.js'),
            this.file('js/rfid-service.js'),
            this.file('js/mm-utils.js'),
            this.file('js/dom-utils.js')
        ]
    },

    getTranslations: function () {
        return {
            es: 'translations/es.json',
            en: 'translations/en.json'
        }
    },

    notificationReceived: function (notification, payload, sender) {
        if (notification === 'ALL_MODULES_STARTED')
            this.sendSocketNotification('READ_MODULES')
        else if (sender == null || sender == undefined)
            return
        else if (sender.name == 'phyxio-connect') {
            if (notification === 'GET_PHYXIO_USER') {
                _console.log('Sending user to module ' + sender.name);
                sender.notificationReceived(
                    notification, {
                        email: this.user.phyxioEmail,
                        token: this.user.phyxioToken
                    }, this)
            }
            else if (notification == 'PHYXIO_OPENED') {
                _console.log('Disabling loginservice...')
                this.state.phyxioOpened()
            }
            else if (notification == 'PHYXIO_CLOSED') {
                _console.log('Enabling loginservice...')
                this.state.phyxioClosed()
            }
        }
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification === 'SET_MODULES') {
            let filters = ['id!==' + this.id]
            for (let value of Array.from(payload)) {
                try {
                    let name = value.name
                    delete value

                    let mod = new AfterLoginModule(name, value)
                    this.modules.push(mod)

                    if ('id' in value)
                        filters.push('id!==' + value.id)
                    else
                        filters.push('name!==' + name)
                } catch (err) {
                    _console.error('Load module from config error: ' + err)
                }
            }

            for (let m of Object.values(this.modules)) {
                // Perform logout if pending login state on previous run
                if ('onStartUp' in m)
                    m.onStartUp()
            }

            for (let m of getModulesByFilter(filters))
                this.modules.push(new BeforeLoginModule(m.name, {
                    id: m.data.identifier.split('_')[1],
                    config: m.config
                }))

            this.modules.push({
                name: 'logout',
                symbol: 'sign-out-alt',
                onClick: this.onLogOut.bind(this),
                isEnabled: function () { return true }
            })

            this.rfidClient.init()
            setTimeout(this.updateDom.bind(this), 1000)
        }
    }
})