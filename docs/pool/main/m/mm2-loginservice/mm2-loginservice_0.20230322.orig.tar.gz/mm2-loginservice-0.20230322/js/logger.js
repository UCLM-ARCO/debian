class Logger {
    #service = undefined

    constructor(loginservice) {
        this.#service = loginservice
    }

    info(message) {
        console.info(message)
        if (this.#service.config.verbose >= 1)
            this.#service.sendSocketNotification(
                'NEW_SYSTEM_LOG', { info: 'loginservice: ' + message })
    }

    warn(message) {
        console.warn(message)
        if (this.#service.config.verbose >= 1)
            this.#service.sendSocketNotification(
                'NEW_SYSTEM_LOG', { warn: 'loginservice: ' + message })
    }

    error(message) {
        console.error(message)
        if (this.#service.config.verbose >= 1)
            this.#service.sendSocketNotification(
                'NEW_SYSTEM_LOG', { error: 'loginservice: ' + message })
    }

    log(message) {
        console.log(message)
        if (this.#service.config.verbose > 1)
            this.#service.sendSocketNotification(
                'NEW_SYSTEM_LOG', { log: 'loginservice: ' + message })
    }
}

var _console = undefined