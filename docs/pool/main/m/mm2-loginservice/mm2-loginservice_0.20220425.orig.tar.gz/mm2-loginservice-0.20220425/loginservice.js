const LoginState = {
    CONNECTION_ERROR: -1,
    LOGGED_OUT: 0,
    LOGIN_ERROR: 0.1,
    LOGGED_IN: 1,
    DISABLED: 2
}

Module.register('loginservice', {
    defaults: {
        fgColor: '#4287f5',
        bgColor: '#ffffff',
        onlyIcons: false,
        animateMenu: false,
        verbose: 1
    },

    onLogIn: function (user) {
        if (this.state === LoginState.DISABLED)
            return
        else if (this.state === LoginState.LOGGED_IN
            && user !== null) {
            this.user.contact = user.contact
            for (let m of Object.values(this.modules)) {
                if ('onCardRead' in m)
                    m.onCardRead()
            }
            return
        } else if (Math.floor(this.state) === LoginState.LOGGED_OUT
            && user === null) {
            this.state = LoginState.LOGIN_ERROR
            this.updateDom(1500)
            return
        } else if (Math.floor(this.state) !== LoginState.LOGGED_OUT)
            return

        this.state = LoginState.LOGGED_IN
        this.user = user

        for (let m of Object.values(this.modules)) {
            if ('onLogIn' in m)
                m.onLogIn()
        }

        this.updateDom(1500)
        _console.log('Logged as ' + this.user.id)
    },

    onLogOut: function () {
        if (this.state !== LoginState.LOGGED_IN)
            return

        if (this.logOutTimeout !== undefined) {
            clearTimeout(this.logOutTimeout)
            this.logOutTimeout = undefined
        }

        for (let m of Object.values(this.modules))
            if ('onLogOut' in m)
                m.onLogOut()

        this.state = LoginState.LOGGED_OUT
        this.user = null

        this.updateDom(1500)
    },

    onLogOutDelayed: function (timeout = 30 * 60 * 1000) {
        if (this.logOutTimeout !== undefined)
            clearTimeout(this.logOutTimeout)

        this.logOutTimeout = setTimeout(function () {
            this.logOutTimeout = undefined
            this.onLogOut()
        }.bind(this), timeout)
    },

    onRFIDConnect: function (connected) {
        if (this.state === LoginState.CONNECTION_ERROR && connected) {
            this.state = LoginState.LOGGED_OUT
            this.updateDom(1500)
        } else if (this.state >= LoginState.LOGGED_OUT && !connected) {
            if (this.state === LoginState.LOGGED_IN)
                this.onLogOut()
            this.state = LoginState.CONNECTION_ERROR
            this.updateDom(1500)
        }
    },

    start: function () {
        this.id = this.data.identifier.split('_')[1]
        this.state = LoginState.LOGGED_OUT
        this.modules = []
        this.user = null
        this.logOutTimeout = undefined

        if (this.data.position === undefined)
            this.data.position = 'bottom_right'

        let iceData = new Ice.InitializationData()
        iceData.properties = Ice.createProperties()
        iceData.properties.setProperty('Ice.ACM.Client.Heartbeat', '3')
        let iceComm = Ice.initialize(iceData)

        this.rfidClient = new RFIDClient(
            iceComm, this.onRFIDConnect.bind(this),
            this.onLogIn.bind(this),
            this.onLogOutDelayed.bind(this),
            location.protocol === 'https:')

        // Autologing for testing
        // this.rfidClient = {
        //     connected: true,
        //     onConnectCallback: this.onRFIDConnect,
        //     init: function () {
        //         this.onConnectCallback(true)
        //     }
        // }

        _console = new Logger(this)
    },

    getDom: function () {
        let dom = document.createElement('span')

        if (this.modules.length == 0)
            dom.textContent = this.translate('loading-message')
        else {
            switch (this.state) {
                case LoginState.CONNECTION_ERROR:
                    dom.textContent = this.translate('connection-error-message')
                    break
                case LoginState.LOGGED_OUT:
                    dom.textContent = this.translate('login-message')
                    break
                case LoginState.LOGIN_ERROR:
                    dom.textContent = this.translate('login-error-message')
                    break
                case LoginState.LOGGED_IN:
                    dom = createMenu()
                    break
                default:
                    break
            }
        }

        return dom
    },

    getStyles: function () {
        return [
            'font-awesome.css',
            this.file('css/menu.css')
        ]
    },

    getScripts: function () {
        return [
            this.file('js/logger.js'),
            this.file('js/Ice-3.7.min.js'),
            this.file('js/rfid-service-iface.js'),
            this.file('js/user-utils.js'),
            this.file('js/rfid-service.js'),
            this.file('js/mm-utils.js'),
            this.file('js/dom-utils.js')
        ]
    },

    getTranslations: function () {
        return {
            es: 'translations/es.json',
            en: 'translations/en.json'
        }
    },

    notificationReceived: function (notification, _payload) {
        if (notification === 'ALL_MODULES_STARTED')
            this.sendSocketNotification('READ_MODULES')
        else if (notification == 'PHYXIO_OPENED')
        {
            _console.log('Disabling loginservice...')
            this.prevState = this.state
            this.state = LoginState.DISABLED
        }
        else if (notification == 'PHYXIO_CLOSED')
        {
            _console.log('Enabling loginservice...')
            this.state = this.prevState
            delete this.prevState
        }
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification === 'SET_MODULES') {
            let filters = ['id!==' + this.id]
            for (let value of Array.from(payload)) {
                try {
                    let name = value.name
                    delete value

                    let mod = new AfterLoginModule(name, value)
                    this.modules.push(mod)
                    mod.onStartUp()

                    if ('id' in value)
                        filters.push('id!==' + value.id)
                    else
                        filters.push('name!==' + name)
                } catch (err) {
                    _console.error('Load module from config error: ' + err)
                }
            }

            for (let m of getModulesByFilter(filters))
                this.modules.push(new BeforeLoginModule(m.name, {
                    id: m.data.identifier.split('_')[1],
                    config: m.config
                }))

            this.modules.push({
                name: 'logout',
                symbol: 'sign-out-alt',
                onClick: this.onLogOut.bind(this)
            })

            this.rfidClient.init()
            // Autologing for testing
            // this.onLogIn(new User(
            //     'anonymous', '+34666666666',
            //     'anonymous2',
            //     'webcal://localhost:8080/modules/loginservice/sample.ics'))

            setTimeout(this.updateDom.bind(this), 1000)
        }
    }
})