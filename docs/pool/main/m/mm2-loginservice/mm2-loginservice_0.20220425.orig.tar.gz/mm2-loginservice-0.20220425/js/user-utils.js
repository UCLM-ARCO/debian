/**
 * User which can be logged in the smart mirror.
 * @param {String} id User id (userId)
 * @param {String} phone User phone number (phoneNumber)
 * @param {String} contact User emergency contact (emergencyContact)
 * @param {String} calendar User Google Calendar URL (?)
 */
const User = function (id, phone, contact, calendar) {
    this.id = id
    this.phone = phone
    this.contact = contact
    this.calendar = calendar
}

/**
 * Replace, if any found, User properties between brakets with its respective value.
 * @param {User} user User whose properties will be used.
 * @param {Any} value If it is a String, it will search and replace User properties. 
 *                    If its an Object/Array, all its values will be looked up.  
 * @returns {Any} Same input value but with strings replaced.
 */
const replaceWithUserProperties = function (user, value) {
    let retval = value
    if (typeof value === 'string') {
        retval = value.slice()
        for (let [k, v] of Object.entries(user)) {
            let regex = new RegExp('{' + k + '}', 'g')
            if (retval.search(regex) != -1) {
                if (v == undefined)
                    throw `Cannot set property "${k}" because it is undefined.`
                retval = retval.replace(regex, v)
            }
        }
    } else if (Array.isArray(value)) {
        let newValue = []
        for (let item of value)
            newValue.push(replaceWithUserProperties(user, item))
        retval = Array.from(newValue)
    } else if (typeof value === 'object') {
        retval = {}
        for (let [k, v] of Object.entries(value))
            retval[k] = replaceWithUserProperties(user, v)
    }
    return retval
}