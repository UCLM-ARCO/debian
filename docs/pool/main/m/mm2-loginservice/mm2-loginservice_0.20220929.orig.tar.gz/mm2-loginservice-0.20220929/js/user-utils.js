class User {
    /**
     * User which can be logged in the smart mirror.
     * @param {String} id User id (userId)
     * @param {String} phone User phone number (phoneNumber)
     * @param {String} contact User emergency contact (emergencyContact)
     * @param {String} calendar User Google Calendar URL (calendarId)
     * @param {String} phyxioEmail Phyxio login email (email)
     * @param {String} phyxioToken Phyxio login token (token)
     */
    constructor(id, phone, contact, calendar, phyxioEmail, phyxioToken) {
        this.id = id
        this.phone = phone
        this.contact = contact
        this.calendar = calendar
        this.phyxioEmail = phyxioEmail
        this.phyxioToken = phyxioToken
    }

    static properties() {
        return ['id', 'phone', 'contact', 'calendar',
            'phyxioEmail', 'phyxioToken']
    }
}

/**
 * Replace, if any found, User properties between brakets with its respective value.
 * @param {User} user User whose properties will be used.
 * @param {Any} value If it is a String, it will search and replace User properties. 
 *                    If its an Object/Array, all its values will be looked up.  
 * @param {Boolean} failSilently If true, set undefined properties as-is. 
 *                               If false, throw exception. 
 * @returns {Any} Same input value but with strings replaced.
 */
const replaceWithUserProperties = function (user, value, failSilently = true) {
    let retval = value
    if (typeof value === 'string') {
        retval = value.slice()
        for (let [k, v] of Object.entries(user)) {
            let regex = new RegExp('{' + k + '}', 'g')
            if (retval.search(regex) != -1) {
                if (v == undefined && !failSilently)
                    throw `Cannot set property "${k}" because it is undefined.`
                retval = retval.replace(regex, v)
            }
        }
    } else if (Array.isArray(value)) {
        let newValue = []
        for (let item of value)
            newValue.push(replaceWithUserProperties(user, item, failSilently))
        retval = Array.from(newValue)
    } else if (typeof value === 'object') {
        retval = {}
        for (let [k, v] of Object.entries(value))
            retval[k] = replaceWithUserProperties(user, v, failSilently)
    }
    return retval
}

const searchUserProperties = function (value, properties = []) {
    if (typeof value === 'string') {
        for (let k of User.properties()) {
            if (properties.includes(k))
                continue
            if (value.search(new RegExp('{' + k + '}', 'g')) != -1)
                properties.push(k)
        }
    } else if (Array.isArray(value)) {
        for (let item of value)
            searchUserProperties(item, properties)
    } else if (typeof value === 'object') {
        for (let v of Object.values(value))
            searchUserProperties(v, properties)
    }
    return properties
}