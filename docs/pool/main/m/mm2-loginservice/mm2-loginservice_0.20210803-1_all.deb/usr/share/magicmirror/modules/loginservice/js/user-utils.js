/**
 * User which can be logged in the smart mirror.
 * @param {String} id User id (userId)
 * @param {String} phone User phone number (phoneNumber)
 * @param {String} contact User emergency contact (emergencyContact)
 * @param {String} calendar User Google Calendar URL (?)
 */
const User = function (id, phone, contact, calendar) {
    this.id = id
    this.phone = phone
    this.contact = contact
    this.calendar = calendar
}

/**
 * Replace, if any found, User properties between brakets with its respective value.
 * @param {User} user User whose properties will be used.
 * @param {Any} value If it is a String, it will search and replace User properties. 
 *                    If its an Object/Array, all its values will be looked up.  
 * @returns {Any} Same input value but with strings replaced.
 */
const replaceWithUserProperties = function (user, value) {
    if (typeof value === 'string') {
        for (let [k, v] of Object.entries(user))
            value = value.replace(new RegExp('{' + k + '}', 'g'), v)
    } else if (typeof value === 'object') {
        for (let [k, v] of Object.entries(value))
            value[k] = replaceWithUserProperties(user, v)
    } else if (Array.isArray(value)) {
        let newValue = []
        for (let item of value)
            newValue.push(replaceWithUserProperties(user, item))
        value = Array.from(newValue)
    }
    return value
}