class Logger {
    #service = undefined

    constructor(loginservice) {
        this.#service = loginservice
    }

    info(message) {
        console.info(message)
        this.#service.sendSocketNotification('NEW_SYSTEM_LOG', { info: 'loginservice: ' + message })
    }

    error(message) {
        console.error(message)
        this.#service.sendSocketNotification('NEW_SYSTEM_LOG', { error: 'loginservice: ' + message })
    }

    log(message) {
        console.log(message)
    }
}

var _console = undefined