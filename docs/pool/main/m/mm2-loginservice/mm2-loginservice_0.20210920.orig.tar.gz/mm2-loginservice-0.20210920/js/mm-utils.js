/**
 * Search through all Magic Mirror modules filtering by provided filters. 
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {Array<String>} filters Comparison expressions to filter by. Default is an empty array (no filter).
 * @returns {Array<object>} Found modules. 
 */
const getModulesByFilter = function (filters = []) {
    var retval = Array.from(MM.getModules())

    for (let index = 0; index < filters.length; index++) {
        const filter = filters[index]

        let filterMatch = filter.match(/([a-z]+)(\={2,3}|\!\={1,2}|\<\=?|\>\=?)(.+)/i)

        if (filterMatch === null) {
            _console.error('Invalid filter "' + filter + '"')
            continue
        } else if (filterMatch[1] !== 'id' && filterMatch[1] !== 'name') {
            _console.error('Unknown property compared in filter "' + filter + '"')
            continue
        } else if (filterMatch[1] === 'name'
            && filterMatch[2].match(/\<\=?|\>\=?/) !== null) {
            _console.error('Invalid string comparison operator in filter "' + filter + '"')
            continue
        }

        var filterProperty = filterMatch[1].toLowerCase()
        var filterOperator = filterMatch[2]
        var filterValue = filterProperty === 'name' ? filterMatch[3] : parseInt(filterMatch[3])

        var newRetval = []
        for (let m of retval) {
            let mId = parseInt(m.data.identifier.split('_')[1])
            let mName = m.name

            if (/\<\=?/.test(filterOperator) && filterProperty === 'id') {
                if ((filterOperator.endsWith('=') && mId <= filterValue)
                    || mId < filterValue)
                    newRetval.push(m)
            } else if (/\>\=?/.test(filterOperator) && filterProperty === 'id') {
                if ((filterOperator.endsWith('=') && mId >= filterValue)
                    || mId > filterValue)
                    newRetval.push(m)
            } else if (filterOperator.startsWith('!')) {
                if ((filterProperty === 'id' && mId != filterValue)
                    || (filterProperty === 'name' && mName != filterValue))
                    newRetval.push(m)
            } else if ((filterProperty === 'id' && mId == filterValue)
                || (filterProperty === 'name' && mName == filterValue)) {
                newRetval.push(m)
            }
        }
        retval = Array.from(newRetval)
    }

    return retval
}

/**
 * Show or hide a module whether it is hidden or shown, respectively.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {String} name Name of module.
 * @param {String} id (optional) Magic Mirror id for module. Default is undefined.
 * @param {Number} speed (optional) Animation speed in milliseconds. Default is 1500.
 * @return {Boolean} True if module was shown
 */
const toggleVisibilityOfModule = function (name, id = undefined, speed = 1500) {
    var retval = true
    MM.getModules().withClass(name).enumerate(m => {
        if (id === undefined || m.data.identifier.split('_')[1] == id) {
            _console.log('Executing "toggleVisibility" for module ' + name)
            if (m.hidden)
                m.show(speed)
            else {
                m.hide(speed)
                retval = false
            }
        }
    })
    return retval
}

/**
 * Show a module.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {String} name Name of module.
 * @param {String} id (optional) Magic Mirror id for module. Default is undefined.
 * @param {Number} speed (optional) Animation speed in milliseconds. Default is 1500.
 * @return {Boolean} True if module was shown
 */
const showModule = function (name, id = undefined, speed = 1500) {
    var retval = true
    MM.getModules().withClass(name).enumerate(m => {
        if (id === undefined || m.data.identifier.split('_')[1] == id) {
            if (m.hidden) {
                _console.log('Executing "show" for module ' + name)
                m.show(speed)
            } else
                retval = false
        }
    })
    return retval
}

/**
 * Hide a module.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {String} name Name of module.
 * @param {String} id (optional) Magic Mirror id for module. Default is undefined.
 * @param {Number} speed (optional) Animation speed in milliseconds. Default is 1500.
 * @return {Boolean} True if module was hidden
 */
const hideModule = function (name, id = undefined, speed = 1500) {
    var retval = true
    MM.getModules().withClass(name).enumerate(m => {
        if (id === undefined || m.data.identifier.split('_')[1] == id) {
            if (!m.hidden) {
                _console.log('Executing "hide" for module ' + name)
                m.hide(speed)
            } else
                retval = false
        }
    })
    return retval
}

/**
 * Change configuration parameters of module.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * Require user-utils script.
 * 
 * @param {object} options Map of module configuration parameters to change.
 * @param {String} name Name of module. 
 * @param {String} id (optional) Magic Mirror id for module. Default is undefined.
 */
const configureModule = function (options, name, id = undefined) {
    let self = MM.getModules().withClass('loginservice')[0]
    options = replaceWithUserProperties(self.user, options)

    MM.getModules().withClass(name).enumerate(m => {
        if (id === undefined || m.data.identifier.split('_')[1] == id) {
            _console.log('Executing "configure" for module ' + name)
            for (let [k, v] of Object.entries(options))
                m.config[k] = v
            m.start()
        }
    })
}

/**
 * Send a Magic Mirror notification to a certain module.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * Require user-utils script.
 * 
 * @param {String} moduleName Name of module. 
 * @param {String} notificationName Name of notification to send.
 * @param {String} moduleId (optional) Magic Mirror id for module. Default is undefined.
 * @param {Array} notificationArgs Array of arguments to send as a payload. If any string contains a user property name between brakets it will be replaced with its real value.
 */
const notifyModule = function (moduleName, notificationName, moduleId = undefined, notificationArgs = []) {
    let self = MM.getModules().withClass('loginservice')[0]

    MM.getModules().withClass(moduleName).enumerate(m => {
        if (moduleId === undefined || m.data.identifier.split('_')[1] == moduleId) {
            _console.log('Executing "notify" for module ' + moduleName
                + ' with notification ' + notificationName)
            m.__proto__.notificationReceived(
                notificationName,
                replaceWithUserProperties(self.user, notificationArgs),
                self
            )
        }
    })
}

class ModuleWrapper {
    constructor(name, kwargs = {}) {
        let filters = ['name==' + name]
        if (kwargs.id !== undefined)
            filters.push('id==' + kwargs.id)

        let moduleSearch = getModulesByFilter(filters)
        if (moduleSearch.length === 0)
            throw 'MM Module "' + name + '" not found'

        this.name = name
        this.id = kwargs.id
        this.defaultConfig = kwargs.config === undefined ?
            Object.assign({}, moduleSearch[0].config)
            : Object.assign({}, kwargs.config)

        for (let event of this.events) {
            let callback = kwargs[event]
            let defaultCallback = callback === undefined || callback.executeDefault !== false ?
                this['default'
                    + event.charAt(0).toUpperCase()
                    + event.slice(1)].bind(this)
                : undefined

            if (callback !== undefined && typeof callback !== 'function') {
                if (Array.isArray(callback)) {
                    for (let obj of callback)
                        if (obj.executeDefault === false)
                            defaultCallback = undefined
                    callback = this.#callbackFromArray(callback)
                } else
                    callback = this.#callbackFromObject(callback)
            }

            this[event] = function (...callbacks) {
                for (let cb of callbacks) {
                    if (cb !== undefined)
                        cb()
                }
            }.bind(this, defaultCallback, callback)
        }
    }

    get events() {
        return ['onLogIn', 'onLogOut', 'onCardRead']
    }

    get callbackTypes() {
        return ['show', 'hide', 'configuration', 'notification', 'reset']
    }

    #callbackFromObject(obj) {
        if (typeof obj !== 'object') {
            _console.error('Callback for ' + this.name + ' is not an object')
            _console.error(obj)
            return undefined
        } else if (obj.type === undefined) {
            _console.error('Callback for ' + this.name + ' lacks "type" property')
            _console.error(obj)
            return undefined
        } else if (obj.type === 'notification') {
            if (obj.name === undefined) {
                _console.error('Notification callback for ' + this.name + ' lacks "name" property')
                _console.error(obj)
                return undefined
            } else if (obj.args !== undefined && !Array.isArray(obj.args)) {
                _console.error('Notification callback for ' + this.name + ' "args" must be an array')
                _console.error(obj)
                return undefined
            }
            return notifyModule.bind(this, this.name, obj.name, this.id, obj.args)
        } else if (obj.type === 'configuration') {
            if (obj.config === undefined || typeof obj.config !== 'object') {
                _console.error('Configuration callback for ' + this.name + ' lacks "config" property or it is not an object')
                _console.error(obj)
                return undefined
            }
            return configureModule.bind(this, obj.config, this.name, this.id)
        } else if (obj.type === 'reset') {
            return configureModule.bind(this, this.defaultConfig, this.name, this.id)
        } else if (obj.type === 'show') {
            return showModule.bind(this, this.name, this.id)
        } else if (obj.type === 'hide') {
            return hideModule.bind(this, this.name, this.id)
        } else {
            _console.error('Callback type for ' + this.name + ' must be one of ' + this.callbackTypes)
            _console.error(obj)
            return undefined
        }
    }

    #callbackFromArray(arr) {
        let callbacks = []
        for (let obj of arr)
            callbacks.push(this.#callbackFromObject(obj))

        return function (callbacks) {
            for (let cb of callbacks) {
                if (cb !== undefined)
                    cb()
            }
        }.bind(this, callbacks)
    }

    defaultOnLogIn() { }
    defaultOnLogOut() { }
    defaultOnCardRead() { }
}

class BeforeLoginModule extends ModuleWrapper {
    defaultOnLogIn() {
        return hideModule(this.name, this.id)
    }

    defaultOnLogOut() {
        return showModule(this.name, this.id)
    }
}

class AfterLoginModule extends ModuleWrapper {
    constructor(name, kwargs = {}) {
        super(name, kwargs)

        this.symbol = kwargs.symbol
    }

    get events() {
        return super.events.concat('onClick')
    }

    defaultOnClick() {
        return toggleVisibilityOfModule(this.name, this.id)
    }

    defaultOnLogOut() {
        return hideModule(this.name, this.id)
    }
}