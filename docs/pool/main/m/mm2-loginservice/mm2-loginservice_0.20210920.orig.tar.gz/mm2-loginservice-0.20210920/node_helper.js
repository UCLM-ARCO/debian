var NodeHelper = require('node_helper')
const fs = require('fs')

module.exports = NodeHelper.create({
    socketNotificationReceived: function (notification, payload) {
        if (notification === 'READ_MODULES')
            this.sendSocketNotification('SET_MODULES', JSON.parse(
                fs.readFileSync('/usr/share/magicmirror/modules/loginservice/config/modules.json')
            ))
        else if (notification === 'NEW_SYSTEM_LOG') {
            if ('error' in payload)
                console.error(payload.error)
            else if ('info' in payload)
                console.info(payload.info)
            else if ('log' in payload)
                console.log(payload.log)
        }
    }
})