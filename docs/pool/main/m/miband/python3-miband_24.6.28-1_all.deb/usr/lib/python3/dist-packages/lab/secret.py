from miband import MiBandDevice  # nopep8

MAC = "F8:67:A0:87:B7:17"
TOKEN = "3e179521d91fa5a59cbb887794bc43c3"
TOKEN = bytes.fromhex(TOKEN)
DEVICE = MiBandDevice("dev", MAC, TOKEN, adapter="hci1")
