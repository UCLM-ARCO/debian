
from numpy import int32

#
# DISCLAIMER: This is a blind port of GadgetBridge's ECDH-B163 to Python
#

int32vec = list[int32]

CURVE_DEGREE = 163
ECC_PRV_KEY_SIZE = 24
ECC_PUB_KEY_SIZE = 2 * ECC_PRV_KEY_SIZE

# margin for overhead needed in intermediate calculations
BITVEC_MARGIN = 3
BITVEC_NBITS = CURVE_DEGREE + BITVEC_MARGIN
BITVEC_NWORDS = (BITVEC_NBITS + 31) // 32
BITVEC_NBYTES = 4 * BITVEC_NWORDS

# *****************************************************************************

# Here the curve parameters are defined.

# NIST B-163
polynomial = [0x000000c9, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000008]
coeff_b    = [0x4a3205fd, 0x512f7874, 0x1481eb10, 0xb8c953ca, 0x0a601907, 0x00000002]
base_x     = [0xe8343e36, 0xd4994637, 0xa0991168, 0x86a2d57e, 0xf0eba162, 0x00000003]
base_y     = [0x797324f1, 0xb11c5c0c, 0xa2cdd545, 0x71a0094f, 0xd51fbc6c, 0x00000000]
base_order = [0xa4234c33, 0x77e70c12, 0x000292fe, 0x00000000, 0x00000000, 0x00000004]

# *****************************************************************************

# some basic bit-manipulation routines that act on bit-vectors follow
def bitvec_get_bit(x: int32vec, idx: int32) -> int32:
    return ((x[idx // 32] & 0xffffffff) >> (idx & 31)) & 1


def bitvec_clr_bit(x: int32vec, idx: int32) -> None:
    x[idx // 32] &= ~(1 << (idx & 31))


def bitvec_copy(x: int32vec, y: int32vec) -> None:
    for i in range(BITVEC_NWORDS):
        x[i] = y[i]


def bitvec_swap(x: int32vec, y: int32vec) -> None:
    tmp = [int32() for _ in range(BITVEC_NWORDS)]
    bitvec_copy(tmp, x)
    bitvec_copy(x, y)
    bitvec_copy(y, tmp)


# fast version of equality test
def bitvec_equal(x: int32vec, y: int32vec) -> bool:
    for i in range(BITVEC_NWORDS):
        if x[i] != y[i]:
            return False
    return True


def bitvec_set_zero(x: int32vec) -> None:
    for i in range(BITVEC_NWORDS):
        x[i] = int32(0)


# fast implementation
def bitvec_is_zero(x: int32vec) -> bool:
    for i in range(BITVEC_NWORDS):
        if x[i] != 0:
            return False
    return True


# return the number of the highest one-bit + 1
def bitvec_degree(x: int32vec) -> int32:
    # for n in x:
        # assert n.bit_length() <= 32, "Invalid int32, size is greater than 32 bits"

    i = BITVEC_NWORDS * 32

    # start at the back of the vector (MSB)
    y = BITVEC_NWORDS - 1

    # skip empty / zero words
    while i > 0 and x[y] == 0:
        i -= 32
        y -= 1

    # run through rest if count is not multiple of bitsize of DTYPE
    if i != 0:
        u32mask = 1 << 31
        while (x[y] & u32mask) == 0:
            u32mask = (u32mask & 0xffffffff) >> 1
            i -= 1
    return i


# left-shift by 'count' digits
def bitvec_lshift(x: int32vec, y: int32vec, nbits: int32) -> None:
    nwords = nbits // 32

    # shift whole words first if nwords > 0
    i, j = 0, 0
    for i in range(nwords):
        # zero-initialize from least-significant word until offset reached
        x[i] = int32(0)

    # copy to x output
    while i < BITVEC_NWORDS:
        x[i] = y[j]
        i += 1
        j += 1

    # shift the rest if count was not multiple of bitsize of DTYPE
    nbits &= 31
    if nbits != 0:
        # left shift rest
        for i in range(BITVEC_NWORDS - 1, 0, -1):
            x[i] = int32((x[i]) << nbits) | ((x[i - 1] & 0xffffffff) >> (32 - nbits))
        x[0] = int32((x[0]) << nbits)


# *****************************************************************************
#
# Code that does arithmetic on bit-vectors in the Galois Field
# GF(2^CURVE_DEGREE).
#
# *****************************************************************************

def gf2field_set_one(x: int32vec) -> None:
    # set first word to one
    x[0] = int32(1)
    # .. and the rest to zero ;
    for i in range(1, BITVEC_NWORDS):
        x[i] = int32(0)


# fastest check if x == 1
def gf2field_is_one(x: int32vec) -> bool:
    # check if first word == 1
    if x[0] != 1:
        return False

    #  ...and if rest of words == 0
    for i in range(1, BITVEC_NWORDS):
        if x[i] != 0:
            return False
    return True


#  galois field(2^m) addition is modulo 2, so XOR is used instead - 'z := a + b'
def gf2field_add(z: int32vec, x: int32vec, y: int32vec) -> None:
    for i in range(BITVEC_NWORDS):
        z[i] = x[i] ^ y[i]


# increment element
def gf2field_inc(x: int32vec) -> None:
    x[0] ^= int32(1)


# field multiplication 'z := (x * y)'
def gf2field_mul(z: int32vec, x: int32vec, y: int32vec) -> None:
    tmp = [int32() for _ in range(BITVEC_NWORDS)]
    assert z != y

    bitvec_copy(tmp, x)

    # LSB set? Then start with x
    if (bitvec_get_bit(y, 0) != 0):
        bitvec_copy(z, x)
    # .. or else start with zero
    else:
        bitvec_set_zero(z)

    # then add 2^i * x for the rest
    for i in range(1, CURVE_DEGREE):
        # lshift 1 - doubling the value of tmp
        bitvec_lshift(tmp, tmp, 1)

        # modulo reduction polynomial if degree(tmp) > CURVE_DEGREE
        if bitvec_get_bit(tmp, CURVE_DEGREE) != 0:
            gf2field_add(tmp, tmp, polynomial)

        # add 2^i * tmp if this factor in y is non-zero
        if bitvec_get_bit(y, i) != 0:
            gf2field_add(z, z, tmp)


# field inversion 'z := 1/x'
def gf2field_inv(z: int32vec, x: int32vec) -> None:
    u = [int32() for _ in range(BITVEC_NWORDS)]
    v = [int32() for _ in range(BITVEC_NWORDS)]
    g = [int32() for _ in range(BITVEC_NWORDS)]
    h = [int32() for _ in range(BITVEC_NWORDS)]

    bitvec_copy(u, x)
    bitvec_copy(v, polynomial)
    bitvec_set_zero(g)
    gf2field_set_one(z)

    i = 0
    while not gf2field_is_one(u):
        i = bitvec_degree(u) - bitvec_degree(v)

        if i < 0:
            bitvec_swap(u, v)
            bitvec_swap(g, z)
            i = -i

        bitvec_lshift(h, v, i)
        gf2field_add(u, u, h)
        bitvec_lshift(h, g, i)
        gf2field_add(z, z, h)


# *****************************************************************************
#
# The following code takes care of Galois-Field arithmetic.
# Elliptic curve points are represented by pairs (x,y) of bitvec_t.
# It is assumed that curve coefficient 'a' is {0,1}
# This is the case for all NIST binary curves.
# Coefficient 'b' is given in 'coeff_b'.
# '(base_x, base_y)' is a point that generates a large prime order group.
#
# *****************************************************************************

def gf2point_copy(x1: int32vec, y1: int32vec, x2: int32vec, y2: int32vec) -> None:
    bitvec_copy(x1, x2)
    bitvec_copy(y1, y2)


def gf2point_set_zero(x: int32vec, y: int32vec) -> None:
    bitvec_set_zero(x)
    bitvec_set_zero(y)


def gf2point_is_zero(x: int32vec, y: int32vec) -> bool:
    return bitvec_is_zero(x) and bitvec_is_zero(y)


# double the point (x,y)
def gf2point_double(x: int32vec, y: int32vec) -> None:
    # if P = O (zero or infinity): 2 * P = P
    if bitvec_is_zero(x):
        bitvec_set_zero(y)
    else:
        l = [int32() for _ in range(BITVEC_NWORDS)]
        gf2field_inv(l, x)
        gf2field_mul(l, l, y)
        gf2field_add(l, l, x)
        gf2field_mul(y, x, x)
        gf2field_mul(x, l, l)
        gf2field_inc(l)
        gf2field_add(x, x, l)
        gf2field_mul(l, l, x)
        gf2field_add(y, y, l)


# add two points together (x1, y1) := (x1, y1) + (x2, y2)
def gf2point_add(x1: int32vec, y1: int32vec, x2: int32vec, y2: int32vec) -> None:
    if not gf2point_is_zero(x2, y2):
        if gf2point_is_zero(x1, y1):
            gf2point_copy(x1, y1, x2, y2)
        else:
            if bitvec_equal(x1, x2):
                if bitvec_equal(y1, y2):
                    gf2point_double(x1, y1)
                else:
                    gf2point_set_zero(x1, y1)

            else:
                # arithmetic with temporary variables
                a = [int32() for _ in range(BITVEC_NWORDS)]
                b = [int32() for _ in range(BITVEC_NWORDS)]
                c = [int32() for _ in range(BITVEC_NWORDS)]
                d = [int32() for _ in range(BITVEC_NWORDS)]

                gf2field_add(a, y1, y2)
                gf2field_add(b, x1, x2)
                gf2field_inv(c, b)
                gf2field_mul(c, c, a)
                gf2field_mul(d, c, c)
                gf2field_add(d, d, c)
                gf2field_add(d, d, b)
                gf2field_inc(d)
                gf2field_add(x1, x1, d)
                gf2field_mul(a, x1, c)
                gf2field_add(a, a, d)
                gf2field_add(y1, y1, a)
                bitvec_copy(x1, d)


# point multiplication via double-and-add algorithm
def gf2point_mul(x: int32vec, y: int32vec, exp: int32vec) -> None:
    tmpx = [int32() for _ in range(BITVEC_NWORDS)]
    tmpy = [int32() for _ in range(BITVEC_NWORDS)]

    nbits = bitvec_degree(exp)
    gf2point_set_zero(tmpx, tmpy)

    for i in range(nbits - 1, -1, -1):
        gf2point_double(tmpx, tmpy)

        if bitvec_get_bit(exp, i) != 0:
            gf2point_add(tmpx, tmpy, x, y)

    gf2point_copy(x, y, tmpx, tmpy)


# check if y^2 + x*y = x^3 + a*x^2 + coeff_b holds
def gf2point_on_curve(x: int32vec, y: int32vec) -> bool:
    a = [int32() for _ in range(BITVEC_NWORDS)]
    b = [int32() for _ in range(BITVEC_NWORDS)]

    if gf2point_is_zero(x, y):
        return False

    gf2field_mul(a, x, x)
    gf2field_mul(b, a, x)
    gf2field_add(a, a, b)
    gf2field_add(a, a, coeff_b)
    gf2field_mul(b, y, y)
    gf2field_add(a, a, b)
    gf2field_mul(b, x, y)

    return bitvec_equal(a, b)


def bytes_to_int(bytes_: bytes, offset: int32) -> int32vec:
    value = [int32() for _ in range(BITVEC_NWORDS)]

    byteptr = offset
    for i in range(BITVEC_NWORDS):
        value[i] = int32(
            (bytes_[byteptr] & 0xff) |
            (bytes_[byteptr+1] & 0xff) << 8 |
            (bytes_[byteptr+2] & 0xff) << 16 |
            (bytes_[byteptr+3] & 0xff) << 24
        )
        byteptr += 4
    return value


def ints_to_bytes(bytes: int32vec, ints: int32vec, offset: int32) -> None:
    byteptr = offset
    for i in range(BITVEC_NWORDS):
        bytes[byteptr] = (ints[i] & 0x000000ff)
        bytes[byteptr+1] = (ints[i] & 0x0000ff00) >> 8
        bytes[byteptr+2] = (ints[i] & 0x00ff0000) >> 16
        bytes[byteptr+3] = (ints[i] & 0xff000000) >> 24
        byteptr += 4


def ecdh_shared_secret(private_key: bytes, others_pub: bytes) -> bytes:
    private_key_int32 = bytes_to_int(private_key, 0)

    # copy other side's public key to output
    output = [int32(c) for c in others_pub]

    # clear bits > CURVE_DEGREE in highest word to satisfy constraint 1 <= exp < n.
    nbits = bitvec_degree(base_order)
    for i in range(nbits - 1, BITVEC_NWORDS * 32, 1):
        bitvec_clr_bit(private_key_int32, i)

    # multiply other side's public key with own private key
    output_int32_1 = bytes_to_int(output, 0)
    output_int32_2 = bytes_to_int(output, BITVEC_NBYTES)

    gf2point_mul(output_int32_1, output_int32_2, private_key_int32)

    ints_to_bytes(output, output_int32_1, 0)
    ints_to_bytes(output, output_int32_2, BITVEC_NBYTES)

    return bytes(output)
