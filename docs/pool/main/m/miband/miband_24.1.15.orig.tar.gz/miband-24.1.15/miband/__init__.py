
import queue
import struct
import time
import zlib
from datetime import datetime, timedelta, timezone
from functools import partial, lru_cache
from struct import pack, unpack
from munch import Munch
from cryptography.hazmat.primitives.asymmetric import ec
from gattlib import DiscoveryService, GATTRequester, CharacteristicNotFound
from gattlib.utils import options, WeakCallback

from .ecdh import ecdh_shared_secret
from .utils import (
    IntervalTimer, log, msg_dump, aes_decrypt_data, aes_encrypt_data, get_crc32,
    png_to_tga, RunOnExit
)


def parse_date(d):
    year    = struct.unpack('h', bytes(d[0:2]))[0]
    month   = struct.unpack('b', bytes(d[2:3]))[0]
    day     = struct.unpack('b', bytes(d[3:4]))[0]
    hours   = struct.unpack('b', bytes(d[4:5]))[0]
    minutes = struct.unpack('b', bytes(d[5:6]))[0]
    seconds = struct.unpack('b', bytes(d[6:7]))[0]

    # d[7]: day of week
    # d[8]: 1/256 fractions of a second

    tz = None
    if len(d) >= 11:
        utc_offset = struct.unpack('h', bytes(d[9:11]))[0]
        tz = timezone(timedelta(seconds=utc_offset))

    return datetime(year, month, day, hours, minutes, seconds, tzinfo=tz)


class BatteryInfo:
    """Holds the battery information for the Mi Band."""

    def __init__(self, data):
        self.level = struct.unpack('b', data[1:2])[0] \
            if len(data) >= 2 else None

        self.status = 'normal'
        if struct.unpack('b', data[2:3])[0] != 0:
            self.status = "charging"

        self.last_off = parse_date(data[3:10])
        self.last_charge = parse_date(data[11:18])
        self.last_level = struct.unpack('b', data[19:20])[0] \
            if len(data) >= 20 else None

    def to_dict(self):
        return self.__dict__

    def __repr__(self):
        return (
            f"<Battery information: \n"
            f" - level: {self.level} %, \n"
            f" - status: {self.status}, \n"
            f" - last off: {self.last_off}, \n"
            f" - last charge: {self.last_charge}, \n"
            f" - last level: {self.last_level}>"
        )


class StepInfo:
    def __init__(self, data):
        """Holds the step information for the Mi Band."""

        self.steps = struct.unpack('<i', data[0:4])[0]
        self.meters = struct.unpack('<i', data[4:8])[0]
        self.calories = struct.unpack('<i', data[8:])[0]

    def to_dict(self):
        return self.__dict__

    def __repr__(self):
        return (
            f"<Step information: \n"
            f" - count: {self.steps} steps, \n"
            f" - distance: {self.meters} m, \n"
            f" - calories: {self.calories} Kcal>"
        )


class ActivityRecord:
    ACTIVITY_NAMES = {
        1:   "fast walking",
        64:  "outdoor running",
        112: "rest",
        115: "not worn",
        118: "charging",
        120: "sleep",
        121: "custom deep sleep",
        122: "custom rem sleep",
    }

    def __init__(self, info, data):
        self.category = data[0]
        self.intensity = data[1]
        self.steps = data[2]
        self.heart_rate = data[3]
        self.index = info.record_id
        self.timestamp = info.record_ts
        self.raw = data[:]

    def __repr__(self):
        cat_name = self.ACTIVITY_NAMES.get(self.category, self.category)
        return (
            f"<Activity, id: {self.index}, "
            f"cat: {cat_name}, "
            f"int: {self.intensity}, "
            f"steps: {self.steps}, "
            f"hr: {self.heart_rate}, "
            f"ts: {self.timestamp}>"
        )


class ResponseReceiver:
    F_FIRST_CHUNK = 0x01
    F_LAST_CHUNK  = 0x02
    F_NEEDS_ACK   = 0x04
    F_ENCRYPT     = 0x08

    def __init__(self, char):
        self._char = char
        self._handle_queues = {}
        self._partials = {}

        self._session_key = None

    def set_encryption_params(self, session_key):
        self._session_key = session_key

    def wait_response(self, handle, timeout=10):
        q = self._get_queue(handle)

        try:
            return q.get(timeout=timeout)
        except queue.Empty:
            msg = f"No response from handle {handle} after {timeout} seconds!"
            raise TimeoutError(msg) from None

    def feed(self, data):
        # response format:
        # * HEADER (first chunk: 11 bytes)
        #          (remain. chunks: 5 bytes)
        #   * 1 byte: 0x03, MAGIC?
        #   * 1 byte: flags, ORed:
        #          0x01 = first_chunk
        #          0x02 = last_chunk
        #          0x04 = needs_ack
        #          0x08 = encrypted
        #   * 1 byte: 0, for extended flags
        #   * 1 byte: write handle (identifies chunks of same message)
        #   * 1 byte: chunk sequence number
        #   * [4 bytes]: length of payload (only first chunk)
        #   * [2 bytes]: message type ("method id") (only first chunk)
        # * PAYLOAD

        msg_dump(f"<- RECV:", data)

        if len(data) < 5 or data[0] != 0x03:
            log.warning(" invalid response data (bad magic), ignored")
            return

        flags = data[1]
        handle = data[3]
        seq_number = data[4]

        is_encrypted = bool(flags & self.F_ENCRYPT)
        is_first_chunk = bool(flags & self.F_FIRST_CHUNK)
        is_last_chunk = bool(flags & self.F_LAST_CHUNK)
        needs_ack = bool(flags & self.F_NEEDS_ACK)

        if is_first_chunk:
            if len(data) < 11:
                log.warning(" invalid response data (too short message), ignored")
                return

            partial = Munch()
            partial.total_size = unpack("<I", data[5:9])[0]
            partial.method_id = unpack("<H", data[9:11])[0]
            partial.seq_number = seq_number
            partial.data = b""
            self._partials[handle] = partial
            payload = data[11:]

        else:
            partial = self._partials.get(handle)
            if not partial:
                log.warning(" invalid response data (invalid flags), ignored`")
                return

            if seq_number != (partial.seq_number + 1 & 0xff):
                log.warning(" invalid response data (unordered sequence), ignored")
                self._partials.pop(handle)
                return

            partial.seq_number = seq_number
            payload = data[5:]

        partial.data += payload

        if is_last_chunk:
            partial = self._partials.pop(handle)

            data = partial.data
            msg_dump(f" * RESPONSE, endp: {partial.method_id:02x}:", data)

            if is_encrypted:
                if self._session_key is None:
                    log.error("Received encrypted data, but session key is not defined!")
                    return

                sk = list(self._session_key)
                message_key = bytes(sk[i] ^ handle for i in range(16))
                data = aes_decrypt_data(data, message_key)
                if len(data) >= partial.total_size + 8:
                    data = data[:partial.total_size]
                else:
                    log.warning("Received less data than expected!")
                msg_dump(f" * DECRYPTED:", data)

            q = self._get_queue(partial.method_id)
            q.put(data)

        if needs_ack:
            self._send_ack(handle, seq_number)

    def _get_queue(self, handle):
        q = self._handle_queues.get(handle)
        if q is None:
            q = queue.Queue()
            self._handle_queues[handle] = q
        return q

    def _send_ack(self, handle, seq_number):
        data = bytes([0x04, 0x00, handle, 0x01, seq_number])
        self._char.WriteValue(data, options({"type": "command"}))


class InvocationSender:
    MSG_REQUEST   = 0x03

    F_FIRST_CHUNK = 0x01
    F_LAST_CHUNK  = 0x02
    F_NEEDS_ACK   = 0x04
    F_ENCRYPT     = 0x08

    def __init__(self, char):
        self._char = char
        self._mtu = self._char.MTU - 3
        self._msg_id = 1

        self._enc_sequence = None
        self._session_key = None

    def invoke(self, method_id, params, encrypt=False):
        if encrypt and self._session_key is None:
            raise RuntimeError("Can not encrypt invocation, session key not found!")

        chunks = self._pack_message(method_id, params, encrypt=encrypt)
        for chunk in chunks:
            msg_dump(f"-> INVOKE, endp: {method_id:02x}", chunk)
            self._char.WriteValue(chunk, options({"type": "command"}))

    def set_encryption_params(self, seq_number, session_key):
        self._enc_sequence = seq_number
        self._session_key = session_key

    def _pack_message(self, method_id, payload, extended_flags=True, encrypt=False):
        msg_id = self._msg_id
        self._msg_id = (self._msg_id + 1) & 0xff
        payload_size = len(payload)

        # request format:
        # * HEADER (first chunk: 10 bytes or 11 bytes if extended_flags)
        #          (remain. chunks: 4 bytes or 5 bytes if extended_flags)
        #   * 1 byte: 0x03, REQUEST
        #   * 1 byte: flags, ORed:
        #          0x01 = first_chunk
        #          0x02 = last_chunk
        #          0x04 = needs_ack
        #          0x08 = encrypted
        #   * [1 byte]: 0, for extended flags, if enabled
        #   * 1 byte: write handle (identifies chunks of same message)
        #   * 1 byte: chunk sequence number
        #   * [4 bytes]: length of payload (only first chunk)
        #   * [2 bytes]: message type ("method id") (only first chunk)
        # * PAYLOAD (MTU - header_Size)

        if extended_flags and encrypt:
            sk = list(self._session_key)
            message_key = bytes(sk[i] ^ msg_id for i in range(16))

            # to align payload to 16 bytes, needed by AES Cypher
            enc_size = payload_size + 8
            enc_size += 16 - (enc_size % 16)

            enc_payload = payload
            enc_payload += self._enc_sequence.to_bytes(4, "little")
            enc_payload += get_crc32(enc_payload)
            enc_payload += bytes(enc_size - len(enc_payload))
            self._enc_sequence = (self._enc_sequence + 1) & 0xffffffff

            payload = aes_encrypt_data(enc_payload, message_key)

        count = 0
        offset = 0
        header_size = 10 if not extended_flags else 11

        while True:
            data_size = self._mtu - header_size
            last = False
            data = payload[offset:offset + data_size]
            offset += data_size

            flags = self.F_ENCRYPT if encrypt else 0x00
            if count == 0:
                header_size = 4 if not extended_flags else 5
                flags |= self.F_FIRST_CHUNK
            if offset >= len(payload):
                last = True
                flags |= self.F_LAST_CHUNK | self.F_NEEDS_ACK

            chunk = [self.MSG_REQUEST, flags]
            if extended_flags:
                chunk.append(0x00)
            chunk.extend([msg_id, count])
            if count == 0:
                chunk.extend(list(pack("<I", payload_size)))
                chunk.extend(list(pack("<H", method_id)))

            yield bytes(chunk) + data

            count = (count + 1) & 0xff
            if last:
                break


class MiBandProxy:
    # ENDPOINT_WEATHER                = 0x000e
    # ENDPOINT_CONNECTION             = 0x0015
    # ENDPOINT_USER_INFO              = 0x0017
    ENDPOINT_STEPS                  = 0x0016
    # ENDPOINT_VIBRATION_PATTERNS     = 0x0018
    # ENDPOINT_WORKOUT                = 0x0019
    ENDPOINT_FIND_DEVICE            = 0x001a
    # ENDPOINT_HEARTRATE              = 0x001d
    ENDPOINT_BATTERY                = 0x0029
    # ENDPOINT_SILENT_MODE            = 0x003b
    ENDPOINT_AUTH                   = 0x0082
    # ENDPOINT_COMPAT                 = 0x0090
    ENDPOINT_ALERT                  = 0x001e

    # ALERT_CMD_REPLY                 = 0x04
    # ALERT_CMD_DISMISS               = 0x05
    # ALERT_CMD_REPLY_ACK             = 0x06
    ALERT_CMD_ICON_REQUEST          = 0x10
    # ALERT_CMD_ICON_REQUEST_ACK      = 0x11
    ALERT_TYPE_NORMAL               = b"\xfa"
    ALERT_TYPE_CALL                 = b"\x03"
    ALERT_TYPE_SMS                  = b"\x05"
    ALERT_SUBCMD_SHOW               = b"\x00"
    ALERT_SUBCMD_DISMISS_FROM_PHONE = b"\x02"
    ALERT_HAS_REPLY                 = b"\x01"
    ALERT_NO_REPLY                  = b"\x00"
    # ALERT_DISMISS_NOTIFICATION      = 0x03
    # ALERT_DISMISS_MUTE_CALL         = 0x02
    # ALERT_DISMISS_REJECT_CALL       = 0x01
    # ALERT_CALL_STATE_START          = 0x00
    # ALERT_CALL_STATE_END            = 0x02

    AUTH_RESP                       = 0x10
    AUTH_SUCCESS                    = 0x01

    CMD_SEND_PUBKEY                 = b"\x04\x02\x00\x02"
    CMD_SEND_CHALLENGE              = b"\x05"

    # FIXME: these could be REQUEST=0x03, RESPONSE=0x04, ENABLE=0x05 and ACK=0x06
    CMD_SEND_ALERT                  = b"\x03"
    CMD_BATTERY_GET                 = b"\x03"
    CMD_BATTERY_RESP                = 0x04
    CMD_STEPS_GET                   = b"\x03"
    CMD_STEPS_RESP                  = 0x04
    CMD_STEPS_ENABLE_RT             = b"\x05"
    CMD_STEPS_ENABLE_RT_ACK         = 0x06

    CMD_FIND_BAND                   = b"\x03"
    CMD_FIND_BAND_ACK               = 0x04
    CMD_FIND_BAND_STOP_FROM_PHONE   = b"\x06"

    def __init__(self, requester):
        self._requester = requester

        # NOTE: I have a strong reference to requester, so avoid cyclical references on
        # callbacks (i.e WeakCallback). Otherwise, the __del__ method will not be called.
        self._requester.enable_notifications(
            Chars.CHUNKED_READ, callback=WeakCallback(self._on_cread_notify), filter=["value"])

        self._generate_key_pair()
        write_char, path = requester.get_characteristic(Chars.CHUNKED_WRITE)
        self._sender = InvocationSender(write_char)

        # send read char to write back ACK messages
        read_char, path = requester.get_characteristic(Chars.CHUNKED_READ)
        self._receiver = ResponseReceiver(read_char)

        self._alert_id = int(time.time()) & 0xffffffff
        self._rt_steps_enabled = False

    def __del__(self):
        try:
            self._requester.disable_notifications(Chars.CHUNKED_READ)
        except:
            log.warning(" could not disable notifications")

    def get_auth_challenge(self):
        payload = self.CMD_SEND_PUBKEY + self._public_key
        resp = self._call_method_with_response(self.ENDPOINT_AUTH, payload)

        if len(resp) != 3 + 16 + 48:
            raise ValueError("Invalid response size")
        if (resp[0] != self.AUTH_RESP or resp[1] != self.CMD_SEND_PUBKEY[0] or
            resp[2] != self.AUTH_SUCCESS):
            raise ValueError("Invalid response message")

        challenge = resp[3:19]
        remote_pubkey = resp[19:]
        return challenge, remote_pubkey

    def send_encrypted_challenge(self, enc_chal):
        payload = self.CMD_SEND_CHALLENGE + enc_chal
        resp = self._call_method_with_response(self.ENDPOINT_AUTH, payload)

        if len(resp) != 3:
            raise ValueError("Invalid response size")
        if (resp[0] == self.AUTH_RESP and resp[1] != self.CMD_SEND_CHALLENGE and
            resp[2] == self.AUTH_SUCCESS):
            return True

        return False

    def set_encryption_params(self, enc_number, session_key):
        self._sender.set_encryption_params(enc_number, session_key)
        self._receiver.set_encryption_params(session_key)

    def get_battery_info(self):
        resp = self._call_method_with_response(self.ENDPOINT_BATTERY, self.CMD_BATTERY_GET)

        if len(resp) < 21:
            raise ValueError("Invalid response size")
        if resp[0] != self.CMD_BATTERY_RESP:
            raise ValueError("Invalid response type")

        return BatteryInfo(resp[1:])

    def get_step_info(self):
        resp = self._call_method_with_response(self.ENDPOINT_STEPS, self.CMD_STEPS_GET, False)
        if len(resp) != 15:
            raise ValueError("Invalid response size")
        if resp[0] != self.CMD_STEPS_RESP:
            raise ValueError("Invalid response type")

        return StepInfo(resp[3:])

    def enable_realtime_steps(self, enable=True):
        cmd = None
        if self._rt_steps_enabled:
            if not enable:
                cmd = self.CMD_STEPS_ENABLE_RT + b"\x00"
        else:
            if enable:
                cmd = self.CMD_STEPS_ENABLE_RT + b"\x01"
        if cmd is None:
            return

        # FIXME: setup a handler for receiving these notifications!!
        resp = self._call_method_with_response(self.ENDPOINT_STEPS, cmd, False)
        if len(resp) != 3:
            raise ValueError("Invalid response size")

        if resp[0] == self.CMD_STEPS_ENABLE_RT_ACK:
            status, enabled = resp[1:]
            if status != 1 or enabled != 1:
                log.error(f" could not enable real time steps! (st:{status}, en:{enabled})")
                return
        else:
            log.error(f" could not enable real time steps, unknown response")
            return

        self._rt_steps_enabled = enable

    def send_find(self):
        resp = self._call_method_with_response(self.ENDPOINT_FIND_DEVICE, self.CMD_FIND_BAND, True)
        if len(resp) < 2:
            raise ValueError("Invalid response size")
        if resp[0] == self.CMD_FIND_BAND_ACK:
            return

        log.warning("Unknown response (expecting ACK for finding device)")

    def send_alert(self, spec):
        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.new_alert.xml

        # alert format:
        # * 1 byte: 0x03, CMD_ALERT
        # * 4 bytes: alert ID, start being a timestamp, and increment each time
        # * 1 byte: type (SMS, CALL, NORMAL)
        # * 1 byte: sub-cmd (SHOW, DISMISS_FROM_PHONE)
        # * n bytes: app package name + 0x00 (could be empty)
        # * n bytes: sender/title + 0x00 (could be empty)
        # * n bytes: message + 0x00 (could be empty)
        # * n bytes: app name + 0x00 (could be empty)
        # * 1 byte: has reply (0x00 || 0x01)

        self._alert_id += 1
        alert_types = {
            "call": self.ALERT_TYPE_CALL,
            "sms": self.ALERT_TYPE_SMS,
        }

        cmd = self.CMD_SEND_ALERT
        cmd += pack("<I", self._alert_id)
        cmd += alert_types.get(spec.type, self.ALERT_TYPE_NORMAL)
        cmd += self.ALERT_SUBCMD_DISMISS_FROM_PHONE if spec.action == "dismiss" \
            else self.ALERT_SUBCMD_SHOW
        cmd += spec.app_name.encode() + b"\x00"
        cmd += spec.title.encode() + b"\x00"
        cmd += spec.body.encode() + b"\x00"
        cmd += b"MiBandLib\x00"

        # FIXME: implement support for REPLYs
        cmd += self.ALERT_NO_REPLY

        resp = self._call_method_with_response(self.ENDPOINT_ALERT, cmd, True)

    # FIXME: to implement this, you need to implement the file transfer protocol
    #        see GadgetBridge ZeppOsFileTransferService.java
    #
    #     if len(resp) < 1:
    #         log.warning(" invalid size response!")
    #     elif resp[0] == self.ALERT_CMD_ICON_REQUEST:
    #         self._handle_icon_request(resp[1:], spec)

    # def _handle_icon_request(self, resp, spec):
    #     request_icon_cb = spec.get("on_icon_request")
    #     if request_icon_cb is None:
    #         log.warning(" icon for alert requested, but no callback provided!")
    #         return

    #     icon_formats = {
    #         0x04: "TGA_RGB565_GCNANOLITE",
    #         0x08: "TGA_RGB565_DAVE2D"}

    #     try:
    #         nullpos = resp.find(0x00)
    #         pkg_name = resp[:nullpos].decode()
    #         format = icon_formats.get(resp[nullpos + 1], f"UNKNOWN {resp[nullpos + 1]:02x}")
    #         width = unpack("<H", resp[nullpos + 2:nullpos + 4])[0]
    #         height = unpack("<H", resp[nullpos + 4:])[0]
    #         icon = request_icon_cb(pkg_name, "PNG", width, height)
    #         icon = png_to_tga(icon, format, width, height)

    #         # FIXME: send icon as a file
    #         # FIXME: send icon request ack

    #     except IndexError:
    #         log.error(" icon request with invalid format!")

    def prx__get_private_key(self):
        return self._private_key

    def _call_method(self, method, params, encrypt=False):
        self._sender.invoke(method, params, encrypt=encrypt)

    def _call_method_with_response(self, method, params, encrypt=False):
        self._call_method(method, params, encrypt)
        return self._receiver.wait_response(method, timeout=10)

    def _on_cread_notify(self, value):
        if value is None:
            return
        self._receiver.feed(bytes(value))

    def _generate_key_pair(self):
        self._private_key = ec.generate_private_key(ec.SECT163R2)
        pub_key = self._private_key.public_key()
        self._public_key = pub_key.public_numbers().x.to_bytes(24, "little")
        self._public_key += pub_key.public_numbers().y.to_bytes(24, "little")


class MiBandDevice:
    """This is the main object of miband library. It represents a Mi
    Band device, and has those methods needed to read its state, and control/change
    its behaviour.

    ``mac`` is its MAC address, in the form of a string like:
    ``00:11:22:33:44:55``. ``name`` is the user given device name. It
    could be empty. ``token`` is the security token used by this band.
    ``version`` is the version of the device (i.e. 4 or 8).
    If `autoconnect` is given, it will connect upon object creation. ::

      >>> device = miband.MiBand4("Jose's Band", "88:0f:10:00:01:02")
    """

    CMD_ACTIVITY_FETCH          = b"\x01"
    CMD_ACTIVITY_GET_DATA       = b"\x02"

    DATA_TYPE_ACTIVITY          = b"\x01"

    RESP_ACTIVITY_FETCH         = b"\x10\x01\x01"
    RESP_ACTIVITY_FETCH_NO_MORE = b"\x10\x02\x04"
    RESP_ACTIVITY_FETCH_END     = b"\x10\x02\x01"
    RESP_ACTIVITY_FETCH_ERROR   = b"\x10\x01\x05"
    RESP_ACTIVITY_RUNNING       = b"\x10\x01\x07"

    def __init__(self, name, mac, token=None, autoconnect=False, version=7):
        self.given_name = name
        self.mac = mac
        self.requester = GATTRequester(self.mac, auto_connect=False)
        self.version = version
        self.log = log.getChild(name)

        self.token = token
        if isinstance(token, str):
            self.token = bytes(int(token[i:i+2], 16) for i in range(0, len(token), 2))

        if version != 4 and version != 7:
            self.log.warning(" this version is not tested/supported, it may not work at all!")

        if autoconnect:
            self.connect()

    @classmethod
    def discover(cls, timeout=10, devname="Mi Smart Band 4"):
        service = DiscoveryService("hci0")
        devices = service.discover(timeout)

        retval = []
        for address, name in devices.items():
            if name != devname:
                continue
            retval.append(address)
        return retval

    def connect(self):
        """Used to create a connection with the Mi Band. It may take some
        time, depending on many factors as LE params, channel usage,
        etc. ::

          >>> device.connect()

        .. note:: This method needs to be called before almost any
                  other command. Also note that the connection will be
                  closed after some period of inactivity. See
                  Bluetooth LE params for more info.
        """

        self.log.info(f" connecting to '{self.mac}'...")
        self.requester.connect(True)
        self.log.info(" - OK, connected")

        try:
            self._miband_prx = MiBandProxy(self.requester)
        except CharacteristicNotFound as ex:
            self.log.error(f"Invalid device (ex: {ex}! Did you pair it first?")
            return False

        if self.token is None:
            return False

        # 1. retrieve challenge and public key from remote device
        self.log.info(" - token provided, try to get authorization...")
        challenge, remote_public_key = self._miband_prx.get_auth_challenge()

        # 2. compute session key
        private_key = self._miband_prx.prx__get_private_key()
        shared_key = self._get_shared_key(private_key, remote_public_key)
        session_key = self._get_session_key(shared_key, self.token)

        # 3. generate first encryption sequence number and setup encoder/decoder
        enc_number = unpack("<I", shared_key[:4])[0]
        self._miband_prx.set_encryption_params(enc_number, session_key)

        # 4. send encrypted challenge to remote device
        enc_chal = self._encrypt_challenge(challenge, session_key)
        ok = self._miband_prx.send_encrypted_challenge(enc_chal)

        if ok: self.log.info(" - auth success!")
        else:  self.log.warning(" - can not auth successfully!")
        return ok

    def disconnect(self):
        """Used to close the connection with the Mi Band when not needed anymore.
        """
        self.requester.disconnect()

    def is_connected(self):
        """Check if Mi Band is currently connected. Returns a bool value.
        """
        return self.requester.is_connected()

    @lru_cache()
    def get_name(self):
        """Retrieves (and stores) the internal device name. Returns a string.
        """
        return self.requester.prop("Name")

    @lru_cache()
    def get_sw_version(self):
        """Retrieves (and stores) the device software version. Returns a string.
        """
        data = self.requester.read_by_uuid(Chars.SW_VERSION)
        return "".join(chr(c) for c in data)

    @lru_cache()
    def get_hw_version(self):
        """Retrieves (and stores) the device hardware version. Returns a string.
        """
        data = self.requester.read_by_uuid(Chars.HW_VERSION)
        return "".join(chr(c) for c in data)

    @lru_cache()
    def get_serial_number(self):
        """Retrieves (and stores) the device serial number. Returns a string.
        """
        data = self.requester.read_by_uuid(Chars.SERIAL_NUMBER)
        return "".join(chr(c) for c in data)

    @lru_cache()
    def get_appearance(self):
        """Retrieves (and stores) the device appearance. Returns a string with the 16bit
        value, and the corresponding description.
        """
        desc_id = self.requester.prop("Appearance")

        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/\
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.gap.appearance.xml
        descriptions = {
            0:   "unknown",                            960:  "generic hid",
            64:  "generic phone",                      961:  "hid keyboard",
            128: "generic computer",                   962:  "hid mouse",
            192: "generic watch",                      963:  "hid joystick",
            193: "watch sports watch",                 964:  "hid gamepad",
            256: "generic clock",                      965:  "hid digitizersubtype",
            320: "generic display",                    966:  "hid card reader",
            384: "generic remote control",             967:  "hid digital pen",
            448: "generic eye glasses",                968:  "hid barcode",
            512: "generic tag",                        1024: "generic glucose meter",
            576: "generic keyring",                    1088: "generic running walking sensor",
            640: "generic media player",               1089: "running walking sensor in shoe",
            704: "generic barcode scanner",            1090: "running walking sensor on shoe",
            768: "generic thermometer",                1091: "running walking sensor on hip",
            769: "thermometer ear",                    1152: "generic cycling",
            832: "generic heart rate sensor",          1153: "cycling cycling computer",
            833: "heart rate sensor heart rate belt",  1154: "cycling speed sensor",
            896: "generic blood pressure",             1155: "cycling cadence sensor",
            897: "blood pressure arm",                 1156: "cycling power sensor",
            898: "blood pressure wrist",               1157: "cycling speed cadence sensor",
        }
        if desc_id not in descriptions:
            desc_id = 0
        appearance = descriptions[desc_id]

        return f"{appearance} (0x{desc_id:x})"

    @lru_cache()
    def get_system_id(self, raw=False):
        """Retrieves (and stores) the device system id number. Returns as an
        hexadecimal string. If ``raw`` is True, it returns an array of bytes. Otherwise,
        it returns an string with LSO and MSO values.
        """

        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/\
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.system_id.xml
        #
        # SystemID is a 64bit number, with two fields:
        #  - LSO 40 bit: manufacturer-defined identifier
        #  - MSO 24 bit: OUI, Organizationally Unique Identifier
        # If based on BL address, then FFFE is used to concatenate both strings

        data = self.requester.read_by_uuid(Chars.SYSTEM_ID)
        if raw:
            return data

        oui = "".join(f"{b:02x}" for b in data[:3])
        mdi = "".join(f"{b:02x}" for b in data[3:])
        return f"{oui}-{mdi}"

    @lru_cache()
    def get_pnp_info(self):
        """Retrieves (and stores) the device PnP information. It returns a string with
        the following fields: Vendor ID Source, Vendor ID, Product ID, Product Version.
        """

        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/\
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.pnp_id.xml

        data = self.requester.read_by_uuid(Chars.PNP_ID)
        vendor_id_s = data[-1]
        vendor_id = "".join(f"{b:02x}" for b in data[-3:-1])
        product_id = "".join(f"{b:02x}" for b in data[-5:-3])
        product_ver = "".join(f"{b:02x}" for b in data[-7:-5])
        return (
            f"Vendor ID source: {vendor_id_s}, "
            f"Vendor ID: {vendor_id}, "
            f"Product ID: {product_id}, "
            f"Product ver.: {product_ver}"
        )

    def get_current_time(self):
        """Retrieves the time and date stablished in the Mi Band device.
        """

        data = self.requester.read_by_uuid(Chars.CURRENT_TIME)
        return parse_date(data)

    def set_current_time(self, dt=None):
        """Sets the given date/time in the Mi Band device. If not provided, use system's
        current date/time.
        """

        if dt is None:
            dt = datetime.now()

        date = struct.pack(
            'hbbbbbbbxx', dt.year, dt.month,
            dt.day, dt.hour, dt.minute,
            dt.second, dt.isoweekday(), 0)
        self.requester.write_by_uuid(Chars.CURRENT_TIME, date)
        self.log.info(" datetime set to {}".format(
            dt.strftime('%Y-%m-%d %H:%M:%S')))

    def get_battery_info(self):
        """Get information about device battery. Returns a
        :class:`miband.BatteryInfo` instance. ::

          >>> info = device.get_battery_info()
          >>> info.status
          'normal'
          >>> info.level
          86
          >>> info.last_charged
          datetime.datetime(2020, 8, 11, 22, 36)
        """

        return self._miband_prx.get_battery_info()

    def get_step_info(self):
        """Get information about step count. Returns a :class:`miband.StepInfo`
        instance, which holds the number of steps, traveled length, calories
        and burnt fat.
        """

        return self._miband_prx.get_step_info()

    def get_activities(self, start=None, progress_cb=None):
        """Get statistics about recorded activities in a period of time.
        `start` is a `datetime` object with the starting point of the period.
        If omitted, the time span will be the last day. Each record spans 1 minute.
        if `progress_cb` is given, it will be called every second with the number of
        fetched and total records.
        """

        if start is None:
            start = datetime.now() - timedelta(days=15)

        activity_fetch = queue.Queue()
        activity_data = queue.Queue()
        ctx = Munch()
        ctx.data_crc32 = 0
        records = []

        # 1. enable notifications
        def on_data(value, queue, src, ctx):
            value = bytes(value) if value else b""

            # send ACK on received data
            if src == "fetch":
                if value[:3] == b"\x10\x02\x01":

                    # FIXME: compute and compare checksums!!
                    # got_crc = unpack(">I", value[3:])[0]
                    # assert got_crc == ctx.data_crc32, "Invalid checksums!"

                    ack = b"\x03\x09"  # 2nd byte: 1-> delete data, 9-> keep on device
                    self.requester.write_cmd_by_uuid(Chars.ACTIVITY_FETCH, ack)
                    return

                if value[:3] == b"\x10\x03\x01":
                    print("ACK (OK) RECEIVED")
                    return

            # FIXME: compute and compare checksums!!
            # else:
            #     ctx.data_crc32 = zlib.crc32(value, ctx.data_crc32)

            # remove last byte
            queue.put(value[:-1])

        self.requester.enable_notifications(Chars.ACTIVITY_FETCH,
            callback=partial(on_data, queue=activity_fetch, src="fetch", ctx=ctx))
        self.requester.enable_notifications(Chars.ACTIVITY_DATA,
            callback=partial(on_data, queue=activity_data, src="data", ctx=ctx))

        # don't forget to disable notifications when finished
        on_exit = RunOnExit()
        on_exit += partial(self.requester.disable_notifications, Chars.ACTIVITY_FETCH)
        on_exit += partial(self.requester.disable_notifications, Chars.ACTIVITY_DATA)

        # 2. start retrieval
        ctime = self.get_current_time()
        ts = struct.pack("<H", start.year)
        ts += bytes([start.month, start.day, start.hour, start.minute])
        ts += struct.pack("<H", ctime.tzinfo.utcoffset(None).seconds)
        cmd = self.CMD_ACTIVITY_FETCH + self.DATA_TYPE_ACTIVITY + ts

        # 3. receive record's metadata, then fire the dump
        self.requester.write_cmd_by_uuid(Chars.ACTIVITY_FETCH, cmd)
        data = activity_fetch.get(timeout=10)

        if data[:3] == self.RESP_ACTIVITY_FETCH:
            num_records = struct.unpack("<i", data[3:7])[0]
            recv_ts = parse_date(data[7:14])
            self.log.info(f" fetch activity data ({num_records} records) from {recv_ts}")
            self.requester.write_cmd_by_uuid(Chars.ACTIVITY_FETCH, self.CMD_ACTIVITY_GET_DATA)

        else:
            if data[:3] == self.RESP_ACTIVITY_FETCH_NO_MORE:
                self.log.info(" no more activity records")
            elif data[:3] == self.RESP_ACTIVITY_RUNNING:
                self.log.warning(" there is an activity running, stop it first")
            elif data[:3] == self.RESP_ACTIVITY_FETCH_ERROR:
                self.log.warning(" there were an error with the fetch request")
            else:
                self.log.warning(" unexpected data received, stopping...")
            return records

        # 4. process batch of notifications
        last = Munch()
        last.record_id = 1
        last.record_ts = recv_ts
        last.expected_id = 0

        progress_ts = 0
        if progress_cb is None:
            progress_cb = lambda x, y: None

        tout_counter = 0
        while len(records) < num_records:
            try:
                pkg = activity_data.get(timeout=1)
                records += self._process_activity_pkg(pkg, last)
            except queue.Empty:
                tout_counter += 1
                if tout_counter >= 10:
                    break
            finally:
                if time.time() - progress_ts >= 1:
                    progress_ts = time.time()
                    progress_cb(len(records), num_records)

        progress_cb(len(records), num_records)
        return records

    def _process_activity_pkg(self, pkg, last):
        pkg_id = pkg[0]
        assert pkg_id == last.expected_id, "some package arrived in unexpected order!"
        assert len(pkg) % 8 == 0, "invalid package size!"
        last.expected_id = (last.expected_id + 1) & 0xff

        pkg = pkg[1:]
        records = []

        # format: 8 bytes
        # - category =   data[0]
        # - intensity =  data[1]
        # - steps =      data[2]
        # - heart_rate = data[3]
        # remaining 4 bytes: unknown (stored as .raw)

        for i in range(0, len(pkg), 8):
            data = pkg[i:i+8]
            record = ActivityRecord(last, data)
            records.append(record)
            last.record_id += 1
            last.record_ts += timedelta(minutes=1)
        return records

    # FIXME: finish the migration of these methods!

    # def get_current_heart_rate(self):
    #     """Return the current heart rate, measured in the moment of the call.
    #     It will take around 25 seconds to measure it, and the user should be still.
    #     Result is in bpm (beats per minute).
    #     """

    #     self.log.info(" getting heart rate, please wait (up to 30 secs.)...")

    #     # enable one-shot HR read
    #     self._enable_notifications(Handles.HEART_RATE_MEASURE_NOTIF, True)
    #     self.requester.write_by_handle(
    #         Handles.HEART_RATE_CTRL, Consts.CMD_START_HR_ONE_SHOT)

    #     # this device will send 3 notifications with the heart rate
    #     m1 = self.requester.wait_for_notification(Handles.HEART_RATE_MEASURE, timeout=30)
    #     m2 = self.requester.wait_for_notification(Handles.HEART_RATE_MEASURE, timeout=5)
    #     m3 = self.requester.wait_for_notification(Handles.HEART_RATE_MEASURE, timeout=5)

    #     self._enable_notifications(Handles.HEART_RATE_MEASURE_NOTIF, False)

    #     # return the average
    #     if None in (m1, m2, m3):
    #         self.log.warning(" no response, did you attach the band correctly?")
    #         return 0

    #     return (m1[-1] + m2[-1] + m3[-1]) // 3

    # def start_hr_streaming(self):
    #     """Configure the Mi Band to start streaming it sensors data. It returns a
    #     generator object which could be iterated.
    #     """

    #     self.log.info(" starting heart rate streaming, please wait (up to 30 secs.)...")

    #     # enable stream HR readings
    #     self._enable_notifications(Handles.HEART_RATE_MEASURE_NOTIF, True)
    #     self.requester.write_by_handle(
    #         Handles.HEART_RATE_CTRL, Consts.CMD_START_HR_STREAMING)

    #     # return a generator that retrieves measurements
    #     last_ping = time()
    #     while True:

    #         # ping service to keep receiving notifications
    #         if time() - last_ping >= 10:
    #             self.requester.write_by_handle(
    #                 Handles.HEART_RATE_CTRL, Consts.CMD_PING_HR)
    #             last_ping = time()

    #         measure = self.requester.wait_for_notification(
    #             Handles.HEART_RATE_MEASURE, timeout=30)

    #         if measure is None:
    #             self.log.warning(" heart rate measure not received!")

    #         yield measure[1] if measure is not None else measure

    # def stop_hr_streaming(self):
    #     """Stops the sensor data streamning."""

    #     self.log.info(" stopping heart rate streaming...")

    #     self.requester.write_by_handle(
    #         Handles.HEART_RATE_CTRL, Consts.CMD_STOP_HR_STREAMING)
    #     self._enable_notifications(Handles.HEART_RATE_MEASURE_NOTIF, False)

    # def set_alert_level(self, level):
    #     """Set the level of alerts. `level` may be one of `silent`, `mild` or `high`.
    #     """

    #     # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/
    #     # Gatt/Xml/Characteristics/org.bluetooth.characteristic.alert_level.xml

    #     code = {
    #         'silent': '\x00',
    #         'mild':   '\x01',
    #         'high':   '\x02',
    #     }

    #     self.log.warning("Mi Band 4 may not support this operation (yet).")
    #     self.requester.write_cmd(Handles.ALERT_LEVEL, code[level])
    #     self.log.info(f" alert level set to {level}")

    def send_alert(self, title, body, app_name="MiBand", type="app", on_icon_request=None):
        """Sends a notification alert to the device.
        """
        spec = Munch(
            type = type,
            action = "show" ,
            title = title,
            body = body,
            app_name = app_name,
            on_icon_request = on_icon_request,
        )

        self._miband_prx.send_alert(spec)

    def find_device(self, period=2):
        """Makes the band to start vibrating, once each `period` of time (in seconds).
        """
        self._miband_prx.send_find()
        self._device_finder = IntervalTimer(self._miband_prx.send_find, period)

    def stop_finding_device(self):
        if not hasattr(self, "_device_finder"):
            return

        self._device_finder.stop()
        self._device_finder = None

    def _encrypt_challenge(self, challenge, session_key):
        enc_chal1 = aes_encrypt_data(challenge, self.token)
        enc_chal2 = aes_encrypt_data(challenge, session_key)
        return enc_chal1 + enc_chal2

    def _get_shared_key(self, private_key, public_key):
        private_key = private_key.private_numbers().private_value.to_bytes(24, "little")
        return ecdh_shared_secret(private_key, public_key)

    def _get_session_key(self, shared_key, token):
        sk = list(shared_key)
        tok = list(token)
        retval = b""
        for i in range(16):
            retval += bytes([sk[i + 8] ^ tok[i]])
        return retval


class Chars:
    """Mi Band characteristic UUID constants."""

    # these UUIDs are defined by the Bluetooth SGI
    SYSTEM_ID           = "00002a23-0000-1000-8000-00805f9b34fb"
    SERIAL_NUMBER       = "00002a25-0000-1000-8000-00805f9b34fb"
    HW_VERSION          = "00002a27-0000-1000-8000-00805f9b34fb"
    SW_VERSION          = "00002a28-0000-1000-8000-00805f9b34fb"
    CURRENT_TIME        = "00002a2b-0000-1000-8000-00805f9b34fb"
    PNP_ID              = "00002a50-0000-1000-8000-00805f9b34fb"

    # these UUDs are custom, defined by Xiaomi (extracted by RE)
    ACTIVITY_FETCH      = "00000004-0000-3512-2118-0009af100700"
    ACTIVITY_DATA       = "00000005-0000-3512-2118-0009af100700"
    CHUNKED_WRITE       = "00000016-0000-3512-2118-0009af100700"
    CHUNKED_READ        = "00000017-0000-3512-2118-0009af100700"

    @classmethod
    def get_name(cls, handle):
        for k, v in cls.__dict__.items():
            if v == handle:
                return k
        return f"<unknown: {handle}>"
