from pathlib import Path
from argparse import ArgumentParser


def get_token(path="token"):
    path = Path(path)
    if not path.is_file():
        print(f"Warning: token file '{path.as_posix()}' does not exist!")
        return None

    with path.open() as src:
        return src.readline().strip()


parser = ArgumentParser()
parser.add_argument("-m", "--mac", required=True,
    help="MAC address of your device")
