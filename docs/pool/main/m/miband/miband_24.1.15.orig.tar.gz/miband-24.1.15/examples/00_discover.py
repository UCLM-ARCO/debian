#!/usr/bin/env python3

from gattlib import DiscoveryService


print("Running discovery, please wait...")
service = DiscoveryService("hci0")
devices = service.discover(10)

for address, name in devices.items():
    print(f"> Name: '{name}', Address: '{address}'")
