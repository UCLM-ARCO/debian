#!/usr/bin/env python3

import logging
from utils import get_token, parser
from miband import MiBandDevice


# logging.basicConfig(level=logging.DEBUG)

args = parser.parse_args()
print(f"> Connecting to {args.mac}...")
device = MiBandDevice("My Mi Band", args.mac, )#token=get_token())
device.connect()

# NOTE: to read these fields, there is no need of authorization
print(f"> Name: '{device.get_name()}'")
print(f"> Software Version: '{device.get_sw_version()}'")
print(f"> Hardware version: '{device.get_hw_version()}'" )
print(f"> Serial Number: '{device.get_serial_number()}'")
print(f"> Appearance: '{device.get_appearance()}'")
print(f"> System ID: '{device.get_system_id()}'")
print(f"> PnP Info: '{device.get_pnp_info()}'")
print(f"> Time: '{device.get_current_time()}'")
print(f"> Battery: '{device.get_battery_info()}'")

# FIXME: show user info