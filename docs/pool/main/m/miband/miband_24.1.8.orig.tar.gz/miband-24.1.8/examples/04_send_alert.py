#!/usr/bin/env python3

# import logging
# from pathlib import Path
from utils import get_token, parser
from miband import MiBandDevice


# logging.basicConfig(level=logging.DEBUG)

args = parser.parse_args()
print(f"> Connecting to {args.mac}...")
device = MiBandDevice("My Mi Band", args.mac, token=get_token())
device.connect()

device.send_alert(title="hello", body="Hello World!")


# FIXME: not finished!
# def on_icon_request(app_name, icon_format, width, height):
#     icon_path = Path(__file__).parent / "app-icon.png"
#     return icon_path.open("rb").read()

# device.send_alert(title="hello", body="Hello World!", app_name="SendAlertApp",
#     on_icon_request=on_icon_request)
