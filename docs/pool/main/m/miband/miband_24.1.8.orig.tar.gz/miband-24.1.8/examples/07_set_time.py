#!/usr/bin/env python3

from datetime import datetime
from utils import get_token, parser
from miband import MiBandDevice

# To set now current date, run:
# python3 ./07_set_time.py -m MAC "$(date +'%Y/%m/%d %H:%M:%S')"

date_fmt = r"%Y/%m/%d %H:%M:%S"
parser.add_argument("datetime", type=lambda x: datetime.strptime(x, date_fmt),
    help=f"new date/time in format {date_fmt.replace('%', '').lower()}")

args = parser.parse_args()
print(f"> Connecting to {args.mac}...")
device = MiBandDevice("My Mi Band", args.mac, token=get_token())
device.connect()

print("> Connected:", device.is_connected())
print("> Current device time:", device.get_current_time())
print(f"> Setting time to: {args.datetime}...")
device.set_current_time(args.datetime)
print("Done!")
