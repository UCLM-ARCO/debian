#!/usr/bin/env python3

from utils import get_token, parser
from miband import MiBandDevice


args = parser.parse_args()
print(f"> Connecting to {args.mac}...")
device = MiBandDevice("My Mi Band", args.mac, token=get_token())
device.connect()

print("> Connected:", device.is_connected())
