
import logging
import queue
import struct
from datetime import datetime, timedelta, timezone
from functools import lru_cache
from time import time
from types import SimpleNamespace as SimpleObj

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from gattlib import DiscoveryService, GATTRequester
from hexdump import hexdump


def parse_date(d):
    year    = struct.unpack('h', d[0:2])[0]
    month   = struct.unpack('b', d[2:3])[0]
    day     = struct.unpack('b', d[3:4])[0]
    hours   = struct.unpack('b', d[4:5])[0]
    minutes = struct.unpack('b', d[5:6])[0]
    seconds = struct.unpack('b', d[6:7])[0]

    # d[7]: day of week
    # d[8]: 1/256 fractions of a second

    tz = None
    if len(d) >= 11:
        utc_offset = struct.unpack('h', d[9:11])[0]
        tz = timezone(timedelta(seconds=utc_offset))

    return datetime(year, month, day, hours, minutes, seconds, tzinfo=tz)


class BatteryInfo:
    """Holds the battery information for the Mi Band."""

    def __init__(self, data):
        self.level = struct.unpack('b', data[1:2])[0] \
            if len(data) >= 2 else None

        self.status = 'normal'
        if struct.unpack('b', data[2:3])[0] != 0:
            self.status = "charging"

        self.last_off = parse_date(data[3:10])
        self.last_charge = parse_date(data[11:18])
        self.last_level = struct.unpack('b', data[19:20])[0] \
            if len(data) >= 20 else None

    def to_dict(self):
        return self.__dict__

    def __repr__(self):
        return (
            f"<Battery information: \n"
            f" - level: {self.level} %, \n"
            f" - status: {self.status}, \n"
            f" - last off: {self.last_off}, \n"
            f" - last charge: {self.last_charge}, \n"
            f" - last level: {self.last_level}>"
        )


class StepInfo:
    def __init__(self, data):
        """Holds the step information for the Mi Band."""

        self.steps = struct.unpack('<i', data[1:5])[0]
        self.meters = struct.unpack('<i', data[5:9])[0]
        self.calories = struct.unpack('<i', data[9:])[0]

    def to_dict(self):
        return self.__dict__

    def __repr__(self):
        return (
            f"<Step information: \n"
            f" - count: {self.steps} steps, \n"
            f" - distance: {self.meters} m, \n"
            f" - calories: {self.calories} Kcal>"
        )


class PPCPInfo:
    def __init__(self, data):
        self.conn_interval_min = struct.unpack('h', data[0:2])[0] * 1.25
        self.conn_interval_max = struct.unpack('h', data[2:4])[0] * 1.25
        self.slave_latency = struct.unpack('h', data[4:6])[0]
        self.conn_supervision_tout_mult = struct.unpack('h', data[6:8])[0]

    def to_dict(self):
        return self.__dict__

    def __repr__(self):
        return (
            f"<Peripheral Preferred Connection Params: \n"
            f" - minimum connection interval: {self.conn_interval_min} ms, \n"
            f" - maximum connection interval: {self.conn_interval_max} ms, \n"
            f" - slave latency: {self.slave_latency} ms\n, "
            f" - conn. supervision timeout mult.: {self.conn_supervision_tout_mult}>"
        )


class ActivityRecord:
    def __init__(self, info, data):
        self.category = data[0]
        self.intensity = data[1]
        self.steps = data[2]
        self.heart_rate = data[3]
        self.index = info.record_id
        self.timestamp = info.record_ts

    def __repr__(self):
        cat_name = Consts.ACTIVITY_NAMES.get(self.category, self.category)
        return (
            f"<Activity, id: {self.index}, "
            f"cat: {cat_name}, "
            f"int: {self.intensity}, "
            f"steps: {self.steps}, "
            f"hr: {self.heart_rate}, "
            f"ts: {self.timestamp}>"
        )


class MiBand4Requester(GATTRequester):
    def __init__(self, log, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.log = log
        self.handle_queues = {}
        self.err_code = 0

    def on_notification(self, handle, data):
        dump = hexdump(data, result="return").replace("\n", "\n  ")
        handle_name = Handles.get_name(handle)
        self.log.debug(f" + notification on handle: 0x{handle:04x}:{handle_name}")
        self.log.debug(f" + message dump: \n  {dump}")

        # fist 3B in data: 1B + handle number, strip them off
        self._get_queue(handle).put(data[3:])

    def on_connect_failed(self, code: int) -> None:
        self.err_code = code

    def wait_for_notification(self, handle, timeout=10):
        q = self._get_queue(handle)

        try:
            return q.get(timeout=timeout)
        except queue.Empty:
            return None

    def _get_queue(self, handle):
        q = self.handle_queues.get(handle)
        if q is None:
            q = queue.Queue()
            self.handle_queues[handle] = q
        return q


class MiBand4:
    """This is the main object of miband library. It represents a Mi
    Band device, and has those methods needed to read its state, and control/change
    its behaviour.

    ``mac`` is its MAC address, in the form of a string like:
    ``00:11:22:33:44:55``. ``name`` is the user given device name. It
    could be empty. ``token`` is the security token used by this band.
    If `autoconnect` is given, it will connect upon object creation. ::

      >>> device = miband.MiBand4("Jose's Band", "88:0f:10:00:01:02")
    """

    def __init__(self, name, mac, token=None, autoconnect=False):
        self.given_name = name
        self.mac = mac
        self.token = token
        self.requester = None

        self.log = logging.getLogger(name)
        self.log.setLevel(logging.INFO)

        if autoconnect:
            self.connect()

    def _enable_notifications(self, handle, enabled):
        self.log.debug(" {} notifications on handle 0x{:04x}:{}...".format(
            "enabling" if enabled else "disabling",
            handle, Handles.get_name(handle)
        ))
        cmd = b"\x01\x00" if enabled else b"\x00\x00"
        self.requester.write_by_handle(handle, cmd)

    def _authorize(self):
        # 1. request a random number from the device
        self._enable_notifications(Handles.AUTH_NOTIF, True)
        self.requester.write_cmd(Handles.AUTH, b"\x02\x00")

        # 2. wait notification with number from device
        while True:
            data = self.requester.wait_for_notification(Handles.AUTH)
            if data is None:
                self.log.error(" - could not get authorization!")
                return False

            if data[:3] == Consts.MSG_AUTH_RANDOM_NUMBER:
                data = data[3:]
                break

        # 3. encode number and send it back
        aes = Cipher(algorithms.AES(self.token), modes.ECB())
        encryptor = aes.encryptor()
        msg = b'\x03\x00' + encryptor.update(data) +\
            encryptor.finalize()
        self.requester.write_cmd(Handles.AUTH, msg)

        # 4. wait for message indicating a valid auth
        data = self.requester.wait_for_notification(Handles.AUTH)
        self._enable_notifications(Handles.AUTH_NOTIF, False)

        if data == b"\x10\x03\x01":
            self.log.info(" - authorization OK")
            return True

        if data is None:
            self.log.error(" - could not get authorization!")
        else:
            self.log.error(" - invalid token for authorization!")
        return False

    @classmethod
    def discover(cls, timeout=10, devname="Mi Smart Band 4"):
        service = DiscoveryService("hci0")
        devices = service.discover(timeout)

        retval = []
        for address, name in devices.items():
            if name != devname:
                continue
            retval.append(address)
        return retval

    def connect(self):
        """Used to create a connection with the Mi Band. It may take some
        time, depending on many factors as LE params, channel usage,
        etc. ::

          >>> device.connect()

        .. note:: This method needs to be called before almost any
                  other command. Also note that the connection will be
                  closed after some period of inactivity. See
                  Bluetooth LE params for more info.
        """

        self.log.info(f" connecting to '{self.mac}'...")
        self.requester = MiBand4Requester(self.log, self.mac, False)
        self.requester.connect(True, security_level="medium")
        self.log.info(" - OK, connected")

        if self.token is None:
            return False

        self.log.info(" - token provided, try to get authorization...")
        return self._authorize()

    def disconnect(self):
        """Used to close the connection with the Mi Band when not needed anymore.
        """
        self.requester.disconnect()

    def is_connected(self):
        """Check if Mi Band is currently connected. Returns a bool value.
        """
        return self.requester.is_connected()

    @lru_cache()
    def get_name(self):
        """Retrieves (and stores) the internal device name. Returns a string.
        """
        data = self.requester.read_by_uuid(Chars.DEVICE_NAME)
        return data[0].decode()

    @lru_cache()
    def get_sw_version(self):
        """Retrieves (and stores) the device software version. Returns a string.
        """
        data = self.requester.read_by_uuid(Chars.SW_VERSION)
        return data[0].decode()

    @lru_cache()
    def get_hw_version(self):
        """Retrieves (and stores) the device hardware version. Returns a string.
        """
        data = self.requester.read_by_uuid(Chars.HW_VERSION)
        return data[0].decode()

    @lru_cache()
    def get_serial_number(self):
        """Retrieves (and stores) the device serial number. Returns a string.
        """
        data = self.requester.read_by_uuid(Chars.SERIAL_NUMBER)
        return data[0].decode()

    @lru_cache()
    def get_appearance(self):
        """Retrieves (and stores) the device appearance. Returns a string with the 16bit
        value, and the corresponding description.
        """

        data = self.requester.read_by_uuid(Chars.APPEARANCE)[0]

        # FIXME: fill this table with:
        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/\
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.gap.appearance.xml
        descriptions = {
            b"\x00\x00": "Unknown appearance"
        }

        return f"{descriptions.get(data, '??')} ({data.hex()})"

    @lru_cache()
    def get_system_id(self):
        """Retrieves (and stores) the device system id number. Returns as an
        hexadecimal string.
        """

        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/\
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.system_id.xml
        #
        # SystemID is a 64bit number, with two fields:
        #  - LSO 40 bit: manufacturer-defined identifier
        #  - MSO 24 bit: OUI, Organizationally Unique Identifier
        # If based on BL address, then use FFFE to concatenate both strings

        data = self.requester.read_by_uuid(Chars.SYSTEM_ID)[0]
        return data.hex()

    @lru_cache()
    def get_pnp_info(self):
        """Retrieves (and stores) the device PnP information. It returns a string with
        the following fields: Vendor ID Source, Vendor ID, Product ID, Product Version.
        """

        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/\
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.pnp_id.xml

        data = self.requester.read_by_uuid(Chars.PNP_ID)[0]
        return (
            f"Vendor ID source: {hex(data[-1])}, "
            f"Vendor ID: {data[-3:-1].hex()}, "
            f"Product ID: {data[-5:-3].hex()}, "
            f"Product ver.: {data[-7:-5].hex()}"
        )

    def get_current_time(self):
        """Retrieves the time and date stablished in the Mi Band device.
        """

        data = self.requester.read_by_uuid(Chars.CURRENT_TIME)[0]
        return parse_date(data)

    def set_current_time(self):
        """Sets system current time in the Mi Band device.
        """
        now = datetime.now()
        date = struct.pack(
            'hbbbbbbbxx', now.year, now.month, 
            now.day, now.hour, now.minute, 
            now.second, now.isoweekday(), 0)
        self.requester.write_by_handle(Handles.CURRENT_TIME, date)
        self.log.info(" datetime set to {}".format(
            now.strftime('%Y-%m-%d %H:%M:%S')))

    def get_preferred_conn_params(self):
        """Retrieves the Peripheral Preferred Connection Parameters for this device.
        """

        # https://raw.githubusercontent.com/oesmith/gatt-xml/master/
        # org.bluetooth.characteristic.gap.peripheral_preferred_connection_parameters.xml

        data = self.requester.read_by_uuid(Chars.CONN_PARAMS)[0]
        return PPCPInfo(data)

    def get_battery_info(self):
        """Get information about device battery. Returns a
        :class:`miband.BatteryInfo` instance. ::

          >>> info = device.get_battery_info()
          >>> info.status
          'normal'
          >>> info.level
          86
          >>> info.last_charged
          datetime.datetime(2020, 8, 11, 22, 36)
        """

        data = self.requester.read_by_uuid(Chars.BATTERY)
        return BatteryInfo(data[0])

    def get_step_info(self):
        """Get information about step count. Returns a :class:`miband.StepInfo`
        instance, which holds the number of steps, traveled length, calories
        and burnt fat.
        """
        data = self.requester.read_by_uuid(Chars.STEPS)
        return StepInfo(data[0])

    def get_activities(self, start, end):
        """Get statistics about recorded activities in a period of time.
        `start` and `end` are `datetime` objects with the starting and
        ending points of the period. Each record spans 1 minute.
        """

        records = []

        # 1. enable notifications
        self._enable_notifications(Handles.ACTIVITY_FETCH_NOTIF, True)
        self._enable_notifications(Handles.ACTIVITY_DATA_NOTIF, True)

        # 2. start retrieval
        ctime = self.get_current_time()
        ts = struct.pack("<H", start.year)
        ts += bytes([start.month, start.day, start.hour, start.minute])
        ts += struct.pack("<H", ctime.tzinfo.utcoffset(None).seconds)
        cmd = b"\x01\x01" + ts

        # 3. receive first record's timestamp, then fire the dump
        self.requester.write_cmd(Handles.ACTIVITY_FETCH, cmd)
        data = self.requester.wait_for_notification(Handles.ACTIVITY_FETCH)

        if data[:3] == Consts.MSG_ACTIVITY_FETCH_TS:
            num_records = struct.unpack("<i", data[3:7])[0]
            recv_ts = parse_date(data[7:14])
            self.log.info(f" fetch activity data ({num_records} records) from {recv_ts}")
            self.requester.write_cmd(Handles.ACTIVITY_FETCH, "\x02")

        else:
            if data[:3] == Consts.MSG_ACTIVITY_FETCH_NO_MORE:
                self.log.info(" no more activity records")
            elif data[:3] == Consts.MSG_ACTIVITY_RUNNING:
                self.log.warning(" there is an activity running, stop it first")
            else:
                self.log.warning(" unexpected data received, stopping...")
            return records

        # 4. process batch of notifications
        num_packets = num_records // 4 + (1 if num_records % 4 else 0)
        last = SimpleObj()
        last.record_id = 1
        last.record_ts = recv_ts
        last.expected_id = 0
        last.end_ts = end

        for _ in range(num_packets):
            pkg = self.requester.wait_for_notification(Handles.ACTIVITY_DATA)
            if pkg is None:
                break
            records += self._process_activity_pkg(pkg, last)

        # 5. after all records, read notification for fetching end
        data = self.requester.wait_for_notification(Handles.ACTIVITY_FETCH)
        if data[:3] != Consts.MSG_ACTIVITY_FETCH_END:
            self.log.warning(" unexpected fetch message, ignoring")

        return records

    @staticmethod
    def _process_activity_pkg(pkg, last):
        pkg_id = pkg[0]
        assert pkg_id == last.expected_id, "some package arrived in unexpected order!"
        last.expected_id += 1
        if last.expected_id > 255:
            last.expected_id = 0

        pkg = pkg[1:]
        records = []
        for i in range(len(pkg) // 4):
            data = pkg[i*4 : i*4+4]
            record = ActivityRecord(last, data)
            if record.timestamp <= last.end_ts:
                records.append(record)
            last.record_id += 1
            last.record_ts += timedelta(minutes=1)
        return records

    def get_current_heart_rate(self):
        """Return the current heart rate, measured in the moment of the call.
        It will take around 25 seconds to measure it, and the user should be still.
        Result is in bpm (beats per minute).
        """

        self.log.info(" getting heart rate, please wait (up to 30 secs.)...")

        # enable one-shot HR read
        self._enable_notifications(Handles.HEART_RATE_MEASURE_NOTIF, True)
        self.requester.write_by_handle(
            Handles.HEART_RATE_CTRL, Consts.CMD_START_HR_ONE_SHOT)

        # this device will send 3 notifications with the heart rate
        m1 = self.requester.wait_for_notification(Handles.HEART_RATE_MEASURE, timeout=30)
        m2 = self.requester.wait_for_notification(Handles.HEART_RATE_MEASURE, timeout=5)
        m3 = self.requester.wait_for_notification(Handles.HEART_RATE_MEASURE, timeout=5)

        self._enable_notifications(Handles.HEART_RATE_MEASURE_NOTIF, False)

        # return the average
        if None in (m1, m2, m3):
            self.log.warning(" no response, did you attach the band correctly?")
            return 0

        return (m1[-1] + m2[-1] + m3[-1]) // 3

    def start_hr_streaming(self):
        """Configure the Mi Band to start streaming it sensors data. It returns a
        generator object which could be iterated.
        """

        self.log.info(" starting heart rate streaming, please wait (up to 30 secs.)...")

        # enable stream HR readings
        self._enable_notifications(Handles.HEART_RATE_MEASURE_NOTIF, True)
        self.requester.write_by_handle(
            Handles.HEART_RATE_CTRL, Consts.CMD_START_HR_STREAMING)

        # return a generator that retrieves measurements
        last_ping = time()
        while True:

            # ping service to keep receiving notifications
            if time() - last_ping >= 10:
                self.requester.write_by_handle(
                    Handles.HEART_RATE_CTRL, Consts.CMD_PING_HR)
                last_ping = time()

            measure = self.requester.wait_for_notification(
                Handles.HEART_RATE_MEASURE, timeout=30)

            if measure is None:
                self.log.warning(" heart rate measure not received!")

            yield measure[1] if measure is not None else measure

    def stop_hr_streaming(self):
        """Stops the sensor data streamning."""

        self.log.info(" stopping heart rate streaming...")

        self.requester.write_by_handle(
            Handles.HEART_RATE_CTRL, Consts.CMD_STOP_HR_STREAMING)
        self._enable_notifications(Handles.HEART_RATE_MEASURE_NOTIF, False)

    def set_alert_level(self, level):
        """Set the level of alerts. `level` may be one of `silent`, `mild` or `high`.
        """

        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.alert_level.xml

        code = {
            'silent': '\x00',
            'mild':   '\x01',
            'high':   '\x02',
        }

        self.log.warning("Mi Band 4 may not support this operation (yet).")
        self.requester.write_cmd(Handles.ALERT_LEVEL, code[level])
        self.log.info(f" alert level set to {level}")

    def send_alert(self, message, type="email", count=1):
        """Sends a notification alert to the device.
        `type` could be: email, call, missed-call, sms.
        `count` is the number of alerts in the server (number of messages, etc.)
        """

        # https://www.bluetooth.com/wp-content/uploads/Sitecore-Media-Library/
        # Gatt/Xml/Characteristics/org.bluetooth.characteristic.new_alert.xml

        code = {
            "email":       1,
            "call":        3,
            "missed-call": 4,
            "sms":         5,
        }

        cmd = bytes([code[type], count])
        if "\n" in message:
            cmd += "\x0a\x0a\x0a"
        cmd += message.encode()

        self.requester.write_by_handle(Handles.NEW_ALERT, cmd)
        self.log.info(" notification sent!")


class Consts:
    """Some constants used in this library and, hopefully, some explanation.
    """

    MSG_ACTIVITY_FETCH_TS      = b"\x10\x01\x01"
    MSG_ACTIVITY_FETCH_NO_MORE = b'\x10\x02\x04'
    MSG_ACTIVITY_FETCH_END     = b'\x10\x02\x01'
    MSG_ACTIVITY_RUNNING       = b'\x10\x01\x07'
    MSG_AUTH_RANDOM_NUMBER     = b"\x10\x02\x01"

    CMD_STOP_HR_STREAMING      = b'\x15\x01\x00'
    CMD_START_HR_STREAMING     = b'\x15\x01\x01'
    CMD_STOP_HR_ONE_SHOT       = b'\x15\x02\x00'
    CMD_START_HR_ONE_SHOT      = b'\x15\x02\x01'
    CMD_PING_HR                = b'\x16'

    ACTIVITY_NAMES = {
        1: "fast walking",
        112: "rest",
        115: "rest",
    }


class Chars:
    """Mi Band characteristic UUID constants."""

    # these UUIDs are defined by the Bluetooth SGI
    DEVICE_NAME         = "00002a00-0000-1000-8000-00805f9b34fb"
    APPEARANCE          = "00002a01-0000-1000-8000-00805f9b34fb"
    CONN_PARAMS         = "00002a04-0000-1000-8000-00805f9b34fb"
    ALERT_LEVEL         = "00002a06-0000-1000-8000-00805f9b34fb"
    SYSTEM_ID           = "00002a23-0000-1000-8000-00805f9b34fb"
    SERIAL_NUMBER       = "00002a25-0000-1000-8000-00805f9b34fb"
    HW_VERSION          = "00002a27-0000-1000-8000-00805f9b34fb"
    SW_VERSION          = "00002a28-0000-1000-8000-00805f9b34fb"
    CURRENT_TIME        = "00002a2b-0000-1000-8000-00805f9b34fb"
    HEART_RATE_MEASURE  = "00002a37-0000-1000-8000-00805f9b34fb"
    HEART_RATE_CTRL     = "00002a39-0000-1000-8000-00805f9b34fb"
    ALERT_CTRL          = "00002a44-0000-1000-8000-00805f9b34fb"
    NEW_ALERT           = "00002a46-0000-1000-8000-00805f9b34fb"
    PNP_ID              = "00002a50-0000-1000-8000-00805f9b34fb"

    # these UUDs are custom, defined by Xiaomi (extracted by RE)
    SENSOR1             = "00000001-0000-3512-2118-0009af100700"
    SENSOR1_FREQ        = "00000002-0000-3512-2118-0009af100700"
    CONFIG              = "00000003-0000-3512-2118-0009af100700"
    ACTIVITY_FETCH      = "00000004-0000-3512-2118-0009af100700"
    ACTIVITY_DATA       = "00000005-0000-3512-2118-0009af100700"
    BATTERY             = "00000006-0000-3512-2118-0009af100700"
    STEPS               = "00000007-0000-3512-2118-0009af100700"
    USER_SETTINGS       = "00000008-0000-3512-2118-0009af100700"
    AUTH                = "00000009-0000-3512-2118-0009af100700"
    # UNK_09               = "0000000e-0000-3512-2118-0009af100700"
    # UNK_10               = "0000000f-0000-3512-2118-0009af100700"
    NOTIFICATIONS       = "00000010-0000-3512-2118-0009af100700"
    # UNK_11               = "00000011-0000-3512-2118-0009af100700"
    # UNK_12               = "00000012-0000-3512-2118-0009af100700"
    # UNK_13               = "00000013-0000-3512-2118-0009af100700"
    CHUNKED_TRANSFER    = "00000020-0000-3512-2118-0009af100700"
    DFU_FIRMWARE        = "00001531-0000-3512-2118-0009af100700"
    DFU_FIRMWARE_WRITE  = "00001532-0000-3512-2118-0009af100700"
    # UNK_00              = "0000fec1-0000-3512-2118-0009af100700"
    # UNK_08              = "00004a02-0000-1000-8000-00805f9b34fb"
    # UNK_04              = "0000fed0-0000-1000-8000-00805f9b34fb"
    # UNK_05              = "0000fed1-0000-1000-8000-00805f9b34fb"
    # UNK_06              = "0000fed2-0000-1000-8000-00805f9b34fb"
    # UNK_07              = "0000fed3-0000-1000-8000-00805f9b34fb"
    # UNK_01              = "0000fedd-0000-1000-8000-00805f9b34fb"
    # UNK_02              = "0000fede-0000-1000-8000-00805f9b34fb"
    # UNK_03              = "0000fedf-0000-1000-8000-00805f9b34fb"


class Handles:
    """Mi Band characteristic handle constants."""

    # NOTE: if nothing works, check that these handles have not changed!!
    #   gatttool -b TH:EM:AC:AD:DR:ES --characteristics

    NEW_ALERT                = 0x001c
    ALERT_LEVEL              = 0x0023
    HEART_RATE_MEASURE       = 0x0026
    HEART_RATE_MEASURE_NOTIF = 0x0027
    HEART_RATE_CTRL          = 0x0029
    ACTIVITY_FETCH           = 0x003b
    ACTIVITY_FETCH_NOTIF     = 0x003c
    ACTIVITY_DATA            = 0x003e
    ACTIVITY_DATA_NOTIF      = 0x003f
    AUTH                     = 0x0060
    AUTH_NOTIF               = 0x0061
    CURRENT_TIME             = 0x002c

    @classmethod
    def get_name(cls, handle):
        for k, v in cls.__dict__.items():
            if v == handle:
                return k
        return f"<unknown: {handle}>"

#
# List of Services and Chars of Mi Band 4
#
# $ gatttool -b D1:9C:BE:CE:4E:C8 --characteristics
# handle = 0x0002, char properties = 0x02, char value handle = 0x0003, uuid = 00002a00-0000-1000-8000-00805f9b34fb
# handle = 0x0004, char properties = 0x02, char value handle = 0x0005, uuid = 00002a01-0000-1000-8000-00805f9b34fb
# handle = 0x0006, char properties = 0x02, char value handle = 0x0007, uuid = 00002a04-0000-1000-8000-00805f9b34fb
# handle = 0x000a, char properties = 0x02, char value handle = 0x000b, uuid = 00002a25-0000-1000-8000-00805f9b34fb
# handle = 0x000c, char properties = 0x02, char value handle = 0x000d, uuid = 00002a27-0000-1000-8000-00805f9b34fb
# handle = 0x000e, char properties = 0x02, char value handle = 0x000f, uuid = 00002a28-0000-1000-8000-00805f9b34fb
# handle = 0x0010, char properties = 0x02, char value handle = 0x0011, uuid = 00002a23-0000-1000-8000-00805f9b34fb
# handle = 0x0012, char properties = 0x02, char value handle = 0x0013, uuid = 00002a50-0000-1000-8000-00805f9b34fb
# handle = 0x0015, char properties = 0x18, char value handle = 0x0016, uuid = 00001531-0000-3512-2118-0009af100700
# handle = 0x0018, char properties = 0x04, char value handle = 0x0019, uuid = 00001532-0000-3512-2118-0009af100700
# handle = 0x001b, char properties = 0x0a, char value handle = 0x001c, uuid = 00002a46-0000-1000-8000-00805f9b34fb
# handle = 0x001e, char properties = 0x1a, char value handle = 0x001f, uuid = 00002a44-0000-1000-8000-00805f9b34fb
# handle = 0x0022, char properties = 0x04, char value handle = 0x0023, uuid = 00002a06-0000-1000-8000-00805f9b34fb
# handle = 0x0025, char properties = 0x10, char value handle = 0x0026, uuid = 00002a37-0000-1000-8000-00805f9b34fb
# handle = 0x0028, char properties = 0x0a, char value handle = 0x0029, uuid = 00002a39-0000-1000-8000-00805f9b34fb
# handle = 0x002b, char properties = 0x1a, char value handle = 0x002c, uuid = 00002a2b-0000-1000-8000-00805f9b34fb
# handle = 0x002e, char properties = 0x14, char value handle = 0x002f, uuid = 00000001-0000-3512-2118-0009af100700
# handle = 0x0031, char properties = 0x10, char value handle = 0x0032, uuid = 00000002-0000-3512-2118-0009af100700
# handle = 0x0034, char properties = 0x14, char value handle = 0x0035, uuid = 00000003-0000-3512-2118-0009af100700
# handle = 0x0037, char properties = 0x16, char value handle = 0x0038, uuid = 00002a04-0000-1000-8000-00805f9b34fb
# handle = 0x003a, char properties = 0x14, char value handle = 0x003b, uuid = 00000004-0000-3512-2118-0009af100700
# handle = 0x003d, char properties = 0x10, char value handle = 0x003e, uuid = 00000005-0000-3512-2118-0009af100700
# handle = 0x0040, char properties = 0x12, char value handle = 0x0041, uuid = 00000006-0000-3512-2118-0009af100700
# handle = 0x0043, char properties = 0x12, char value handle = 0x0044, uuid = 00000007-0000-3512-2118-0009af100700
# handle = 0x0046, char properties = 0x18, char value handle = 0x0047, uuid = 00000008-0000-3512-2118-0009af100700
# handle = 0x0049, char properties = 0x10, char value handle = 0x004a, uuid = 00000010-0000-3512-2118-0009af100700
# handle = 0x004c, char properties = 0x16, char value handle = 0x004d, uuid = 00000020-0000-3512-2118-0009af100700
# handle = 0x004f, char properties = 0x08, char value handle = 0x0050, uuid = 0000000e-0000-3512-2118-0009af100700
# handle = 0x0052, char properties = 0x14, char value handle = 0x0053, uuid = 0000000f-0000-3512-2118-0009af100700
# handle = 0x0055, char properties = 0x16, char value handle = 0x0056, uuid = 00000011-0000-3512-2118-0009af100700
# handle = 0x0058, char properties = 0x16, char value handle = 0x0059, uuid = 00000012-0000-3512-2118-0009af100700
# handle = 0x005b, char properties = 0x1a, char value handle = 0x005c, uuid = 00000013-0000-3512-2118-0009af100700
# handle = 0x005f, char properties = 0x16, char value handle = 0x0060, uuid = 00000009-0000-3512-2118-0009af100700
# handle = 0x0062, char properties = 0x08, char value handle = 0x0063, uuid = 0000fedd-0000-1000-8000-00805f9b34fb
# handle = 0x0064, char properties = 0x02, char value handle = 0x0065, uuid = 0000fede-0000-1000-8000-00805f9b34fb
# handle = 0x0066, char properties = 0x02, char value handle = 0x0067, uuid = 0000fedf-0000-1000-8000-00805f9b34fb
# handle = 0x0068, char properties = 0x0a, char value handle = 0x0069, uuid = 0000fed0-0000-1000-8000-00805f9b34fb
# handle = 0x006a, char properties = 0x0a, char value handle = 0x006b, uuid = 0000fed1-0000-1000-8000-00805f9b34fb
# handle = 0x006c, char properties = 0x02, char value handle = 0x006d, uuid = 0000fed2-0000-1000-8000-00805f9b34fb
# handle = 0x006e, char properties = 0x0a, char value handle = 0x006f, uuid = 0000fed3-0000-1000-8000-00805f9b34fb
# handle = 0x0070, char properties = 0x1a, char value handle = 0x0071, uuid = 0000fec1-0000-3512-2118-0009af100700
# handle = 0x0074, char properties = 0x1a, char value handle = 0x0075, uuid = 00004a02-0000-1000-8000-00805f9b34fb
