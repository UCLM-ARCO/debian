# python3-miband - Xiaomi MiBand reader library (Python 3)

This is a Python 3 library which allows one to read
MiBand devices information: steps and calories record,
heart rate, battery, and more.

## Installation

```shell
$ sudo apt-get install python3-miband
```