# python3-miband - Xiaomi MiBand reader library (Python 3)

This is a Python 3 library which allows one to read
MiBand devices information: steps and calories record,
heart rate, battery, and more.

## Installation

    sudo apt-get install python3-miband


## How to get the token

For the Mi Band (version <= 7), you need to pair it first with the Zepp Life application. After that, just run the following commands and follow the given steps:

    make setup-env
    make get-keys-from-xiaomi-account

Copy the token (without the prefix `0x`) inside a file named `token` for the examples, or store it in the configuration of your application.


## Running examples

You can install the needed depends in a virtual environment, and use it for testing. To create the env, run:

    make setup-env
    source venv/bin/activate

Then, run the examples from the root folder. Also, if the device token is inside a file named `token`, it will be read from there. So, for instance, to run the example `01_connect.py`:

    export PYTHONPATH=$(pwd)
    python examples/01_connect.py
