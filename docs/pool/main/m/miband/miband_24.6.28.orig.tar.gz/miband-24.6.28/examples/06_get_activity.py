#!/usr/bin/env python3

from datetime import datetime, timedelta
from pprint import pprint
from miband import MiBandDevice

from utils import get_token, parser

# import logging
# logging.basicConfig(level=logging.DEBUG)

args = parser.parse_args()
print(f"> Connecting to {args.mac}...")
device = MiBandDevice("My Mi Band", args.mac, token=get_token())
if not device.connect():
    exit(1)

def on_progress(fetched, total):
    print(f" - {fetched} / {total}")

print("> Connected, retrieving activity data for the last 30 minutes...")
start = datetime.now() - timedelta(minutes=30)
activities = device.get_activities(start, on_progress)
pprint(activities)
