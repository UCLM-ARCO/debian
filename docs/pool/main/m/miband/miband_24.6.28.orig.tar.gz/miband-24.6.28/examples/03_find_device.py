#!/usr/bin/env python3

from utils import get_token, parser
from miband import MiBandDevice


args = parser.parse_args()
print(f"> Connecting to {args.mac}...")
device = MiBandDevice("My Mi Band", args.mac, token=get_token())
device.connect()

print("> Sending find device...")
device.find_device()
input("> Press ENTER to stop...")
device.stop_finding_device()
print("> Done!")
