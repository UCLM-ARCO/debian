import zlib
from struct import pack
from threading import Thread, Event
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from hexdump import hexdump
from PIL import Image
from io import BytesIO

from gattlib.utils import get_colour_logger


log = get_colour_logger("MiBand")


def msg_dump(header, data):
    size = f" [{len(data)} bytes] "
    hlen = len(header)
    header += " " + "-" * max(35 - hlen, 1) + size
    msg = header + "\n" + hexdump(data, result="return")
    log.debug(msg)


def aes_encrypt_data(data, key):
    aes = Cipher(algorithms.AES(key), modes.ECB())
    encryptor = aes.encryptor()
    return encryptor.update(data) + encryptor.finalize()


def aes_decrypt_data(data, key):
    aes = Cipher(algorithms.AES(key), modes.ECB())
    decryptor = aes.decryptor()
    return decryptor.update(data) + decryptor.finalize()


def get_crc32(data):
    return (zlib.crc32(data) & 0xffffffff).to_bytes(4, "little")


def png_to_tga(data, format, width, height):
    img = Image.open(BytesIO(data)).convert('RGB')
    if img.size[0] != width or img.size[1] != height:
        img = img.resize((width, height))

    tgaid = b"SOMHP" if format == "TGA_RGB565_GCNANOLITE" else b"SOMH6"
    tgaid += bytes(max(0, 46 - len(tgaid)))

    # see https://en.wikipedia.org/wiki/Truevision_TGA
    # size: 18 bytes
    header = bytes([
        len(tgaid) & 0xff,                   # id length
        0x00,                                # color map type - (0 - no color map)
        0x02,                                # image type (2 - uncompressed true-color image)
        0x00, 0x00, 0x00, 0x00, 0x00,        # color map specification (5 bytes)
        0x00, 0x00,                          # x origin
        0x00, 0x00,                          # y origin
        width & 0xff, (width >> 8) & 0xff,   # width
        height & 0xff, (height >> 8) & 0xff, # height
        16,                                  # bits per pixel (10)
        0x20,                                # image descriptor (0x20, 00100000)
    ])

    body = b""
    raw = list(img.getdata())
    for pix in raw:
        r = (pix[0] >> 3) & 0x1F
        g = (pix[1] >> 2) & 0x3F
        b = (pix[2] >> 3) & 0x1F
        body += pack('H', (r << 11) + (g << 5) + b)

    return header + tgaid + body


class IntervalTimer(Thread):
    def __init__(self, callback, period):
        super().__init__()
        self._callback = callback
        self._period = period
        self._should_stop = Event()

        self.daemon = True
        self.start()

    def stop(self):
        self._should_stop.set()

    def run(self):
        while not self._should_stop.wait(timeout=self._period):
            self._callback()


class RunOnExit:
    def __init__(self, callback=None):
        self._callbacks = []
        if callback is not None:
            self._callbacks.append(callback)

    def __iadd__(self, cb):
        assert callable(cb), "Object must be callable"
        self._callbacks.append(cb)
        return self

    def __del__(self):
        for cb in self._callbacks:
            try:
                cb()
            except Exception:
                log.warning(f" on cleaning, call to {cb} failed! (ignoring)")
