import logging
import os.path
import struct
import sys
from datetime import datetime
from traceback import format_exc

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from miband import Chars, MiBandDevice  # nopep8

from .secret import MAC, TOKEN  # nopep8
# from .gatt import PRIMARY  # nopep8


class CustomDevice(MiBandDevice):
    def set_current_time(self, dt=None):
        if dt is None:
            dt = datetime.now()

        date = struct.pack(
            'hbbbbbbbxx', dt.year, dt.month,
            dt.day, dt.hour, dt.minute,
            dt.second, dt.isoweekday(), 0)
        self.requester.write_by_uuid(Chars.CURRENT_TIME, date)
        self.log.info(" datetime set to {}".format(
            dt.strftime('%Y-%m-%d %H:%M:%S')))


if __name__ == "__main__":
    d = CustomDevice("dev", MAC, TOKEN, adapter="hci1")
    d.log.setLevel(logging.DEBUG)
    if d.connect():
        try:
            print(d.requester.get_characteristic(
                "00002a2b-0000-1000-8000-00805f9b34fb"))
            # t = d.get_current_time()
            # print(f"Current time: {t}")
            # d.set_current_time()
        except Exception:
            print(format_exc())
        finally:
            d.disconnect()
