Module.register('cognitive-tests', {
    defaults: {
        fgColor: '#ffffff',
        bgColor: '#333333',
    },

    socketNotificationReceived: function(notification, payload) {
        if (notification == 'OPEN') {
            if (payload != null)
                Logger.error("Cognitive tests failed: " + payload)
        }
    },

    getDom: function () {
        let dom = document.createElement('div')
        dom.className = 'wrapper wrapper-' +
            this.data.position.replace('_', '-')

        let button = document.createElement('button')
        button.className = 'button medium'
        button.textContent = this.translate('button-text')
        button.style = 'color: ' + this.config.fgColor +
            '; background: ' + this.config.bgColor + ';'

        var self = this
        button.onclick = function () {
            self.sendSocketNotification('OPEN', '-l ' + config.language)
        }

        dom.appendChild(button)
        return dom
    },

    getStyles: function () {
        return [
            'font-awesome.css',
            this.file('css/main.css')
        ]
    },

    getTranslations: function () {
        return {
            es: 'translations/es.json',
            en: 'translations/en.json'
        }
    },
})