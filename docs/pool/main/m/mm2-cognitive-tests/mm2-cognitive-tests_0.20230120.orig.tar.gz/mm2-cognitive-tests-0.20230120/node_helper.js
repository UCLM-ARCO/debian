const NodeHelper = require('node_helper');
const ChildProcess = require('child_process');

module.exports = NodeHelper.create({
    execAsUser: function (cmd, _default = undefined) {
        let _cmd = 'XDG_RUNTIME_DIR=/run/user/$(id -u $USER) ' + cmd;
        try {
            return ChildProcess.execSync(
                _cmd, { encoding: 'utf-8' }).trim();
        } catch (error) {
            console.error('ChildProcess.execSync error: '
                + 'command: "' + _cmd + '" ' +
                + 'error: "' + error + '"');
            if (_default !== undefined)
                return _default;
            else
                throw error;
        }
    },

    socketNotificationReceived: function (notification, argString) {
        if (notification == 'OPEN') {
            try {
                this.execAsUser('arcomirror-neurotests ' + argString);
                this.sendSocketNotification(notification, null);
            } catch (error) {
                this.sendSocketNotification(notification, error);
            }
        }
    }
});