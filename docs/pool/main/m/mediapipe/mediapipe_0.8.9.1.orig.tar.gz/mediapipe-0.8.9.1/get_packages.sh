#!/usr/bin/env bash

ROOT_PATH="$(realpath $(dirname $0))"
VERSION="0.8.9.1"
SUPPORTED="10 9 8"

for PYTHON3_MIN_VERSION in $SUPPORTED; do
    docker build -t mediapipe-cp$PYTHON3_MIN_VERSION:$VERSION \
        --platform linux/amd64 \
        --build-arg PYTHON3_MIN_VERSION=$PYTHON3_MIN_VERSION \
        --build-arg MEDIAPIPE_VERSION=$VERSION $ROOT_PATH
done
docker image prune -f

for PYTHON3_MIN_VERSION in $SUPPORTED; do
    docker run -it --rm \
        -v $ROOT_PATH/packages:/packages \
        -e PYTHON3_MIN_VERSION=$PYTHON3_MIN_VERSION \
        mediapipe-cp$PYTHON3_MIN_VERSION:$VERSION
done

sudo chown -R $USER:$USER packages