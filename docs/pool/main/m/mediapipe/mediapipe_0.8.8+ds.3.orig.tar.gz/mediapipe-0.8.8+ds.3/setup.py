import re
from functools import lru_cache

from setuptools import setup, find_packages

CHANGELOG_PATH = 'debian/changelog'
CONTROL_PATH = 'debian/control'


@lru_cache(1)
def get_version():
    try:
        with open(CHANGELOG_PATH) as fr:
            retval = re.split(r'[\(\+\-]', fr.readline())[1]
    except Exception:
        retval = '-1'
    finally:
        return retval


@lru_cache(1)
def get_name():
    try:
        with open(CHANGELOG_PATH) as fr:
            retval = fr.readline().split(" ")[0]
    except Exception:
        retval = '-1'
    finally:
        return retval


@lru_cache(1)
def get_short_description():
    try:
        with open(CONTROL_PATH) as fr:
            match = re.search(r'Description:(.*)\n', fr.read())
            if not match:
                retval = '-1'
            else:
                retval = match.group(1).strip()
    except Exception:
        retval = '-1'
    finally:
        return retval


@lru_cache(1)
def get_long_description():
    try:
        with open(CONTROL_PATH) as fr:
            match = re.search(r'Description:.*\n(.*)$', fr.read())
            if not match:
                retval = '-1'
            else:
                retval = match.group(1).strip()
    except Exception:
        retval = '-1'
    finally:
        return retval


@lru_cache(1)
def get_author():
    try:
        with open(CONTROL_PATH) as fr:
            match = re.search(r'Maintainer:(.*)<', fr.read())
            if not match:
                retval = '-1'
            else:
                retval = match.group(1).strip()
    except Exception:
        retval = '-1'
    finally:
        return retval


@lru_cache(1)
def get_author_email():
    try:
        with open(CONTROL_PATH) as fr:
            match = re.search(r'Maintainer:.*<(.*)>', fr.read())
            if not match:
                retval = '-1'
            else:
                retval = match.group(1).strip()
    except Exception:
        retval = '-1'
    finally:
        return retval


setup(
    name=get_name(),
    version=get_version(),
    description=get_short_description(),
    long_description=get_long_description(),
    author=get_author(),
    author_email=get_author_email(),
    packages=find_packages(),
    package_data={
        '': ['*.so']
    },
    include_package_data=True
)
