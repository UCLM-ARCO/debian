from functools import partial, wraps
from queue import Queue
from threading import Thread
from time import sleep, time
from typing import Any

from .device import MiBandDevice
from .log import LogMixin


def update_task_ts(fn):
    @wraps(fn)
    def _deco(self, *args, **kwargs):
        self._running = True
        ret = fn(self, *args, **kwargs)
        self._last_ts = time()
        self._running = False
        self._queued = False
        return ret
    return _deco


class Task(LogMixin):
    def __init__(self, name: str = None,
                 level: int = 0,
                 use_stdout: bool = True,
                 use_syslog: bool = False,
                 use_filelog: bool = False) -> None:
        super().__init__(name=name,
                         level=level,
                         use_stdout=use_stdout,
                         use_syslog=use_syslog,
                         use_filelog=use_filelog)
        self._running = False
        self._queued = False
        self._last_ts = None

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def is_queued(self) -> bool:
        return self._queued

    def shall_run(self, timeout: int) -> bool:
        if self.is_running or self.is_queued:
            return False
        elif self._last_ts is None:
            return True
        return (time() - self._last_ts > timeout)

    def run(self) -> int:
        raise NotImplemented

    def enqueue(self):
        self._queued = True

    @staticmethod
    def create(obj: object,
               method_name: str,
               level: int = 0,
               use_stdout: bool = True,
               use_syslog: bool = False,
               use_filelog: bool = False,
               *args, **kwargs) -> Any:
        ret = Task(name=f'Task_{obj.name}_{method_name}',
                   level=level,
                   use_stdout=use_stdout,
                   use_syslog=use_syslog,
                   use_filelog=use_filelog)
        ret.run = partial(getattr(obj, method_name),
                          *args, **kwargs)
        return ret


class DeviceMultiTask(Task):
    def __init__(self, device: MiBandDevice,
                 level: int = 0,
                 use_stdout: bool = True,
                 use_syslog: bool = False,
                 use_filelog: bool = False) -> None:
        super().__init__(
            name='{}_{}'.format(self.__class__.__name__,
                                device.name),
            level=level,
            use_stdout=use_stdout,
            use_syslog=use_syslog,
            use_filelog=use_filelog)
        self._d = device
        self._subtasks = Queue()
        for item in self._d.to_update():
            t = Task.create(self._d, f'update_{item}',
                            level=self.level,
                            use_stdout=self.use_stdout,
                            use_syslog=self.use_syslog,
                            use_filelog=self.use_filelog)
            t.log.disabled = True  # prevent propagation
            self._subtasks.put(t)

    def is_empty(self) -> bool:
        return self._subtasks.empty()

    @update_task_ts
    def run(self) -> int:
        try:
            self._d.connect()
        except Exception as err:
            self.log.error(f'Connection error: {err}')
            return -1

        while not self._subtasks.empty():
            if not self._d.is_ready():
                break
            t = self._subtasks.get()
            self.log.info(f'Running subtask {t.name}.')
            try:
                code = t.run()
                if code != 0:
                    self.log.error(
                        f'Task {t.name} failed with' +
                        f' code {code}.')
            except Exception as err:
                self.log.error(
                    'Task {} failed: ({}) {}.'.format(
                        t.name, type(err).__name__, err))

        self._d.disconnect()
        return 0


class TaskRunner(Thread, LogMixin):
    def __init__(self, level: int = 0,
                 use_stdout: bool = True,
                 use_syslog: bool = False,
                 use_filelog: bool = False) -> None:
        Thread.__init__(self, name=self.__class__.__name__, daemon=True)
        LogMixin.__init__(self, level=level,
                          use_stdout=use_stdout,
                          use_syslog=use_syslog,
                          use_filelog=use_filelog)
        self.tasks = Queue()
        self.queued = []

    def add_task(self, t: Task) -> None:
        if t.name in self.queued:
            return
        self.tasks.put(t)
        self.queued.append(t.name)
        self.log.debug(f'Added new task {self.queued[-1]}.')

    def run(self) -> None:
        while True:
            try:
                t = self.tasks.get(block=True)
                self.log.info(f'Running task {t.log.name}.')
                code = t.run()
                if code != 0:
                    self.log.error(
                        f'Task {t.name} failed with code {code}.')
            except Exception as err:
                self.log.error(
                    f'Task {t.name} failed: ({type(err).__name__}) {err}.')
            finally:
                self.queued.remove(t.name)
                sleep(15)  # 15 seconds for restoring Bluetooth socket
