import socket
import struct

BIND_ADDR = ('localhost', 8465)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    try:
        s.bind(BIND_ADDR)
        s.listen(1)
        while True:
            print('Listening...')
            conn, addr = s.accept()
            with conn:
                print(f'Connected by {addr}')
                pkg = bytes()
                while True:
                    data = conn.recv(1024)
                    if not data: break
                    pkg += data
                n = struct.unpack('<i', pkg[:4])[0]
                print(struct.unpack('<i' + '6s?' * n, pkg))
    except KeyboardInterrupt:
        print('Closing...')