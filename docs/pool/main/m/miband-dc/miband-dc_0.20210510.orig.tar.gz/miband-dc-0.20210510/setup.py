from setuptools import find_packages, setup

with open("README.md", "r") as fh:
    long_description = fh.read()


def get_version():
    with open('debian/changelog') as chlog:
        return chlog.readline().split("(")[1].split("-")[0]


setup(
    name='miband-dc',
    packages=find_packages(),
    version=get_version(),
    description='Python script to collect data from Xiaomi activity bands.',
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Oscar Acena Herrera",
    author_email="oscaracena@gmail.com",
    license='Apache-2.0',
    install_requires=[
        'miband',
        'peewee',
        'psycopg2',
        'pytimeparse',
        'requests'],
    # setup_requires=[],
    scripts=['miband-dc'],
    # package_data={'miband-dc': ['README.md']},
    data_files=[
        ('miband-dc', ['devices.csv', 'settings.json'])
    ],
)
