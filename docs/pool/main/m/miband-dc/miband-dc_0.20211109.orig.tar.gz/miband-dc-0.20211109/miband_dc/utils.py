import json
import logging
import time


class Settings:
    def __init__(self, filename="settings.json"):
        self.path = filename
        self.config = {}
        try:
            with open(self.path, "r") as src:
                self.config = json.loads(src.read())
        except OSError:
            pass

    def __setitem__(self, k, v):
        self.config[k] = v

    def __getitem__(self, k):
        return self.config.get(k)

    def save(self):
        with open(self.path, "w") as dst:
            dst.write(json.dumps(self.config))


class LogMixin:
    name = "<unknown>"
    log_level = logging.DEBUG

    def __init__(self):
        self.log = logging.getLogger(self.name)
        self.log.setLevel(self.log_level)


class BooleanContext:
    def __init__(self):
        self._b = False

    def __enter__(self):
        self._b = True

    def __exit__(self, *args):
        self._b = False

    def __bool__(self):
        return self._b


class Task(LogMixin):
    def __init__(self):
        super().__init__()
        self.is_running = BooleanContext()
        self.last_run = 0

    @staticmethod
    def update_ts(fn):
        def _deco(self, *args, **kwargs):
            with self.is_running:
                retval = fn(self, *args, **kwargs)
                self.last_run = time.time()
                return retval
        return _deco

    def run(self):
        raise NotImplementedError

    def __repr__(self):
        return f"<Task: {self.name}>"
