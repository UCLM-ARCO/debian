import sqlite3
from datetime import datetime
from uuid import getnode as get_host_mac

import peewee
import pkg_resources

psql_db = peewee.PostgresqlDatabase(None, autorollback=True)


class MiBandRecord(peewee.Model):
    class Meta:
        database = psql_db

    mac = peewee.CharField(unique=True)
    last_activity_ts = peewee.DateTimeField(null=True)
    last_battery_ts = peewee.DateTimeField(null=True)
    last_heart_rate_ts = peewee.DateTimeField(null=True)
    last_steps_ts = peewee.DateTimeField(null=True)
    ts_drift = peewee.IntegerField(default=0)


class MiBandStaticInfo(peewee.Model):
    class Meta:
        database = psql_db

    dev = peewee.ForeignKeyField(MiBandRecord)

    name = peewee.CharField()
    sw_version = peewee.CharField()
    hw_version = peewee.CharField()
    serial_number = peewee.CharField()
    appearance = peewee.CharField()
    system_id = peewee.CharField()
    pnp_id = peewee.CharField()
    pcon_params = peewee.CharField()

    def __repr__(self):
        return f'<MiBandStaticInfo, mac: {self.dev.mac}>'


class ActivityRecord(peewee.Model):
    class Meta:
        database = psql_db
        indexes = (
            (('dev', 'ts'), True),  # avoid duplicated records
        )

    dev = peewee.ForeignKeyField(MiBandRecord)
    ts = peewee.DateTimeField()

    category = peewee.SmallIntegerField()
    intensity = peewee.SmallIntegerField()
    steps = peewee.SmallIntegerField()
    heart_rate = peewee.SmallIntegerField()


class BatteryInfoRecord(peewee.Model):
    BAT_NORMAL = 0
    BAT_CHARGING = 1

    class Meta:
        database = psql_db

    dev = peewee.ForeignKeyField(MiBandRecord)
    ts = peewee.DateTimeField()
    level = peewee.SmallIntegerField()
    status = peewee.SmallIntegerField(choices=(
        (BAT_NORMAL, 'normal'),
        (BAT_CHARGING, 'charging'),
    ))


class StepRecord(peewee.Model):
    class Meta:
        database = psql_db

    dev = peewee.ForeignKeyField(MiBandRecord)
    ts = peewee.DateTimeField()

    steps = peewee.IntegerField()
    meters = peewee.IntegerField()
    calories = peewee.IntegerField()


class HeartRateRecord(peewee.Model):
    class Meta:
        database = psql_db

    dev = peewee.ForeignKeyField(MiBandRecord)
    ts = peewee.DateTimeField()
    bpm = peewee.SmallIntegerField()


class NotificationRecord(peewee.Model):
    class Meta:
        database = psql_db
        indexes = (
            (('id', 'sender'), True),
        )

    id = peewee.TextField(primary_key=True)
    type = peewee.TextField(choices=['update_state'], null=False)
    last_ts = peewee.DateTimeField(null=True)
    sender = peewee.TextField(default=get_host_mac(), null=False)


class SubscriberRecord(peewee.Model):
    class Meta:
        database = psql_db
        indexes = (
            (('address', 'notification'), True),
        )

    address = peewee.TextField(null=False)
    notification = peewee.ForeignKeyField(
        NotificationRecord, on_delete='CASCADE')
    type = peewee.TextField(null=False, choices=['tcp', 'email'])
    active = peewee.BooleanField(default=True)
