# miband-dc - MiBand data collector

This is a Python 3 script (and system service) which
collects data from Xiaomi MiBand4, previously configured,
and stores it on a provided postgresql database.

## Installation

```shell
$ sudo apt-get install miband-dc
```

## Configuration

### Settings file (`settings.json`)

It is stored at `/etc/miband-dc`, and holds all settings that affects `miband-dc`. Every time you modify this file, restart `miband-dc` service to reload the settings.

Available configurarion parameters:

1. Database connection:

   a. (required) `db_name`: PostgreSQL database name (must exist before `miband-dc` is runned).   
   b. (required) `db_user`: OWNER of database (must exist before `miband-dc` is runned).   
   c. (required) `db_password`: Password for `db_user`.   
   d. (required) `db_host`: Host which holds the database.   
   e. (required) `db_port`: Port of `db_host` to connect to PostgreSQL.   

2. Tasks timeout:

   a. `discovery_timeout`: `Discovery` task must execute after elapsed specified time, in seconds. Default is 60.   
   b. `activity_timeout`: `Activity` and `Steps` task must execute after elapsed specified time, in seconds. Default is 3600 (1 hour).   
   a. `battery_timeout`: `Battery` task must execute after elapsed specified time, in seconds. Default is 900 (15 minutes).   
   a. `heart_rate_timeout`: `Heart Rate` task must execute after elapsed specified time, in seconds. Default is 300 (5 minutes).  

3. Notifications (see Hooks section):

   a. `notify_update_state`: List containing `host:port` addresses to send device update status.    
   b. `notify_update_state_timeout`: `Notification Update State` must execute after elapsed specified time, specified as time expression. Default is '60s'.   
   c. `notify_update_state_timerange`: A device stored information will be considered outdated after this time, specified as time expression. Default is '1d'.   

4. `update_mode`: Change `miband-dc` behaviour. Available choices are:

   a. `always`: Update devices information always, if can. This means that `miband-dc` will try to get all information for every online device every time it can.   
   b. `charging`: Only update devices information when they are charging. This mode pretends to simulate a `updating station`, where users leave their devices charging while data is being stored, resulting in a less aggressive communication. In this mode, `Heart Rate` tasks won´t be executed, as the user won´t wear the device, thus making imposible to read heart rate information.   

### Devices file (`devices.csv`)

It is stored at `/etc/miband-dc`, and holds all the devices from `miband-dc` will collect information. Every time you modify this file, restart `miband-dc` service to reload the configured devices.

There is a line for each device, and follows the pattern: `id | mac | token`.

Visit [this post](https://arcogroup.bitbucket.io/shapes/integrating_miband_with_smart_mirror/#devices) to know more about configuring MiBand devices for miband-dc.

## Usage

Stop the service and modify configuration files. When finished, restart the program:

```shell
$ sudo systemctl stop miband-dc.service
[... Modify configuration files ...]
$ sudo systemctl restart miband-dc.service
```

This will start the daemon and collect the data from the devices 
in the `devices.csv` file.

Each time you change the configuration file, execute:
```shell
$ sudo systemctl restart miband-dc.service
```

## Hooks

`miband-dc` stores all data collected in a PostgreSQL database, but it can also notify other running processes about extracted information from that collected data, in real time.

This is done by TCP socket connections. `miband-dc` tries to connect to specified addresses in its settings and sends this information.

For example, a program wants to know which devices need to be updated. Maybe that devices are far from the RPi or they battery run off, so their data could not be collected. If that program is listening in the port 8888, we have to add the following line to the `settings.json`:

```json
"notify_update_state": "localhost:8888"
```

Information sended is:

- `notify_update_state`:

   **number_of_devices** (4B) +  [ **MAC** (6B) + **updated** (1B) ] * **number_of_devices**

   Where **MAC** is an hex number representing the device address, and **updated** is a boolean (1 when updated and 0 when not).