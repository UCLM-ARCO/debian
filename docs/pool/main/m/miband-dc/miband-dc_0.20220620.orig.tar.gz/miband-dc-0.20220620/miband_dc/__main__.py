import os.path
import sys
from argparse import ArgumentParser
from os import environ, getuid

from miband_dc import MiBandCollector


def file_type(x: str, ext: str = None) -> str:
    """Return x if it is a file and exists. Otherwise, raise an error."""
    if not os.path.exists(x):
        raise ValueError
    elif not os.path.isfile(x):
        raise ValueError
    if ext != None:
        x_ext = os.path.splitext(os.path.basename(x))[1]
        if x_ext.lower() != '.' + ext.lower():
            raise ValueError
    return x


def json_type(x: str) -> str:
    """Return x if it is a JSON file and exists. Otherwise, raise an error."""
    return file_type(x, 'json')


def csv_type(x: str) -> str:
    """Return x if it is a CSV file and exists. Otherwise, raise an error."""
    return file_type(x, 'csv')


def pem_type(x: str) -> str:
    """Return x if it is a PEM file and exists. Otherwise, raise an error."""
    return file_type(x, 'pem')


if __name__ == '__main__':
    if getuid() != 0:
        print('CRITICAL: User is not root.')
        sys.exit(-1)

    parser = ArgumentParser('miband-dc')
    parser.add_argument(
        '-d', '--devices', dest='devices_path',
        default='devices.csv', type=csv_type,
        help='CSV file (using | as separator) with ' +
        'the list of managed devices. Defaults to "devices.csv".')
    parser.add_argument(
        '-c', '--config', dest='config_path',
        default='settings.json', type=json_type,
        help='Configuration JSON file. Defaults to "settings.json".')

    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument(
        '-v', '--verbose', action='count',
        dest='log_level', default=0,
        help='Increase output verbosity.')
    verbosity.add_argument(
        '-q', '--quiet', action='store_const',
        dest='log_level', const=-1,
        help='Silence output.')

    parser.add_argument(
        '-V', '--vault-key', default='miband-dc.pem',
        dest='app_key_path', type=pem_type,
        help='Application key path (PEM file). Defaults to "miband-dc.pem".')

    try:
        sys.exit(MiBandCollector(
            **vars(parser.parse_args()),
            use_syslog=environ.get('MIBAND_DC_USE_SYSLOG', '0') == '1',
            use_filelog=environ.get('MIBAND_DC_USE_FILELOG', '0') == '1'
        ).run())
    except Exception as err:
        print(f'CRITICAL Could not create collector: {err}')
        sys.exit(-1)
