from datetime import timezone

import peewee

DATABASE = peewee.PostgresqlDatabase(
    None, autorollback=True)


class DateTimeWithTZField(peewee.DateTimeField):
    field_type = 'TIMESTAMP WITH TIME ZONE'
    formats = peewee.DateTimeField.formats + [
        '%Y-%m-%d %H:%M:%S.%f%z',
        '%Y-%m-%d %H:%M:%S%z'
    ]

    @property
    def tzinfo(self):
        return DATABASE.extract_date('timezone', self)


class MiBandRecord(peewee.Model):
    class Meta:
        database = DATABASE

    mac = peewee.CharField(unique=True)
    last_activity_ts = DateTimeWithTZField(null=True)
    last_battery_ts = DateTimeWithTZField(null=True)
    last_heart_rate_ts = DateTimeWithTZField(null=True)
    last_steps_ts = DateTimeWithTZField(null=True)
    last_time_check_ts = DateTimeWithTZField(null=True)
    ts_drift = peewee.IntegerField(default=0)


class MiBandStaticInfo(peewee.Model):
    class Meta:
        database = DATABASE

    dev = peewee.ForeignKeyField(
        MiBandRecord, on_delete='CASCADE')
    name = peewee.CharField()
    sw_version = peewee.CharField()
    hw_version = peewee.CharField()
    serial_number = peewee.CharField()
    appearance = peewee.CharField()
    system_id = peewee.CharField()
    pnp_id = peewee.CharField()
    pcon_params = peewee.CharField()


class ActivityRecord(peewee.Model):
    class Meta:
        database = DATABASE
        # avoid duplicated records
        indexes = ((('dev', 'ts'), True), )

    dev = peewee.ForeignKeyField(
        MiBandRecord, on_delete='CASCADE')
    ts = DateTimeWithTZField(null=False)
    category = peewee.SmallIntegerField()
    intensity = peewee.SmallIntegerField()
    steps = peewee.SmallIntegerField()
    heart_rate = peewee.SmallIntegerField()


class BatteryInfoRecord(peewee.Model):
    class Meta:
        database = DATABASE

    dev = peewee.ForeignKeyField(
        MiBandRecord, on_delete='CASCADE')
    ts = DateTimeWithTZField(null=False)
    level = peewee.SmallIntegerField()
    status = peewee.SmallIntegerField(choices=(
        (0, 'normal'),
        (1, 'charging'),
    ))


class StepRecord(peewee.Model):
    class Meta:
        database = DATABASE

    dev = peewee.ForeignKeyField(
        MiBandRecord, on_delete='CASCADE')
    ts = DateTimeWithTZField(null=False)
    steps = peewee.IntegerField()
    meters = peewee.IntegerField()
    calories = peewee.IntegerField()


class HeartRateRecord(peewee.Model):
    class Meta:
        database = DATABASE

    dev = peewee.ForeignKeyField(
        MiBandRecord, on_delete='CASCADE')
    ts = DateTimeWithTZField(null=False)
    bpm = peewee.SmallIntegerField()


class NotificationRecord(peewee.Model):
    class Meta:
        database = DATABASE
        indexes = (
            (('id', 'sender'), True),
        )

    id = peewee.TextField(primary_key=True)
    type = peewee.TextField(choices=['update_state'], null=False)
    last_ts = DateTimeWithTZField(null=True)
    sender = peewee.TextField(null=False)


class SubscriberRecord(peewee.Model):
    class Meta:
        database = DATABASE
        indexes = ((('address', 'notification'), True), )

    address = peewee.TextField(null=False)
    notification = peewee.ForeignKeyField(
        NotificationRecord, on_delete='CASCADE')
    type = peewee.TextField(null=False, choices=['tcp', 'email'])
    active = peewee.BooleanField(default=True)


def init_db(**psql_params) -> bool:
    ret = True
    DATABASE.init(**psql_params)
    try:
        DATABASE.connect(reuse_if_open=True)
        DATABASE.create_tables([MiBandRecord,
                                MiBandStaticInfo,
                                ActivityRecord,
                                BatteryInfoRecord,
                                StepRecord,
                                HeartRateRecord,
                                NotificationRecord,
                                SubscriberRecord])
        DATABASE.set_time_zone(timezone=timezone.utc)
    except peewee.OperationalError:
        ret = False
    finally:
        return ret
