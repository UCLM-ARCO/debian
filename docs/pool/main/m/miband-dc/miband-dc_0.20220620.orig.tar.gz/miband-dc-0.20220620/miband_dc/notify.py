from datetime import datetime
import re
import smtplib
import socket
import struct
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from time import timezone
from uuid import getnode as get_host_mac

from Crypto.Cipher import PKCS1_v1_5

from .db import NotificationRecord, SubscriberRecord
from .task import Task, update_task_ts

SENDER_ID = get_host_mac()


class NotifyTask(Task):
    """Task which notifies a list of subscribers about some topic.

    To extend this class, the methods `_generate_package` and 
    `_generate_text` must be implemented.
    """

    def __init__(self, _id: str,
                 _type: str,
                 secret_key,
                 subscribers: list = [],
                 timeout: int = 3600,
                 level: int = 0,
                 use_stdout: bool = True,
                 use_syslog: bool = False,
                 use_filelog: bool = False) -> None:
        """Create a NotifyTask object.

        :param str _id: Notification id. Must be the always the same. 
        :param str _type: Notification type.
        :param Any secret_key: Application RSA key. Needed for sending emails.
        :param list subscribers: Subscribers addresses. `host:port` (TCP notify) or `email` (Email notify).
        :param int timeout: Notification timeout (seconds), defaults to 3600
        :param int level: _description_, defaults to 0
        :param bool use_stdout: _description_, defaults to True
        :param bool use_syslog: _description_, defaults to False
        """
        super().__init__(name=f'{self.__class__.__name__}_{_id}',
                         level=level,
                         use_stdout=use_stdout,
                         use_syslog=use_syslog,
                         use_filelog=use_filelog,
                         secret_key=secret_key)
        self._type = _type
        self._timeout = timeout
        self._id = _id  # generated in by Configuration

        # Database records
        self._record, created = NotificationRecord.get_or_create(
            id=self._id, type=self._type, sender=SENDER_ID)
        if created:
            self._record.save()
        self._last_ts = self._record.last_ts.timestamp()

        # Delete all subscribers in db for having clean subs
        SubscriberRecord.delete().where(
            SubscriberRecord.notification == self._id).execute()

        # Add subscribers
        for sub in subscribers:
            self._add_sub(sub)
        # TODO Raise error if no subscribers

    def _generate_package(self) -> bytes:
        raise NotImplemented

    def _generate_text(self) -> str:
        raise NotImplemented

    def _run_tcp(self) -> int:
        cnt = 0
        pkg = self._generate_package()

        for sub in SubscriberRecord.select().where(
                SubscriberRecord.notification == self._id,
                SubscriberRecord.type == 'tcp'):
            host, port = sub.address.split(':')
            s = socket.socket(socket.AF_INET,
                              socket.SOCK_STREAM)
            try:
                s.connect((host, int(port)))
                s.sendall(pkg)
            except socket.timeout:
                self.log.warning(f'Timeout notifying {sub.address}.')
            except socket.error as err:
                self.log.error(
                    f'Unreachable subscriber {sub.address}. Disabling.' +
                    f'More info: {err}')
                if sub.active:
                    sub.active = False
                    sub.save()
            except Exception as err:
                self.log.error(
                    f'Unknown error on notify TCP: {err}.')
                if sub.active:
                    sub.active = False
                    sub.save()
            else:
                cnt += 1
                if not sub.active:
                    sub.active = True
                    sub.save()
            finally:
                s.close()
        return cnt

    def _run_email(self) -> int:
        return 0  # TODO

    def shall_run(self) -> bool:
        return super().shall_run(self._timeout)

    def _add_sub(self, sub: str) -> bool:
        """Add notification subscriber.

        :param str sub: Subscriber addresses. `host:port` (TCP notify) or `email` (Email notify).
        :return bool: Operation success.
        """
        retval = False
        for _type, regex in [  # TODO ('email', r'\S*@\S*\.\S*'),
                ('tcp', r'\S*:\d*')]:
            match = re.search(regex, sub)
            if not match:
                continue
            record, created = SubscriberRecord.get_or_create(
                address=sub, notification=self._id, type=_type)
            if created:
                record.save()
            retval = True
            break
        if not retval:
            self.log.warning(
                f'Skipping notification sub {sub}. Unknown format.')
        return retval

    @update_task_ts
    def run(self) -> int:
        self.log.debug(f'Start notification {self._id}')
        sub_cnt = self._run_tcp()
        sub_cnt += self._run_email()
        if sub_cnt > 0:  # Update last_ts on db
            self._record.last_ts = datetime.now(timezone.utc)
            self._record.save()
        self.log.info(f'Notified {sub_cnt} subscribers.')
        self.log.debug(f'End notification {self._id}')
        return 0


class NotifyUpdateStateTask(NotifyTask):
    def __init__(self, _id: str,
                 secret_key,
                 devices: dict,
                 subscribers: list = [],
                 timeout: int = 3600,
                 level: int = 0,
                 use_stdout: bool = True,
                 use_syslog: bool = False) -> None:
        """Create a NotifyTask object.

        :param str _id: Notification id. Must be the always the same. 
        :param Any secret_key: Application RSA key. Needed for sending emails.
        :param dict devices: Collector MiBand devices.
        :param list subscribers: Subscribers addresses. `host:port` (TCP notify) or `email` (Email notify).
        :param int timeout: Notification timeout (seconds), defaults to 3600
        :param int level: _description_, defaults to 0
        :param bool use_stdout: _description_, defaults to True
        :param bool use_syslog: _description_, defaults to False
        """
        super().__init__(_id, 'update_state', secret_key,
                         subscribers, timeout, level,
                         use_stdout, use_syslog)
        self._devices = devices

    def _generate_package(self) -> bytes:
        data = []
        for mac, d in self._devices.items():
            data.append(bytes.fromhex(mac.replace(':', '')))
            data.append(len(d.to_update()) > 0)
        n = int(len(data) / 2)
        if n == 0:
            return b''
        return struct.pack('<i' + '6s?' * n, n, *data)

    def _generate_text(self) -> str:
        txt = [['MAC address', 'Is fully updated?']]
        for mac, d in self._devices.items():
            txt.append([mac, 'No' if len(d.to_update()) > 0 else 'Yes'])
        return '\n'.join(['\t'.join([c for c in r]) for r in txt])
