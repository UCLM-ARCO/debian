from datetime import datetime, timedelta, timezone
from os import strerror
from time import sleep, time

from gattlib import BTIOException
from miband import MiBand4

from .db import *


class MiBandDevice:
    # MiBand4 device status
    STATUS_INVALID = 'invalid'
    STATUS_ONLINE = 'online'

    # Update mode for device
    UPDATE_MODE_ALL = 'all'
    UPDATE_MODE_CHARGING = 'charging'

    def __init__(self, mac: str,
                 token: bytes,
                 update_mode: str = 'all',
                 activity_timeout: int = 60 * 60,
                 battery_timeout: int = 15 * 60,
                 heart_rate_timeout: int = 10 * 60,
                 time_check_timeout: int = 60 * 60 * 24) -> None:
        """Create a MiBand device object.

        :param str mac: MiBand4 MAC address
        :param bytes token: MiBand4 authentication token
        :param str update_mode: MiBand4 update mode, choices are ['all', 'charging'], defaults to 'all'
        :param int activity_timeout: Seconds to wait to perform an activity update, defaults to 60*60
        :param int battery_timeout: Seconds to wait to perform a battery update, defaults to 15*60
        :param int heart_rate_timeout: Seconds to wait to perform a heart rate update, defaults to 10*60
        :param int time_check_timeout: Seconds to wait to perform a time check update, defaults to 60*60*24
        """
        self._dev = MiBand4(mac, mac, token)
        self.status = self.STATUS_ONLINE
        self.is_charging = False
        self.update_mode = update_mode
        self.activity_timeout = activity_timeout
        self.battery_timeout = battery_timeout
        self.heart_rate_timeout = heart_rate_timeout
        self.time_check_timeout = time_check_timeout
        self._invalid_time_epoch = 0  # last state change to invalid
        self._connect_time_epoch = 0  # last connection attempt

        # Load database record
        self._record, created = MiBandRecord.get_or_create(mac=mac)
        if created:
            self._record.save()
        self._record_static = MiBandStaticInfo.get_or_none(
            dev=self._record)
        self.name = f'band_{self._record.id}'

    def connect(self) -> None:
        """Connect to device. Raise an exception on any error."""
        if self._dev.requester:
            if self._dev.is_connected():
                return
        elif time() - self._connect_time_epoch <= 5:
            # Wait at least 5 seconds before reconnect
            raise BTIOException('Too soon to connect.')
        elif not self.is_ready():
            raise BTIOException('Device is in invalid state.')

        err = None
        try:
            if not self._dev.connect():
                err = BTIOException('Unable to connect.')
            else:
                self.status = self.STATUS_ONLINE
        except Exception as _err:
            errnum = self._dev.requester.err_code
            if errnum != 0:  # on_connection_failed was fired
                # raise Exception with errnum description
                err = Exception(f'{strerror(errnum)} ({errnum})')
            else:
                err = _err
        finally:
            self._connect_time_epoch = time()

        if err is not None:
            self.status = self.STATUS_INVALID
            self._invalid_time_epoch = time()
            raise err

    def disconnect(self, nowait: bool = False) -> None:
        """Disconnect from device.

        :param bool nowait: Do not wait to bluetooth socket to restore itself, defaults to False
        """
        if self._dev.requester:
            self._dev.disconnect()
            # Give bluetooth some time to recover from opening socket
            if not nowait:
                sleep(5)

    def is_ready(self) -> bool:
        """Return whether the device is ready for connecting."""
        # If invalid, wait at least 5 minutes before reconnect
        return any((self.status != self.STATUS_INVALID,
                    self.status == self.STATUS_INVALID and time() -
                    self._invalid_time_epoch > 300))

    def to_update(self) -> list:
        """Return a list items that need updating."""
        retval = []
        if not self.is_ready():  # invalid device
            return retval

        now_utc = datetime.now(tz=timezone.utc)

        # battery
        if self._record.last_battery_ts is None:
            retval.append('battery')
        elif (now_utc - self._record.last_battery_ts) > timedelta(
                seconds=self.battery_timeout):
            retval.append('battery')

        # check-time
        if self._record.last_time_check_ts is None:
            retval.append('time_check')
        elif (now_utc - self._record.last_time_check_ts) > timedelta(
                seconds=self.time_check_timeout):
            retval.append('time_check')

        if all((self.update_mode == self.UPDATE_MODE_CHARGING,
                not self.is_charging)):
            return retval

        if self._record_static is None:  # static
            retval.append('static')

        # activity
        if self._record.last_activity_ts is None:
            retval.append('activity')
        elif (now_utc - self._record.last_activity_ts) > timedelta(
                seconds=self.activity_timeout):
            retval.append('activity')

        # steps
        if self._record.last_steps_ts is None:
            retval.append('steps')
        elif (now_utc - self._record.last_steps_ts) > timedelta(
                seconds=self.activity_timeout):
            retval.append('steps')

        # heart-rate
        if self.update_mode != 'charging':
            if self._record.last_heart_rate_ts is None:
                retval.append('heart_rate')
            elif (now_utc - self._record.last_heart_rate_ts) > timedelta(
                    seconds=self.heart_rate_timeout):
                retval.append('heart_rate')

        return retval

    @DATABASE.atomic()
    def update_static(self) -> int:
        """Update static record on database from device data. Raise an exception on any error."""
        err = None

        # STAGE 1: Fetch
        try:
            if not self._dev.is_connected():
                return -1

            r = MiBandStaticInfo(
                dev=self._record,
                mac=self._dev.mac,
                name=self._dev.given_name,
                sw_version=self._dev.get_sw_version(),
                hw_version=self._dev.get_hw_version(),
                serial_number=self._dev.get_serial_number(),
                appearance=self._dev.get_appearance(),
                system_id=self._dev.get_system_id(),
                pnp_id=self._dev.get_pnp_info(),
                pcon_params=str(
                    self._dev.get_preferred_conn_params().to_dict()),
            )
        except Exception as _err:
            err = _err
            self.status = self.STATUS_INVALID
            self._invalid_time_epoch = time()

        if err:
            raise err  # Delegate exception

        # STAGE 2: Upload
        try:
            self._record_static = r
            self._record_static.save()

            # compute the device timestamp drift and utc offset
            now = datetime.now(tz=timezone.utc)
            dev_ts = self._dev.get_current_time()
            self._record.ts_drift = (now - dev_ts).seconds
            self._record.save()
        except Exception as _err:
            err = _err

        if err:
            raise err  # Delegate exception
        return 0

    @DATABASE.atomic()
    def update_activity(self) -> int:
        """Update activity record on database from device data. Raise an exception on any error."""
        err = None
        now_utc = datetime.now().astimezone(timezone.utc)
        last_ts_utc = self._record.last_activity_ts

        # max fetch is 15 days
        if last_ts_utc is None:
            last_ts_utc = now_utc - timedelta(days=15)
        else:
            last_ts_utc += timedelta(seconds=60)
            last_ts_utc = max(now_utc - timedelta(days=15), last_ts_utc)

        # Last record is expressed in UTC timezone
        #   Change to local timezone for device comparison
        now = now_utc.astimezone()
        local_timezone = now.tzinfo
        last_ts = last_ts_utc.astimezone(local_timezone)

        # STAGE 1: Fetch
        try:
            if not self._dev.is_connected():
                return -1

            # WARN Gives less records than expected, has to execute twice
            activities = self._dev.get_activities(
                last_ts.replace(tzinfo=None),
                now.replace(tzinfo=None))
        except Exception as _err:
            err = _err
            self.status = self.STATUS_INVALID
            self._invalid_time_epoch = time()

        if err:
            raise err  # Delegate exception
        elif len(activities) == 0:
            return 0

        insert_data = [{
            'dev': self._record,
            'ts': a.timestamp.astimezone(timezone.utc),  # To UTC
            'category': a.category,
            'intensity': a.intensity,
            'steps': a.steps,
            'heart_rate': a.heart_rate
        } for a in activities]

        # STAGE 2: Upload
        try:
            with DATABASE.atomic():
                batch_size = min(100, len(insert_data))  # batches of 100
                for idx in range(0, len(insert_data), batch_size):
                    # if last batch does not have 100 items
                    if len(insert_data[idx:]) < batch_size:
                        batch_size = len(insert_data[idx:])
                    ActivityRecord.insert_many(
                        insert_data[idx:idx + batch_size]
                    ).on_conflict_ignore().execute()

            with DATABASE.atomic():
                # Get last saved record ts and update it in MiBandRecord
                last_ts_stored = ActivityRecord.select().where(
                    ActivityRecord.dev == self._record).order_by(
                    ActivityRecord.ts.desc()).execute()[0].ts
                self._record.last_activity_ts = last_ts_stored
                self._record.save()
        except Exception as _err:
            err = _err

        if err:
            raise err  # Delegate exception
        return 0

    @DATABASE.atomic()
    def update_battery(self) -> int:
        """Update battery record on database from device data. Raise an exception on any error."""
        err = None

        # STAGE 1: Fetch
        try:
            if not self._dev.is_connected():
                return -1

            battery = self._dev.get_battery_info()
        except Exception as _err:
            err = _err
            self.status = self.STATUS_INVALID
            self._invalid_time_epoch = time()

        if err:
            raise err  # Delegate exception

        self.is_charging = battery.status == 'charging'
        now_utc = datetime.now(tz=timezone.utc)

        # STAGE 2: Upload
        try:
            r = BatteryInfoRecord(
                dev=self._record,
                ts=now_utc,
                level=battery.level,
                status=int(self.is_charging))
            r.save()
            self._record.last_battery_ts = now_utc
            self._record.save()
        except Exception as _err:
            err = _err

        if err:
            raise err  # Delegate exception
        return 0

    @DATABASE.atomic()
    def update_heart_rate(self) -> int:
        """Update heart rate record on database from device data. Raise an exception on any error."""
        err = None
        now_utc = datetime.now(tz=timezone.utc)

        # STAGE 1: Fetch
        try:
            if not self._dev.is_connected():
                return -1

            bpm = self._dev.get_current_heart_rate()
        except Exception as _err:
            err = _err
            self.status = self.STATUS_INVALID
            self._invalid_time_epoch = time()

        if err:
            raise err  # Delegate exception

        # STAGE 2: Upload
        try:
            r = HeartRateRecord(dev=self._record,
                                ts=now_utc,
                                bpm=bpm)
            r.save()
            self._record.last_heart_rate_ts = now_utc
            self._record.save()
        except Exception as _err:
            err = _err

        if err:
            raise err  # Delegate exception
        return 0

    @DATABASE.atomic()
    def update_steps(self) -> int:
        """Update steps record on database from device data. Raise an exception on any error."""
        err = None
        now_utc = datetime.now(tz=timezone.utc)

        # STAGE 1: Fetch
        try:
            if not self._dev.is_connected():
                return -1

            data = self._dev.get_step_info()
        except Exception as _err:
            err = _err
            self.status = self.STATUS_INVALID
            self._invalid_time_epoch = time()

        if err:
            raise err  # Delegate exception

        # STAGE 2: Upload
        try:
            r = StepRecord(
                dev=self._record,
                ts=now_utc,
                steps=data.steps,
                meters=data.meters,
                calories=data.calories)
            r.save()
            self._record.last_steps_ts = now_utc
            self._record.save()
        except Exception as _err:
            err = _err

        if err:
            raise err  # Delegate exception
        return 0

    @DATABASE.atomic()
    def update_time_check(self) -> int:
        """Update last time check record on database from device data. Raise an exception on any error."""
        err = None
        # Remove tzinfo for comparison,
        #   but both must be in local timezone
        now = datetime.now().replace(tzinfo=None)

        # STAGE 1: Fetch
        try:
            if not self._dev.is_connected():
                return

            band_time = self._dev.get_current_time().replace(tzinfo=None)
        except Exception as _err:
            err = _err
            self.status = self.STATUS_INVALID
            self._invalid_time_epoch = time()

        if err:
            raise err  # Delegate exception

        # STAGE 2: Update (if needed)
        if abs(now - band_time) >= timedelta(minutes=30):
            try:
                self._dev.set_current_time()
            except Exception as _err:
                err = _err
                self.status = self.STATUS_INVALID
                self._invalid_time_epoch = time()

        if err:
            raise err  # Delegate exception

        # STAGE 3: Upload
        try:
            self._record.last_time_check_ts = now.astimezone(timezone.utc)
            self._record.save()
        except Exception as _err:
            err = _err

        if err:
            raise err  # Delegate exception
        return 0
