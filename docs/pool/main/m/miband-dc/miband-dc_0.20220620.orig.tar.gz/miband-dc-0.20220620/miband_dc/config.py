import json
from hashlib import md5

import pytimeparse


class Configuration:
    def __init__(self, params: dict) -> None:
        self._c = params

        # Check required configuration
        if not all([k in self._c.keys() for k in (
            'db_name', 'db_user', 'db_passwd',
                'db_host', 'db_port')]):
            raise AttributeError('Configuration must contain ' +
                                 'all of: db_name, db_user, ' +
                                 'db_passwd, db_host and db_port.')

        # Load default if not provided
        for k, v, choices in (
                ('activity_timeout', 60 * 60, None),
                ('battery_timeout', 15 * 60, None),
                ('heart_rate_timeout', 10 * 60, None),
                ('time_check_timeout', 60 * 60 * 24, None),
                ('update_mode', 'all', ['all', 'charging'])):
            if k not in self._c.keys():
                self._c[k] = v
            elif k.endswith('timeout'):
                if isinstance(self._c[k], str):
                    if self._c[k] .isdigit():
                        self._c[k] = int(self._c[k])
                    else:
                        self._c[k] = pytimeparse.parse(
                            self._c[k])
                        if self._c[k] == None:
                            raise ValueError(f'Value of {k} must be an ' +
                                            'int or a time expression.')
                if self._c[k] < 300:
                    raise ValueError(f'Timeout {k} value must be ' +
                                        '5 minutes or greater.')

            if choices != None:
                if self._c[k] not in choices:
                    raise ValueError(f'Choices for {k} are {choices}.')

        # Load notifications parameters
        self.notifications = {}
        if 'notifications' not in self._c.keys():
            return  # No more config

        notifications = self._c.pop('notifications')
        for k in ['update_state']:
            if k not in notifications.keys():
                continue

            # Wrap subscribers as list
            if not isinstance(notifications[k], list):
                notifications[k] = [notifications[k]]

            # Load notifications (group subscribers by type and extra params value)
            for n in notifications[k]:
                sub = n
                extra_params = {}  # notifications default params

                if isinstance(n, dict):
                    if 'address' not in n.keys():
                        raise ValueError('A notification must contain ' +
                                         '"address" field.')
                    sub = n['address']
                    if len(n.keys()) > 1:
                        # notifications with custom params
                        extra_params = {i: j for i,
                                        j in n.items() if i != 'address'}
                        # check extra params
                        for param, value in extra_params.items():
                            # timeout (for all types)
                            if param == 'timeout':
                                if isinstance(extra_params[param], int):
                                    extra_params[param] = value
                                elif value.isdigit():
                                    extra_params[param] = int(value)
                                else:
                                    extra_params[param] = pytimeparse.parse(
                                        value)
                                    if extra_params[param] == None:
                                        raise ValueError(f'Value of {param} must be an ' +
                                                         'int or a time expression.')
                            else:
                                raise TypeError(
                                    f'Unknown extra param {param} for {k} notification.')

                h = md5()  # Use MD5 for stability (hash fn can change each runtime)
                h.update(k.encode('utf-8'))
                h.update(str(extra_params).encode('utf-8'))
                nkey = h.hexdigest()
                if nkey not in self.notifications.keys():
                    self.notifications[nkey] = {'type': k, 'subs': [],
                                                'params': extra_params}

                if isinstance(sub, str):
                    self.notifications[nkey]['subs'].append(sub)
                elif isinstance(sub, list):
                    if not all([isinstance(i, str) for i in sub]):
                        raise ValueError('If notification is a list, ' +
                                         'must contain only strings.')
                    for s in sub:
                        self.notifications[nkey]['subs'].append(s)
                else:
                    raise ValueError('Notification must be a ' +
                                     'str, list or dict.')

                # TODO Check address format

    def __getattr__(self, name: str):
        if name in self._c.keys():
            return self._c[name]
        raise AttributeError

    @property
    def psql_params(self) -> dict:
        """Return psql params for connection."""
        return {'database': self.db_name,
                'user': self.db_user,
                'password': self.db_passwd,
                'host': self.db_host,
                'port': int(self.db_port)}

    @property
    def device_params(self) -> dict:
        """Return device config params."""
        return {'update_mode': self.update_mode,
                'activity_timeout': self.activity_timeout,
                'battery_timeout': self.battery_timeout,
                'heart_rate_timeout': self.heart_rate_timeout,
                'time_check_timeout': self.time_check_timeout, }

    @staticmethod
    def from_json(path: str):
        with open(path) as fr:
            params = json.load(fr)
        return Configuration(params)
