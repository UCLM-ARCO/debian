from setuptools import setup

with open("README.md", "r") as fh:
    long_description = fh.read()


def get_version():
    with open('debian/changelog') as chlog:
        return chlog.readline().split("(")[1].split("-")[0]


def parse_requirements() -> list:
    retval = []
    try:
        with open('requirements.txt') as fr:
            for line in fr:
                if not (line.isspace() or line.startswith('#')):
                    retval.append(line.strip())
    except Exception as err:
        print(err)
    finally:
        return retval


setup(
    name='miband-dc',
    packages=['miband_dc'],
    version=get_version(),
    description='Python script to collect data from Xiaomi activity bands.',
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Oscar Acena Herrera",
    author_email="oscaracena@gmail.com",
    license='Apache-2.0',
    install_requires=parse_requirements(),
    # setup_requires=[],
    scripts=['miband-dc'],
    # package_data={'miband-dc': ['README.md']},
    data_files=[
        ('miband-dc', ['devices.csv', 'settings.json', 'miband-dc.pem'])
    ],
)
