miband-dc(1) -- Data collector for Xiaomi MiBand4
===

## SYNOPSIS

  miband-dc [-d|--devices devices_file] [-c|--config configuration_file]

## DESCRIPTION

  This is a Python 3 script (and system service) which
  collects data from Xiaomi MiBand4, previously configured,
  and stores it on a provided postgresql database.

## CONFIGURATION

  There is a JSON settings file on the path `/etc/miband-dc` called `settings.json` which 
  configures the program. It holds the **database connection parameters**, 
  so it is important to check it out before running the daemon. This program **do not** create the databases **nor** the users.

  Also, in the same path, there is the `devices.csv` file, which holds the 
  configured devices to read from.

## USAGE

  Stop the service and modify configuration files. When finished, restart the program:

  ```
  $ sudo systemctl stop miband-dc.service
  [... Modify configuration files ...]
  $ sudo systemctl restart miband-dc.service
  ```

  This will start the daemon and collect the data from the devices 
  in the `devices.csv` file.

  Each time you change the configuration file, execute:
  ```
  $ sudo systemctl restart miband-dc.service
  ```

## AUTHOR

  Oscar Aceña Herrera (oscar.acena@gmail.com)

## COPYRIGHT

  Copyright © 2020 Oscar Aceña

  This manual page was written for the Debian system (and may be used by
  others).

  Permission is granted to copy, distribute and/or modify this document
  under the terms of the GNU General Public License, Version 2 or (at
  your option) any later version published by the Free Software
  Foundation.

  On Debian systems, the complete text of the GNU General Public License
  can be found in /usr/share/common-licenses/GPL.