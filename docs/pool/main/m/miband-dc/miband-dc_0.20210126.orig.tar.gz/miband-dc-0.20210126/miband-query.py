#!/usr/bin/python3

import os
import logging
import json
import time
from datetime import datetime, timedelta
from argparse import ArgumentParser

from miband import MiBand4

logging.basicConfig(level=logging.INFO)


class MiBandQuery:
    def __init__(self, args):
        self.args = args
        self.devices = {}

        if not os.path.exists(args.devices):
            raise RuntimeError(f"provided devices file ({args.devices}) not found")

        with open(args.devices) as src:
            for line in src.readlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    bid, mac, token = map(str.strip, line.split("|"))
                    token = bytes.fromhex(token) if token else None
                    self.devices[bid] = {"mac": mac, "token": token}
                except ValueError:
                    print(f"WARNING: invalid format in line: {line}")

    def run(self):
        bid = "1"
        dev = MiBand4("miband " + bid, **self.devices[bid])
        dev.connect()

        self.get_static_info(dev)
        self.get_dynamic_info(dev)
        self.stream_heart_rate(dev)

    def get_static_info(self, dev):
        info = {
            "mac": dev.mac,
            "given name": dev.given_name,
            "device name": dev.get_name(),
            "software version": dev.get_sw_version(),
            "hardware version": dev.get_hw_version(),
            "serial number": dev.get_serial_number(),
            "appearance": dev.get_appearance(),
            "system ID": dev.get_system_id(),
            "PnP ID": dev.get_pnp_info(),
            "preferred conn params": dev.get_preferred_conn_params().to_dict(),
        }

        print(json.dumps(info, indent=4))

    def get_dynamic_info(self, dev):
        now = datetime.now()
        twenty_mins_ago = now - timedelta(minutes=20)

        info = {
            "battery": dev.get_battery_info().to_dict(),
            "step info": dev.get_step_info().to_dict(),
            "current time": dev.get_current_time(),
            "last 20 mins of activity": dev.get_activities(twenty_mins_ago, now),
            "current h. rate": dev.get_current_heart_rate(),
        }

        print(json.dumps(info, indent=4, default=str))

    def stream_heart_rate(self, dev):
        events = dev.start_hr_streaming()
        print("Streaming service started, press Ctrl+C to stop\nWaiting events...")
        try:
            for ev in events:
                print(f" HR received: {ev}")
        except KeyboardInterrupt:
            dev.stop_hr_streaming()
            print("\b\bStreaming service stop.")

    def identify_devices(self):
        for bid, info in self.devices.items():
            dev = MiBand4("miband " + bid, **info)
            try:
                dev.connect()
                dev.send_alert(dev.given_name, type="sms")
                dev.disconnect()
            except RuntimeError as err:
                logging.error(err)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-d", "--devices", default="devices.csv",
        help="configuration file with the list of devices to get data from")

    _args = parser.parse_args()
    MiBandQuery(_args).run()
