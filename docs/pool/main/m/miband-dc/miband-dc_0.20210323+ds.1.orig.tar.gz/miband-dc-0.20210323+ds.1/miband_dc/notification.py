import abc
import functools
import os
import re
import socket
import struct
from datetime import datetime, timedelta
from hashlib import md5
from uuid import getnode as get_host_mac

import requests
from peewee import IntegrityError
from pytimeparse import parse

from .db import NotificationRecord, SubscriberRecord
from .utils import Task

api_url_sendinblue = 'https://api.sendinblue.com/v3/smtp/email'
api_url_sendgrid = 'https://api.sendgrid.com/v3/mail/send'


class NotifyTask(Task, abc.ABC):
    name = "NotifyTask"

    def __init__(self, subscribers: list, **kwargs):
        """Task which notifies subscribers.

        Args:
            subscribers (list): List of subscribers addresses. These can be a
                                host:port string (TCP notification) or an email
                                string (Email notification).
            timeout (str, optional): Time expression. Sets the notification
                                     timeout (parsed to seconds). Defaults to '1m'
                                     (one minute).
            only_updatable (bool, optional): If True, notification will only notify
                                             about updatable devices, not all
                                             available. Defaults to False.
        """
        super().__init__()
        self.queued = False

        if 'timeout' in kwargs:
            timeout = kwargs.pop('timeout')
            self.timeout = int(
                timeout) if timeout.isdigit() else parse(
                timeout)
            if not self.timeout:
                self.log.warning(
                    f' unknown time expression {timeout}. Using default.')
                self.timeout = 60
        else:
            self.timeout = 60

        if 'only_updatable' in kwargs:
            self.only_updatable = kwargs.pop('only_updatable')
        else:
            self.only_updatable = False

        if len(kwargs.keys()) > 0:
            self.log.warning(f' unknown arguments {kwargs.keys()}')

        self.record, created = NotificationRecord.get_or_create(
            id=self.id, type=self.type)

        if created:
            self.record.save()

        SubscriberRecord.delete().where(
            SubscriberRecord.notification == self.id).execute()
        self.add_subscribers(subscribers)

    def __hash__(self):
        return hash((self.name, self.timeout))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return hash(self) == hash(other)

    @abc.abstractproperty
    def pretty_name(self) -> str:
        pass

    @property
    def id(self) -> str:
        hashfn = md5()
        for item in (self.name, self.timeout, get_host_mac()):
            if isinstance(item, str):
                item = item.encode('utf-8')
            else:
                item = str(item).encode('utf-8')
            hashfn.update(item)
        return hashfn.hexdigest()

    @abc.abstractproperty
    def type(self) -> str:
        pass

    @abc.abstractproperty
    def data(self) -> bytes:
        pass

    @abc.abstractproperty
    def mail(self) -> str:
        pass

    def add_subscribers(self, subscribers: list):
        for sub in subscribers:
            email_match = re.search(r'\S*@\S*\.\S*', sub)
            if email_match:
                sub_record, created = SubscriberRecord.get_or_create(
                    address=sub, notification=self.id, type='email')
                if created:
                    sub_record.save()
                continue
            tcp_match = re.search(r'\S*:\d*', sub)
            if tcp_match:
                sub_record, created = SubscriberRecord.get_or_create(
                    address=sub, notification=self.id, type='tcp')
                if created:
                    sub_record.save()
                continue
            self.log.warning(
                f" unknown type of subscriber {sub}. Choices are: email, host:port address")

    def shall_run(self) -> bool:
        if self.is_running or self.queued:
            return False
        elif len(SubscriberRecord.select().where(
            SubscriberRecord.notification == self.id,
            SubscriberRecord.active
        )) == 0:
            return False
        elif self.record.last_ts == None:
            return True
        return (
            datetime.now() -
            self.record.last_ts) >= timedelta(
            seconds=self.timeout)

    def enqueue(self):
        self.queued = True
        return self

    def _notify_tcp(self) -> int:
        retval = 0
        if not self.data:
            return retval

        for sub in SubscriberRecord.select().where(
            SubscriberRecord.notification == self.id,
            SubscriberRecord.type == 'tcp',
            SubscriberRecord.active
        ):
            addr = sub.address.split(':')
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                try:
                    sock.connect((addr[0], int(addr[1])))
                    sock.sendall(self.data)
                    retval += 1
                except socket.timeout:
                    self.log.error(f' timeout when notifying {sub.address}')
                except socket.error as err:
                    self.log.error(
                        f' could not reach {sub.address}. Removing... More info: {err}')
                    sub.active = False
                    sub.save()
                else:
                    self.log.info(f' {sub.address} successfully notified')

        return retval

    def _notify_email(self) -> int:
        retval = 0

        for sub in SubscriberRecord.select().where(
            SubscriberRecord.notification == self.id,
            SubscriberRecord.type == 'email',
            SubscriberRecord.active
        ):
            payload = {
                'personalizations': [{
                    'to': [{'email': sub.address}]
                }],
                'from': {
                    'email': 'smartmirrorshapes@gmail.com',
                    'name': 'Smart Mirror'
                },
                'subject': f'{self.pretty_name}',
                'content': [{
                    'type': 'text/plain',
                    'value': self.mail
                }]
            }
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {os.environ.get('MIBAND_DC_MAIL_KEY')}"
            }
            response = requests.request(
                "POST", api_url_sendgrid,
                json=payload, headers=headers
            )
            if response.status_code == 202:
                retval += 1
                self.log.info(f' {sub.address} successfully notified')
            else:
                self.log.error(
                    f" could not reach {sub}. More info: {response.reason}")
        return retval

    def run(self):
        with self.is_running:
            self.queued = False
            self.log.info(" start notify ...")
            notified = self._notify_tcp()
            notified += self._notify_email()
            self.log.info(f' notified {notified} subscribers')
            self.record.last_ts = datetime.now()
            self.record.save()


class NotifyUpdateStateTask(NotifyTask):
    name = "NotifyUpdateStateTask"

    def __init__(self, subscribers: list, devices: list, **kwargs):
        """Task which notifies subscribers about devices update state.

        Args:
            subscribers (list): List of subscribers addresses. These can be a
                                host:port string (TCP notification) or an email
                                string (Email notification).
            devices (list): List of MiBandDevice instances.
            timeout (str, optional): Time expression. Sets the notification
                                     timeout (parsed to seconds). Defaults to '1m'
                                     (one minute).
            timerange (str, optional): Time expression. After this time, the device
                                       will be considered outdated. Defaults to '1d'
                                       (one day).
            only_updatable (bool, optional): If True, notification will only notify
                                             about updatable devices, not all
                                             available. Defaults to False.
        """
        self.devices = devices
        if 'timerange' in kwargs:
            timerange = kwargs.pop('timerange')
            self.timerange = int(
                timerange) if timerange.isdigit() else parse(
                timerange)
            if not self.timerange:
                self.log.warning(
                    f' unknown time expression {timerange}. Using default.')
                self.timerange = parse('1d')
        else:
            self.timerange = parse('1d')

        super_kwargs = {}
        if 'timeout' in kwargs:
            super_kwargs['timeout'] = kwargs.pop('timeout')
        if 'only_updatable' in kwargs:
            super_kwargs['only_updatable'] = kwargs.pop('only_updatable')
        super().__init__(subscribers, **super_kwargs)

        if len(kwargs.keys()) > 0:
            self.log.warning(f' unknown arguments {kwargs.keys()}')

    def __hash__(self):
        return hash((self.name, self.timeout, self.timerange))

    @property
    def pretty_name(self) -> str:
        return 'MiBand Update State Notification'

    @property
    def id(self) -> str:
        hashfn = md5()
        for item in (self.name, self.timeout, self.timerange, get_host_mac()):
            if isinstance(item, str):
                item = item.encode('utf-8')
            else:
                item = str(item).encode('utf-8')
            hashfn.update(item)
        return hashfn.hexdigest()

    @property
    def type(self) -> str:
        return 'update_state'

    @property
    @functools.lru_cache()
    def data(self) -> bytes:
        data = []
        for dev in self.devices:
            if self.only_updatable:
                if not dev.shall_be_collected():
                    continue
            data.append(bytes.fromhex(dev.dev_record.mac.replace(':', '')))
            data.append(dev.is_updated(self.timerange))
        n = int(len(data) / 2)

        return struct.pack('<i' + '6s?' * n, n, *data) if n > 0 else None

    @property
    @functools.lru_cache()
    def mail(self) -> str:
        outdated = [
            dev for dev in self.devices if not dev.is_updated(
                self.timerange) and (
                dev.shall_be_collected() == self.only_updatable)]
        if len(outdated) > 0:
            retval = 'Hi! The following devices have their data outdated:\n'
            for dev in outdated:
                retval += f'\n\t- {dev.dev_record.mac}'
        else:
            retval = 'Congratulations! All devices are updated :)\n'

        retval += '\n\nUntil next time!'
        return retval
