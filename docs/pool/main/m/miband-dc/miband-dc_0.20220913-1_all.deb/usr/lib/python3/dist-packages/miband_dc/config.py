import json
from hashlib import md5

import pytimeparse


class Configuration:
    def __init__(self, params: dict) -> None:
        self._c = params

        # Check required configuration
        if not all([k in self._c.keys() for k in (
            'db_name', 'db_user', 'db_passwd',
                'db_host', 'db_port')]):
            raise AttributeError('Configuration must contain ' +
                                 'all of: db_name, db_user, ' +
                                 'db_passwd, db_host and db_port.')

        # Load default if not provided
        for k, v, choices in (
                ('activity_timeout', 60 * 60, None),
                ('battery_timeout', 15 * 60, None),
                ('heart_rate_timeout', 10 * 60, None),
                ('time_check_timeout', 60 * 60 * 24, None),
                ('update_mode', 'all', ['all', 'charging'])):
            if k not in self._c.keys():
                self._c[k] = v
            elif k.endswith('timeout'):
                if isinstance(self._c[k], str):
                    if self._c[k] .isdigit():
                        self._c[k] = int(self._c[k])
                    else:
                        self._c[k] = pytimeparse.parse(
                            self._c[k])
                        if self._c[k] == None:
                            raise ValueError(f'Value of {k} must be an ' +
                                            'int or a time expression.')
                if self._c[k] < 300:
                    raise ValueError(f'Timeout {k} value must be ' +
                                        '5 minutes or greater.')

            if choices != None:
                if self._c[k] not in choices:
                    raise ValueError(f'Choices for {k} are {choices}.')

    def __getattr__(self, name: str):
        if name in self._c.keys():
            return self._c[name]
        raise AttributeError

    @property
    def psql_params(self) -> dict:
        """Return psql params for connection."""
        return {'database': self.db_name,
                'user': self.db_user,
                'password': self.db_passwd,
                'host': self.db_host,
                'port': int(self.db_port)}

    @property
    def device_params(self) -> dict:
        """Return device config params."""
        return {'update_mode': self.update_mode,
                'activity_timeout': self.activity_timeout,
                'battery_timeout': self.battery_timeout,
                'heart_rate_timeout': self.heart_rate_timeout,
                'time_check_timeout': self.time_check_timeout, }

    @staticmethod
    def from_json(path: str):
        with open(path) as fr:
            params = json.load(fr)
        return Configuration(params)
