import os.path
import signal
import sys
from time import sleep

from Crypto.PublicKey import RSA

from .config import Configuration
from .db import DATABASE, init_db
from .device import MiBandDevice
from .log import LogMixin
from .task import DeviceMultiTask, TaskRunner


class MiBandCollector(LogMixin):
    def __init__(self, devices_path: str,
                 config_path: str,
                 app_key_path: str,
                 log_level: int = 0,
                 use_stdout: bool = True,
                 use_syslog: bool = False,
                 use_filelog: bool = False) -> None:
        super().__init__(level=log_level,
                         use_stdout=use_stdout,
                         use_syslog=use_syslog,
                         use_filelog=use_filelog)
        self.__killed = False

        # Configuration
        self.config = Configuration.from_json(config_path)

        # Key for secrets
        with open(app_key_path, 'rb') as fd:
            self._key = RSA.importKey(fd.read())

        # Database
        if not init_db(**self.config.psql_params):
            raise RuntimeError('Cannot connect to database.')

        # Devices
        self.devices = {}
        self.__load_devices(devices_path)

        # Tasks
        self.runner = TaskRunner(level=log_level,
                                 use_stdout=use_stdout,
                                 use_syslog=use_syslog,
                                 use_filelog=use_filelog)

    def __load_devices(self, path: str) -> None:
        with open(path) as fr:
            lines = [l.strip() for l in fr]
        for l in lines:
            if not l or l.startswith('#'):
                continue
            try:
                _, mac, token = map(
                    str.strip, l.split('|'))
                token = bytes.fromhex(token)
                self.devices[mac] = MiBandDevice(
                    mac=mac, token=token,
                    **self.config.device_params)
                if self.level <= 1:  # not debug
                    # Disable logging from MiBand4
                    self.devices[mac]._dev.log.disabled = True
            except ValueError:
                self.log.warning(
                    f'Skipping invalid device: {l}.')
        self.log.info('Devices loaded.')

    def gracefully_exit(self, signum, _) -> None:
        """Exit gracefully if anything different from a KeyboardInterrupt ends the program"""
        self.log.warning(f'Received signal #{signum}. Forced exit.')
        self.__killed = True

    def run(self) -> int:
        # Set handlers for some signals
        signal.signal(signal.SIGTERM, self.gracefully_exit)
        signal.signal(signal.SIGABRT, self.gracefully_exit)

        ret = 0
        self.runner.start()
        try:
            while not self.__killed and self.runner.is_alive():
                # Device specific tasks
                for d in self.devices.values():
                    t = DeviceMultiTask(
                        d, level=self.level,
                        use_stdout=self.use_stdout,
                        use_syslog=self.use_syslog,
                        use_filelog=self.use_filelog)
                    if t.is_empty():
                        continue
                    self.runner.add_task(t)

                sleep(1)
        except KeyboardInterrupt:
            self.log.info('Exiting')
        except Exception as err:
            exc_tb = sys.exc_info()[2]
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            self.log.critical(
                f'Unknown error occured at {fname}:{exc_tb.tb_lineno}: {err}')
            ret = 1
        finally:
            for d in self.devices.values():
                d.disconnect(nowait=True)
            DATABASE.close()
            return ret if not self.__killed else -1
