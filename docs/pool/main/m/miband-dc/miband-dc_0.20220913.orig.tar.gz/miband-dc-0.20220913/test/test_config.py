import unittest
from hashlib import md5

from miband_dc.config import Configuration


class ConfigTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.params = {'db_name': 'db',
                       'db_user': 'user',
                       'db_passwd': 'passwd',
                       'db_host': 'localhost',
                       'db_port': 5432}

    def test_basic(self):
        c = Configuration(self.params)
        self.assertEqual(c.db_name, 'db')
        self.assertEqual(c.db_user, 'user')
        self.assertEqual(c.db_passwd, 'passwd')
        self.assertEqual(c.db_host, 'localhost')
        self.assertEqual(c.db_port, 5432)
        self.assertEqual(c.psql_params, {
            'database': 'db',
            'user': 'user',
            'password': 'passwd',
            'host': 'localhost',
            'port': 5432})

    def test_required_err(self):
        with self.assertRaises(AttributeError):
            Configuration({})

    def test_default(self):
        c = Configuration(self.params)
        self.assertEqual(c.update_mode, 'all')
        self.assertEqual(c.activity_timeout, 3600)
        self.assertEqual(c.battery_timeout, 900)
        self.assertEqual(c.heart_rate_timeout, 600)
        self.assertEqual(c.time_check_timeout, 86400)
        self.assertEqual(c.notifications, {})

    def test_unknown_param_err(self):
        self.params['unknown'] = 0  # Does not affect
        self.test_basic()
        self.test_default()

    def test_update_mode(self):
        self.params['update_mode'] = 'charging'
        c = Configuration(self.params)
        self.assertEqual(c.update_mode, 'charging')

    def test_update_mode_err(self):
        self.params['update_mode'] = 'unknown'
        with self.assertRaises(ValueError):
            Configuration(self.params)

    def test_timeout(self):
        for battery_timeout in [3600, '3600s', '60m', '1h']:
            self.params['battery_timeout'] = battery_timeout
            c = Configuration(self.params)
            self.assertEqual(c.battery_timeout, 3600)

    def test_minimum_timeout(self):
        self.params['battery_timeout'] = 5
        with self.assertRaises(ValueError):
            Configuration(self.params)

    def test_timeout_parse_err(self):
        self.params['battery_timeout'] = 'unknown'
        with self.assertRaises(ValueError):
            Configuration(self.params)

    def test_notify_update_state(self):
        # Calculate basic key
        h = md5()
        h.update('update_state'.encode('utf-8'))
        h.update(str({}).encode('utf-8'))
        key = h.hexdigest()

        for update_state in ['address@domain.com',
                             ['address@domain.com'],
                             {'address': 'address@domain.com'},
                             {'address': ['address@domain.com']}]:
            self.params['notifications'] = {'update_state': update_state}
            c = Configuration(self.params)
            self.assertEqual(c.notifications, {
                key: {
                    'type': 'update_state',
                    'subs': ['address@domain.com'],
                    'params': {}
                }
            })

    def test_notify_update_state_extra_params_parse_err(self):
        self.params['notifications'] = {
            'update_state': {
                'address': 'address@domain.com',
                'timeout': 'unkwnown'
            }}
        with self.assertRaises(ValueError):
            Configuration(self.params)

    def test_notify_update_state_unknown_extra_params(self):
        self.params['notifications'] = {
            'update_state': {
                'address': 'address@domain.com',
                'unknown': 0
            }}
        with self.assertRaises(TypeError):
            Configuration(self.params)
