import inspect
import os.path
from time import sleep
import unittest
from datetime import datetime, timedelta, timezone
from fileinput import close
from os import environ

from miband import MiBand4
from miband_dc.config import Configuration
from miband_dc.db import DATABASE, init_db
from miband_dc.device import MiBandDevice
from playhouse.test_utils import assert_query_count, count_queries


class MiBand4Dummy(MiBand4):
    def __init__(self):
        super().__init__(name='DummyBand', mac='00:00:00:00:00:00',
                         token=None,
                         autoconnect=False)
        self.log.disabled = True
        self.connect = lambda: True
        self.disconnect = lambda: None
        # self.discover
        self.get_appearance = lambda: None
        self.get_hw_version = lambda: None
        self.get_name = lambda: None
        self.get_pnp_info = lambda: None
        self.get_preferred_conn_params = lambda: None
        self.get_serial_number = lambda: None
        self.get_sw_version = lambda: None
        self.get_system_id = lambda: None
        self.is_connected = lambda: True
        self.send_alert = lambda: None
        self.set_alert_level = lambda: None
        self.set_current_time = lambda: None
        self.start_hr_streaming = lambda: None
        self.stop_hr_streaming = lambda: None

    def get_current_time(self):
        return datetime.now().replace(
            microsecond=0,
            tzinfo=timezone.utc)

    def get_battery_info(self):
        return type('BatteryInfo', (object,),
                    {'status': 'normal',
                     'level': 100})

    def get_step_info(self):
        return type('StepInfo', (object,),
                    {'steps': 100,
                     'meters': 100,
                     'calories': 100})

    def get_activities(self, start: datetime, end: datetime):
        minutes = int((end.replace(microsecond=0, second=0) -
                       start.replace(microsecond=0, second=0)).total_seconds() / 60)
        return [type('ActivityRecord', (object,),
                     {'category': 0,
                      'intensity': 0,
                      'steps': 100,
                      'heart_rate': 80,
                      'index': 0,
                      'timestamp': start + timedelta(minutes=m)
                      }) for m in range(minutes)]

    def get_current_heart_rate(self):
        return 80


class MiBandDummy(MiBandDevice):
    def __init__(self) -> None:
        super().__init__(mac='00:00:00:00:00:00',
                         token=None)
        self._dev = MiBand4Dummy()


class DeviceTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        settings_path = environ.get(
            'MIBAND_DC_TEST_SETTINGS_PATH',
            'settings.try.json')
        params = Configuration.from_json(
            settings_path).psql_params
        init_db(**params)
        assert DATABASE.is_closed() == False

        cls.device = MiBandDummy()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.device._record.delete_instance()
        DATABASE.close()

    def test_activity_duplication(self) -> None:
        with DATABASE.atomic() as ctx:
            self.device.update_activity()
            # Force activity change -> -5 minutes
            ts = self.device._record.last_activity_ts
            self.device._record.last_activity_ts -= timedelta(minutes=5)
            self.device._record.save()
            
            # This must not add any record
            self.device.update_activity()
            self.assertEqual(self.device._record.last_activity_ts, ts)

            ctx.rollback()

    def test_invalid_time(self) -> None:
        # TODO Check an invalid device (prior error) will become
        #   online or unknown if 5 minutes passed
        raise NotImplemented
