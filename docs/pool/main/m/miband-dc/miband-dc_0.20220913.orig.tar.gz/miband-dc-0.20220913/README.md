# miband-dc - MiBand data collector

This is a Python 3 script (and system service) which
collects data from Xiaomi MiBand4, previously configured,
and stores it on a provided postgresql database.

## Installation

```shell
$ sudo apt-get install miband-dc
```

## Configuration

### Settings file

It is called `settings.json`, stored at `/etc/miband-dc`, and holds all settings that affects `miband-dc`. Every time you modify this file, restart `miband-dc` service to reload the settings.

Available configurarion parameters:

1. Database connection:

   a. (required) `db_name`: PostgreSQL database name (must exist before `miband-dc` is runned).   
   b. (required) `db_user`: OWNER of database (must exist before `miband-dc` is runned).   
   c. (required) `db_passwd`: Password for `db_user`.   
   d. (required) `db_host`: Host which holds the database.   
   e. (required) `db_port`: Port of `db_host` to connect to PostgreSQL.   

2. Tasks timeout:

   a. `activity_timeout`: `Activity` and `Steps` task must execute after elapsed specified time, in seconds. Default is 3600 (1 hour).   
   b. `battery_timeout`: `Battery` task must execute after elapsed specified time, in seconds. Default is 900 (15 minutes).   
   c. `heart_rate_timeout`: `Heart Rate` task must execute after elapsed specified time, in seconds. Default is 600 (10 minutes).   
   d. `time_check_timeout`: `Check time` task must execute after elapsed specified time, in seconds. Default is 86400 (1 day).

> NOTE: All timeouts, is specified, must be 5 minutes or greater.

3. `update_mode`: Change `miband-dc` behaviour. Available choices are:

   a. `always`: Update devices information always, if can. This means that `miband-dc` will try to get all information for every online device every time it can.   
   b. `charging`: Only update devices information when they are charging. This mode pretends to simulate a `updating station`, where users leave their devices charging while data is being stored, resulting in a less aggressive communication. In this mode, `Heart Rate` tasks won´t be executed, as the user won´t wear the device, thus making imposible to read heart rate information.  

See also [Examples](#examples) section.

### Devices file

It is called `devices.csv`, stored at `/etc/miband-dc`, and holds all the devices from `miband-dc` will collect information. Every time you modify this file, restart `miband-dc` service to reload the configured devices.

There is a line for each device, and follows the pattern: `id | mac | token`.

Visit [this post](https://arcogroup.bitbucket.io/shapes/integrating_miband_with_smart_mirror/#devices) to know more about configuring MiBand devices for miband-dc.

## Usage

Stop the service and modify configuration files. When finished, restart the program:

```shell
$ sudo systemctl stop miband-dc.service
[... Modify configuration files ...]
$ sudo systemctl restart miband-dc.service
```

This will start the daemon and collect the data from the devices 
in the `devices.csv` file.

Each time you change the configuration file, execute:
```shell
$ sudo systemctl restart miband-dc.service
```

## Examples

### 1. Test every feature. 

```json
{
    "db_name": "miband-dc",
    "db_user": "root",
    "db_passwd": "D45g5gllojdf9",
    "db_host": "localhost",
    "db_port": 5432,

    "battery_timeout": 300,

    "update_mode": "all"
}
```

With this configuration `miband-dc` will:

1. Use the specified database with the provided connection parameters.   
2. Update battery data every 5 minutes.