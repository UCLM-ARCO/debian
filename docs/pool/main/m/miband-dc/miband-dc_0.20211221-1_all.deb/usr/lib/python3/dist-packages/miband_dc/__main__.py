#!/usr/bin/python3

# This service will acquire sensor information from Mi Band 4 devices

import json
import logging
import os
import socket
import struct
import sys
import time
from argparse import ArgumentParser
from datetime import datetime, timedelta, timezone
from queue import Queue
from threading import Thread
from uuid import getnode as get_host_mac

from miband import MiBand4
from peewee import IntegrityError, OperationalError

from .db import (ActivityRecord, BatteryInfoRecord, HeartRateRecord,
                 MiBandRecord, MiBandStaticInfo, NotificationRecord,
                 StepRecord, SubscriberRecord, psql_db)
from .notification import NotifyTask, NotifyUpdateStateTask
from .utils import LogMixin, Settings, Task


class MiBandDevice(LogMixin):
    ST_INVALID = "invalid"
    ST_ONLINE = "online"
    ST_UNKNOWN = "unknown"
    UPDATE_MODE_ALWAYS = "always"
    UPDATE_MODE_CHARGING = "charging"

    def __init__(self, name, mac, token,
                 update_mode="always"):
        self.name = name
        LogMixin.__init__(self)

        self.dev = MiBand4(name, mac, token)
        self.update_mode = update_mode
        self.status = self.ST_UNKNOWN
        self.charging_status = BatteryInfoRecord.BAT_NORMAL
        self.run_queue = []

        self.dev_record, created = MiBandRecord.get_or_create(mac=mac)
        if created:
            self.dev_record.save()
        self.static = MiBandStaticInfo.get_or_none(dev=self.dev_record)
        self.log.info(f" init dev, mac: {mac}, static-id: {self.static}")

    def _connect_device(self):
        if self.status == self.ST_INVALID:
            return False

        if not self.dev.connect():
            self.log.error(" could not authorize device, discard update")
            self.status = self.ST_INVALID
            return False
        return True

    def shall_be_collected(self):
        """Return if device shall have its data collected.

        Returns:
            bool: True if device data shall be collected.
        """
        return (self.update_mode == self.UPDATE_MODE_ALWAYS or (
            self.update_mode ==
            self.UPDATE_MODE_CHARGING and self.charging_status == BatteryInfoRecord.BAT_CHARGING))

    def is_updated(self, timerange: int = 60 * 60 * 24):
        """Return whether collected data is updated or not considering the provided timerange.

        Args:
            timerange (int, optional):  Seconds. If data collected is older than this value,
                                        the data is outdated. Defaults to 86400 (1 day).

        Returns:
            bool: True if device is updated.
        """
        now = datetime.now()
        t = timedelta(seconds=timerange)
        return (
            now -
            self.dev_record.last_activity_ts < t) and (
            now -
            self.dev_record.last_battery_ts < t) and (
            now -
            self.dev_record.last_heart_rate_ts < t) and (
            now -
            self.dev_record.last_steps_ts < t)

    def shall_update_static(self):
        return (
            "update_static" not in self.run_queue and
            self.status != self.ST_INVALID and
            self.static is None and
            self.shall_be_collected()
        )

    def update_static(self):
        try:
            if not self._connect_device():
                return

            info = MiBandStaticInfo(
                dev=self.dev_record,
                mac=self.dev.mac,
                name=self.dev.given_name,
                sw_version=self.dev.get_sw_version(),
                hw_version=self.dev.get_hw_version(),
                serial_number=self.dev.get_serial_number(),
                appearance=self.dev.get_appearance(),
                system_id=self.dev.get_system_id(),
                pnp_id=self.dev.get_pnp_info(),
                pcon_params=str(
                    self.dev.get_preferred_conn_params().to_dict()),
            )
            info.save()
            self.static = info

            # compute the device timestamp drift and utc offset
            now = datetime.now()
            dev_ts = self.dev.get_current_time().replace(tzinfo=None)
            self.dev_record.ts_drift = (now - dev_ts).seconds
            self.dev_record.save()

        finally:
            self.dev.disconnect()

    def shall_update_activity(self, time_lapse):
        if "update_activity" in self.run_queue:
            return False
        if self.status == self.ST_INVALID:
            return False
        if self.update_mode == self.UPDATE_MODE_CHARGING and self.charging_status != BatteryInfoRecord.BAT_CHARGING:
            return False
        if self.dev_record.last_activity_ts is None:
            return True

        # ts = self.dev_record.last_activity_ts + \
        #     timedelta(seconds=self.dev_record.ts_drift)
        # elapsed = datetime.now() - ts
        # return elapsed > timedelta(seconds=time_lapse)
        return (
            datetime.now() -
            self.dev_record.last_activity_ts) > timedelta(
            seconds=time_lapse)

    def update_activity(self):
        try:
            if not self._connect_device():
                return

            now = datetime.now()
            last_ts = self.dev_record.last_activity_ts
            if last_ts is not None:
                last_ts += timedelta(seconds=60)
            else:
                # the band can hold up to around 12 days of records
                # last_ts = now - timedelta(minutes=60 * 24 * 12)
                last_ts = now - timedelta(minutes=10)

            activities = self.dev.get_activities(last_ts, now)
            r = None
            for a in activities:
                try:
                    r = ActivityRecord(
                        dev=self.dev_record,
                        ts=a.timestamp,
                        category=a.category,
                        intensity=a.intensity,
                        steps=a.steps,
                        heart_rate=a.heart_rate,
                    )
                    r.save()
                    self.dev_record.last_activity_ts = r.ts
                    self.dev_record.save()
                except IntegrityError:
                    pass

        finally:
            self.dev.disconnect()

    def shall_update_battery_info(self, time_lapse):
        if "update_battery_info" in self.run_queue:
            return False
        if self.status == self.ST_INVALID:
            return False
        if self.dev_record.last_battery_ts is None:
            return True

        # elapsed = datetime.now() - (
        #     self.dev_record.last_battery_ts +
        #     timedelta(seconds=self.dev_record.ts_drift)
        # )
        # return elapsed > timedelta(seconds=time_lapse)
        return (
            datetime.now() -
            self.dev_record.last_battery_ts) > timedelta(
            seconds=time_lapse)

    def update_battery_info(self):
        try:
            if not self._connect_device():
                return

            info = self.dev.get_battery_info()
            status = BatteryInfoRecord.BAT_NORMAL
            if info.status == "charging":
                status = BatteryInfoRecord.BAT_CHARGING

            r = BatteryInfoRecord(
                dev=self.dev_record,
                ts=datetime.now(),
                level=info.level,
                status=status)
            r.save()
            self.dev_record.last_battery_ts = datetime.now()
            self.dev_record.save()
            self.charging_status = status

        finally:
            self.dev.disconnect()

    def shall_update_heart_rate(self, time_lapse):
        if "update_heart_rate" in self.run_queue:
            return False
        if self.status == self.ST_INVALID:
            return False
        if self.update_mode == self.UPDATE_MODE_CHARGING:
            return False
        if self.dev_record.last_heart_rate_ts is None:
            return True

        # elapsed = datetime.now() - (
        #     self.dev_record.last_heart_rate_ts +
        #     timedelta(seconds=self.dev_record.ts_drift)
        # )
        # return elapsed > timedelta(seconds=time_lapse)
        return (
            datetime.now() -
            self.dev_record.last_heart_rate_ts) > timedelta(
            seconds=time_lapse)

    def update_heart_rate(self):
        try:
            if not self._connect_device():
                return

            r = HeartRateRecord(
                dev=self.dev_record,
                ts=datetime.now(),
                bpm=self.dev.get_current_heart_rate())
            r.save()
            self.dev_record.last_heart_rate_ts = datetime.now()
            self.dev_record.save()

        finally:
            self.dev.disconnect()

    def shall_update_steps(self, time_lapse):
        if "update_steps" in self.run_queue:
            return False
        if self.status == self.ST_INVALID:
            return False
        if self.update_mode == self.UPDATE_MODE_CHARGING and self.charging_status != BatteryInfoRecord.BAT_CHARGING:
            return False
        if self.dev_record.last_steps_ts is None:
            return True

        # elapsed = datetime.now() - (
        #     self.dev_record.last_steps_ts +
        #     timedelta(seconds=self.dev_record.ts_drift)
        # )
        # return elapsed > timedelta(seconds=time_lapse)
        return (
            datetime.now() -
            self.dev_record.last_steps_ts) > timedelta(
            seconds=time_lapse)

    def update_steps(self):
        try:
            if not self._connect_device():
                return

            info = self.dev.get_step_info()
            r = StepRecord(
                dev=self.dev_record,
                ts=datetime.now(),
                steps=info.steps,
                meters=info.meters,
                calories=info.calories)
            r.save()
            self.dev_record.last_steps_ts = datetime.now()
            self.dev_record.save()

        finally:
            self.dev.disconnect()

    def shall_update_time(self, time_lapse):
        if "update_time" in self.run_queue:
            return False
        if self.status == self.ST_INVALID:
            return False
        if self.dev_record.last_time_check_ts is None:
            return True

        return (
            datetime.now() -
            self.dev_record.last_time_check_ts) > timedelta(
            seconds=time_lapse)

    def update_time(self):
        try:
            if not self._connect_device():
                return

            now = datetime.now(
                tz=timezone(timedelta(0))) # MiBand tz is 0
            band_time = self.dev.get_current_time()

            if abs(now - band_time) >= timedelta(hours=1):
                self.dev.set_current_time()

            self.dev_record.last_time_check_ts = datetime.now()
            self.dev_record.save()

        finally:
            self.dev.disconnect()

    def __repr__(self):
        return f"<MiBandDev, mac: {self.dev.mac}, status: {self.status}>"


class DiscoverTask(Task):
    name = "DiscoverTask"

    def __init__(self, devices):
        super().__init__()
        self.devices = devices
        self.queued = False

    def shall_run(self, timeout):
        ts = time.time()
        if self.is_running or self.queued:
            return False
        if ts - self.last_run < timeout:
            return False
        return True

    def enqueue(self):
        self.queued = True
        return self

    @Task.update_ts
    def run(self):
        # Log each 5 minutes to reduce output
        if self.last_run == 0 or time.time() - self.last_run >= 5 * 60:
            if self.log.level != Task.log_level:
                self.log.setLevel(Task.log_level)
        elif self.log.level != logging.ERROR:
            self.log.setLevel(logging.ERROR)

        self.queued = False
        self.log.info(" start discovery process...")

        discovered = MiBand4.discover(5)
        self.log.info(f" - discovered {len(discovered)} devices")

        for mac in discovered:
            dev = self.devices.get(mac)
            if dev is None:
                self.log.info(f" Mi Band 4 discovered but not managed ({mac})")
                continue
            if dev.status != MiBandDevice.ST_INVALID:
                dev.status = MiBandDevice.ST_ONLINE

        # set status to 'unknown' for those not discovered
        for mac in self.devices.keys() - discovered:
            self.devices[mac].status = MiBandDevice.ST_UNKNOWN

        for d in self.devices.values():
            self.log.info(f" - got device: {d}")


class RunFunctionTask(Task):
    def __init__(self, obj, method, *args, **kwargs):
        self.name = f"RunFunctionTask-{method}"
        super().__init__()

        self.obj = obj
        self.method = method
        self.args = args
        self.kwargs = kwargs

        self.obj.run_queue.append(self.method)

    def __del__(self):
        self.obj.run_queue.remove(self.method)

    def run(self):
        fn = getattr(self.obj, self.method)
        fn(*self.args, **self.kwargs)


class TaskRunner(Thread, LogMixin):
    name = "TaskRunner"
    log_level = logging.INFO

    def __init__(self):
        LogMixin.__init__(self)
        super().__init__()

        self.daemon = True
        self.tasks = Queue()

        self.start()

    def add_task(self, task):
        self.tasks.put(task)

    def run(self):
        while True:
            self.log.debug(f" remaining tasks: {self.tasks.qsize()}")
            t = self.tasks.get()
            self._exec_task(t)

    def _exec_task(self, task):
        try:
            self.log.info(f" run task: {task}")
            task.run()
        except Exception as err:
            self.log.error(f" task failed: {err}")


class TaskCoordinator(LogMixin):
    name = "TaskCoordinator"

    DISCOVER_TIMEOUT = 60
    ACTIVITY_TIMEOUT = 60 * 60
    BATTERY_TIMEOUT = 15 * 60
    HEART_RATE_TIMEOUT = 5 * 60
    CHECK_TIME_TIMEOUT = 15 * 3600

    def __init__(self, runner, devices,
                 task_timeout={},
                 notifications=[]):
        LogMixin.__init__(self)
        self.runner = runner
        self.devices = devices
        self.notifications = []

        if 'discovery_timeout' in task_timeout:
            self.DISCOVER_TIMEOUT = task_timeout['discovery_timeout']
        if 'activity_timeout' in task_timeout:
            self.ACTIVITY_TIMEOUT = task_timeout['activity_timeout']
        if 'battery_timeout' in task_timeout:
            self.BATTERY_TIMEOUT = task_timeout['battery_timeout']
        if 'heart_rate_timeout' in task_timeout:
            self.HEART_RATE_TIMEOUT = task_timeout['heart_rate_timeout']
        if 'check_time_timeout' in task_timeout:
            self.CHECK_TIME_TIMEOUT = task_timeout['check_time_timeout']

        self.notifications = notifications
        self.discover_task = DiscoverTask(devices)

    def tick(self):
        # at start & periodically: run a device discovery
        if self.discover_task.shall_run(self.DISCOVER_TIMEOUT):
            self.runner.add_task(self.discover_task.enqueue())

        # for every 'online' device...
        for d in self._get_online_devices():
            if d.shall_update_static():
                self.runner.add_task(RunFunctionTask(d, 'update_static'))

            if d.shall_update_time(self.CHECK_TIME_TIMEOUT):
                self.runner.add_task(RunFunctionTask(d, 'update_time'))

            if d.shall_update_activity(self.ACTIVITY_TIMEOUT):
                self.runner.add_task(RunFunctionTask(d, 'update_activity'))

            if d.shall_update_battery_info(self.BATTERY_TIMEOUT):
                self.runner.add_task(RunFunctionTask(d, 'update_battery_info'))

            if d.shall_update_steps(self.ACTIVITY_TIMEOUT):
                self.runner.add_task(RunFunctionTask(d, 'update_steps'))

            if d.shall_update_heart_rate(self.HEART_RATE_TIMEOUT):
                self.runner.add_task(RunFunctionTask(d, 'update_heart_rate'))

        if len(self._get_online_devices()) > 0:
            for notification in self.notifications:
                if notification.shall_run():
                    self.runner.add_task(notification.enqueue())

    def _get_online_devices(self):
        return [v for v in self.devices.values() if v.status ==
                MiBandDevice.ST_ONLINE]


class MiBandDataCollector(LogMixin):
    name = "DataCollector"

    def __init__(self, args):
        LogMixin.__init__(self)
        self.args = args
        self.devices = {}

        if not os.path.exists(args.devices):
            raise RuntimeError(
                f"provided devices file ({args.devices}) not found")
        if not os.path.exists(args.config):
            raise RuntimeError(
                f"provided config file ({args.config}) not found")

        self.load_settings()
        self.load_devices()
        self.load_notifications()

    def load_settings(self):
        self.settings = Settings(self.args.config)
        psql_db.init(self.settings['db_name'],
                     user=self.settings['db_user'],
                     password=self.settings['db_passwd'],
                     host=self.settings['db_host'],
                     port=self.settings['db_port'])
        try:
            psql_db.connect()
            psql_db.create_tables([
                MiBandRecord,
                MiBandStaticInfo,
                ActivityRecord,
                BatteryInfoRecord,
                StepRecord,
                HeartRateRecord,
                NotificationRecord,
                SubscriberRecord
            ])
        except OperationalError as err:
            self.log.error(f" Could not connect the database server: {err}")
            sys.exit(-1)

        self.task_timeout = {}
        for timeout in ['discovery_timeout', 'activity_timeout',
                        'battery_timeout', 'heart_rate_timeout',
                        'check_time_timeout']:
            if timeout in self.settings.config:
                self.task_timeout[timeout] = self.settings[timeout]

        self.update_mode = MiBandDevice.UPDATE_MODE_ALWAYS
        if 'update_mode' in self.settings.config:
            if self.settings['update_mode'] in [
                    MiBandDevice.UPDATE_MODE_ALWAYS,
                    MiBandDevice.UPDATE_MODE_CHARGING]:
                self.update_mode = self.settings['update_mode']

        if self.update_mode == MiBandDevice.UPDATE_MODE_CHARGING:
            if 'discovery_timeout' in self.task_timeout.keys():
                self.task_timeout['battery_timeout'] = self.task_timeout['discovery_timeout']
            else:
                self.task_timeout['battery_timeout'] = TaskCoordinator.DISCOVER_TIMEOUT

    def load_devices(self):
        with open(self.args.devices) as src:
            for line in src.readlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    bid, mac, token = map(str.strip, line.split("|"))
                    token = bytes.fromhex(token)
                    self.devices[mac] = MiBandDevice(
                        f"mi band {bid}", mac, token, self.update_mode)
                except ValueError:
                    self.log.warning(f" invalid format in line: {line}")

    def load_notifications(self):
        self.notifications = []
        present = []
        if 'notifications' in self.settings.config:
            for ntype, nsubs in self.settings.config['notifications'].items():
                if ntype not in ['update_state']:
                    self.log.error(
                        f" unknown notification type in settings: {ntype}")
                    continue
                elif isinstance(nsubs, str):
                    nsubs = [{'address': nsubs}]
                elif isinstance(nsubs, dict):
                    nsubs = [nsubs]
                elif not isinstance(nsubs, list):
                    self.log.error(
                        f" unknown subscriber definition in settings: {nsubs}")
                    continue

                for sub in nsubs:
                    if isinstance(sub, str):
                        sub = {'address': sub}
                    elif 'address' not in sub.keys():
                        self.log.error(
                            f" not found 'address' in sub in settings: {sub}")
                        continue

                    subscribers = sub.pop('address')
                    if isinstance(subscribers, str):
                        subscribers = [subscribers]

                    if ntype == 'update_state':
                        try:
                            nobj = NotifyUpdateStateTask(
                                subscribers, self.devices.values(), **sub
                            )
                        except Exception as err:
                            self.log.error(
                                f' notification could not be created. More information: {err}')
                        else:
                            if nobj in self.notifications:
                                self.log.warning(
                                    f' found notification with same params. Using last declaration.')
                            else:
                                self.notifications.append(nobj)
                                present.append(nobj.id)

        for record in NotificationRecord.select().where(
                NotificationRecord.sender == get_host_mac()):
            if record.id not in present:
                record.delete_instance()

    def run(self):
        runner = TaskRunner()
        coord = TaskCoordinator(
            runner, self.devices,
            self.task_timeout,
            self.notifications)

        while True:
            try:
                coord.tick()
                time.sleep(1)
            except KeyboardInterrupt:
                self.log.info(" interrupt received, exiting...")
                break


if __name__ == "__main__":
    logging.debug('debug init')

    parser = ArgumentParser()
    parser.add_argument(
        "-d",
        "--devices",
        default="devices.csv",
        help="CSV file (using | as separator) with the list of managed devices")
    parser.add_argument("-c", "--config", default="settings.json",
                        help="configuration file for this service")

    _args = parser.parse_args()
    if os.getuid() != 0:
        print("CRITICAL: User is not root")
        sys.exit(-1)
    MiBandDataCollector(_args).run()
