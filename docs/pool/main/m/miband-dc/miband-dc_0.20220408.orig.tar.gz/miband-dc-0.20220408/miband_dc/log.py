import datetime
import gzip
import logging
import logging.handlers
import os.path
import shutil
import sys
from functools import cache
from os import mkdir

logging.basicConfig(level=logging.WARNING)


def rotate_and_compress(source, dest) -> None:
    """When rotating, rotate and compress the current log.

    :param source: The source filename. This is normally the base
                    filename, e.g. 'test.log'
    :param dest:   The destination filename. This is normally
                    what the source is rotated to, e.g. 'test.log.1'.
    """
    if os.path.exists(source):
        with open(source, 'rb') as f_in:
            with gzip.open(dest + '.gz', 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)


class ErrFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return record.levelno >= logging.ERROR


class OutFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return record.levelno < logging.ERROR


class TimedRotatingGZipFileHandler(logging.handlers.TimedRotatingFileHandler):
    def rotate(self, source: str, dest: str) -> None:
        """When rotating, rotate and compress the current log.

        :param source: The source filename. This is normally the base
                        filename, e.g. 'test.log'
        :param dest:   The destination filename. This is normally
                        what the source is rotated to, e.g. 'test.log.1.gz'.
        """
        if os.path.exists(source) and dest.endswith('.gz'):
            with open(source, 'rb') as f_in:
                with gzip.open(dest, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)

    def rotation_filename(self, default_name: str) -> str:
        return super().rotation_filename(default_name) + '.gz'


@cache
def get_or_create_logger(name: str, verbose: int,
                         use_stdout: bool, use_syslog: bool,
                         use_filelog: bool, filelog_dir: str = '/var/log/miband-dc',
                         filelog_filename: str = 'miband-dc') -> logging.Logger:
    """Create a Logger with specific configuration.

    :param str name: Logger name
    :param int verbose: Verbosity level: 0 =Quiet, 1 =Errors, 2 =Normal, 3+ =Debug.
    :param bool use_stdout: Add standard output handler
    :param bool use_syslog: Add syslog handler
    :param bool use_filelog: Add filelog handler
    :param str filelog_dir: If use_filelog is True, sets output directory, defaults to '/var/log/miband-dc'
    :param str filelog_filename: If use_filelog is True, sets output filename, defaults to 'miband-dc'
    :return logging.Logger
    """
    l = logging.getLogger(name)
    l.propagate = False

    # Verbosity
    if verbose < 0:
        logging.disable()
    elif verbose == 0:
        l.setLevel(logging.WARNING)
    elif verbose == 1:
        l.setLevel(logging.INFO)
    else:
        l.setLevel(logging.DEBUG)

    # Standard output handlers
    if use_stdout:
        std_out_hdl = logging.StreamHandler(sys.stdout)
        std_out_hdl.addFilter(OutFilter())
        std_out_hdl.setFormatter(logging.Formatter(
            fmt='%(levelname)s %(message)s'))
        l.addHandler(std_out_hdl)

        std_err_hdl = logging.StreamHandler(sys.stderr)
        std_err_hdl.addFilter(ErrFilter())
        std_err_hdl.setFormatter(logging.Formatter(
            fmt='%(levelname)s %(filename)s:%(lineno)d ' +
                '%(message)s'))
        l.addHandler(std_err_hdl)

    # Syslog handler
    if use_syslog:
        syslog_hdl = logging.handlers.SysLogHandler(
            address='/dev/log')
        syslog_hdl.addFilter(ErrFilter())
        syslog_hdl.setLevel(logging.INFO)  # Never debug
        syslog_hdl.setFormatter(logging.Formatter(
            fmt='%(levelname)s %(filename)s:%(lineno)d ' +
                '%(message)s'))
        l.addHandler(syslog_hdl)

    # Filelog handler
    if use_filelog:
        if not os.path.exists(filelog_dir):
            mkdir(filelog_dir)

        filelog_hdl = TimedRotatingGZipFileHandler(
            filename=os.path.join(filelog_dir, filelog_filename),
            when='W6', atTime=datetime.time(12, 0, 0),
            backupCount=2, encoding='utf-8')
        filelog_hdl.setLevel(logging.INFO)  # Never debug
        filelog_hdl.setFormatter(logging.Formatter(
            fmt='%(asctime)s %(levelname)s %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'))
        l.addHandler(filelog_hdl)

    return l


class LogMixin:
    def __init__(self, name: str = None,
                 level: int = 0,
                 use_stdout: bool = True,
                 use_syslog: bool = False,
                 use_filelog: bool = False) -> None:
        self.name = self.__class__.__name__ if not name else name
        self.level = level
        self.use_stdout = use_stdout
        self.use_syslog = use_syslog
        self.use_filelog = use_filelog
        self.log = get_or_create_logger(
            name=self.name, verbose=self.level,
            use_stdout=self.use_stdout, use_syslog=self.use_syslog,
            use_filelog=self.use_filelog)
