# miband-dc - MiBand data collector

This is a Python 3 script (and system service) which
collects data from Xiaomi MiBand4, previously configured,
and stores it on a provided postgresql database.

## Installation

```shell
$ sudo apt-get install miband-dc
```

## Configuration

There is a JSON settings file on the path `/etc/miband-dc` called `settings.json` which 
configures the program. It holds the **database connection parameters**, 
so it is important to check it out before running the daemon. This program **do not** create the databases **nor** the users.

Also, in the same path, there is the `devices.csv` file, which holds the 
configured devices to read from.

## Usage

Stop the service and modify configuration files. When finished, restart the program:

```shell
$ sudo systemctl stop miband-dc.service
[... Modify configuration files ...]
$ sudo systemctl restart miband-dc.service
```

This will start the daemon and collect the data from the devices 
in the `devices.csv` file.

Each time you change the configuration file, execute:
```shell
$ sudo systemctl restart miband-dc.service
```