# miband-dc - MiBand data collector

This is a Python 3 script (and system service) which
collects data from Xiaomi MiBand4, previously configured,
and stores it on a provided postgresql database.

## Installation

```shell
$ sudo apt-get install miband-dc
```

## Configuration

### Settings file

It is called `settings.json`, stored at `/etc/miband-dc`, and holds all settings that affects `miband-dc`. Every time you modify this file, restart `miband-dc` service to reload the settings.

Available configurarion parameters:

1. Database connection:

   a. (required) `db_name`: PostgreSQL database name (must exist before `miband-dc` is runned).   
   b. (required) `db_user`: OWNER of database (must exist before `miband-dc` is runned).   
   c. (required) `db_password`: Password for `db_user`.   
   d. (required) `db_host`: Host which holds the database.   
   e. (required) `db_port`: Port of `db_host` to connect to PostgreSQL.   

2. Tasks timeout:

   a. `discovery_timeout`: `Discovery` task must execute after elapsed specified time, in seconds. Default is 60.   
   b. `activity_timeout`: `Activity` and `Steps` task must execute after elapsed specified time, in seconds. Default is 3600 (1 hour).   
   c. `battery_timeout`: `Battery` task must execute after elapsed specified time, in seconds. Default is 900 (15 minutes).   
   d. `heart_rate_timeout`: `Heart Rate` task must execute after elapsed specified time, in seconds. Default is 300 (5 minutes).   
   e. `check_time_timeout`: `Check time` task must execute after elapsed specified time, in seconds. Default is 54000 (15 days).   

3. `notifications` (see [Notifications](#notifications) section): dictionary containing notifications configuration. 

   a. `update_state`: List of Update State notification subscribers. Subscribers are described as an object with the following parameters:

      * (required) `address`: List containing subscribers addresses, which can be `host:port` addresses, for TCP connection, or `email` addresses, for notification via email.   
      * `timeout`: `Notification Update State` must execute after elapsed specified time, specified as time expression. Default is '1m'.   
      * `timerange`: A device stored information will be considered outdated after this time, specified as time expression. Default is '1d'.   
      * `only_updatable`: Boolean. If true, notification will only notify about updatable devices (related to `update_mode` parameter). 

4. `update_mode`: Change `miband-dc` behaviour. Available choices are:

   a. `always`: Update devices information always, if can. This means that `miband-dc` will try to get all information for every online device every time it can.   
   b. `charging`: Only update devices information when they are charging. This mode pretends to simulate a `updating station`, where users leave their devices charging while data is being stored, resulting in a less aggressive communication. In this mode, `Heart Rate` tasks won´t be executed, as the user won´t wear the device, thus making imposible to read heart rate information.  

See also [Examples](#examples) section.

### Devices file

It is called `devices.csv`, stored at `/etc/miband-dc`, and holds all the devices from `miband-dc` will collect information. Every time you modify this file, restart `miband-dc` service to reload the configured devices.

There is a line for each device, and follows the pattern: `id | mac | token`.

Visit [this post](https://arcogroup.bitbucket.io/shapes/integrating_miband_with_smart_mirror/#devices) to know more about configuring MiBand devices for miband-dc.

## Usage

Stop the service and modify configuration files. When finished, restart the program:

```shell
$ sudo systemctl stop miband-dc.service
[... Modify configuration files ...]
$ sudo systemctl restart miband-dc.service
```

This will start the daemon and collect the data from the devices 
in the `devices.csv` file.

Each time you change the configuration file, execute:
```shell
$ sudo systemctl restart miband-dc.service
```

## Notifications

`miband-dc` stores all data colected in a PostgreSQL database, but it can also notify the user about extracted information for that data using several mechanisms, in real time. Those notifying methods are:

1. TCP socket connections.   
2. Email.

Currently there are available these notification types:

1. Devices update state (`update_state`):

   a. TCP socket type: Sends a binary package representing whether the devices have their collected data outdated or not. Its format is:

      ```
      number_of_devices (4B) +  [ MAC (6B) + updated (1B) ] * number_of_devices

      Where MAC is an hex number representing the device address, and updated is a boolean (1 when updated and 0 when not).
      ```

   b. Email type: Sends an email with a list of outdated devices. An example is:

      ```
      Hi! The following devices have their data outdated:

        - E3:49:01:ED:00:A6

      Until next time!
      ``` 

This is configured in `settings.json` (see `notifications` subsection in [Settings file](#settings-file) section).

`miband-dc` stores all data collected in a PostgreSQL database, but it can also notify other running processes about extracted information from that collected data, in real time.

## Examples

### 1. Test every feature. 

```json
{
    "db_name": "miband-dc",
    "db_user": "root",
    "db_passwd": "D45g5gllojdf9",
    "db_host": "localhost",
    "db_port": 5432,

    "discovery_timeout": 300,

    "update_mode": "all",
    "notifications": {
        "update_state": [
            {
               "address": ["name@example.com"],
               "timeout": "4d"
            },
            {
               "address": ["localhost:8465"]
            }
        ]
    }
}
```

With this configuration `miband-dc` will:

1. Use the specified database with the provided connection parameters.   
2. Execute `DiscoveryTask` every 5 minutes.   
3. Update the data of every discoverable device.   
4. Notify, about update state of devices, *name@example.com* every 4 days, and *localhost:8465* every minute via TCP sockets.