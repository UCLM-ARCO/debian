miband-dc(1) -- Data collector for Xiaomi MiBand4
===

## SYNOPSIS

  miband-dc [-d|--devices devices_file] [-c|--config configuration_file]

## DESCRIPTION

  See https://bitbucket.org/arco_group/prj.shapes/src/master/src/miband-dc/README.md

## AUTHOR

  Oscar Aceña Herrera (oscar.acena@gmail.com)

## COPYRIGHT

  Copyright © 2020 Oscar Aceña

  This manual page was written for the Debian system (and may be used by
  others).

  Permission is granted to copy, distribute and/or modify this document
  under the terms of the GNU General Public License, Version 2 or (at
  your option) any later version published by the Free Software
  Foundation.

  On Debian systems, the complete text of the GNU General Public License
  can be found in /usr/share/common-licenses/GPL.