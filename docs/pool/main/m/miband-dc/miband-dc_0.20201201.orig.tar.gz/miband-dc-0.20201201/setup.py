from setuptools import find_packages, setup

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name='miband-dc',
    packages=find_packages(),
    version='0.20201201',
    description='Python script to collect data from Xiaomi activity bands.',
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Oscar Acena Herrera",
    author_email="oscaracena@gmail.com",
    license='Apache-2.0',
    install_requires=['miband', 'peewee', 'psycopg2'],
    setup_requires=[],
    python_requires='>=3.8',
    scripts=['miband-dc'],
    package_data={'miband-dc': ['README.md']},
    data_files=[('share/miband-dc', ['devices.csv', 'settings.json'])],
)