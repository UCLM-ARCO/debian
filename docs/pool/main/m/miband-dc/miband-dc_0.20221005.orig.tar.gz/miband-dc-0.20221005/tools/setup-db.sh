#!/bin/bash

# This script will setup two users, named USER_rd and USER_wr, with the correct
# permissions on a given DB, to be ready for miband-dc and grafana services.
#
# For testing and devel, you may create a file called 'admin-pass' with the
# user admin password inside. Remember to delete it when finished!

ADMIN_USER="doadmin"
SERVER="$1"
DB_NAME="$2"
USER_NAME="$3"

if [ -z "$SERVER" -o -z "$DB_NAME" -o -z "$USER_NAME" ]; then
	echo "Usage: $0 <db-host> <db-name> <user-name>"
	exit 1
fi

# remember to delete 'admin-pass' file!!
if [ -f "admin-pass" ]; then
	admin_pwd=$(cat admin-pass)
else
	read -s -p "${ADMIN_USER} password: " admin_pwd
fi

psql -a "postgresql://${ADMIN_USER}:${admin_pwd}@${SERVER}/${DB_NAME}?sslmode=require" << EOF

	-- set permissions on read-only user
	REVOKE ALL ON DATABASE ${DB_NAME} FROM ${USER_NAME}_rd;
	GRANT CONNECT ON DATABASE ${DB_NAME} TO ${USER_NAME}_rd;
	GRANT SELECT ON ALL TABLES IN SCHEMA public TO ${USER_NAME}_rd;

	-- FIXME: I think that REVOKE as default is better
	-- ALTER DEFAULT PRIVILEGES IN SCHEMA public
    --	GRANT SELECT ON TABLES TO ${USER_NAME}_rd;
	ALTER DEFAULT PRIVILEGES IN SCHEMA public
        REVOKE SELECT ON TABLES FROM ${USER_NAME}_rd;

	-- set permissions on read-and-write user
	REVOKE ALL ON DATABASE ${DB_NAME} FROM ${USER_NAME}_wr;
	GRANT CONNECT ON DATABASE ${DB_NAME} TO ${USER_NAME}_wr;
	GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO ${USER_NAME}_wr;
	ALTER DEFAULT PRIVILEGES IN SCHEMA public
		GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO ${USER_NAME}_wr;
	ALTER DATABASE ${DB_NAME} OWNER TO ${USER_NAME}_wr;

EOF
