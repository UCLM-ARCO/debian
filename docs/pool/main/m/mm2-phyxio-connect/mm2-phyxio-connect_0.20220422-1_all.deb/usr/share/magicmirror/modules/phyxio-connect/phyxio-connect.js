Module.register('phyxio-connect', {
    defaults: {
        fgColor: '#333333',
        bgColor: '#6da849',
    },

    onOpen: function () {
        this.phyxioWindow = window.open(
            'https://phyx.io/account/login/',
            '_blank', [
                'height=' + screen.height,
                'width=' + screen.width,
                'fullscreen=yes' // only works in IE, but here for completeness
            ].join(','))
        this.phyxioWindow.moveTo(0, 0)
        this.checkCloseInterval = setInterval(() => {
            if (this.phyxioWindow.closed)
                this.onClose()
        }, 1000)

        // Notify loginservice
        let ls = MM.getModules().withClass('loginservice')[0]
        if (ls != undefined)
            ls.notificationReceived(
                'PHYXIO_OPENED', {}, this)
    },

    onClose: function () {
        this.phyxioWindow = null
        clearInterval(this.checkCloseInterval)
        this.checkCloseInterval = null

        // Notify loginservice
        let ls = MM.getModules().withClass('loginservice')[0]
        if (ls != undefined)
            ls.notificationReceived(
                'PHYXIO_CLOSED', {}, this)
    },

    start: function () {
        this.phyxioWindow = null
        this.checkCloseInterval = null
    },

    getDom: function () {
        let dom = document.createElement('div')
        dom.className = 'wrapper wrapper-' +
            this.data.position.replace('_', '-')

        let button = document.createElement('button')
        button.className = 'button medium'
        button.textContent = this.translate('button-text')
        button.style = 'color: ' + this.config.fgColor +
            '; background: ' + this.config.bgColor + ';'

        var self = this
        button.onclick = function () {
            self.onOpen()
        }

        dom.appendChild(button)
        return dom
    },

    getStyles: function () {
        return [
            'font-awesome.css',
            this.file('css/phyxio-connect.css')
        ]
    },

    getTranslations: function () {
        return {
            es: 'translations/es.json',
            en: 'translations/en.json'
        }
    },
})