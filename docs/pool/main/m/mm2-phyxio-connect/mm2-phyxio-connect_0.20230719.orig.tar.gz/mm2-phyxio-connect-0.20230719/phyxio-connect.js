Module.register('phyxio-connect', {
    defaults: {
        fgColor: '#333333',
        bgColor: '#6da849',
    },

    requestUserForOpening: function() {
        this.sendNotification('GET_PHYXIO_USER', {})
    },

    notificationReceived: function (notification, payload, sender) {
        if (notification === 'GET_PHYXIO_USER') {
            if (payload == null) {
                console.error(this.name + ': User is not logged!')
                return
            }
            this.onOpen(payload, sender);
        }
    },

    onOpen: function (uidArgs, loginservice) {
        let url = 'https://phyx.io/account/login?fmode=totem&uid=' + btoa(JSON.stringify(uidArgs))
        this.phyxioWindow = window.open(
            url, '_blank', [
                'height=' + screen.height,
                'width=' + screen.width,
                'fullscreen=yes' // only works in IE, but here for completeness
            ].join(','))
        this.phyxioWindow.moveTo(0, 0)
        this.checkCloseInterval = setInterval(() => {
            if (this.phyxioWindow.closed)
                this.onClose.bind(this, loginservice)()
        }, 1000)

        // Notify loginservice
        loginservice.notificationReceived(
            'PHYXIO_OPENED', {}, this)
    },

    onClose: function (loginservice) {
        this.phyxioWindow = null
        clearInterval(this.checkCloseInterval)
        this.checkCloseInterval = null

        // Notify loginservice
        loginservice.notificationReceived(
            'PHYXIO_CLOSED', {}, this)
    },

    start: function () {
        this.phyxioWindow = null
        this.checkCloseInterval = null
    },

    getDom: function () {
        let dom = document.createElement('div')
        dom.className = 'wrapper wrapper-' +
            this.data.position.replace('_', '-')

        let button = document.createElement('button')
        button.id = 'phyxio-button'
        button.className = 'button medium'
        button.textContent = this.translate('button-text')
        button.style = 'color: ' + this.config.fgColor +
            '; background: ' + this.config.bgColor + ';'

        var self = this
        button.onclick = function () {
            self.requestUserForOpening()
        }

        dom.appendChild(button)
        return dom
    },

    getStyles: function () {
        return [
            'font-awesome.css',
            this.file('css/phyxio-connect.css')
        ]
    },

    getTranslations: function () {
        return {
            es: 'translations/es.json',
            en: 'translations/en.json',
            pt: 'translations/pt.json',
            el: 'translations/el.json'
        }
    },
})