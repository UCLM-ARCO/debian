var NodeHelper = require("node_helper");
const os = require('os');

module.exports = NodeHelper.create({
	start: function() {
        var self = this;
        var net_connected;


	setTimeout(function() {
        var networkInterfaces = os.networkInterfaces();
        var ip = networkInterfaces['wlan0'];

        if(ip == null || ip[0].address == '192.168.4.1') {
            console.log('[NodeHelper] disconnected');
            net_connected = 0;
        } else {
            console.log('[NodeHelper]', ip[0].address);
            net_connected = 1;
        }

	console.log("Enviando " + net_connected);
        self.sendSocketNotification("NET_INFO", {net_connected: net_connected})  	
	}, 10000); 
	},

})
