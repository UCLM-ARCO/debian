import os
from flask_wtf import FlaskForm
from wtforms import PasswordField, SelectField
from wtforms.validators import DataRequired, Length

def clean_ssid_list(ap_ssid):
    ap_ssid = ap_ssid.replace(" ", "")
    ap_ssid = ap_ssid.replace("ESSID:", "")
    ap_ssid = ap_ssid.replace('"', '')
    return ap_ssid

def get_detected_ssids():
    scanprocess = os.popen("sudo iwlist scan | grep SSID")
    scanprocess_return = scanprocess.read()

    ap_list = list(set(scanprocess_return.split("\n")))
    ap_list = list(map(clean_ssid_list, ap_list))
    ap_list = [(ssid, ssid) for ssid in ap_list if ssid != ""]
    return ap_list

class WifiForm(FlaskForm):
    ssid = SelectField('SSID', validators=[DataRequired()], choices=get_detected_ssids())
    password = PasswordField('Password', validators=[DataRequired(), Length(max=64, min=8)])
    
    def __init__(self, *args, **kwargs):
        super(WifiForm, self).__init__(*args, **kwargs)
        WifiForm.ssid.choices = get_detected_ssids()