Module.register('MMM-GrafanaEmbed', {
    defaults: {
        host: 'localhost',
        port: 3000,
        orgId: 1,
        time_interval: '7d',
        refresh: '5m',
        width: '25vw',
        height: '20vh',
        orientation: 'row'
    },

    start: function () {
        this.urls = []

        if (this.config.orientation !== 'row' && this.config.orientation !== 'column')
            this.config.orientation = 'row'

        this.sendSocketNotification('GRAFANA_SET_DASHBOARD', {
            id: this.config.id,
            name: this.config.name,
            user: this.config.user,
            host: this.config.host,
            port: this.config.port,
            orgId: this.config.orgId,
            from: 'now-' + this.config.time_interval,
            to: 'now',
            refresh: this.config.refresh,
            panels: this.config.panels
        })
    },

    getStyles: function () {
        return [
            this.file('MMM-GrafanaEmbed.css')
        ]
    },

    getDom: function () {
        var wrapper = document.createElement('div')
        wrapper.className = 'grafana-' + this.config.orientation

        this.urls.forEach(url => {
            var panel_wrapper = document.createElement('div')
            panel_wrapper.className = 'grafana-item'

            var panel_element = document.createElement('iframe')
            panel_element.src = url
            panel_element.className = 'grafana-panel'
            panel_element.style.width = this.config.width
            panel_element.style.height = this.config.height

            panel_wrapper.appendChild(panel_element)
            wrapper.appendChild(panel_wrapper)
        })
        return wrapper;
    },

    getHeader: function () {
        if (this.data.header == undefined) {
            return 'User activity'
        }
        return this.data.header
    },

    notificationReceived: function (notification, payload, sender) {
        if (notification === 'GRAFANA_CHANGE_USER')
            this.sendSocketNotification(notification, payload)
        else if (notification === 'GRAFANA_CHANGE_ID')
            this.sendSocketNotification(notification, payload)
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification === 'GRAFANA_PANELS_CHANGED') {
            this.urls = payload
            this.updateDom()
        }
    }
});
