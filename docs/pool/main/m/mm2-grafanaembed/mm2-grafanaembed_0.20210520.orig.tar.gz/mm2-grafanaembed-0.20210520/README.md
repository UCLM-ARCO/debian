# MMM-GrafanaEmbed

A [MagicMirror²](https://magicmirror.builders/) module for displaying graphs and charts using [Grafana](https://grafana.com/). It is needed a running Grafana instance for this module to work. You can install Grafana following its [official documentation](https://grafana.com/docs/grafana/latest/installation/).

## Screenshots

![MMM-GrafanaEmbed screenshot](/public/mmm-grafanaembed.png)

## Installation

```shell
pi@raspberry:/path/to/MagicMirror/modules/$ git clone https://bitbucket.org/arco_group/mmm-grafanaembed.git MMM-GrafanaEmbed
```

To install it with Debian package `magic-mirror-2`:

```shell
pi@raspberry:~/$ sudo apt install mm2-grafanaembed
```

## Configuration

### Grafana

```ini
[auth.anonymous]
enabled = true

[security]
allow_embbeding = true
```

### Magic Mirror

```js
modules: [
    {
        module: 'MMM-GrafanaEmbed',
        position: 'top_left',
        config: {
            // See bellow options
        }
    }
]
```

All configuration options are:

| Option | Type | Default | Description |
|-|-|-|-|
| `host` | string | localhost | IP address of the host running Grafana |
| `port` | integer | 3000 | Port where Grafana service is running |
| `dash_id` | string | **REQUIRED** | Dashboard id of the one to access to |
| `dash_name` | string | **REQUIRED** | Dashboard name of the one to access to |
| `dash_orgId` | int | 1 | Dashboard provider orgId |
| `dash_refresh` | time expression\* | 5m | Time interval to refresh panels info |
| `dash_interval` | time expression\* | 7d | Time interval, since specified expression until now, applied to the graphs |
| `dash_username` | string | unknown user | Name of the user which owns graphs data  |
| `panels` | list<integer> | **REQUIRED** | List of panel ids to load from dashboard |
| `width` | length\*\* | 25vw | Panels desired width |
| `height` | length\*\* | 20vw | Panels desired height |
| `orientation` | string | row | Displays panels following orientation. Choices are: row, column |


\* A time expression is a string composed by a number and a letter, representing a quantity and a timespan, respectively. Choices for the timespan are: `s` (seconds), `m` (minutes), `h` (hours) and `d` (days). For example, five minutes are expressed as `5m`.

\*\* Length format follows CSS \<length\> data type. For more information visit [Mozilla Developer page about \<length\>](https://developer.mozilla.org/es/docs/Web/CSS/length).

## FAQ

**1. Where is my dashboard and panel information?**

   There are two diferent type of files when provisioning dashboards to Grafana:

   * Dashboard providers: located on which is [Grafana provisioning path](https://grafana.com/docs/grafana/latest/administration/configuration/#provisioning). This holds the `dash_orgId` parameter as `orgId`, and where to look for dashboards definitions with `path` parameter. See [this page](https://grafana.com/docs/grafana/latest/administration/provisioning/#dashboards) for an example of this file.
   
   * Dashboard definitions: This are JSON files, and they hold `dash_id`, as `uid`, and `dash_name`, as `title`, on the first level object. Then, inside the list `panels`, you can find `panel_id` for each panel object found on it. You can get the JSON definition of a dashboard through the Grafana UI with Share Dashboard > Export > View JSON.
