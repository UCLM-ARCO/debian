var NodeHelper = require("node_helper");
const dashboard = require('./dashboard.js')

module.exports = NodeHelper.create({
    start: function () {
        this.dashboard = undefined
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification === 'GRAFANA_SET_DASHBOARD') {
            if (payload.user != undefined)
                this.dashboard = new dashboard.MiBandDashboard(
                    payload.user,
                    payload.host,
                    payload.port,
                    payload.orgId,
                    payload.from,
                    payload.to,
                    payload.refresh
                )
            else if (payload.id != undefined && payload.name != undefined)
                this.dashboard = new dashboard.Dashboard(
                    payload.id,
                    payload.name,
                    payload.host,
                    payload.port,
                    payload.orgId,
                    payload.from,
                    payload.to,
                    payload.refresh
                )
            else {
                console.error(this.name + ': Invalid configuration. It is required either an user id or dashboard id and name.')
                this.dashboard = undefined
            }

            if (this.dashboard != undefined) {
                payload.panels.forEach(panel_id => {
                    let result = this.dashboard.add_panel(panel_id)
                    if (result > 0)
                        console.warning(this.name + ': Panel ' + panel_id + ' not loaded due to error "' + this.dashboard.get_message(result) + '"')
                })
                this.sendSocketNotification('GRAFANA_PANELS_CHANGED', this.dashboard.urls)
            }
        } else if (notification === 'GRAFANA_CHANGE_ID' || notification === 'GRAFANA_CHANGE_USER') {
            if (this.dashboard == undefined) {
                console.error(this.name + ': Cannot change if dashboard is not setted first')
                return
            }

            if (notification === 'GRAFANA_CHANGE_ID') {
                if (payload.id == undefined || payload.name == undefined) {
                    console.error(this.name + ': Payload must be an object with the following properties: id, name')
                    return
                } else if (this.dashboard instanceof dashboard.Dashboard) {
                    this.dashboard.id = payload.id
                    this.dashboard.name = payload.name
                } else {
                    var panels = this.dashboard.panels
                    this.dashboard = new dashboard.Dashboard(
                        payload.id,
                        payload.name,
                        this.dashboard.host,
                        this.dashboard.port,
                        this.dashboard.orgId,
                        this.dashboard.from,
                        this.dashboard.to,
                        this.dashboard.refresh
                    )
                    panels.forEach(panel => {
                        this.dashboard.add_panel(panel)
                    })
                }
            } else {
                if (typeof payload !== 'number') {
                    console.error(this.name + ': Payload must be a number')
                    return
                } else if (this.dashboard instanceof dashboard.MiBandDashboard) {
                    this.dashboard.user = payload
                } else {
                    var panels = this.dashboard.panels
                    this.dashboard = new dashboard.MiBandDashboard(
                        payload,
                        this.dashboard.host,
                        this.dashboard.port,
                        this.dashboard.orgId,
                        this.dashboard.from,
                        this.dashboard.to,
                        this.dashboard.refresh
                    )
                    panels.forEach(panel => {
                        this.dashboard.add_panel(panel)
                    })
                }
            }

            console.log(this.name + ': Dashboard changed to ' + this.dashboard.id)
            this.sendSocketNotification('GRAFANA_PANELS_CHANGED', this.dashboard.urls)
        }
    }
});
