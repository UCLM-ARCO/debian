const uuidgen = require('/usr/lib/nodejs/uuid/v3.js')

const uuidgen_namespace = 'a0a50c9e-6556-48a1-8bd9-dd9cb4384d5c'
const uuidgen_name = 'miband-grafana_dev{user}.json'
const dashboard_name = 'mi-band-data-user-{user}'

class Panel {
    id = undefined
    #dashboard = undefined

    constructor(id, dashboard) {
        this.id = id
        this.#dashboard = dashboard
    }

    get id() {
        return this.id
    }

    get url() {
        return this.#dashboard.baseurl +
            '&panelId=' + this.id
    }
}

class Dashboard {
    #panels = {}

    constructor(id, name, host, port, orgId, from, to, refresh) {
        this.id = id
        this.name = name
        this.orgId = orgId
        this.host = host
        this.port = port
        this.from = from
        this.to = to
        this.refresh = refresh
    }

    get baseurl() {
        return 'http://' + this.host + ':' + this.port +
            '/d-solo/' + this.id + '/' + this.name +
            '?orgId=' + this.orgId +
            '&refresh=' + this.refresh +
            '&from=' + this.from +
            '&to=' + this.to
    }

    get panels() {
        return Object.keys(this.#panels)
    }

    get urls() {
        var retval = []
        Object.values(this.#panels).forEach(panel => {
            retval.push(panel.url)
        })
        return retval
    }

    get_message(id) {
        switch (id) {
            case 0:
                return 'Success'
            case 1:
                return 'Panel id must be a number'
            case 2:
                return 'Panel id not valid'
            case 3:
                return 'Panel is shown already'
            case 4:
                return 'Panel is not present'
            default:
                return undefined
        }
    }

    add_panel(panel_id) {
        if (typeof panel_id === 'string')
            panel_id = parseInt(panel_id)
        else if (typeof panel_id !== 'number')
            return 1

        if (isNaN(panel_id))
            return 2

        if (Object.keys(this.#panels).includes(panel_id))
            return 3

        this.#panels[panel_id] = new Panel(panel_id, this)
        return 0
    }

    remove_panel(panel_id) {
        if (typeof panel_id === 'string')
            panel_id = parseInt(panel_id)
        else if (typeof panel_id !== 'number')
            return 1

        if (isNaN(panel_id))
            return 2

        if (!Object.keys(this.#panels).includes(panel_id))
            return 4

        delete this.#panels[panel_id]
        return 0
    }
}

class MiBandDashboard extends Dashboard {
    #user = undefined
    
    constructor(user_id, host, port, orgId, from, to, refresh) {
        var _id = uuidgen(
            uuidgen_name.replace('{user}', user_id),
            uuidgen_namespace)
        var _name = dashboard_name.replace('{user}', user_id)

        super(_id, _name, host, port, orgId, from, to, refresh)
        this.#user = user_id
    }

    get user() {
        return this.#user
    }

    set user(user_id) {
        this.#user = user_id
        this.id = uuidgen(
            uuidgen_name.replace('{user}', user_id),
            uuidgen_namespace)
        this.name = dashboard_name.replace('{user}', user_id)
    }
}

module.exports = {
    Dashboard: Dashboard,
    MiBandDashboard: MiBandDashboard
}