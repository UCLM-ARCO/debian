with sleep_record as (
    select ts,
        case 
            when category > 112 then 'Deep Sleep'
            when category = 112 then 'Light Sleep'
            else 'Awake'
        end category 
    from activityrecord
    where dev_id = 10
        and ts >= timestamp '2021-04-03T00:00:00Z'
        and ts <= timestamp '2021-04-10T23:59:59Z'
        and (ts::time >= time '23:00:00' or ts::time <= time '09:00:00')
)
select category, 
    extract(epoch from count(category) * interval '1m')/3600 as "hours"
from sleep_record
group by category;