# miband-grafana - Grafana provision for `miband-dc` stored data

Creates, and modifies existing, configuration files
for Grafana instance to get `miband-dc` data from
configured database. Based on configuration file.

## Install

```shell
user@user-pc:~/$ sudo apt-key adv --fetch-keys https://uclm-arco.github.io/debian/key.asc
user@user-pc:~/$ sudo apt update
user@user-pc:~/$ sudo apt install miband-grafana
```
## Usage

Edit the configuration file with `sudo miband-grafana -e` with the right values and execute:

```shell
user@user-pc:~/$ sudo miband-grafana -u
Database checked!
Done updating!
user@user-pc:~/$ sudo miband-grafana -s
Datasource provider file at /etc/grafana/provisioning/datasources/miband-grafana.yaml
Dashboard provider file at /etc/grafana/provisioning/dashboards/miband-grafana.yaml
Found dashboard definition at /var/lib/grafana/dashboards/miband-grafana_dev1.json:
        Name: mi-band-data-user-1       UID: c9b38467-5d9a-3c27-918d-cfa1bd575db2
Available panels:
        ID: 11  Description: Steps per day
        ID: 12  Description: Steps today
        ID: 21  Description: Calories per day
        ID: 22  Description: Calories today
        ID: 31  Description: Heart rate
        ID: 32  Description: Heart rate today
        ID: 41  Description: Battery info
        ID: 51  Description: Sleep time
        ID: 52  Description: Sleep hours per day
        ID: 53  Description: Last night sleep
```

**NOTE:** The user provided on the configuration file **should have only** CONNECT and SELECT privileges as Grafana 
do not validate that queries are safe. 

## See also

miband-dc(1)   
miband-grafana(1)