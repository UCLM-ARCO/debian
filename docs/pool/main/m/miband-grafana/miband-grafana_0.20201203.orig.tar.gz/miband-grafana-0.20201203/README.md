# miband-grafana (DEB) - Grafana provision for MiBand data

Creates, and modifies existing, configuration files
for Grafana instance to get MiBand data from
configured database. Based on configuration file.

To change configuration just edit `/usr/share/miband-grafana/configuration.conf`
with the right values and execute `miband-grafana-update`.

## Install

```shell
user@user-pc:~/$ sudo apt-key adv --fetch-keys https://uclm-arco.github.io/debian/key.asc
user@user-pc:~/$ sudo apt update
user@user-pc:~/$ sudo apt install miband-grafana
```

## Build from source

```shell
user@user-pc:~/miband-grafana$ ian build -f
```

Install `ian` package from [ARCO repository](https://uclm-arco.github.io/debian).

## See also

ian(1)