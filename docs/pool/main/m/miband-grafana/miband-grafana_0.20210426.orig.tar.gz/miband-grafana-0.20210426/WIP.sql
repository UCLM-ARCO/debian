with sleep_time_range as (
    select datetime
    from generate_series(date '04-04-2021', date '04-11-2021', '1m') datetime
    where datetime::time >= time '23:00:00'
        or datetime::time <= time '09:00:00'
),
sleep_record as (
    select ts,
        category
    from activityrecord
    where dev_id = 10
        and category > 111
        and ts >= date '04-04-2021'
        and ts <= date '04-11-2021'
),
sleeping as (
    select case
            when datetime::time >= time '23:00:00' then datetime::date + interval '23h'
            when datetime::time <= time '09:00:00' then datetime::date - interval '1d' + interval '23h'
            else null
        end ts_start,
        datetime,
        category
    from sleep_time_range
        left outer join sleep_record on sleep_time_range.datetime = sleep_record.ts
    where category is not null
)
select ts_start::date as "date",
    category,
    count(category) * interval '1m' as "duration"
from sleeping
group by ts_start::date,
    category
order by ts_start::date, category;