#!/usr/bin/python3

import sys
import time
import datetime
import os
import csv
import argparse
from metamotion import MetaMotion, Method

root_dir = os.path.expanduser("~/metamotion_files")

def write_data_to_csv():
    if not os.path.exists(root_dir):
        os.makedirs(root_dir)

    timestamp = datetime.datetime.fromtimestamp(
        time.time()).strftime('%Y-%m-%d_%H:%M:%S')
    filename = root_dir + "/" + save_file + "_" + timestamp + ".csv"
    
    print("Writing all data to a csv")
    with open(filename, mode='a+') as csv_file:
        fieldnames = ['timestamp', 'acc_x', 'acc_y', 'acc_z',\
            'gyro_x', 'gyro_y', 'gyro_z']
        
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
        writer.writeheader()    
        for i in range(min(len(sensor.accelerometer.acc_log), len(sensor.gyroscope.rotation_log))):
            writer.writerow({
                'timestamp': sensor.accelerometer.acc_log[i][1],
                'acc_x': sensor.accelerometer.acc_log[i][0].x, 
                'acc_y': sensor.accelerometer.acc_log[i][0].y, 
                'acc_z': sensor.accelerometer.acc_log[i][0].z,
                'gyro_x': sensor.gyroscope.rotation_log[i][0].x, 
                'gyro_y': sensor.gyroscope.rotation_log[i][0].y, 
                'gyro_z': sensor.gyroscope.rotation_log[i][0].z,
                })
    os._exit(0)

def disconnection():
    print("An abrupt disconnection detected, some data will not be downloaded, download again after")
    write_data_to_csv()

parser = argparse.ArgumentParser()
parser.add_argument("mac", help="mac address of the metamotion sensor to be connected")
parser.add_argument("file", help="file name where the data will be saved")
args = parser.parse_args()

save_file = args.file

#### DOWNLOAD PART #####
sensor = MetaMotion(args.mac, method=Method.LOGGING)
sensor.connect()

sensor.setup_accelerometer(freq = 100)
sensor.setup_gyroscope(freq = 100)

sensor.stop_logging()
sensor.sync_host_with_device()
sensor.subscribe_anonymous_datasignals()

sensor.on_disconnect(disconnection)
sensor.download_logs()

sensor.wait_until_download_complete()
sensor.clean()
write_data_to_csv()

sensor.disconnect()
############################
