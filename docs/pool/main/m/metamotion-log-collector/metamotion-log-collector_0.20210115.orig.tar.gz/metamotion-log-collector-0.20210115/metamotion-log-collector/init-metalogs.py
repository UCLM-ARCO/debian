#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion, Method
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("mac", help="mac address of the metamotion sensor to be connected")
args = parser.parse_args()

#### INIT LOGS PART #####
sensor = MetaMotion(args.mac, method=Method.LOGGING)
sensor.connect()

sensor.setup_accelerometer(freq = 100)
sensor.setup_gyroscope(freq = 100)

sensor.gyroscope.setup_logger()
sensor.accelerometer.setup_logger()

sensor.start_logging()
sensor.disconnect()
