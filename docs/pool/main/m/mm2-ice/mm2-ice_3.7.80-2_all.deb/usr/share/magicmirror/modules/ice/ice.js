Module.register('ice', {
    getScripts: function () {
        return [this.file('Ice.min.js')]
    }
})