const logos = ["arco", "shapes", "uclm"]
const module_name = "mm2-shapes-logos"

Module.register(module_name, {
    getDom: function () {
        var wrapper = document.createElement("div")
        wrapper.className = "logos-wrapper"

        for (let i = 0; i < logos.length; i++) {
            var logo = document.createElement("img")
            logo.src = this.file("images/" + logos[i] + "-logo.png")
            wrapper.appendChild(logo)
        }

        return wrapper
    },

    getStyles: function () {
        return [
            this.file(module_name + ".css")
        ]
    }
})