# mm2-shapes-logos

Magic Mirror module for displaying ARCO-SHAPES Smart Mirror logos. 

## Configuration

```js
modules: [
    {
        module: "mm2-shapes-logos",
        position: "top_bar"
    }
]
```