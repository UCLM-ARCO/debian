var NodeHelper = require("node_helper");
const net = require('net');

function unpack_devices(pkg) {
    var devices = []
    var n = pkg.readUIntLE(0, 4)
    for (var i = 4; i < n * 7; i += 7) {
        var device = pkg.slice(i, i + 7)
        var device_mac = device.slice(0, 6).toString('hex')
        device_mac = device_mac.slice(0, 2) + ':' +
            device_mac.slice(2, 4) + ':' +
            device_mac.slice(4, 6) + ':' +
            device_mac.slice(6, 8) + ':' +
            device_mac.slice(8, 10) + ':' +
            device_mac.slice(10, 12)
        var device_updated = device.readUInt8(6) == 1
        var device_obj = {
            mac: device_mac,
            is_updated: device_updated
        }
        devices.push(device_obj)
    }
    devices.sort(function (a, b) {
        if (a.is_updated && !b.is_updated)
            return 1
        else if (!a.is_updated && b.is_updated)
            return -1
        else {
            if (a.mac < b.mac)
                return -1
            else if (a.mac > b.mac)
                return 1
            return 0
        }
    })
    return devices
}

module.exports = NodeHelper.create({
    socketNotificationReceived: function (notification, payload) {
        if (notification === 'BANDUPDATER_START_SERVER') {
            console.log('Listening in ' + payload.port)
            this.server.listen(payload.port, '127.0.0.1')
        }
    },

    start: function () {
        var self = this;
        this.server = net.createServer()
        this.server.on('connection', on_connection)

        function on_connection(conn) {
            function sendDevicesToFront(pkg) {
                self.sendSocketNotification(
                    "BANDUPDATER_UPDATE", unpack_devices(pkg)
                )
            }
            if (conn.remoteAddress !== "127.0.0.1") {
                conn.writeHead(403, { "Content-Type": "text/plain" })
                conn.write("403 Access denied")
                conn.end()
                return
            }
            conn.on('data', sendDevicesToFront)
        }
    },

    stop: function() {
        if (this.server.listening) {
            this.server.close()
        }
    }
})