
function create_device_element(mod, mac, is_updated) {
    var wrapper = document.createElement("div")
    wrapper.className = "band-wrapper"

    var icon = document.createElement("img")
    icon.className = "band-icon"
    if (is_updated) {
        icon.src = mod.file('icons/updated.png')
        icon.alt = 'updated'
    } else {
        icon.src = mod.file('icons/outdated.png')
        icon.alt = 'outdated'
    }
    wrapper.appendChild(icon)

    var address = document.createElement("span")
    address.className = "band-address"
    address.innerText = mac.toUpperCase()
    wrapper.appendChild(address)

    return wrapper
}

function create_dots_element() {
    var template = document.createElement('template')
    template.innerHTML = `<div class="band-wrapper" style="justify-content: center;">
    <span>...</span>
    </div>`.trim()
    return template.content.firstChild
}

var devices = []

Module.register("mm2-bandupdater", {
    defaults: {
        port: 8465,
        max_devices: 10
    },

    getDom: function () {
        var wrapper = document.createElement("div")
        wrapper.className = "mm2-bandupdater-wrapper"

        if (devices.length == 0) {
            wrapper.innerText = this.translate('info_no_data')
        } else {
            var date = document.createElement("span")
            date.className = "band-last-updated"
            date.innerText = this.last_updated.toLocaleString()
            wrapper.appendChild(date)

            var band_wrapper = document.createElement("div")
            band_wrapper.className = "band-module-wrapper"

            var n = devices.length
            if (n > this.config.max_devices)
                n = this.config.max_devices
            for (var i = 0; i < n; i++) {
                band_wrapper.appendChild(
                    create_device_element(this, devices[i].mac, devices[i].is_updated)
                )
            }

            if (devices.length > this.config.max_devices)
                band_wrapper.appendChild(create_dots_element())

            wrapper.appendChild(band_wrapper)
        }

        return wrapper
    },

    getHeader: function() {
        return this.translate('header_title')
    },

    getStyles: function () {
        return [
            this.file('css/mm2-bandupdater.css')
        ]
    },

    getTranslations: function () {
        return {
            en: "translations/en.json",
            es: "translations/es.json"
        }
    },

    start: function () {
        this.sendSocketNotification('SET_COMM')
        this.sendSocketNotification('BANDUPDATER_START_SERVER', { port: this.config.port })
        this.last_updated = new Date()
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification == "BANDUPDATER_UPDATE") {
            devices = payload
            this.last_updated = new Date()
            this.updateDom()
        }
    }

})