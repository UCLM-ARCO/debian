# mm2-bandupdater

A Magic Mirror module for displaying miband-dc devices update state. It is needed the miband-dc service up and running, with a hook to 'update state notification' (see [Configuration](#configuration)).


## Screenshots 
![mm2-bandupdater screenshot](public/screenshot.png)

## Installation

```shell
pi@raspberry:~/$ sudo apt install mm2-bandupdater
```

## Configuration

## Magic Mirror

**Recommended positions**: sides of Magic Mirror (top_right, top_left, bottom_right, bottom_left).

**Configuration parameters**:

1. (optional) port: Port where a TCP server will listening to data updates. Default is 8465.
2. (optional) max_devices: maximum number of devices entries which will be displayed in UI. Default is 10.

An example:

```js
modules: [
    [...]
    {
        module: 'mm2-bandupdater',
        position: 'top_right',
        config: {
            port: 8465,
            max_devices: 10
        }
    }
    [...]
]
```

## miband-dc

In `settings.json` add the following notification configuration:
```json
{
    [...]
    "notifications": {
        "update_state": [
            {
                "address": ["localhost:<port>"]
                [...]
            }
            [...]
        ]
    }
    [...]
}
```

Where `port` is the one we configured in the [earlier step](#magic-mirror), or 8465 if not configured.

For more information and configuration see `man miband-dc`.