import socket
import struct
import random
import time
import argparse


def generate_devices(size):
    if size >= 256:
        size = 255
    retval = []
    ftm = '{0}:' * 5 + '{0}'
    for i in range(size):
        if i >= 16:
            retval.append(
                ftm.format(hex(i).replace('0x', ''))
            )
        else:
            retval.append(
                ftm.format((hex(i) * 2).replace('0x', ''))
            )
    return retval


def generate_notification(devices):
    n = random.randint(1, len(devices) - 1)
    data = []
    for addr in random.sample(devices, n):
        data.append(bytes.fromhex(addr.replace(':', '')))
        data.append(random.randint(0, 1) == 1)
    return struct.pack('<i' + '6s?' * n, n, *data)


def send_notification(pkg, host='localhost', port=8465):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.connect((host, port))
            sock.sendall(pkg)
            print(f"{host}:{port} has been notified")
        except socket.timeout:
            print(f"could not connect to {host}:{port}")


def max_devices_argument_type(value):
    if isinstance(value, str):
        mult = 1
        if value.startswith('-'):
            mult *= -1
            value = value.lstrip('-')
        if value.isdigit():
            value = int(value) * mult

    if isinstance(value, int):
        if value > 0 and value < 256:
            return value
        raise argparse.ArgumentTypeError(
            f"invalid int value: must be greater than 0 and lesser than 256")
    raise argparse.ArgumentTypeError(f"invalid int value: '{value}'")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        'max_devices',
        metavar='MAX-DEVICES',
        type=max_devices_argument_type,
        help='Max number of devices to generate. Valid values range is (0, 256)')
    parser.add_argument(
        '-p',
        '--port',
        type=int,
        default=8465,
        help='Port where mm2-bandupdater is running (default is 8465)')
    args = parser.parse_args()

    devices = generate_devices(args.max_devices)
    try:
        while True:
            pkg = generate_notification(devices)
            send_notification(pkg=pkg, port=args.port)
            print('Sleeping...')
            time.sleep(10)
    except KeyboardInterrupt:
        pass
