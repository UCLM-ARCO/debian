# mm2-bandupdater

A Magic Mirror module for displaying miband-dc devices update state. It is needed the miband-dc service up and running, with a hook to 'update state notification' in localhost:8465.

## Installation

```shell
pi@raspberry:~/$ sudo apt install mm2-bandupdater
```

## Configuration

### miband-dc

In `settings.json` add the following line:
```json
{
    [...]
    "notify_update_state": "localhost:8465"
    [...]
}
```

For more information and configuration see `man miband-dc`.

## Magic Mirror

```js
modules: [
    [...]
    {
        module: 'mm2-bandupdater',
        position: 'top_right'
    }
    [...]
]
```