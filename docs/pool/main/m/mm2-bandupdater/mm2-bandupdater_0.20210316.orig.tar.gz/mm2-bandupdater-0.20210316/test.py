import socket
import struct
import random
import time

DEVICES = [
    '00:00:00:00:00:00',
    '11:11:11:11:11:11',
    '22:22:22:22:22:22',
    '33:33:33:33:33:33'
]


def generate_notification():
    n = random.randint(1, len(DEVICES) - 1)
    data = []
    for addr in random.sample(DEVICES, n):
        data.append(bytes.fromhex(addr.replace(':', '')))
        data.append(random.randint(0, 1) == 1)
    return struct.pack('<i' + '6s?' * n, n, *data)


def send_notification(pkg, host='localhost', port=8465):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.connect((host, port))
            sock.sendall(pkg)
            print(f"{host}:{port} has been notified")
        except socket.timeout:
            print(f"could not connect to {host}:{port}")


if __name__ == '__main__':
    try:
        while True:
            pkg = generate_notification()
            print(f'package is: {pkg}')
            send_notification(pkg)
            time.sleep(10)
    except KeyboardInterrupt:
        pass