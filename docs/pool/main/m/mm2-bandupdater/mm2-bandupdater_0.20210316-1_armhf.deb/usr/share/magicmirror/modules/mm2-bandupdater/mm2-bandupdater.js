

function create_device_element(mod, mac, is_updated) {
    var wrapper = document.createElement("div")
    wrapper.className = "band-wrapper"

    var icon = document.createElement("img")
    icon.className = "band-icon"
    if (is_updated) {
        icon.src = mod.file('icons/updated.png')
        icon.alt = 'updated'
    } else {
        icon.src = mod.file('icons/outdated.png')
        icon.alt = 'outdated'
    }
    wrapper.appendChild(icon)

    var address = document.createElement("span")
    address.className = "band-address"
    address.innerText = mac.toUpperCase()
    wrapper.appendChild(address)

    return wrapper
}

var devices = []

Module.register("mm2-bandupdater", {

    getDom: function () {
        var wrapper = document.createElement("div")
        wrapper.className = "mm2-bandupdater-wrapper"

        if (devices.length == 0) {
            wrapper.innerText = "No data received yet. Waiting for information..."
        } else {
            var date = document.createElement("span")
            date.className = "band-last-updated"
            date.innerText = this.last_updated.toLocaleString()
            wrapper.appendChild(date)

            var band_wrapper = document.createElement("div")
            band_wrapper.className = "band-module-wrapper"
            for (var i = 0; i < devices.length; i++) {
                band_wrapper.appendChild(
                    create_device_element(this, devices[i].mac, devices[i].is_updated)
                )
            }
            wrapper.appendChild(band_wrapper)
        }

        return wrapper
    },

    getHeader: function() {
        return 'MiBand4 Update State'
    },

    getStyles: function () {
        return [
            this.file('css/mm2-bandupdater.css')
        ]
    },

    getTranslations: function () {
        // TODO
        return false
    },

    start: function () {
        this.sendSocketNotification('SET_COMM')
        this.last_updated = new Date()
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification == "MIBAND_UPDATE_STATE") {
            devices = payload
            this.last_updated = new Date()
            this.updateDom()
        }
    }

})