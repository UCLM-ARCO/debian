var NodeHelper = require("node_helper");
const net = require('net');

module.exports = NodeHelper.create({
    start: function () {
        var self = this;

        function unpack_devices(pkg) {
            var devices = []
            var n = pkg.readUIntLE(0, 4)
            for (var i = 4; i < n * 7; i += 7) {
                var device = pkg.slice(i, i + 7)
                var device_mac = device.slice(0, 6).toString('hex')
                device_mac = device_mac.slice(0, 2) + ':' +
                    device_mac.slice(2, 4) + ':' +
                    device_mac.slice(4, 6) + ':' +
                    device_mac.slice(6, 8) + ':' +
                    device_mac.slice(8, 10) + ':' +
                    device_mac.slice(10, 12)
                var device_updated = device.readUInt8(6) == 1
                var device_obj = {
                    mac: device_mac,
                    is_updated: device_updated
                }
                devices.push(device_obj)
            }
            devices.sort(function (a, b) {
                if (a.is_updated && !b.is_updated)
                    return 1
                else if (!a.is_updated && b.is_updated)
                    return -1
                else {
                    if (a.mac < b.mac)
                        return -1
                    else if (a.mac > b.mac)
                        return 1
                    return 0
                }
            })
            self.sendSocketNotification(
                "MIBAND_UPDATE_STATE", devices
            )
        }

        function handleConnection(conn) {
            if (conn.remoteAddress !== "127.0.0.1") {
                conn.writeHead(403, { "Content-Type": "text/plain" })
                conn.write("403 Access denied")
                conn.end()
                return
            }
            conn.on('data', unpack_devices)
        }

        console.log("Hello")
        var server = net.createServer()
        server.on('connection', handleConnection)

        server.listen(8465, '127.0.0.1')
    },
})