#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion

if len(sys.argv) != 2:
    print("Error. Usage: ./get_rotation.py <mac>")
    exit(1)

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion(sys.argv[1])
sensor.connect()

sensor.setup_gyroscope()

measure = sensor.gyroscope.read_rotation()

print(measure)

sensor.disconnect()