#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion

if len(sys.argv) != 2:
    print("Error. Usage: ./get_acceleration.py <mac>")
    exit(1)

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion(sys.argv[1])
sensor.connect()
sensor.setup_accelerometer()

time.sleep(5)

acc = sensor.accelerometer.read_acceleration()
motion = sensor.accelerometer.read_motion()
steps = sensor.accelerometer.read_step_counter()
tap = sensor.accelerometer.read_tap()
print(f"Acceleration: {acc}\n Motion: {motion}\n Steps:{steps}\n Tap: {tap}")

sensor.disconnect()