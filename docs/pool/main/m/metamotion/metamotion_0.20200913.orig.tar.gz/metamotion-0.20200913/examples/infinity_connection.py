#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion, Mode, Color, ConnectionError

if len(sys.argv) != 2:
    print("Error. Usage: ./led.py <mac>")
    exit(1)

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion(sys.argv[1])

def function():
    sensor.on_disconnect(function)
    while 1:
        try:
            sensor.connect()
            break
        except ConnectionError:
            print("None device found")
    sensor.turn_on_led(Mode.SOLID, Color.GREEN)
    sensor.wait_until_break()

function()
time.sleep(4)
sensor.disconnect()