#!/usr/bin/python3

import types
import time
import copy
from threading import Event
from collections import namedtuple
from mbientlab.metawear import MetaWear, libmetawear, parse_value
from mbientlab.metawear.cbindings import *

class LoggerError(Exception):
    """
    Exception which is throw when the sensor failed to create a logger
    """
    pass

class Sensor:
    """
    Generic class to represent the sensors that are part of the board MetaMotionR
    """
    def __init__(self, board):
        """
        Initialize a sensor with the information of the desired MetaMotion board where
        we are going to read the different measures

        **Parameter:**

         * `board` *[mandatory]* this is a reference to tha MetaMotionR board.
        """
        self.board = board
        self.callbacks = []
        self.log_wrappers = []
        self.progress_wrappers = []
        self.download_handlers = []
        self.logger_signal = Event()

    def get_callback(self, attr, handler):
        """
        Generic method to generate a callback that wil be executed when a signal 
        from a sensor is received

        **Parameter:**

         * `attr` *[mandatory]* this is the class atribute where the data recived by
         the signal is going to be saved.
         * `handler` *[mandatory]* a user handler to process the data once received.
        """
        def callback(context, data):
            data = parse_value(data)
            setattr(self, attr, copy.copy(data))
            if handler is not None:
                handler(data)

        return callback  

    def subscribe_signal(self, attr, signal_subscriber, func = None):
        """
        Method to subscribe a client to a signal, indicating the attribute where the 
        data received must be saved, the method to subscribe to the signal and the user function
        that will process the data. If no function is indicated, the data will be saved only

        **Parameter:**

         * `attr` *[mandatory]* this is the class atribute where the data recived by
         the signal is going to be saved.
         * `signal_subscriber` *[mandatory]* is the metawear function that enable the
         user to receive data from a signal.
         * `func` *[optional]* a user handler to process the data once received.
        """
        if not isinstance(func, types.FunctionType) and func is not None:
            raise TypeError("Error, argument must be a function")

        handler = func
        cb = self.get_callback(attr, handler)
        
        signal = signal_subscriber(self.board)

        self.callbacks.append(FnVoid_VoidP_DataP(cb))
        libmetawear.mbl_mw_datasignal_subscribe(signal, None, self.callbacks[-1])

    def create_logger(self, logger_attr, measure):
        def log_creator(context, logger):
            if logger is not None:
                print("Logger for {} ready".format(measure))
                setattr(self, logger_attr, copy.copy(logger))
                self.logger_signal.set()
            else:
                self.logger_signal.set()
                raise LoggerError("Failed to create logger for {}".format(measure))
        return log_creator

    def get_log_procedure(self, list_to_save_logs):
        def log_handler(context, data):
            list_to_save_logs.append(copy.copy(parse_value(data)))
        return log_handler

    def setup_logger(self, signal, logger, measure):
        """
        Create and initialize a logger in the MetaMotionR device

        **Paramter:**

        * `signal` *[mandatory]* is the signal that the log is going to be subscribed
        A signal is asociated with a measure, like acceleration.
        * `logger` *[mandatory]* is a representation of the element instantiated in the
        MetaMotionR device in order to log data. This variables is an int representing an
        id for the logger. In this case you must pass a string with the name of the variable
        that is going to save the id.
        * `measure` *[mandatory]* is a string representing the measure that is going to listen
        the logger. An example value could be "acceleration" 
        """
        self.create_logger_wrapper = FnVoid_VoidP_VoidP(self.create_logger(logger, measure))
        libmetawear.mbl_mw_datasignal_log(signal, None, self.create_logger_wrapper)
        self.logger_signal.wait()
        self.logger_signal.clear()

    def subscribe_logged_data(self, log, logger):
        self.log_wrappers.append(FnVoid_VoidP_DataP(self.get_log_procedure(log)))
        libmetawear.mbl_mw_logger_subscribe(logger, None, self.log_wrappers[-1])