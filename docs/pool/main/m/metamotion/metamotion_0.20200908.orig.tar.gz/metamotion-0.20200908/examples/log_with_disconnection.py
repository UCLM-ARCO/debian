#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion

if len(sys.argv) != 2:
    print("Error. Usage: ./get_metamotion_info <mac>")
    exit(1)

##### INIT LOGS PART #####
sensor = MetaMotion(sys.argv[1])
sensor.connect()

sensor.setup_accelerometer(freq=25)
sensor.setup_gyroscope(freq = 25)

sensor.gyroscope.setup_logger()
sensor.accelerometer.setup_logger()

sensor.start_logging()
sensor.disconnect()
##########################

time.sleep(4)

##### DOWNLOAD PART #####
sensor = MetaMotion(sys.argv[1])
sensor.connect()

sensor.stop_logging()
sensor.sync_host_with_device()
sensor.subscribe_anonymous_datasignals()
# time.sleep(3)

sensor.download_logs()
sensor.wait_until_download_complete()

print("The logged data by gyroscope ", len(sensor.gyroscope.rotation_log))
print("The logged data by accelerometer", len(sensor.accelerometer.acc_log))
sensor.clean()
sensor.disconnect()
############################
