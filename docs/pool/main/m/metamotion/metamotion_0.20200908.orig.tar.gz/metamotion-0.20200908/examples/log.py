#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion

if len(sys.argv) != 2:
    print("Error. Usage: ./log.py <mac>")
    exit(1)

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion(sys.argv[1])
sensor.connect()

sensor.setup_accelerometer(freq=1)
sensor.setup_gyroscope(freq = 25)

sensor.gyroscope.setup_logger()
sensor.accelerometer.setup_logger()
sensor.start_logging()

time.sleep(4)

sensor.stop_logging()
sensor.gyroscope.subscribe_logged_data()
sensor.accelerometer.subscribe_logged_data()

sensor.download_logs()

sensor.wait_until_download_complete()

print("The logged data by accelerometer ", sensor.accelerometer.acc_log)
print("The logged data by gyroscope ", sensor.gyroscope.rotation_log)

sensor.clean()
sensor.disconnect()
