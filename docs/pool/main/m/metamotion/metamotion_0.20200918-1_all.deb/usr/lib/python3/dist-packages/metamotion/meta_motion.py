#!/usr/bin/python3

import time
import asyncio
from mbientlab.metawear import MetaWear, libmetawear, parse_value
from mbientlab.metawear.cbindings import *
from mbientlab.warble import WarbleException
from bleak import discover
from enum import Enum
from threading import Event
from multiprocessing import Process
from .sensors import Accelerometer, Gyroscope, FusionSensor

class WrongMetaDeviceModel(Exception):
    """
    Exception which indicates that the sensor connecte is not a MetaMotionR device
    """
    pass

class UninitializedSensor(Exception):
    """
    Exception to inform that a sensor can't be accesed because it is not initialize
    """
    pass

class MetaMotionDeviceNotFound(Exception):
    """
    After a scanner, MetaMotion device was not found
    """
    pass

class ConnectionError(Exception):
    """
    A exception to inform that a connection with a concrete sensor failed
    """
    pass

class Color(Enum):
    """
    Class to save constants about color LEDS. The three constants are *GREEN*, *RED*, and *BLUE*
    """
    GREEN = 0
    RED = 1
    BLUE = 2

class Mode(Enum):
    """
    Class to save constants about the led modes. There are three modes, *BLINK*, *PULSE* and *SOLID*
    """
    BLINK = 0
    PULSE = 1
    SOLID = 2

class Method(Enum):
    """
    Class to indicate the gathering mode
    """
    STREAMING = 0
    LOGGING = 1

class MetaMotion:
    """
    This class is used for request and add handlers for MetaMotionR sensor
    This is an abstraction of the Mbientlab Metawear API. This class has two
    main attributes that represents the sensors that formed the device:

    * accelerometer: Instance of the `Accelerometer` class
    * gyroscope: Instance of the `Gyroscope` class
    """
    def __init__(self, mac_address=None, method=Method.STREAMING, hci_mac=None):
        """
        MetaMotion constructor. This method is the start point of the library 
        and must be invoked in order to use the library characteristics

        **Parameters:**

         * `mac_address`, *[optional]* the MAC addres of the MetaMotion sensor
            that will be used in order to connect it by bluetooth.
        """
        if mac_address == None:
            scanned_sensors = self.scan_metamotion_sensor()
            mac_address = self.select_scanned_metamotion(scanned_sensors)

        self.mac = mac_address

        if not isinstance(method, Method):
            print("Indicate method doesn't exists, using streaming instead") 
            method = Method.STREAMING
        
        self.method = method
        print("Connecting to {}...".format(self.mac))

        if hci_mac is not None:
            self.device = MetaWear(self.mac, hci_mac=hci_mac)
        else:
            self.device = MetaWear(self.mac)

        self.battery_level = None
        self.progress_wrappers = []
        self.download_handlers = []
        self.entries = []
        self.anonymous_signals = {}
        self.cbs_anonymous_data = []

        self.left_entries = 0
        self.total_entries = 0

        self.download_event = Event()
        self.ready_anonymous_signals = Event()
        self.commands_recorded = Event()

    def connect(self):
        """
        Method to make the bluetooth connection with the MetaMotion sensor. It includes some
        necessary initialization for the library, like create an instance for the sensors and 
        subscribe to some events. Also, check that the model of the sensor that we are connecting 
        is the properly (MetaMotionR)
        """
        try:
            self.device.connect()
        except WarbleException:
            raise ConnectionError("The connection with the sensor {} failed".format(self.mac))

        # If we are gathering on streaming we need to reset the sensor on disconnections
        if self.method == Method.STREAMING:
            self.setup_commands_on_disconnect()
        
        model = libmetawear.mbl_mw_metawearboard_get_model(self.device.board)
        libmetawear.mbl_mw_settings_set_tx_power(self.device.board, 4)

        self.check_model(model)
        self.subscribe_battery()
        self.pattern = LedPattern(repeat_count= Const.LED_REPEAT_INDEFINITELY)
        return True

    def is_connected(self):
        """
        Method to check if the MetaMotion sensor is correctly connected. If the sensor is correctly
        connected return True, else return False
        """
        return self.device.is_connected

    def logging(self):
        """
        Method to check the length from the log (in develop yet)
        """
        def callback(context, data):
            print(parse_value(data))

        self.cb = FnVoid_VoidP_DataP(callback)
        signal = libmetawear.mbl_mw_logging_get_length_data_signal(self.device.board)
        libmetawear.mbl_mw_datasignal_subscribe(signal, None, self.cb)
        libmetawear.mbl_mw_datasignal_read(signal)

    def clean(self):
        libmetawear.mbl_mw_debug_reset_after_gc(self.device.board)
        libmetawear.mbl_mw_metawearboard_tear_down(self.device.board)
        libmetawear.mbl_mw_metawearboard_free(self.device.board)

    # def disable_sensors(self):
    #     try:
    #         self.gyroscope.disable()
    #     except UninitializedSensor:
    #         pass

    #     try:
    #         self.accelerometer.disable()        
    #     except UninitializedSensor:
    #         pass

    def disconnect(self):
        """
        Disables all the sensors of the MetaMotionR device, and clean and disconnect
        it.
        """
        libmetawear.mbl_mw_led_stop_and_clear(self.device.board)
        libmetawear.mbl_mw_debug_disconnect(self.device.board)
        self.device.disconnect()



    def on_disconnect(self, func):
        self.device.on_disconnect = lambda status: func()
        
    def setup_commands_on_disconnect(self):
        dc_event = libmetawear.mbl_mw_settings_get_disconnect_event(self.device.board)
        libmetawear.mbl_mw_event_record_commands(dc_event)
        libmetawear.mbl_mw_led_stop_and_clear(self.device.board)
        libmetawear.mbl_mw_debug_disconnect(self.device.board)
        libmetawear.mbl_mw_debug_reset_after_gc(self.device.board)
        libmetawear.mbl_mw_event_remove_all(self.device.board)
        self.cb_end_record = FnVoid_VoidP_VoidP_Int(self.function)
        libmetawear.mbl_mw_event_end_record(dc_event, None, self.cb_end_record)
        self.commands_recorded.wait()

    def function(self, context, board, status):
        if status != 0:
            print("[WARNING] Error in configuring sensor on disconnects, a malfunctions could be noticed")
        self.commands_recorded.set()

    def setup_accelerometer(self, freq=25, motion_samples=4, motion_threshold=0.70, tap_threshold=1):
        """
        Initialize the accelerometer sensors that is part of the MetaMotionR device. Is mandatory to
        invoke this method before use any funcionalities of the accelerometer.

        **Parameters:**

         * `freq` *[optional]* Frequency at which the acceleration is updatea. By default, the frequency is
         25Hz what means that will be sent 25 acceleration signales per second. 
         * `motion_samples` *[optional]* Number of samples that must overpass the `motion_threshold` in order
         to consider a motion.
         * `motion_threshold` *[optional]* Difference between the samples indicated in `motion_samples` to consider
         a motion.
         * `tap_threshold` *[optional]* Difference between samples acceleration to consider a tap.
        """
        self.accelerometer = Accelerometer(self.device.board, freq, motion_samples, motion_threshold, tap_threshold)

    def setup_gyroscope(self, freq=25):
        """
        Initialize the gyroscope sensor that is part of the MetaMotionR device. Is mandatory to
        invoke this method before use any funcionalities of the gyroscope.

        **Parameters:**

         * `freq` *[optional]* Frequency at which the rotation is updated. By default the frequency is 25Hz. The library
         will try to assign the frequency closest to that indicated by the user and allowed by the sensor.
        """
        self.gyroscope = Gyroscope(self.device.board, freq)

    def setup_fusion_sensor(self):
        """
        Initialize the sensor fusion to get the absolute orientation of the imu
        """
        self.fusion_sensor = FusionSensor(self.device.board)

    def get_device_info(self):
        """
        Returns a string with the basic information of the device
        """
        info_struct = libmetawear.mbl_mw_metawearboard_get_device_information(self.device.board)
        info = "Manufacturer: {}, ".format(info_struct.contents.manufacturer.decode())
        info += "Model: {}, ".format(info_struct.contents.model_number.decode())
        info += "Serial number: {}, ".format(info_struct.contents.serial_number.decode())
        info += "Firmware revision: {}, ".format(info_struct.contents.firmware_revision.decode())
        info += "Hardware revision: {}".format(info_struct.contents.hardware_revision.decode())
        return info

    def check_model(self, model):
        """
        Check if the model of the connected device is the MetaMotionR

        **Parameters:**

        * `model`, *[mandatory]* the model of the device connected.
        """
        if model != Model.METAMOTION_R:
            raise WrongMetaDeviceModel("The device must be MetaMotionR")
        return True

    def wait_until_break(self):
        while True:
            try:
                time.sleep(0.1)
            except KeyboardInterrupt:
                break

    def wait_until_download_complete(self):
        """
        Wait until the logs download finish
        """

        self.download_event.wait()
        self.download_event.clear()

    def subscribe_battery(self):
        """
        Subscribe for battery signal in order tu update the battery level attribute
        """
        battery_signal = libmetawear.mbl_mw_settings_get_battery_state_data_signal(self.device.board)
        def callback(context, data):
            self.battery_level = parse_value(data)

        self.battery_cb = FnVoid_VoidP_DataP(callback)
        libmetawear.mbl_mw_datasignal_subscribe(battery_signal, None, self.battery_cb)
        libmetawear.mbl_mw_datasignal_read(battery_signal)

    def read_battery(self):
        """
        **Return information about the battery of the device. It has two fields:**

        * `voltage`: Voltage that feed the device.
        * `charge`: Percentage of battery that the sensor has. 
        """
        time.sleep(0.5)
        return self.battery_level

    def download_logs(self):
        """
        Download the data saved in the logs previosuly created in a MetaMotion device
        """
        libmetawear.mbl_mw_logging_download(self.device.board, 10, byref(self.get_download_wrapper()))

    def start_logging(self):
        """
        Start to logging the data
        """
        libmetawear.mbl_mw_logging_start(self.device.board, 0)

    def stop_logging(self):
        """
        Stop data logging.
        """
        libmetawear.mbl_mw_logging_stop(self.device.board)

    def download_progress(self, context, entries_left, total_entries):
        self.left_entries = entries_left
        self.total_entries = total_entries
        print("entries left/total entries: {}/{}".format(entries_left, total_entries))
        if (entries_left == 0):
            print("download complete")
            self.download_event.set()

    def handler_entries(self, context, data):
        print("Generic Entry")
        print(parse_value(data))
        self.entries.append(copy.copy(parse_value(data)))

    def get_download_wrapper(self):
        self.progress_wrappers.append(FnVoid_VoidP_UInt_UInt(self.download_progress))
        self.download_handlers.append(LogDownloadHandler(context = None, \
        received_progress_update = self.progress_wrappers[-1], \
        received_unknown_entry = cast(None, FnVoid_VoidP_UByte_Long_UByteP_UByte), \
        received_unhandled_entry = cast(None, FnVoid_VoidP_DataP)))

        return self.download_handlers[-1]

    def turn_on_led(self, mode, color):
        """
        **Turn on the led of the sensor. It has tow parameters**

        * `mode`: Mode in which the led is going to turn on. There are 3 different modes
        Mode.BLINK, Mode.PULSE and Mode.SOLID
        * `color`: Color of the led, which could be Color.RED, Color.GREEN and Color.BLUE 
        """
        if not self.check_mode_and_color(mode, color):
            print(
                "Mode or Color for the led doesn't exists, the led is not going to turn on")
            return
        libmetawear.mbl_mw_led_load_preset_pattern(byref(self.pattern), mode.value)
        libmetawear.mbl_mw_led_write_pattern(self.device.board, byref(self.pattern), color.value)
        libmetawear.mbl_mw_led_play(self.device.board)

    def turn_off_led(self):
        """
        **Turn off the led of the sensor**
        """
        libmetawear.mbl_mw_led_stop_and_clear(self.device.board)

    def check_mode_and_color(self, mode, color):
        if isinstance(mode, Mode) and isinstance(color, Color):
            return True
        else:
            return False

    def __getattr__(self, name):
        if name == 'accelerometer':
            raise UninitializedSensor(
                "Before use the accelerometer you must initialized it with the setup_accelerometer method")
        elif name == 'gyroscope':
            raise UninitializedSensor(
                "Before use the gyroscope you must initialized it with the setup_gyroscope method")

    def __del__(self):
        self.disconnect()

    @staticmethod
    async def discover_devices():
        discovered_devs = await discover()
        return discovered_devs

    @staticmethod
    def get_metamotion_devices(discovered_devs):
        metamotion_devs = []

        for dev in discovered_devs:
            if dev.name == "MetaWear":
                metamotion_devs.append(dev.address)
        
        return metamotion_devs

    def choose_sensor(self, metamotion_devs):
        choose = -1
        while choose == -1:
            for i in range(len(metamotion_devs)):
                print("{}. {}".format(i, metamotion_devs[i]))

            choose = input("Choose a device from the list (0-{}): ".format(
                len(metamotion_devs)-1))
            if not choose.isdigit() or (int(choose) < 0 or int(choose) > len(metamotion_devs)-1):
                choose = -1
                print("Error, you must choose a device from the list with its number (0-{})\n".format(
                    len(metamotion_devs)-1))
        
        return metamotion_devs[int(choose)]

    @classmethod
    def scan_metamotion_sensor(cls):
        """
        Method of the class that enable te user to scan MetaMotionR sensor. After the scanner
        this method return a list with the address of all the sensors found. If the list is empty
        there is no MetaMotionR devices nearby
        """
        print("Scanning for BLE devices...")
        leftover_scans = 3
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        while leftover_scans >= 1:
            discovered_devs = loop.run_until_complete(cls.discover_devices())
            metamotion_devs = cls.get_metamotion_devices(discovered_devs)
            leftover_scans -= 1
            if len(metamotion_devs) > 0:
                break

        return metamotion_devs
    
    def select_scanned_metamotion(self, metamotion_devs):
        mac_address = None

        if len(metamotion_devs) == 1:
            mac_address = metamotion_devs[0]
        elif len(metamotion_devs) > 1:
            mac_address = self.choose_sensor(metamotion_devs)

        if mac_address == None:
            print("No MetaWear device found")
            raise MetaMotionDeviceNotFound("A MetaMotionR device cannot be connected")

        return mac_address

    def sync_host_with_device(self):
        libmetawear.mbl_mw_metawearboard_create_anonymous_datasignals(
            self.device.board, None, self.get_anonymous_signals_handler())
        self.ready_anonymous_signals.wait()
        self.ready_anonymous_signals.clear()
        time.sleep(1)

    def subscribe_anonymous_datasignals(self):
        print(self.anonymous_signals)
        for i in range(0, self.anonymous_signals['length']):
            signal = self.anonymous_signals['signals'].contents[i]
            id = libmetawear.mbl_mw_anonymous_datasignal_get_identifier(signal)
            libmetawear.mbl_mw_anonymous_datasignal_subscribe(
                signal, None, self.get_anonymous_data_handler(id))

    def get_anonymous_signals_handler(self):
        def anonymous_signals_handler(context, board, signals, len):
            self.anonymous_signals['length'] = len
            self.anonymous_signals['signals'] = cast(signals, POINTER(c_void_p * len)) if signals is not None else None
            self.ready_anonymous_signals.set()

        self.cb_anonymous_signals = FnVoid_VoidP_VoidP_VoidP_UInt(anonymous_signals_handler)
        return self.cb_anonymous_signals

    def get_anonymous_data_handler(self, id):
        def anonymous_data_handler(context, data):
            data_type = id.decode()
            if data_type == "angular-velocity":
                self.gyroscope.rotation_log.append(
                    [copy.copy(parse_value(data)), data.contents.epoch])
            if data_type == "acceleration": 
                self.accelerometer.acc_log.append(
                    [copy.copy(parse_value(data)), data.contents.epoch])

        self.cbs_anonymous_data.append(FnVoid_VoidP_DataP(anonymous_data_handler))
        return self.cbs_anonymous_data[-1]    