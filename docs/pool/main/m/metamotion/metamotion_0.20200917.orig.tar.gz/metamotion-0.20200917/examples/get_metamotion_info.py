#!/usr/bin/python3

import sys
sys.path.append("../")
from metamotion import MetaMotion

if len(sys.argv) != 2:
    print("Error. Usage: ./get_metamotion_info <mac>")
    exit(1)

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion(sys.argv[1])
sensor.connect()

print(sensor.get_device_info())
print(sensor.read_battery())

sensor.disconnect()