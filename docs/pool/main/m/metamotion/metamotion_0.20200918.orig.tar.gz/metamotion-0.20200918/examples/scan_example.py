#!/usr/bin/python3

import sys
sys.path.append("../")
from metamotion import MetaMotion

sensor = MetaMotion()
sensor.connect()
print(sensor.get_device_info())

sensor.disconnect()