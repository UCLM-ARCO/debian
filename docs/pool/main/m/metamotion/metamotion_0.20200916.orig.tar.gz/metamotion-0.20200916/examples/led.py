#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion, Mode, Color

if len(sys.argv) != 2:
    print("Error. Usage: ./led.py <mac>")
    exit(1)

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion("E9:75:41:AF:11:AE") #hci_mac="00:13:25:AB:DE:0C")
sensor.connect()
sensor.turn_on_led(Mode.SOLID, Color.GREEN)

sensor.wait_until_break()

sensor.disconnect()
