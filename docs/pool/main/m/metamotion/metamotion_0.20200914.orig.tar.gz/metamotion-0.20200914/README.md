# Metamotion #

Library to the easy use of the MetaMotionR imu sensor for python developers. With this library, 
you can get all the information produce by the accelerometer and gyroscope sensor of a MetaMotionR
in a simple manner. This library is based (and use) the official library **Metawear**, from the
manufacturer Mbeintlab, but in a simpler and more intuitive way.