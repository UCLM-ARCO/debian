#!/usr/bin/python3

import sys
import time
import datetime
sys.path.append("../")
from metamotion import MetaMotion, Mode, Color, ConnectionError

# if len(sys.argv) != 2:
#     print("Error. Usage: ./led.py <mac>")
#     exit(1)

sensor = MetaMotion("E9:75:41:AF:11:AE")
ts_init = 0
# sensor = MetaMotion(sys.argv[1])

def data_handler(data):
    print(data)

def function():
    sensor.on_disconnect(function)
    while 1:
        try:
            sensor.connect()
            sensor.setup_accelerometer()
            sensor.setup_gyroscope()
            sensor.setup_fusion_sensor()
            ts_init = datetime.datetime.now()
            sensor.accelerometer.on_acceleration(data_handler)
            sensor.gyroscope.on_rotation(data_handler)
            sensor.fusion_sensor.on_orientation(data_handler)
            break
        except ConnectionError:
            print("None device found")
            ts_end = datetime.datetime.now()
            print("Inicio: ", ts_init)
            print("Fin ", ts_end)
    # sensor.turn_on_led(Mode.SOLID, Color.GREEN)
    sensor.wait_until_break()
    ts_end = datetime.datetime.now()
    print("Inicio: ", ts_init)
    print("Fin ", ts_end)

function()
# time.sleep(4)
sensor.disconnect()