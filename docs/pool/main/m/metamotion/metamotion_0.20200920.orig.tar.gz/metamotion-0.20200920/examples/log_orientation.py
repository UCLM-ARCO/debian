#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion, Method, FusionModes

if len(sys.argv) != 2:
    print("Error. Usage: ./log.py <mac>")
    exit(1)

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion(method=Method.LOGGING)
sensor.connect(sys.argv[1])

sensor.setup_fusion_sensor(FusionModes.IMUPLUS)
sensor.fusion_sensor.setup_logger()

sensor.start_logging()

time.sleep(4)

sensor.stop_logging()

sensor.fusion_sensor.subscribe_logged_data()

sensor.download_logs()
sensor.wait_until_download_complete()


print("The logged data by orientation ", sensor.fusion_sensor.orientation_log)
print("The len by orientation ", len(sensor.fusion_sensor.orientation_log))

sensor.clean()
sensor.disconnect()
