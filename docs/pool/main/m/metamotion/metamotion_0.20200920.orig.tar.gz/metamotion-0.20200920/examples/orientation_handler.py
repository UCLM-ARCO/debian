#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion, FusionModes

def handler(data, timestamp):
    print(f"The orientations is: {data}")
    print(f"The timestamp {timestamp}")

if len(sys.argv) != 2:
    print("Error. Usage: ./handler.py <mac>")

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion()
sensor.connect(sys.argv[1])
print(FusionModes.NDOF)
sensor.setup_fusion_sensor(FusionModes.IMUPLUS)

sensor.fusion_sensor.on_orientation(handler)

sensor.wait_until_break()

sensor.disconnect()