#!/usr/bin/python3

import time
from .sensor import Sensor
from mbientlab.metawear import MetaWear, libmetawear, parse_value
from mbientlab.metawear.cbindings import *
import logging

class FusionModes:
    """
    Class to select the fusion mode to calculate orientation
    """
    NDOF = 1
    IMUPLUS = 2
    COMPASS = 3
    M4G = 4

class FusionSensor(Sensor):

    def __init__(self, board, fusion_mode):
        """
        Method for initialice the fusion sensor, which enable the user to 

        **Parameters:**

         * `board` *[mandatory]* this is the MetaMotionR Board where the sensor is located.
        """
        self.orientation = None
        self.orientation_log = []
        self.logger = None
        super().__init__(board)

        self.active(fusion_mode)
        # self.init_measures()

    def active(self, fusion_mode):
        if fusion_mode not in ([FusionModes.NDOF, FusionModes.IMUPLUS, FusionModes.COMPASS, FusionModes.M4G]):
            logging.error("Fusion Mode selected does not exist")
            exit()

        libmetawear.mbl_mw_sensor_fusion_set_mode(self.board, SensorFusionMode.IMU_PLUS)
        libmetawear.mbl_mw_sensor_fusion_set_acc_range(self.board, SensorFusionAccRange._16G)
        libmetawear.mbl_mw_sensor_fusion_set_gyro_range(self.board, SensorFusionGyroRange._2000DPS)
        libmetawear.mbl_mw_sensor_fusion_write_config(self.board)

    def disable(self):
        libmetawear.mbl_mw_datasignal_unsubscribe(
            libmetawear.mbl_mw_sensor_fusion_get_data_signal(self.board, SensorFusionData.EULER_ANGLE))

    def init_measures(self):
        """
        Subcribe to orientation data in order to update the attribute saving the data
        """
        self.on_orientation()

    def on_orientation(self, func = None):
        """
        Add a handler to process the data received by the signal. If there is no handler, the data is
        saved in the attribute self.orientation

        **Parameter:**

         * `func` *[optional]* a handler to process the data.
        """
        sensor_fusion_signal = libmetawear.mbl_mw_sensor_fusion_get_data_signal

        self.subscribe_signal('orientation', sensor_fusion_signal, func, SensorFusionData.EULER_ANGLE)

        libmetawear.mbl_mw_sensor_fusion_enable_data(self.board, SensorFusionData.EULER_ANGLE)
        libmetawear.mbl_mw_sensor_fusion_start(self.board)

    def read_orientation(self):
        """
        Return the last rotation detected by the sensor. The rotation is formed by the following 
        attributes:

        * `roll`: Euler angle in *X* axis.
        * `pitch`: Euler angle in the *Y* axis.
        * `yaw`: Euler angle in the *Z* axis.
        """
        time.sleep(0.5)
        return self.orientation

    def setup_logger(self):
        """
        Create and initialize an orientation logger
        """
        sensor_fusion_signal = libmetawear.mbl_mw_sensor_fusion_get_data_signal(self.board, SensorFusionData.EULER_ANGLE)
        libmetawear.mbl_mw_sensor_fusion_enable_data(self.board, SensorFusionData.EULER_ANGLE)
        libmetawear.mbl_mw_sensor_fusion_start(self.board)
        super().setup_logger(sensor_fusion_signal, 'logger', 'orientation')

    def subscribe_logged_data(self):
        super().subscribe_logged_data(self.orientation_log, self.logger)

    