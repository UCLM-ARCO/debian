#!/usr/bin/python3

import sys
import time
sys.path.append("../")
from metamotion import MetaMotion

def handler(data, timestamp):
    print(f"The acceleration is: {data.x} {data.y} {data.z}")
    print(f"The timestamp {timestamp}")

if len(sys.argv) != 2:
    print("Error. Usage: ./handler.py <mac>")

# sensor = MetaMotion("E9:75:41:AF:11:AE")
sensor = MetaMotion(sys.argv[1])
sensor.connect()
sensor.setup_gyroscope(freq=100)
sensor.setup_accelerometer(freq=100)

sensor.accelerometer.on_acceleration(handler)
sensor.gyroscope.on_rotation(handler)

sensor.wait_until_break()

sensor.disconnect()