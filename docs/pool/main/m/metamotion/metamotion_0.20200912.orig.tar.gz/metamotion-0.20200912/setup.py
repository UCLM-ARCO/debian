#!/usr/bin/python3

from distutils.core import setup

setup(name='metamotion',
      version='0.20200529',
      description='Python library to control MetaMotionR devices',
      author='Arco Group',
      author_email='arco.group@gmail.com',
      packages=['metamotion', 'metamotion.sensors'],
     )