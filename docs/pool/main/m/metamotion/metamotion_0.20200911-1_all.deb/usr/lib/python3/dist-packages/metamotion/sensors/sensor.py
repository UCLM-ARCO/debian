#!/usr/bin/python3

import types
import time
import copy
import time
from threading import Event
from collections import namedtuple
from inspect import signature
from mbientlab.metawear import MetaWear, libmetawear, parse_value
from mbientlab.metawear.cbindings import *


class LoggerError(Exception):
    """
    Exception which is throw when the sensor failed to create a logger
    """
    pass

class WrongHandler(Exception):
    """
    Exception which is throw when a handler for some data is incorrect
    """
    pass

class Sensor:
    """
    Generic class to represent the sensors that are part of the board MetaMotionR
    """
    def __init__(self, board):
        """
        Initialize a sensor with the information of the desired MetaMotion board where
        we are going to read the different measures

        **Parameter:**

         * `board` *[mandatory]* this is a reference to tha MetaMotionR board.
        """
        self.board = board
        self.callbacks = []
        self.log_wrappers = []
        self.progress_wrappers = []
        self.download_handlers = []
        self.logger_signal = Event()

    def get_callback(self, attr, handler):
        """
        Generic method to generate a callback that wil be executed when a signal 
        from a sensor is received

        **Parameter:**

         * `attr` *[mandatory]* this is the class atribute where the data recived by
         the signal is going to be saved.
         * `handler` *[mandatory]* a user handler to process the data once received.
        """
        def callback(context, data):
            datetime = time.strftime(
                '%Y-%m-%d %H:%M:%S', time.gmtime(data.contents.epoch/1000))
            epoch = data.contents.epoch
            data = parse_value(data)
            setattr(self, attr, copy.copy(data))
            if handler is not None:
                sig = signature(handler)
                if len(sig.parameters) == 1:
                    handler(data)
                elif len(sig.parameters) == 2:
                    handler(data, epoch)
                else:
                    raise WrongHandler(
                        "The number of handler arguments must be 1 or 2") 

        return callback  

    def subscribe_signal(self, attr, signal_subscriber, func = None, subscriber_arg = None):
        """
        Method to subscribe a client to a signal, indicating the attribute where the 
        data received must be saved, the method to subscribe to the signal and the user function
        that will process the data. If no function is indicated, the data will be saved only

        **Parameter:**

         * `attr` *[mandatory]* this is the class atribute where the data recived by
         the signal is going to be saved.
         * `signal_subscriber` *[mandatory]* is the metawear function that enable the
         user to receive data from a signal.
         * `func` *[optional]* a user handler to process the data once received.
        """
        if not isinstance(func, (types.FunctionType, types.MethodType)) and func is not None:
            raise TypeError("Error, argument must be a function")

        handler = func
        cb = self.get_callback(attr, handler)
        
        if subscriber_arg is None:
            signal = signal_subscriber(self.board)
        else:
            signal = signal_subscriber(self.board, subscriber_arg)

        self.callbacks.append(FnVoid_VoidP_DataP(cb))
        libmetawear.mbl_mw_datasignal_subscribe(signal, None, self.callbacks[-1])

    def create_logger(self, logger_attr, measure):
        def log_creator(context, logger):
            if logger is not None:
                print("Logger for {} ready".format(measure))
                setattr(self, logger_attr, copy.copy(logger))
                self.logger_signal.set()
            else:
                self.logger_signal.set()
                raise LoggerError("Failed to create logger for {}".format(measure))
        return log_creator

    def get_log_procedure(self, list_to_save_logs):
        def log_handler(context, data):
            datetime = time.strftime(
                '%Y-%m-%d %H:%M:%S', time.gmtime(data.contents.epoch/1000))
            list_to_save_logs.append([copy.copy(parse_value(data)), datetime])
        return log_handler

    def setup_logger(self, signal, logger, measure):
        """
        Create and initialize a logger in the MetaMotionR device

        **Paramter:**

        * `signal` *[mandatory]* is the signal that the log is going to be subscribed
        A signal is asociated with a measure, like acceleration.
        * `logger` *[mandatory]* is a representation of the element instantiated in the
        MetaMotionR device in order to log data. This variables is an int representing an
        id for the logger. In this case you must pass a string with the name of the variable
        that is going to save the id.
        * `measure` *[mandatory]* is a string representing the measure that is going to listen
        the logger. An example value could be "acceleration" 
        """
        self.create_logger_wrapper = FnVoid_VoidP_VoidP(self.create_logger(logger, measure))
        libmetawear.mbl_mw_datasignal_log(signal, None, self.create_logger_wrapper)
        self.logger_signal.wait()
        self.logger_signal.clear()

    def subscribe_logged_data(self, log, logger):
        self.log_wrappers.append(FnVoid_VoidP_DataP(self.get_log_procedure(log)))
        libmetawear.mbl_mw_logger_subscribe(logger, None, self.log_wrappers[-1])

    def translate_frequency(self, desired_freq, Frequency):
        """
        Translate a numeric frequency in the corresponding macro
        """
        if desired_freq <= 35:
            freq = Frequency._25Hz
        elif desired_freq > 35 and desired_freq <= 70:
            freq = Frequency._50Hz
        elif desired_freq > 70 and desired_freq <= 160:
            freq = Frequency._100Hz
        elif desired_freq > 160 and desired_freq <= 300:
            freq = Frequency._200Hz
        elif desired_freq > 300 and desired_freq <= 600:
            freq = Frequency._400Hz
        elif desired_freq > 600 and desired_freq <= 1300:
            freq = Frequency._800Hz
        elif desired_freq > 1300 and desired_freq <= 2500:
            freq = Frequency._1600Hz
        else:
            freq = Frequency._3200Hz

        return freq
