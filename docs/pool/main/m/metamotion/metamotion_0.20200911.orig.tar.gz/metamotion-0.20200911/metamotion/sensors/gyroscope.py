#!/usr/bin/python3

import types
import time
import copy
from collections import namedtuple
from .sensor import Sensor
from mbientlab.metawear import MetaWear, libmetawear, parse_value
from mbientlab.metawear.cbindings import *
from enum import Enum


class Frequency(Enum):
    _0_78Hz = 0
    _1_56Hz = 1
    _3_12Hz = 2
    _6_25Hz = 3
    _12_5Hz = 4
    _25Hz = 6
    _50Hz = 7
    _100Hz = 8
    _200Hz = 9
    _400Hz = 10
    _800Hz = 11
    _1600Hz = 12
    _3200Hz = 13


class Gyroscope(Sensor):
    """
    Class for represent a Gyroscope of a MetaMotionR device, this class enables
    the user to gather the rotation data from the gyroscope sensor
    """
    def __init__(self, board, freq):
        """
        Method to initalize the gyroscope client. The initialization include the activation
        of the gyroscope and subscription in order to update the attributes
        """
        self.gyro = None
        self.logger = None
        self.rotation_log = []
        self.freq = freq

        super().__init__(board)
        self.active(freq)

    def active(self, freq):
        """
        Active and configure the gyroscope sensor with default configuration
        """
        libmetawear.mbl_mw_gyro_bmi160_set_odr(
            self.board, super().translate_frequency(freq, Frequency).value)
        libmetawear.mbl_mw_gyro_bmi160_set_range(self.board, GyroBmi160Range._2000dps)
        libmetawear.mbl_mw_gyro_bmi160_write_config(self.board)
        libmetawear.mbl_mw_gyro_bmi160_enable_rotation_sampling(self.board)
        libmetawear.mbl_mw_gyro_bmi160_start(self.board)

    def disable(self):
        libmetawear.mbl_mw_gyro_bmi160_disable_rotation_sampling(self.board)
        libmetawear.mbl_mw_gyro_bmi160_stop(self.board)
        libmetawear.mbl_mw_datasignal_unsubscribe(
            libmetawear.mbl_mw_gyro_bmi160_get_rotation_data_signal(self.board))

    def on_rotation(self, func = None):
        """
        Add a handler to process the data received by the signal. If there is no handler, the data is
        saved in the attribute self.gyro

        **Parameter:**

         * `func` *[optional]* a handler to process the data.
        """
        gyro_signal = libmetawear.mbl_mw_gyro_bmi160_get_rotation_data_signal

        self.subscribe_signal('gyro', gyro_signal, func)

    def read_rotation(self):
        """
        Return the last rotation detected by the sensor. The rotation is formed by the following 
        attributes:

        * `x`: Rotation in the *X* axis in degrees per second.
        * `y`: Rotation in the *Y* axis in degrees per second.
        * `z`: Rotation in the *Z* axis in degrees per second.
        """
        self.on_rotation()
        time.sleep(0.5)
        libmetawear.mbl_mw_datasignal_unsubscribe(
            libmetawear.mbl_mw_gyro_bmi160_get_rotation_data_signal(self.board))
        return self.gyro

    def setup_logger(self):
        """
        Create and initialize a rotation logger
        """
        rotation_signal = libmetawear.mbl_mw_gyro_bmi160_get_rotation_data_signal(self.board)
        super().setup_logger(rotation_signal, 'logger', 'rotation')

    def subscribe_logged_data(self):
        """
        Subscribe to the rotation logger in order to receive the rotation data 
        when the download action is performed
        """
        return super().subscribe_logged_data(self.rotation_log, self.logger)