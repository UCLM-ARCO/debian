const logos = ["arco", "shapes", "uclm"]
const module_name = "mm2-shapes-login"

Module.register(module_name, {
    defaults: {
        demo: false
    },

    getClockDom: function () {
        var retval = document.createElement("div")
        if (this.modules_loaded) {
            MM.getModules().exceptModule(this).enumerate(function (module) {
                if (module.name == "clock")
                    retval = module.getDom()
            })
        }
        return retval
    },

    start: function () {
        var self = this
        self.data.position = "fullscreen_below"
        self.modules_loaded = false
        self.seconds = -1

        setInterval(function () {
            if (self.modules_loaded) {
                MM.getModules().exceptModule(this).enumerate(function (module) {
                    if (module.name == "clock")
                        if (self.seconds !== module.seconds)
                            self.updateDom();
                })
            }
        }, 500);
    },

    getDom: function () {
        var self = this
        var wrapper = document.createElement("div")
        wrapper.className = "login-wrapper"

        if (this.config.demo) {
            var logos_wrapper = document.createElement("div")
            logos_wrapper.className = "login-logos"

            for (let i = 0; i < logos.length; i++) {
                var logo = document.createElement("img")
                logo.src = this.file("images/" + logos[i] + "-logo.png")
                logos_wrapper.appendChild(logo)
            }
            wrapper.appendChild(logos_wrapper)
        }

        var footer = document.createElement("div")
        footer.className = "login-footer"

        footer.appendChild(this.getClockDom())

        MM.getModules().exceptModule(this).enumerate(function (module) {
            if (module.name == "mm2-qrwificredentials" && module.hidden) {
                var text = document.createElement("div")
                text.innerText = self.translate('footer_text')
                footer.appendChild(text)
            }
        })

        wrapper.appendChild(footer)

        return wrapper
    },

    getStyles: function () {
        return [
            this.file(module_name + ".css")
        ]
    },

    getTranslations: function () {
        return {
            en: "translations/en.json",
            es: "translations/es.json"
        }
    },

    notificationReceived: function (notification) {
        if (notification === 'DOM_OBJECTS_CREATED')
            this.modules_loaded = true
    }
})