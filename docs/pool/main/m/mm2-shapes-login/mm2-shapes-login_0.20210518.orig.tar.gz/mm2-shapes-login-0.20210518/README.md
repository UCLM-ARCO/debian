# mm2-shapes-login

Magic Mirror module for displaying ARCO-SHAPES Smart Mirror login page. 
It will take up all screen (`position: fullscreen-below`).

## Configuration

```js
modules: [
    {
        module: "mm2-shapes-login",
        config: {
            demo: false     // (optional) If true, displays ARCO, SHAPES and UCLM logos
        }
    }
]
```

## Utils

This module do not respond to MM CSS regions, so it can be 
"in the way" of other modules if set along the login page.

For that, it provides 2 CSS classes: `margin-login-header` and `marging-login-footer`, which sets 
margins to elements and let them be separated of login header and footer, respectively.