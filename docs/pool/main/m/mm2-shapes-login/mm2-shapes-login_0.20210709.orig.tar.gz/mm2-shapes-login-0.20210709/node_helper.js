var NodeHelper = require('node_helper')
const fs = require('fs')

module.exports = NodeHelper.create({
    socketNotificationReceived: function (notification, _payload) {
        if (notification === 'READ_MODULES')
            this.sendSocketNotification('SET_MODULES', JSON.parse(
                fs.readFileSync('/usr/share/magicmirror/modules/mm2-shapes-login/config/modules.json')
            ))
    }
})