const LoginState = {
    ERROR: 0,
    LOGGED_IN: 1,
    LOGGED_OUT: 2
}

Module.register('mm2-shapes-login', {
    defaults: {
        fgColor: '#4287f5',
        bgColor: '#ffffff',
        onlyIcons: false,
        showMenu: true
    },

    onLogIn: function (user) {
        if (this.state !== LoginState.LOGGED_OUT
            || user === null)
            return

        this.state = LoginState.LOGGED_IN
        this.user = user

        for (let m of Object.values(this.modules)) {
            if ('onLogIn' in m)
                m.onLogIn()
        }

        this.sendNotification('USER_LOGGED_IN', this.user)
        this.updateDom(1500)
        console.log('Logged as ' + this.user.id)
    },

    onLogOut: function () {
        if (this.state !== LoginState.LOGGED_IN)
            return

        if (this.logOutTimeout !== undefined)
            clearTimeout(this.logOutTimeout)

        for (let m of Object.values(this.modules))
            if ('onLogOut' in m)
                m.onLogOut()

        this.state = LoginState.LOGGED_OUT
        this.user = null

        this.sendNotification('USER_LOGGED_OUT')
        this.updateDom(1500)
    },

    onLogOutDelayed: function (timeout = 30 * 60 * 1000) {
        this.logOutTimeout = setTimeout(function () {
            this.logOutTimeout = undefined
            this.onLogOut()
        }.bind(this), timeout)
    },

    onRFIDConnect: function (connected) {
        if (this.state === LoginState.ERROR && connected) {
            this.state = LoginState.LOGGED_OUT
            this.updateDom(1500)
        } else if (this.state !== LoginState.ERROR && !connected) {
            this.state = LoginState.ERROR
            this.updateDom(1500)
        }
    },

    start: function () {
        this.id = this.data.identifier.split('_')[1]
        this.state = LoginState.LOGGED_OUT
        this.modules = []
        this.user = null

        this.logOutTimeout = undefined

        let iceData = new Ice.InitializationData()
        iceData.properties = Ice.createProperties()
        iceData.properties.setProperty('Ice.ACM.Client.Heartbeat', '3')
        let iceComm = Ice.initialize(iceData)

        this.rfidClient = new RFIDClient(
            iceComm, this.onRFIDConnect.bind(this), 
            this.onLogIn.bind(this), 
            this.onLogOutDelayed.bind(this), 
            location.protocol === 'https:')

        // Autologing for testing
        // this.rfidClient = {
        //     connected: true,
        //     onConnectCallback: this.onRFIDConnect,
        //     init: function () {
        //         this.onConnectCallback(true)
        //     }
        // }
    },

    getDom: function () {
        let dom = document.createElement('span')

        if (this.modules.length == 0)
            dom.textContent = this.translate('loading-message')
        else {
            switch (this.state) {
                case LoginState.ERROR:
                    dom.textContent = this.translate('connection-error-message')
                    break
                case LoginState.LOGGED_OUT:
                    dom.textContent = this.translate('login-message')
                    break
                case LoginState.LOGGED_IN:
                    if (this.config.showMenu)
                        dom = createMenu()
                    else
                        dom = createMenuItemFromModuleWrapper(
                            this.modules[this.modules.length - 1]
                        )
                    break
                default:
                    break
            }
        }

        return dom
    },

    getStyles: function () {
        return [
            'font-awesome.css',
            this.file('css/mm2-shapes-login.css')
        ]
    },

    getScripts: function () {
        return [
            this.file('js/Ice-3.7.min.js'),
            this.file('js/rfid-service-iface.js'),
            this.file('js/user-utils.js'),
            this.file('js/rfid-service.js'),
            this.file('js/mm-utils.js'),
            this.file('js/dom-utils.js')
        ]
    },

    getTranslations: function () {
        return {
            es: 'translations/es.json',
            en: 'translations/en.json'
        }
    },

    notificationReceived: function (notification, _payload) {
        if (notification === 'ALL_MODULES_STARTED')
            this.sendSocketNotification('READ_MODULES')
    },

    socketNotificationReceived: function (notification, payload) {
        if (notification === 'SET_MODULES') {
            for (let m of getModulesByFilter(['id<' + this.id]))
                this.modules.push(new BeforeLoginModule(
                    m.name, m.data.identifier.split('_')[1],
                    m.config))

            let addedFromConfig = []
            for (let value of Array.from(payload)) {
                try {
                    if (MM.getModules().withClass(value.name).length === 0) {
                        console.log('Module ' + value.name + ' not loaded. Did you add it to Magic Mirror configuration?')
                        continue
                    }

                    if (this.config.showMenu)
                        this.modules.push(AfterLoginModule.fromObject(value))
                    else
                        this.modules.push(AfterLoginModuleWithoutDom.fromObject(value))

                    if ('id' in value)
                        addedFromConfig.push('id:' + value.id)
                    else
                        addedFromConfig.push('name:' + value.name)
                } catch (err) {
                    console.error('Load module from config error: ' + err)
                }
            }

            let filter = ['id>' + this.id]
            for (let added of addedFromConfig)
                if (added.startsWith('name:'))
                    filter.push('name!==' + added.replace('name:', ''))
                else
                    filter.push('id!==' + added.replace('id:', ''))

            for (let m of getModulesByFilter(filter))
                if (this.config.showMenu)
                    this.modules.push(new AfterLoginModule(
                        m.name, undefined, m.data.identifier.split('_')[1],
                        m.config))
                else
                    this.modules.push(new AfterLoginModuleWithoutDom(
                        m.name, m.data.identifier.split('_')[1],
                        m.config))

            this.modules.push({
                name: 'logout',
                symbol: 'sign-out-alt',
                onClick: this.onLogOut.bind(this)
            })

            this.rfidClient.init()
            // Autologing for testing
            // this.onLogIn(new User(
            //     'anonymous', '+34666666666',
            //     'anonymous2',
            //     'webcal://localhost:8080/modules/mm2-shapes-login/sample.ics'))

            setTimeout(this.updateDom.bind(this), 1000)
        }
    }
})