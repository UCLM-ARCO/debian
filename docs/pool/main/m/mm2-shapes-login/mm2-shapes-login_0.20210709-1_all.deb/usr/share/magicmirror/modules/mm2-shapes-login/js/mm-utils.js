/**
 * Search through all Magic Mirror modules filtering by provided filters. 
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {Array<String>} filters Comparison expressions to filter by. Default is an empty array (no filter).
 * @returns {Array<object>} Found modules. 
 */
const getModulesByFilter = function (filters = []) {
    var retval = Array.from(MM.getModules())

    for (let index = 0; index < filters.length; index++) {
        const filter = filters[index]

        let filterMatch = filter.match(/([a-z]+)(\={2,3}|\!\={1,2}|\<\=?|\>\=?)(.+)/i)

        if (filterMatch === null) {
            console.error('Invalid filter "' + filter + '"')
            continue
        } else if (filterMatch[1] !== 'id' && filterMatch[1] !== 'name') {
            console.error('Unknown property compared in filter "' + filter + '"')
            continue
        } else if (filterMatch[1] === 'name'
            && filterMatch[2].match(/\<\=?|\>\=?/) !== null) {
            console.error('Invalid string comparison operator in filter "' + filter + '"')
            continue
        }

        var filterProperty = filterMatch[1].toLowerCase()
        var filterOperator = filterMatch[2]
        var filterValue = filterProperty === 'name' ? filterMatch[3] : parseInt(filterMatch[3])

        var newRetval = []
        for (let m of retval) {
            let mId = parseInt(m.data.identifier.split('_')[1])
            let mName = m.name

            if (/\<\=?/.test(filterOperator) && filterProperty === 'id') {
                if ((filterOperator.endsWith('=') && mId <= filterValue)
                    || mId < filterValue)
                    newRetval.push(m)
            } else if (/\>\=?/.test(filterOperator) && filterProperty === 'id') {
                if ((filterOperator.endsWith('=') && mId >= filterValue)
                    || mId > filterValue)
                    newRetval.push(m)
            } else if (filterOperator.startsWith('!')) {
                if ((filterProperty === 'id' && mId != filterValue)
                    || (filterProperty === 'name' && mName != filterValue))
                    newRetval.push(m)
            } else if ((filterProperty === 'id' && mId == filterValue)
                || (filterProperty === 'name' && mName == filterValue)) {
                newRetval.push(m)
            }
        }
        retval = Array.from(newRetval)
    }

    return retval
}

/**
 * Show or hide a module whether it is hidden or shown, respectively.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {String} name Name of module.
 * @param {String} id (optional) Magic Mirror id for module. Default is undefined.
 * @param {Number} speed (optional) Animation speed in milliseconds. Default is 1500.
 * @return {Boolean} True if module was shown
 */
const toggleVisibilityOfModule = function (name, id = undefined, speed = 1500) {
    var retval = true
    MM.getModules().withClass(name).enumerate(m => {
        if (id === undefined || m.data.identifier.split('_')[1] == id) {
            console.log('Executing "toggleVisibility" for module ' + name)
            if (m.hidden)
                m.show(speed)
            else {
                m.hide(speed)
                retval = false
            }
        }
    })
    return retval
}

/**
 * Show a module.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {String} name Name of module.
 * @param {String} id (optional) Magic Mirror id for module. Default is undefined.
 * @param {Number} speed (optional) Animation speed in milliseconds. Default is 1500.
 * @return {Boolean} True if module was shown
 */
const showModule = function (name, id = undefined, speed = 1500) {
    var retval = true
    MM.getModules().withClass(name).enumerate(m => {
        if (id === undefined || m.data.identifier.split('_')[1] == id) {
            console.log('Executing "show" for module ' + name)
            if (m.hidden)
                m.show(speed)
            else
                retval = false
        }
    })
    return retval
}

/**
 * Hide a module.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * 
 * @param {String} name Name of module.
 * @param {String} id (optional) Magic Mirror id for module. Default is undefined.
 * @param {Number} speed (optional) Animation speed in milliseconds. Default is 1500.
 * @return {Boolean} True if module was hidden
 */
const hideModule = function (name, id = undefined, speed = 1500) {
    var retval = true
    MM.getModules().withClass(name).enumerate(m => {
        if (id === undefined || m.data.identifier.split('_')[1] == id) {
            console.log('Executing "hide" for module ' + name)
            if (!m.hidden)
                m.hide(speed)
            else
                retval = false
        }
    })
    return retval
}

/**
 * Change configuration parameters of module.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * Require user-utils script.
 * 
 * @param {object} options Map of module configuration parameters to change.
 * @param {String} name Name of module. 
 * @param {String} id (optional) Magic Mirror id for module. Default is undefined.
 */
const configureModule = function (options, name, id = undefined) {
    let self = MM.getModules().withClass('mm2-shapes-login')[0]
    options = replaceWithUserProperties(self.user, options)

    MM.getModules().withClass(name).enumerate(m => {
        if (id === undefined || m.data.identifier.split('_')[1] == id) {
            console.log('Executing "configure" for module ' + name)
            for (let [k, v] of Object.entries(options))
                m.config[k] = v
            m.start()
        }
    })
}

/**
 * Send a Magic Mirror notification broadcast.
 * Use it after receiving 'ALL_MODULES_STARTED' notification.
 * Require user-utils script.
 * 
 * @param {String} notificationName Name of notification to send.
 * @param {Array} notificationArgs Array of arguments to send as a payload. If any string contains a user property name between brakets it will be replaced with its real value.
 */
const notifyAll = function (notificationName, notificationArgs = []) {
    console.log('Executing "notifyAll" with notification ' + notificationName)

    let self = MM.getModules().withClass('mm2-shapes-login')[0]
    self.sendNotification(notificationName, replaceWithUserProperties(
        self.user, notificationArgs))
}

class ModuleWrapper {

    constructor(name, id = undefined,
        defaultConfig = undefined,
        onLogIn = undefined,
        onLogOut = undefined) {

        this.name = name
        this.id = id

        let filter = ['name==' + this.name]
        if (this.id !== undefined)
            filter.push('id==' + this.id)

        if (defaultConfig == undefined) {
            for (let m of getModulesByFilter(filter)) {
                this.defaultConfig = Object.assign({}, m.config)
                break
            }
        } else
            this.defaultConfig = Object.assign({}, defaultConfig)

        this.onLogIn = function (defaultCallback, callback) {
            defaultCallback()
            if (callback !== undefined)
                callback()
        }.bind(this, this.defaultOnLogIn.bind(this), onLogIn)

        this.onLogOut = function (defaultCallback, callback) {
            defaultCallback()
            if (callback !== undefined)
                callback()
        }.bind(this, this.defaultOnLogOut.bind(this), onLogOut)
    }

    static fromObject(obj) {
        if (!('name' in obj))
            throw 'Object lacks "name" property.'

        let filter = ['name==' + obj.name]
        if (obj.id !== undefined)
            filter.push('id==' + obj.id)

        let defaultConfig = {}
        for (let m of getModulesByFilter(filter)) {
            defaultConfig = Object.assign({}, m.config)
            break
        }

        if ('onLogIn' in obj)
            obj.onLogIn = this.callbackFromObject(
                obj.name, obj.id, defaultConfig, obj.onLogIn)

        if ('onLogOut' in obj)
            obj.onLogOut = this.callbackFromObject(
                obj.name, obj.id, defaultConfig, obj.onLogOut)

        return new this(
            obj.name, obj.id, defaultConfig,
            obj.onLogIn, obj.onLogOut)
    }

    static callbackFromObject(moduleName, moduleId, moduleDefaultConfig, obj) {
        if (!Array.isArray(obj))
            obj = [obj]

        let retval = undefined
        for (let callback of obj) {
            if (typeof callback !== 'object') {
                console.error('Callback is not an object.')
                continue
            } else if (!('type' in callback)) {
                console.error('Callback lacks "type" property.')
                continue
            } else if (!['show', 'hide', 'configuration', 'notification', 'reset'].includes(callback.type)) {
                console.error('Callback type must be one of the following: show, hide, configuration, notification or reset.')
                continue
            }

            let parsedCallback = undefined
            switch (callback.type) {
                case 'notification':
                    if (!('name' in callback)) {
                        console.error('Notification callback lacks "name" property.')
                        break
                    }
                    let notificationName = callback.name
                    let notificationArgs = []

                    if ('args' in callback)
                        if (!Array.isArray(callback.args))
                            console.error('Notification callback "args" must be an array.')
                        else
                            notificationArgs = Array.from(callback.args)

                    parsedCallback = notifyAll.bind(this, notificationName, notificationArgs)
                    break
                case 'configuration':
                    let options = Object.assign({}, callback)
                    delete options.type

                    parsedCallback = configureModule.bind(this, options, moduleName, moduleId)
                    break
                case 'reset':
                    parsedCallback = configureModule.bind(this, moduleDefaultConfig, moduleName, moduleId)
                    break
                case 'show':
                    parsedCallback = showModule.bind(this, moduleName, moduleId)
                    break
                case 'hide':
                    parsedCallback = hideModule.bind(this, moduleName, moduleId)
                    break
                default:
                    break
            }
            if (retval === undefined)
                retval = [parsedCallback]
            else
                retval.push(parsedCallback)
        }

        if (retval !== undefined) {
            retval = function (callbacks) {
                for (let cb of callbacks)
                    cb()
            }.bind(this, retval)
        }

        return retval
    }

    defaultOnLogIn() { }
    defaultOnLogOut() { }
}

class BeforeLoginModule extends ModuleWrapper {
    defaultOnLogIn() {
        return hideModule(this.name, this.id)
    }

    defaultOnLogOut() {
        return showModule(this.name, this.id)
    }
}

class AfterLoginModuleWithoutDom extends ModuleWrapper {

    defaultOnLogIn() {
        return showModule(this.name, this.id)
    }

    defaultOnLogOut() {
        return hideModule(this.name, this.id)
    }
}

class AfterLoginModule extends ModuleWrapper {
    constructor(name, symbol = 'question', id = undefined,
        defaultConfig = undefined,
        onLogIn = undefined,
        onLogOut = undefined,
        onClick = undefined) {

        super(name, id, defaultConfig, onLogIn, onLogOut)
        this.symbol = symbol

        this.onClick = function (defaultCallback, callback) {
            if (defaultCallback())
                if (callback !== undefined)
                    callback()
        }.bind(this, this.defaultOnClick.bind(this), onClick)
    }

    static fromObject(obj) {
        if (!('name' in obj))
            throw 'Object lacks "name" property.'

        if (!('symbol' in obj))
            obj.symbol = 'question'

        let filter = ['name==' + obj.name]
        if (obj.id !== undefined)
            filter.push('id==' + obj.id)

        let defaultConfig = {}
        for (let m of getModulesByFilter(filter)) {
            defaultConfig = Object.assign({}, m.config)
            break
        }

        if ('onLogIn' in obj)
            obj.onLogIn = this.callbackFromObject(
                obj.name, obj.id, defaultConfig, obj.onLogIn)

        if ('onLogOut' in obj)
            obj.onLogOut = this.callbackFromObject(
                obj.name, obj.id, defaultConfig, obj.onLogOut)

        if ('onClick' in obj)
            obj.onClick = this.callbackFromObject(
                obj.name, obj.id, defaultConfig, obj.onClick)

        return new AfterLoginModule(
            obj.name, obj.symbol, obj.id, defaultConfig,
            obj.onLogIn, obj.onLogOut, obj.onClick)
    }

    defaultOnClick() {
        return toggleVisibilityOfModule(this.name, this.id)
    }

    defaultOnLogOut() {
        return hideModule(this.name, this.id)
    }
}