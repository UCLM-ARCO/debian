
import json
import requests

# NOTE: some older versions of requests does not have exceptions.JSONDecodeError
try:
    from requests.exceptions import JSONDecodeError
except ImportError:
    JSONDecodeError = Exception


class ASAPAUser:
    BASE_URL = "https://kubernetes.pasiphae.eu/shapes/asapa"

    def __init__(self, x_shapes_key):
        self._x_shapes_key = x_shapes_key
        self._token = None

    def _send_request(self, url, body=None, *, use_post=False, add_token=True):
        if add_token and self._token is None:
            return False, "User not logged in."

        url = self.BASE_URL + url
        headers = {
            "X-Shapes-Key": self._x_shapes_key,
            'Content-Type': 'application/json'
        }
        if add_token:
            headers["X-Pasiphae-Auth"] = self._token

        data = json.dumps(body or {})
        if use_post:
            resp = requests.post(url, headers=headers, data=data)
        else:
            resp = requests.get(url, headers=headers, data=data)
        try:
            resp = resp.json()
        except JSONDecodeError:
            return False, "Invalid response from server."

        if resp['code'] != 200:
            return False, resp["error"]
        return True, resp

    def is_logged_in(self):
        return self._token is not None

    def login(self, email, password):
        url = "/auth/login"
        body = {"email": email, "password": password}
        ok, resp = self._send_request(url, body, use_post=True, add_token=False)
        if ok:
            self._token = resp['items'][0]['token']
        return ok

    @property
    def token(self):
        # FIXME: renew token if is too old
        return self._token

    def get_information(self):
        url = "/users/me"
        info = {}
        ok, resp = self._send_request(url)
        if ok:
            for i in resp['items']:
                info.update(i)
        return info

    def register(self, email, password, metadata=None):
        url = "/auth/register"
        body = {"email": email, "password": password}
        if metadata is not None:
            body["metadata"] = metadata
        ok, resp = self._send_request(url, body, use_post=True, add_token=False)
        if not ok:
            raise ValueError(resp)
