
# Introducción

La librería de Python `asapa` proporciona una API para utilizar el servicio de Shapes ASAPA con el objetivo
de autenticar usuarios, y obtener el token de autorización que se emplea en el resto de soluciones integradas
en Shapes. Se proporciona como paquete Debian, y se puede instalar con el siguiente comando:

```shell
sudo apt install python3-asapa
```

# Instanciación de un usuario

El módulo proporciona una clase llamada `ASAPAUser`, que es la encargada de representar a un usuario, y se
utiliza para realizar todas las operaciones con él. Para comenzar, será necesario importar la clase desde
el módulo `asapa`:

```python
from asapa import ASAPAUser
```

Una vez importado, creamos una instancia por cada usuario que necesitemos. Es necesario indicar en el
constructor la clave `X-SHAPES-KEY`, proporcionada por los desarrolladores del servicio, y específica para
cada partner. En este manual, usaremos la definida para el entorno de pruebas. Así pues, para gestionar a un
usuario de ejemplo llamado *Juan*, haríamos lo siguiente:

```python
shapes_key = "7Msbb3w^SjVG%j"
juan = ASAPAUser(shapes_key)
```

A partir de ahora, podremos autenticar, obtener el token de autorización, la información del usuario, etc.
usando esa instancia, `juan`.


# Autenticación

Obviamente, la instancia está creada, pero no se ha autenticado en el sistema. Para ello, debemos proporcionar
las credenciales para ese usuario (que ya había sido registrado en ASAPA previamente). Utilizaremos el método
`login`, pasando como argumentos: 1) **correo electrónico** del usuario, y 2) **contraseña** (en texto plano).

El método login retorna `True` o `False`, en función de si la autenticación has sido correcta o no:

```python
ok = juan.login("juansinmiedo@correo.es", "mySecretPassword")
if ok:
    print("Usuario correctamente autenticado.")
else:
    print("Usuario o contraseña incorrectos.")
```

También es posible saber si un usuario está autenticado o no por medio del método `is_logged_in()`, que retorna
un valor *booleano*.

```python
print("- Juan está autenticado?", "Si." if juan.is_logged_in() else "No.")
```


# Obtención del token

Para autorizar a este usuario en otros servicios de Shapes, es necesario incluir en todas las peticiones
una cabecera específica. El nombre de la cabecera puede variar (por ejemplo, para el propio ASAPA es
`X-Pasiphae-Auth`), pero su valor es siempre el mismo: el token que se ha obtenido en la autenticación del
usuario. Este token está accesible desde la propiedad `token` de la instancia del usuario:

```python
print(f"- Token de autorización: {juan.token}")
```

Si el usuario no se ha autenticado correctamente (`is_logged_in()` retorna `False`), entonces el valor del
token será `None`. En caso contrario, será una cadena de texto en la forma `v2.local.ghWat_P0ESn....PLA`.


# Información del usuario

Con la instancia del usuario también es posible obtener sus metadatos registrados en ASAPA. Para ello,
usamos el método `get_information()`. Es necesario que el usuario se haya autenticado previamente.

```python
print(f"- Información de Juan: {juan.get_information()}")
```

El método `get_information()` siempre retorna un diccionario. Si ha habido un problema al obtener los datos,
el diccionario estará vacío. Si se han podido obtener correctamente, contendrá los registros que existan en
la DB de ASAPA.


# Registro

Si el usuario no existe en ASAPA, es posible registrarlo. Para ello, empleamos el método `register()`, que
acepta dos parámetros obligatorios y uno opcional. Los parámetros requeridos son: 1) el **correo electrónico**
del usuario y 2) su **contraseña**. El tercer parámetro es un diccionario con información específica de este
usuario, los llamados metadatos.

> **NOTA:** en el caso de los metadatos, se deben usar nombres únicos para evitar reemplazar
> información de otras aplicaciones. Lo recomendable es emplear prefijos de aplicación para las claves.

Si el usuario se crea correctamente, el método `register()` no devolverá nada. En caso contrario, lanzará una
exception `ValueError` con información sobre el problema encontrado (generalmente, que el usuario ya está
registrado en el sistema). Así pues, por ejemplo, para crear al usuario 'Pedro', haríamos algo como lo
siguiente:

```python
pedro = ASAPAUser(shapes_key)
try:
    pedro.register("pedrosinmiedo@correo.es", "SN(#*&dfkjhk3s", {"test": "This is a test user."})
    print("- Nuevo usuario creado correctamente.")
except ValueError:
    print("- El usuario ya existe, no se ha podido crear.")
```

> **Nota**: el método `register()` sólo registra al usuario en el sistema, no realiza la autorización. Es decir,
> para usar ese objeto como se ha descrito hasta ahora, será necesario autenticarlo usando `login()`.
