#!/usr/bin/python3

import re
from distutils.core import setup


def get_version():
    with open('debian/changelog') as fr:
        retval = re.search(r'\((.*)-\d*\)', fr.read()).group(1)
    return retval


def get_short_description():
    with open('debian/control') as fr:
        retval = re.search(
            r'^Description:(.*)$',
            fr.read(),
            re.MULTILINE).group(1).strip()
    return retval


setup(
    name          = 'asapa',
    version       = get_version(),
    description   = get_short_description(),
    author        = "Oscar Acena",
    author_email  = "oscaracena@gmail.com",
    url           = "https://bitbucket.org/arco_group/prj.shapes",

    py_modules    = ["asapa"],
)
