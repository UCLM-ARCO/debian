import logging
from pathlib import Path
from argparse import ArgumentParser
import Ice

logging.basicConfig()

log = logging.getLogger("ModuleTools")
log.setLevel(logging.INFO)

SYSTEM_SLICE_DIR = "/usr/share/slice/phyxio"

# load common slices
runner_slice = (Path(__file__) / "../../module-runner.ice").resolve()
if not runner_slice.exists():
    log.debug(f" slice '{runner_slice}' missing, try system wide...")
    runner_slice = Path(f"{SYSTEM_SLICE_DIR}/module-runner.ice").resolve()
log.info(f" loading slice '{runner_slice}'...")
Ice.loadSlice(runner_slice.as_posix())


# this function is to be called from inside a module, which follows the
# structure: modname/src/slicename.ice
# - loc: the __file__ object from modname/src/bin/modname.py
# - name: name of the slice file (usually modname.ice)
def load_slice(loc, name):
    slice_path = (Path(loc) / f"../../{name}").resolve()
    if not slice_path.exists():
        log.debug(f" slice '{slice_path}' missing, try system wide...")
        slice_path = (Path(f"{SYSTEM_SLICE_DIR}/{name}")).resolve()
    log.info(f" loading slice '{slice_path}'...")
    Ice.loadSlice(slice_path.as_posix())


class AttrDict(dict):
    """Use keys as attributes."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__dict__ = self


def get_global_parser():
    parser = ArgumentParser()

    # options provided by phyxio, required by all modules
    parser.add_argument("--iterations", type=int, required=True,
        help="number of iterations for this exercise")
    parser.add_argument("--runner-prx", required=True,
        help="proxy for IPC with the runner")

    # common config options, defined in 'config:module-options'
    parser.add_argument("--camera-source", type=str, default="/dev/video0",
        help="camera device path (ie. /dev/video0)")
    parser.add_argument("--video-sink", type=str, default="/dev/video5",
        help="V4L2Loopback device as video sink (ie. /dev/video5)")
    parser.add_argument("--video-width", type=int, default=1280,
        help="input and output video width")
    parser.add_argument("--video-height", type=int, default=720,
        help="input and output video height")
    parser.add_argument("--video-fps", type=int, default=30,
        help="input and output video frames per second")

    return parser
