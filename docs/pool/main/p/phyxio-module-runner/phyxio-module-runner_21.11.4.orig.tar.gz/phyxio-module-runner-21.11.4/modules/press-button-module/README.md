## Descripción

Este módulo es un ejemplo mínimo (pero completo) de Phyxio, pensado para probar el sistema, con la mayor complejidad posible.

Se encarga de monitorizar el siguiente escenario: el usuario tiene que pulsar tres botones físicos, según el ejercicio se lo indique, en un orden fijo o aleatorio. Esto implica lo siguiente:

* el módulo debe acceder a hardware específico (los botones).
* el ejercicio usa parámetros para configurar el módulo (orden fijo o aleatorio). Algunos los extrae de los `ExerciseIteration`: el número de iteraciones indica la veces que ha de pulsar una tecla
* el módulo proporciona feedback a Phyxio: le indica cuándo se ha pulsado el botón, para así poder pasar al siguiente, o si es el botón incorrecto.
* el módulo debe generar un reporte con el tiempo que tarda el usuario para pulsar cada botón, los fallos que ha cometido, etc.

Por otro lado, el módulo también deberá proporcionar la interfaz empotrada de control (ECI), un componente HTML/JS que se incluirá en la vista durante la realización del ejercicio, y que servirá para dar instrucciones al usuario, recibir feedback del módulo, etc.
