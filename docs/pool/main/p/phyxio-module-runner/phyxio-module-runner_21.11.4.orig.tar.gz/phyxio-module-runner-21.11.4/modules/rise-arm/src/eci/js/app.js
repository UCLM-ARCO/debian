// const FEEDBACK_WAIT = 1000;

// class PressButtonClientI extends Phyxio.PressButtonClient {
//    constructor() {
//       super();
//       this.total_iters = 1;
//       this.current_iter = 1;
//       this.current_btn = 1;
//       this.wait = false;
//    }

//    setTimeLimit(time) {
//       _(`setTimeLimit ${time}`);
//    }

//    setIterations(current, total) {
//       _(`setIterations ${current}, ${total}`);
//       this.total_iters = total;
//       this.current_iter = current;
//    }

//    setNextButton(btnId) {
//       _(`setNextButton ${btnId}`);
//       if (!this.wait)
//          this.setup_iter(btnId);
//       else
//          setTimeout(() => {
//             this.setup_iter(btnId);
//          }, FEEDBACK_WAIT);
//    }

//    setup_iter(btnId) {
//       $('.top img, .bottom img').css("visibility", "hidden");
//       $(`#btn-${btnId} .top img`)
//          .attr("src", "eci/images/arrow-down.png")
//          .css("visibility", "visible");
//       $("#iter-counter").text(`${this.current_iter} / ${this.total_iters}`);
//       this.current_btn = btnId;
//       this.wait = false;
//    }

//    onPress(result) {
//       _(`onPress ${result}`);
//       this.wait = true;

//       result = JSON.parse(result);
//       if (result.status == "ok") {
//          $(`#btn-${this.current_btn} .top img`)
//             .attr("src", "eci/images/square-check.png");
//       }
//       else {
//          $(`#btn-${this.current_btn} .top img`)
//             .attr("src", "eci/images/square-times.png");
//          $(`#btn-${result.pressed} .bottom img`)
//             .css("visibility", "visible");
//       }
//    }

//    setFinished(results) {
//       _(`setFinished: ${results}`);
//       results = JSON.parse(results);
//       if (!this.wait)
//          this.show_finish(results);
//       else
//          setTimeout(this.show_finish, FEEDBACK_WAIT, results);
//    }

//    show_finish(r) {
//       $('#play-area').hide();
//       $('#results-total').text(r.total);
//       $('#results-failed').text(r.failed);
//       $('#results-correct').text(r.total - r.failed);
//       $('#results').show();
//    }
// };

class RiseArmApp {
   constructor(ic) {
      this.ic = ic;
      this._check_and_connect_video();
   }

   async setup(proxy) {
      _("RiseArmApp: setup...");
      this.mod_observer = Phyxio.ObserverPrx.uncheckedCast(
         this.ic.stringToProxy(proxy)
      );

      this.adapter = await this.ic.createObjectAdapter("");
//       this.client_prx = Phyxio.PressButtonClientPrx.uncheckedCast(
//          this.adapter.addWithUUID(new PressButtonClientI())
//       );

      return await this.connect();
   }

   async connect() {
      _("RiseArmApp: connect...");

      try {
         var conn = this.mod_observer.ice_getCachedConnection()
         if (!conn) {
            await this.mod_observer.ice_ping();
            conn = this.mod_observer.ice_getCachedConnection();
         }
         conn.setAdapter(this.adapter);
         await this.mod_observer.setClientProxy(this.client_prx);
         return true;
      }
      catch (err) {
         var reason = err;
         if (err.ice_id)
            reason = err.ice_id();
         console.error("RiseArmApp: could not register servant, reason: " + reason);
         return false;
      }
   }

   async _check_and_connect_video() {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
         show_error("<h2>Sorry, mediaDevices not supported here!</h2>");
         return;
      }

      var retry_count = 7;
      async function _check_devid() {
         // check if phyxio camera is found
         const devices = await navigator.mediaDevices.enumerateDevices();
         let device_id = null;
         devices.some(dev => {
            if (dev.label == "phyxio") {
               device_id = dev.deviceId;
               return true;
            }
         });

         // if not found, retry
         if (device_id == null) {
            if (--retry_count) {
               setTimeout(_check_devid.bind(this), 500);
               return;
            }
            show_error("Could not open video device (not found).");
         }

         this._connect_video(device_id);
      };

      // force to show ask-permission-dialog to use video devices
      navigator.mediaDevices.getUserMedia({video: true})
         .then(_check_devid.bind(this)).catch(_check_devid.bind(this));
   }

   async _connect_video(device_id) {
      _(`Video device found: ${device_id}`);

      let video = $('#play-area video')[0];
      let constraints = {video: {deviceId: {exact: device_id}}};
      try {
         const stream = await navigator.mediaDevices.getUserMedia(constraints);
         video.srcObject = stream;
         video.play();
      } catch(err) {
         show_error(`ERROR: ${err} `);
      }
   }
};

function create_ice_comm() {
   var idata = new Ice.InitializationData();
   idata.properties = Ice.createProperties();
   idata.properties.setProperty("Ice.ACM.Client.Heartbeat", "3");
   return Ice.initialize(idata);
}

function show_error(msg) {
   $('#play-area').hide();
   $('#error-msg').append(msg).show();
}

window.addEventListener("load", async function() {
   let params = get_eci_params();

   try {
      var ic = create_ice_comm();
      var server = new RiseArmApp(ic, params);
      if (!await server.setup(params.proxy)) {
         // FIXME: translate this
         show_error("There were some problem, can not contact with service.");
         return;
      }
    }
    catch (err) {
        if (err.ice_id)
           err = err.ice_id();
        console.error("Error on initialization: " + err);
    }
});

