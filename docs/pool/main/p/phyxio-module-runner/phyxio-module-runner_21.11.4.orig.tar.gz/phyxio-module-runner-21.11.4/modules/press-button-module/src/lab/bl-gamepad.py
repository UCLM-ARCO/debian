#!/usr/bin/env python3

import pygame


pygame.init()
clock = pygame.time.Clock()
pygame.joystick.init()

joystick_count = pygame.joystick.get_count()
if joystick_count == 0:
    print("No gamepads connected!")
    exit(1)

joystick = pygame.joystick.Joystick(0)
joystick.init()


def loop():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.JOYBUTTONDOWN:
                print(f"Joystick button {event.button} pressed.")
            elif event.type == pygame.JOYBUTTONUP:
                print(f"Joystick button {event.button} released.")

        clock.tick(20)

try:
    loop()
except KeyboardInterrupt:
    pygame.quit()
