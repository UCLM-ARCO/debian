
const FEEDBACK_WAIT = 1000;

class PressButtonClientI extends Phyxio.PressButtonClient {
   constructor() {
      super();
      this.total_iters = 1;
      this.current_iter = 1;
      this.current_btn = 1;
      this.wait = false;
   }

   setTimeLimit(time) {
      _(`setTimeLimit ${time}`);
   }

   setIterations(current, total) {
      _(`setIterations ${current}, ${total}`);
      this.total_iters = total;
      this.current_iter = current;
   }

   setNextButton(btnId) {
      _(`setNextButton ${btnId}`);
      if (!this.wait)
         this.setup_iter(btnId);
      else
         setTimeout(() => {
            this.setup_iter(btnId);
         }, FEEDBACK_WAIT);
   }

   setup_iter(btnId) {
      $('.top img, .bottom img').css("visibility", "hidden");
      $(`#btn-${btnId} .top img`)
         .attr("src", "eci/images/arrow-down.png")
         .css("visibility", "visible");
      $("#iter-counter").text(`${this.current_iter} / ${this.total_iters}`);
      this.current_btn = btnId;
      this.wait = false;
   }

   onPress(result) {
      _(`onPress ${result}`);
      this.wait = true;

      result = JSON.parse(result);
      if (result.status == "ok") {
         $(`#btn-${this.current_btn} .top img`)
            .attr("src", "eci/images/square-check.png");
      }
      else {
         $(`#btn-${this.current_btn} .top img`)
            .attr("src", "eci/images/square-times.png");
         $(`#btn-${result.pressed} .bottom img`)
            .css("visibility", "visible");
      }
   }

   setFinished(results) {
      _(`setFinished: ${results}`);
      results = JSON.parse(results);
      if (!this.wait)
         this.show_finish(results);
      else
         setTimeout(this.show_finish, FEEDBACK_WAIT, results);
   }

   show_finish(r) {
      $('#play-area').hide();
      $('#results-total').text(r.total);
      $('#results-failed').text(r.failed);
      $('#results-correct').text(r.total - r.failed);
      $('#results').show();
   }
};

class PressButtonServer {
   constructor(ic) {
      this.ic = ic;
   }

   async setup(proxy) {
      _("PressButtonServer: setup...");
      this.mod_observer = Phyxio.ObserverPrx.uncheckedCast(
         this.ic.stringToProxy(proxy)
      );

      this.adapter = await this.ic.createObjectAdapter("");
      this.client_prx = Phyxio.PressButtonClientPrx.uncheckedCast(
         this.adapter.addWithUUID(new PressButtonClientI())
      );

      return await this.connect();
   }

   async connect() {
      _("PressButtonServer: connect...");

      try {
         var conn = this.mod_observer.ice_getCachedConnection()
         if (!conn) {
            await this.mod_observer.ice_ping();
            conn = this.mod_observer.ice_getCachedConnection();
         }
         conn.setAdapter(this.adapter);
         await this.mod_observer.setClientProxy(this.client_prx);
         return true;
      }
      catch (err) {
         var reason = err;
         if (err.ice_id)
            reason = err.ice_id();
         console.error("PressButtonServer: could not register servant, reason: " + reason);
         return false;
      }
   }
};

function create_ice_comm() {
   var idata = new Ice.InitializationData();
   idata.properties = Ice.createProperties();
   idata.properties.setProperty("Ice.ACM.Client.Heartbeat", "3");
   return Ice.initialize(idata);
}

function show_error(msg) {
   $('#play-area').hide();
   $('#error-msg').append(msg).show();
}

window.addEventListener("load", async function() {
   let params = get_eci_params();

   try {
      ic = create_ice_comm();
      pb_server = new PressButtonServer(ic);
      if (!await pb_server.setup(params.proxy)) {
         // FIXME: translate this
         show_error("There were some problem, can not contact with service.");
         return;
      }
    }
    catch (err) {
        var reason = err;
        if (err.ice_id)
           reason = err.ice_id();
        console.error("Error on initialization: " + reason);
    }
});

