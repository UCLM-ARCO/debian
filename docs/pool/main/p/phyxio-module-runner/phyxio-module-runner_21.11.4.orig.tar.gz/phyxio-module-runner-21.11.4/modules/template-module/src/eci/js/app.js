
class MyModuleApp {
   constructor(ic, params) {
      this.ic = ic;

      _(params.video_dev);
   }

   async setup(proxy) {
      _("MyModuleApp: setup...");
      this.mod_observer = Phyxio.ObserverPrx.uncheckedCast(
         this.ic.stringToProxy(proxy)
      );

      this.adapter = await this.ic.createObjectAdapter("");

      //
      // create here a servant of your module
      // this.client_prx = Phyxio.MyModuleClientPrx.uncheckedCast(
      //   this.adapter.addWithUUID(new MyMomduleClientI())
      // );
      //

      return await this.connect();
   }

   async connect() {
      _("MyModuleApp: connect...");

      try {
         var conn = this.mod_observer.ice_getCachedConnection()
         if (!conn) {
            await this.mod_observer.ice_ping();
            conn = this.mod_observer.ice_getCachedConnection();
         }
         conn.setAdapter(this.adapter);
         await this.mod_observer.setClientProxy(this.client_prx);
         return true;
      }
      catch (err) {
         var reason = err;
         if (err.ice_id)
            reason = err.ice_id();
         console.error("MyModuleApp: could not register servant, reason: " + reason);
         return false;
      }
   }
};

function create_ice_comm() {
   var idata = new Ice.InitializationData();
   idata.properties = Ice.createProperties();
   idata.properties.setProperty("Ice.ACM.Client.Heartbeat", "3");
   return Ice.initialize(idata);
}

function show_error(msg) {
   $('#play-area').hide();
   $('#error-msg').append(msg).show();
}

window.addEventListener("load", async function() {
   let params = get_eci_params();

   try {
      var ic = create_ice_comm();
      var server = new RiseArmApp(ic, params);
      if (!await server.setup(params.proxy)) {
         // FIXME: translate this
         show_error("There were some problem, can not contact with service.");
         return;
      }
    }
    catch (err) {
        if (err.ice_id)
           err = err.ice_id();
        console.error("Error on initialization: " + err);
    }
});

