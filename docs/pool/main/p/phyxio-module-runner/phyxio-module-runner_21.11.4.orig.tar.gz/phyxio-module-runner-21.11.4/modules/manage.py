#!/usr/bin/env python3

# This script is used to create a new module, using 'template-module' as
# boilerplate.

print("FIXME! implement this tool.")
