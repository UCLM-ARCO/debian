#!/usr/bin/env python3

# pylint: disable = logging-fstring-interpolation

import os
import sys
import logging
import json
import yaml
import ssl
from urllib.parse import urljoin, urlparse
from subprocess import Popen, TimeoutExpired, signal
from pathlib import Path
from threading import Thread, Event
from http.server import HTTPServer, BaseHTTPRequestHandler
from argparse import ArgumentParser
import Ice

from libs import Phyxio

logging.basicConfig()
log = logging.getLogger("ModuleRunner")
log.setLevel(logging.INFO)


class HTTPResquestHandler(BaseHTTPRequestHandler):
    DEFAULT_FILE = "index.html"

    def do_GET(self):
        asset = self._get_requested_asset()
        if asset is None:
            log.info(f" HTTP GET {self.path}, ret: 404")
            return self._response_404()

        log.info(f" HTTP GET {asset}, ret: 200")
        mimetype = self._get_mime_type(asset)
        self._copy_file(asset, mimetype)

    def log_message(self, format, *args):
        return

    def _get_requested_asset(self):
        path = urlparse(self.path).path
        req = Path(path)
        resource_path = None
        for p in self.server.static_paths:
            absp = Path("/") / p
            try:
                remain = req.relative_to(absp)
                resource_path = req.relative_to("/")
                if remain == Path("."):
                    resource_path /= self.DEFAULT_FILE
                break
            except ValueError:
                continue

        if resource_path is None or not resource_path.is_file():
            return None
        return resource_path

    def _get_mime_type(self, asset):
        return {
            ".html": "text/html",
            ".css": "text/css",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".js": "text/javascript",
        }.get(asset.suffix.lower(), "application/octet-stream")

    def _response_404(self):
        self.send_response(404)
        self.end_headers()

    def _copy_file(self, asset, mimetype):
        self.send_response(200)
        self.send_header('Content-type', mimetype)
        self.end_headers()
        self.wfile.write(asset.open("rb").read())


class HTTPServerDaemon(Thread):
    def __init__(self, settings):
        super().__init__()
        host = settings.get("http-server-host", "127.0.0.1")
        port = settings.get("http-server-post", 7501)
        cert_path = settings.get("ssl-cert", "localhost-cert.pem")
        key_path = settings.get("ssl-key", "localhost-key.pem")

        self._static_paths = set()
        self._httpd = HTTPServer((host, port), HTTPResquestHandler)

        sslctx = ssl.SSLContext(ssl.PROTOCOL_TLS)
        sslctx.load_cert_chain(cert_path, key_path)
        self._httpd.socket = sslctx.wrap_socket(self._httpd.socket, server_side = True)
        self._httpd.static_paths = self._static_paths
        self._base_url = f"https://{host}:{port}"

        self.daemon = True
        self.start()

    def run(self):
        self._httpd.serve_forever()

    def add_static_path(self, path):
        self._static_paths.add(Path(path))
        return urljoin(self._base_url, path.as_posix())

    def remove_static_path(self, path):
        self._static_paths.remove(Path(path))


class ModuleHandlerI(Phyxio.ModuleHandler):
    def __init__(self, modname, adapter, runner):
        self._proxy = None

        self._modname = modname
        self._adapter = adapter
        self._runner = runner
        self._ready = Event()

    def enable(self):
        self._ready.clear()
        if self._proxy is None:
            self._proxy = self._adapter.addWithUUID(self)

    def disable(self):
        if self._proxy is not None:
            self._adapter.remove(self._proxy.ice_getIdentity())
            self._proxy = None

    def wait_for_ready(self, tout=1):
        return self._ready.wait(tout)

    def ready(self, current):
        self._ready.set()

    def finished(self, report, current):
        self._runner.notify_finished(self._modname, report)


class ModuleDef:
    NO_MODULE_URL = "/module/not-running"

    def __init__(self, runner, httpserver, adapter, opts, settings):
        # public fields
        self.is_running = False
        self.name = opts["codename"]
        self.exec = opts["exec"]
        self.eci_url = self.NO_MODULE_URL
        self.eci_path = opts["module_dir"] / "eci"
        self.info = json.dumps(opts.get("eci_params", "{}"))

        # private parts
        self._settings = settings
        self._httpserver = httpserver
        self._process = None
        self._mh = ModuleHandlerI(self.name, adapter, runner)

        assert self.eci_path.is_dir(), f"missing directory: {self.eci_path}"

    def run(self, params):
        if self.is_running:
            return False

        if self._process is not None:
            log.error(" this module is already running!")
            return False

        if not self._run_process(params):
            log.error(f" module '{self.name}' could not start!!")
            self._stop_process()
            return False

        self.eci_url = self._httpserver.add_static_path(self.eci_path)
        self.is_running = True
        log.info(f" module '{self.name}' successfully started.")
        return True

    def _run_process(self, params):
        if not os.access(self.exec, os.X_OK):
            log.error(f" module path '{self.exec}' is not executable!")
            return False

        self._mh.enable()
        cmd = [self.exec.as_posix(), "--runner-prx", str(self._mh._proxy)]

        # update args with common module options
        for name, value in self._settings.get("module-options", {}).items():
            cmd += [f"--{name}", str(value)]

        # add user defined options
        if params.iterations:
            cmd += ["--iterations", f"{params.iterations}"]
        if params.runtime:
            cmd += ["--runtime", f"{params.runtime}"]
        cmd += params.config.split()

        str_cmd = " ".join(cmd)
        log.info(f" running module as: '{str_cmd}'")
        try:
            # note: PYTHONPATH is changed to a system wide path, using a patch
            self._process = Popen(cmd,
                env={"PYTHONPATH": Path(__file__).parent.resolve()})
        except OSError as ex:
            log.error(f" module binary could not run: {ex}")
            return False

        return self.wait_for_ready()

    def wait_for_ready(self):
        ready = False

        count = 5  # wait up to 5 seconds
        while self._process.returncode is None and count != 0:
            if self._mh.wait_for_ready(1):
                ready = True
                break
            count -= 1

        return ready

    def stop(self):
        if not self.is_running or self._process is None:
            return False
        if not self._stop_process():
            return False

        self._mh.disable()
        self._httpserver.remove_static_path(self.eci_path)
        self.eci_url = self.NO_MODULE_URL
        self.is_running = False
        log.info(f" module '{self.name}' successfully stopped.")
        return True

    def _stop_process(self):
        if self._process is None:
            return False

        log.info(f" module '{self.name}', stopping process...")

        # first: try to gracefully quit process
        for sig in [signal.SIGINT, signal.SIGQUIT]:
            try:
                self._process.send_signal(sig)
                log.info(f" - {signal.strsignal(sig)} sent...")
                self._process.wait(1.5)
                self._process = None
                return True
            except TimeoutExpired:
                pass

        # otherwise: force to terminate
        try:
            self._process.terminate()
            log.info(f" - terminate sent...")
            self._process.wait(1)
        except TimeoutExpired:
            log.info(f" - kill sent...")
            self._process.kill()

        self._process = None
        return True


class ModuleRunnerI(Phyxio.ModuleRunner):
    def __init__(self, settings, adapter):
        super().__init__()
        self._httpserver = HTTPServerDaemon(settings)
        self._httpserver.add_static_path(Path("shared"))
        self._modules = {}

        # there is only one observer because there is only one user interface
        self._observer = None
        self._running = None

        self._settings = settings
        self._adapter = adapter
        self._load_modules(settings.get("module-dir", "modules"))

    def start(self, modname, modparams, current):
        log.info(f" start called, '{modname}'...")
        mod = None

        if self._running is not None:
            log.warning(f" there is already a module running ({self._running.name})...")
            if self._running.name != modname:
                log.info(" - module is different, I'll stop the former...")
                self.stop()
            else:
                log.info(" - try to resync module with client...")
                if not self._running.wait_for_ready():
                    log.info(" - could not resync, stopping it...")
                    self.stop()
            mod = self._running

        if mod is None:
            mod = self._get_module(modname)
            if mod.run(modparams):
                self._running = mod

        # notify observer about this module status
        if self._observer is not None and mod.eci_url:
            info = Phyxio.ModuleInfo(mod.eci_url, mod.info)
            self._observer.sendModuleInfoAsync(info)

    def stop(self, current=None):
        if self._running is None:
            log.info(" stop called, but no module running")
            return

        self._running.stop()
        self._running = None

    def getReport(self, modname, current):
        log.info(f" getReport called, '{modname}'")

    def setObserver(self, observer, current):
        log.info(f" setObserver called, '{observer}'")
        self._observer = observer.ice_fixed(current.con)

    def notify_finished(self, modname, report):
        if self._observer is None:
            return

        info = {
            "modname": modname,
            "status": "finished",
            "report": json.loads(report),
        }
        self._observer.sendStatusAsync(json.dumps(info))

    def _get_module(self, modname):
        try:
            return self._modules[modname]
        except KeyError:
            log.error(f" No such module: '{modname}'")
            raise Phyxio.NoSuchModule(modname)

    def _load_modules(self, module_dir):
        module_dir = Path(module_dir)
        if not module_dir.is_dir():
            raise RuntimeError(f"Invalid module dir: {module_dir}")

        for d in module_dir.iterdir():
            if not d.is_dir():
                continue
            mod_def = d / "module.json"
            if not mod_def.is_file():
                log.warning(f" Invalid module {d}, discarded")
                continue
            self._load_module(mod_def)

    def _load_module(self, mod_def):
        log.info(f" Loading module {mod_def}")
        try:
            mod_props = json.load(mod_def.open())
            for k in ["codename", "name", "exec"]:
                assert k in mod_props, f"missing key: {k}"

            codename = mod_props['codename']
            mod_dir = mod_props.get("module_dir", ".")
            mod_props["module_dir"] = mod_def.parent / mod_dir
            mod_props["exec"] = mod_props["module_dir"] / mod_props["exec"]

            self._modules[codename] = ModuleDef(self,
                self._httpserver, self._adapter, mod_props, self._settings)
            log.info(f" - module named '{codename}' correctly loaded!")

        except (json.JSONDecodeError, KeyError, AssertionError) as err:
            log.warning(f" Invalid module '{mod_def}'")
            if isinstance(err, KeyError):
                err = f"missing key: {err}"
            log.warning(f"  - {err}")


class ModuleRunnerService(Ice.Application):
    def run(self, args_):
        if not self._check_args(args_):
            return -1

        if not os.path.exists(self.args.config):
            log.error(f" configuration file ({self.args.config}) does not exist!")
            return -1

        ic = self.communicator()
        adapter = ic.createObjectAdapter("ModuleRunner.Adapter")
        adapter.activate()

        settings = yaml.safe_load(open(self.args.config))
        prx = adapter.add(
            ModuleRunnerI(settings, adapter),
            Ice.stringToIdentity("ModuleRunner"))
        log.info(f" Service ready: {prx}")
        log.info(" Waiting events....")

        self.shutdownOnInterrupt()
        try:
            ic.waitForShutdown()
        except KeyboardInterrupt:
            log.info(" Exiting...")

    def _check_args(self, args):
        parser = ArgumentParser()
        parser.add_argument("--Ice.Config", dest="icecfg",
            help="configuration file path with Ice related settings")
        parser.add_argument("--config", required=True,
            help="configuration file path with service settings")

        try:
            self.args = parser.parse_args(args[1:])
            return True
        except SystemExit:
            return False


if __name__ == "__main__":
    ModuleRunnerService().main(sys.argv)
