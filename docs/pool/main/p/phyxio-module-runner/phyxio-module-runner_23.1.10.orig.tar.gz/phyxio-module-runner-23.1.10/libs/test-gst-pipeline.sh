#!/bin/bash

# In case of SEGFAULT, this may help you catch it.

PIPELINE="
 v4l2src device=/dev/video0 extra-controls=c,exposure_auto=1,exposure_absolute=250
 ! image/jpeg,width=1280,height=720,framerate=30/1
 ! decodebin
 ! videoflip video-direction=horiz
 ! tee name=t

 t. ! queue max-size-buffers=1 leaky=downstream
    ! videoconvert
    ! rsvgoverlay name=pre-scale-overlay
    ! videoconvert
    ! v4l2sink device=/dev/video5 name=rendersink sync=false qos=false

 t. ! queue max-size-buffers=1 leaky=downstream
    ! video/x-raw,format=RGB,width=1280,height=720
    ! videoconvert
    ! appsink name=appsink emit-signals=true max-buffers=1 drop=true
"

#   ! xvimagesink

# gdb -ex r --args gst-launch-1.0 $PIPELINE
gst-launch-1.0 $PIPELINE
