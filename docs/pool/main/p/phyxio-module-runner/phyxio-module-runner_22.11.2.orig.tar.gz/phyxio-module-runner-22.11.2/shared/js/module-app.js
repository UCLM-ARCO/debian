
class IterCtrl {
    constructor() {
        this.total_iters = 1;
        this.current_iter = 1;
    }

    set_no_limit() {
        $('#iter-counter .expected h1').text("Max.");
    }

    update(current, total) {
        this.total_iters = total;
        this.current_iter = current;

        if (total)
            $('#iter-counter .expected h1').text(`${total}`.padStart(2, "0"));
        $('#iter-counter .current h1').text(`${current}`.padStart(2, "0"));
    }
};

class TimerCtrl {
    constructor(limit) {
        this._time_limit = limit;

        this._start_ts = null;
        this._timer = null;
    }

    set_limit(limit) {
        this._time_limit = limit;
    }

    is_running() {
        return this._start_ts != null;
    }

    start() {
        // update expected counter and timeout
        let mins = Math.floor(this._time_limit / 60);
        let secs = this._time_limit % 60;
        this._update_timer_ui(mins, secs, 100);

        // start timer (if not started) to update timeout
        if (!this._start_ts) {
            this._start_ts = Date.now();
            this._timer = setInterval(this._update_elapsed.bind(this), 1000);
        }
    }

    _update_elapsed() {
        // count time upwards
        if (!this._time_limit) {
            let elapsed = new Date(Date.now() - this._start_ts);
            let width = lerp(elapsed.getSeconds(), 0, 60, 5, 100);
            this._update_timer_ui(
                elapsed.getMinutes(), elapsed.getSeconds(), width);
        }
        // count time downwards
        else {
            let elapsed = Math.floor((Date.now() - this._start_ts) / 1000);
            let remain = Math.max(0, this._time_limit - elapsed);
            let mins = Math.floor(remain / 60);
            let secs = remain % 60;
            let width = lerp(remain, 0, this._time_limit, 5, 100);
            this._update_timer_ui(mins, secs, width);
            if (remain == 0) {
                clearInterval(this._timer);
            }
        }
    }

    _update_timer_ui(mins, secs, width) {
        $('#elapsed-s').text(secs);
        $('#elapsed-m').text(mins);
        $('#elapsed-per').css({ "width": `${width}%` });
    }
}

class ModuleApp {
    constructor(name, ic, params) {
        this.name = name;
        this.ic = ic;

        this._video_retry_count = 5;
        this._check_and_connect_video();
    }

    // to be implemented on subclasses
    _register_servants(adapter) {
    }

    async setup(proxy) {
        _(`${this.name}: setup...`);

        this.module_prx = Phyxio.ECIObserverPrx.uncheckedCast(
            this.ic.stringToProxy(proxy)
        );

        this.adapter = await this.ic.createObjectAdapter("");
        this._register_servants(this.adapter);
        return await this.connect();
    }

    async connect() {
        _(`${this.name}: connect...`);

        try {
            var conn = this.module_prx.ice_getCachedConnection()
            if (!conn) {
                await this.module_prx.ice_ping();
                conn = this.module_prx.ice_getCachedConnection();
            }
            conn.setAdapter(this.adapter);
            await this.module_prx.setClientProxy(this.client_prx);
            return true;
        }
        catch (err) {
            var reason = err;
            if (err.ice_id)
                reason = err.ice_id();
            console.error(`${this.name}: could not register servant, reason: ${reason}`);
            return false;
        }
    }

    async _check_and_connect_video() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
            show_error("<h2>Sorry, mediaDevices not supported here!</h2>");
            return;
        }

        var retry_count = 7;
        async function _check_devid() {
            // check if phyxio camera is found
            const devices = await navigator.mediaDevices.enumerateDevices();
            let device_id = null;
            devices.some(dev => {
                if (dev.label == "phyxio") {
                    device_id = dev.deviceId;
                    return true;
                }
            });

            // if not found, retry
            if (device_id == null) {
                if (--retry_count) {
                    setTimeout(_check_devid.bind(this), 500);
                    return;
                }
                show_error("Could not open video device (not found).");
            }

            this._connect_video(device_id);
        };

        // force to show ask-permission-dialog to use video devices
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(_check_devid.bind(this)).catch(_check_devid.bind(this));
    }

    async _connect_video(device_id) {
        _(`${this.name}: video device found: ${device_id}`);

        let video = $('#play-area video')[0];
        let constraints = { video: { deviceId: { exact: device_id } } };
        try {
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            var tr = stream.getVideoTracks()[0];
            tr.addEventListener("ended", (ev) => {
                if (this._video_retry_count <= 0) {
                    _('Warning: could not reconnect video after many retries.\n');
                    return;
                }
                this._video_retry_count--;
                setTimeout(() => this._connect_video(device_id), 500);
            });
            video.srcObject = stream;
            video.play();
        } catch (err) {
            show_error(`ERROR: ${err} `);
        }
    }
};

function create_ice_comm() {
    var idata = new Ice.InitializationData();
    idata.properties = Ice.createProperties();
    idata.properties.setProperty("Ice.ACM.Client.Heartbeat", "3");
    return Ice.initialize(idata);
}

function show_error(msg) {
    $('#play-area').hide();
    $('#error-msg').append(msg).show();
}

async function create_module_app(AppClass, name) {
    let params = get_eci_params();

    try {
        var ic = create_ice_comm();
        var server = new AppClass(name, ic, params);
        if (!await server.setup(params.proxy)) {
            // FIXME: translate this
            show_error("There were some problem, can not contact with service.");
            return;
        }
    }
    catch (err) {
        if (err.ice_id)
            err = err.ice_id();
        console.error("Error on initialization: " + err);
    }
}