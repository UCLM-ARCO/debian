# Requirements

Some modules will provide a video feedback of the user actions. In order to do so, the module runner must load and configure a V4L2Loopback device. To do so, run:

    make setup-devices
