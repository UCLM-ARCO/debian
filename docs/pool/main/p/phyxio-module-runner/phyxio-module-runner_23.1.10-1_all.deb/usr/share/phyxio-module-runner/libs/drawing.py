
import os
import math
import importlib
from xml.etree import ElementTree
from abc import ABC, abstractmethod
import svgwrite


class DrawingContext(ABC):
    ORANGE       = (253, 95, 0)     # RGB
    GREEN        = (134, 194, 50)   # RGB
    WHITE        = (255, 255, 255)  # RGB
    GRAY         = (50, 50, 50)     # RGB
    NORMAL_COLOR = ORANGE
    GOAL_COLOR   = GREEN
    TEXT_COLOR   = WHITE

    TEXT_SIZE    = 2
    TEXT_FONT    = "font-family:sans-serif"
    LINEW        = 2

    @abstractmethod
    def reset(self):
        """Discards whatever state this object may hold."""

    @abstractmethod
    def to_string(self):
        """Returns a string representation of this object."""

    @abstractmethod
    def angle(self, image, points, line_color=WHITE, joint_color=None, label="", draw_ids=False):
        """Draws an angle brackets."""

    @abstractmethod
    def percentage_bar(self, image, percentage, position, size, color=WHITE):
        """Draws a vertical percentage bar."""

    @abstractmethod
    def arc(self, image, position, radius, rotation, start, end, color=WHITE):
        """Draws an arc."""

    @abstractmethod
    def line(self, image, start, end, color=WHITE):
        """Draws a line."""

    @abstractmethod
    def dots(self, image, points, radius, color=ORANGE):
        """Draws a serie of points."""

    @abstractmethod
    def shadow_text(self, image, text, position=(0, 0)):
        """Draws text with a slight shadow behind."""

    @abstractmethod
    def degrees_text(self, image, value, position):
        """Draws a number and the degrees symbol."""


# got from: https://github.com/mozman/svgwrite/issues/13
class External(svgwrite.container.Group):
    NS = u'{http://www.w3.org/2000/svg}'

    def __init__(self, xml, **extra):
        self.xml = xml

        # Remove namespace
        nsl = len(self.NS)
        for elem in self.xml.iter():
            if elem.tag.startswith(self.NS):
                elem.tag = elem.tag[nsl:]

        super().__init__(**extra)

    def get_xml(self):
        return self.xml


class GstDrawingContext(DrawingContext):
    ORANGE       = f"rgb{DrawingContext.ORANGE}"
    GREEN        = f"rgb{DrawingContext.GREEN}"
    WHITE        = f"rgb{DrawingContext.WHITE}"
    GRAY         = f"rgb{DrawingContext.GRAY}"
    NORMAL_COLOR = ORANGE
    GOAL_COLOR   = GREEN
    TEXT_COLOR   = WHITE

    TEXT_SIZE    = 20

    def __init__(self, canvas_size, init=True):
        self._canvas_size = canvas_size
        if init:
            self.reset()

    def reset(self):
        self._canvas = svgwrite.Drawing('', size=self._canvas_size)

    def copy_linked(self):
        retval = GstDrawingContext(self._canvas_size, False)
        retval._canvas = self._canvas
        return retval

    def to_string(self):
        return self._canvas.tostring()

    def angle(self, image, points, line_color=WHITE, joint_color=None, label="", draw_ids=False):
        svg = self._canvas

        svg.add(svg.line(points[0], points[1], stroke=line_color, stroke_width=2))
        svg.add(svg.line(points[2], points[1], stroke=line_color, stroke_width=2))

        if joint_color is not None:
            svg.add(svg.circle(points[0], r=8, stroke=joint_color, fill=joint_color))
            svg.add(svg.circle(points[1], r=8, stroke=joint_color, fill=joint_color))
            svg.add(svg.circle(points[2], r=8, stroke=joint_color, fill=joint_color))

        settings = dict(style=self.TEXT_FONT, font_size=self.TEXT_SIZE, fill=self.GREEN)
        if draw_ids:
            x1, y1 = points[0]
            x2, y2 = points[1]
            x3, y3 = points[2]
            svg.add(svg.text("1", insert=(x1 + 10, y1), **settings))
            svg.add(svg.text("2", insert=(x2 - 30, y2), **settings))
            svg.add(svg.text("3", insert=(x3 + 10, y3), **settings))

        if label:
            svg.add(svg.text(label, insert=(x2 - 20, y2 + 50), **settings))

    def percentage_bar(self, image, percentage, position, size, color=WHITE):
        svg = self._canvas
        x, y = position
        w, h = size
        barh = int(h * percentage)

        svg.add(svg.rect((x, y), (w, h),
            stroke=color, stroke_width=self.LINEW, fill="none"))  # outside rect
        svg.add(svg.rect((x, y + h - barh), (w, barh),
            stroke=color, stroke_width=self.LINEW, fill=color))   # inside rect

        text = f'{int(percentage * 100)}%'
        svg.add(svg.text(text, (x, y - 5),
            fill=self.WHITE, font_size=self.TEXT_SIZE, style=self.TEXT_FONT))

    def arc(self, image, position, radius, rotation, start, end, color=WHITE):
        svg = self._canvas
        x0, y0 = position[0] + radius, position[1]
        x1, y1 = position[0] + radius, position[1]
        rad_start = math.radians(start % 360)
        rad_end = math.radians(end % 360)
        x0 -= (1 - math.cos(rad_start)) * radius
        y0 += math.sin(rad_start) * radius
        x1 -= (1 - math.cos(rad_end)) * radius
        y1 += math.sin(rad_end) * radius

        args = {
            'x0': x0,
            'y0': y0,
            'x1': x1,
            'y1': y1,
            'xradius': radius,
            'yradius': radius,
            'ellipseRotation': 0,
            'swap': 1 if end > start else 0,
            'large': 1 if abs(start - end) > 180 else 0,
        }

        # 'a/A' params: (rx,ry x-axis-rotation large-arc-flag,sweep-flag x,y)+ (case dictates relative/absolute pos)
        path = """M %(x0)f,%(y0)f
                  A %(xradius)f,%(yradius)f %(ellipseRotation)f %(large)d,%(swap)d %(x1)f,%(y1)f
        """ % args
        arc = svg.path(d=path, fill="none", stroke=color, stroke_width=3)
        arc.rotate(rotation, position)
        svg.add(arc)

    def line(self, image, start, end, color=WHITE):
        svg = self._canvas
        svg.add(svg.line(start, end, stroke=color, stroke_width=self.LINEW))

    def dots(self, image, points, radius, color=ORANGE):
        svg = self._canvas
        for p in points:
            svg.add(svg.circle(p, r=radius, stroke=color, fill=color))

    def shadow_text(self, image, text, position=(0, 0)):
        svg = self._canvas
        x, y = position

        svg.add(svg.text(text, insert=(x + 1, y + 1), fill=self.GRAY,
            font_size=self.TEXT_SIZE, style=self.TEXT_FONT))
        svg.add(svg.text(text, insert=(x, y), fill=self.WHITE,
            font_size=self.TEXT_SIZE, style=self.TEXT_FONT))

    def degrees_text(self, image, value, position):
        svg = self._canvas
        text = value + " °"

        svg.add(svg.text(text, insert=position, fill=self.TEXT_COLOR,
            font_size=self.TEXT_SIZE, style=self.TEXT_FONT))

    # other methods, not in base class
    def load_svg_layer(self, path, layer_name):
        try:
            assert os.path.exists(path), f"The given path ({path}) does not exist!"
            root = ElementTree.parse(path).getroot()
            layer = root.find(f"{External.NS}g[@id='{layer_name}']")
            assert layer, f"Layer '{layer_name}' not found on given document!"
            external = External(layer)
            self._canvas.add(external)
            return external
        except Exception as err:
            print("Error: could not load SVG layer:", err)


class Cv2DrawingContext(DrawingContext):
    ORANGE       = tuple(reversed(DrawingContext.ORANGE))  # BGR
    GREEN        = tuple(reversed(DrawingContext.GREEN))   # BGR
    WHITE        = tuple(reversed(DrawingContext.WHITE))   # BGR
    NORMAL_COLOR = ORANGE
    GOAL_COLOR   = GREEN
    TEXT_COLOR   = WHITE

    def __init__(self, canvas_size=None):
        # NOTE: not globally imported to speed up modules that do not use it
        global cv2
        cv2 = importlib.import_module("cv2")

        self.TEXT_FONT  = cv2.FONT_HERSHEY_PLAIN

    def reset(self):
        """This object is state-less."""

    def to_string(self):
        """Nothing to do here."""

    def angle(self, image, points, line_color=WHITE, joint_color=None, label="", draw_ids=False):
        x1, y1 = points[0]
        x2, y2 = points[1]
        x3, y3 = points[2]

        cv2.line(image, (x1, y1), (x2, y2), line_color, 2, cv2.LINE_AA)
        cv2.line(image, (x3, y3), (x2, y2), line_color, 2, cv2.LINE_AA)

        if joint_color is not None:
            cv2.circle(image, (x1, y1), 8, joint_color, cv2.FILLED, cv2.LINE_AA)
            cv2.circle(image, (x2, y2), 8, joint_color, cv2.FILLED, cv2.LINE_AA)
            cv2.circle(image, (x3, y3), 8, joint_color, cv2.FILLED, cv2.LINE_AA)

        settings = (self.TEXT_FONT, self.TEXT_SIZE, self.GREEN, self.LINEW, cv2.LINE_AA)
        if draw_ids:
            cv2.putText(image, "1", (x1 + 10, y1), *settings)
            cv2.putText(image, "2", (x2 - 30, y2), *settings)
            cv2.putText(image, "3", (x3 + 10, y3), *settings)

        if label:
            cv2.putText(image, label, (x2 - 20, y2 + 50), *settings)

    def percentage_bar(self, image, percentage, position, size, color=WHITE):
        x, y = position
        w, h = size

        cv2.rectangle(image, (x, y), (x + w, y + h), color, self.LINEW)         # outside rect
        cv2.rectangle(image, (x, y + h - int(h * percentage)), (x + w, y + h),  # inside rect
            color, cv2.FILLED)
        text = f'{int(percentage * 100)}%'
        tw = cv2.getTextSize(text, self.TEXT_FONT, self.TEXT_SIZE, self.LINEW)[0][0]
        cv2.putText(image, text, (x + w - tw // 2, y - 5),
            self.TEXT_FONT, self.TEXT_SIZE, self.TEXT_COLOR, self.LINEW, cv2.LINE_AA)

    def arc(self, image, position, radius, rotation, start, end, color=WHITE):
        cv2.ellipse(image, position, (radius, radius), rotation, start, end, color, self.LINEW, cv2.LINE_AA)

    def line(self, image, start, end, color=WHITE):
        cv2.line(image, start, end, color, self.LINEW, cv2.LINE_AA)

    def dots(self, image, points, radius, color=ORANGE):
        for p in points:
            cv2.circle(image, p, radius, color, cv2.FILLED, cv2.LINE_AA)

    def shadow_text(self, image, text, position=(0, 0)):
        x, y = position
        font = self.TEXT_FONT
        size = self.LINEW
        h = cv2.getTextSize(text, font, size, self.LINEW)[0][1]

        cv2.putText(image, text, (x + 1, y + h + 1),
            font, size, self.GRAY, self.LINEW, cv2.LINE_AA)
        cv2.putText(image, text, (x,     y + h),
            font, size, self.WHITE, self.LINEW, cv2.LINE_AA)

    def degrees_text(self, image, value, position):
        x, y = position
        ts, _ = cv2.getTextSize(value,
            self.TEXT_FONT, self.TEXT_SIZE, self.LINEW)
        cv2.putText(image, value, position,
            self.TEXT_FONT, self.TEXT_SIZE, self.TEXT_COLOR, self.LINEW, cv2.LINE_AA)
        cv2.circle(image, (x + 10 + ts[0], y + 3 - ts[1]), 4,
            self.WHITE, self.LINEW, cv2.LINE_AA)
