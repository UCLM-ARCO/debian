import cv2
import av


class V4L2LoopbackRenderer:
    def __init__(self, device, width=1280, height=720, fps=30):
        self._dev = av.open(device, mode="w", format="video4linux2,v4l2")
        self._stream = self._dev.add_stream("rawvideo", fps)
        self._stream.width = width
        self._stream.height = height
        self._stream.pix_fmt = 'rgb24'

    def render(self, img):
        frame = av.VideoFrame.from_ndarray(img, format='bgr24')
        for packet in self._stream.encode(frame):
            self._dev.mux(packet)
        return True

    def close(self):
        self._stream = None
        if getattr(self, "_dev") is not None:
            self._dev.close()
        del self._dev
        self._dev = None


class WindowRenderer:
    def render(self, img):
        cv2.imshow("Image", img)
        return cv2.waitKey(1) & 0xFF != 27

    def close(self):
        pass
