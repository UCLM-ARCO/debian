_ = console.info.bind(console);

function lerp(value, in_min, in_max, out_min, out_max) {
   return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

function get_from_referer(path) {
   let params = new URLSearchParams(window.location.search);
   let proto = params.get("proto") || "https:";
   let ref = params.get("referer");
   let static = params.get("static");

   return `${proto}//${ref}${static}/${path}`;
}

function get_eci_params() {
   let params = new URLSearchParams(window.location.search);
   let eci_params = params.get("eci_params");
   return JSON.parse(atob(eci_params));
}

function load_referer_css(path) {
   var head = document.getElementsByTagName('head')[0];
   var link = document.createElement('link');
   link.rel = 'stylesheet';
   link.type = 'text/css';
   link.href = get_from_referer(path);
   head.appendChild(link);
}

function load_referer_js(path) {
   var head = document.getElementsByTagName('head')[0];
   var script = document.createElement('script');
   script.type = 'text/javascript';
   script.src = get_from_referer(path);
   head.appendChild(script);
}

load_referer_css("css/bootstrap.min.css");
load_referer_css("css/animate.min.css");
load_referer_css("css/common.css");
load_referer_css('css/totem-style.css');

let mode = document.currentScript.getAttribute("data-mode");
if (mode == "mirror")
   load_referer_css('css/mirror-style.css');
