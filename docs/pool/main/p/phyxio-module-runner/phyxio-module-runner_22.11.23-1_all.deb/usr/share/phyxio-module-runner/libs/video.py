import fcntl
import importlib
import logging
import os.path
from abc import ABC, abstractmethod
from typing import Any, Iterable, Mapping

import cv2

logging.basicConfig()
log = logging.getLogger("VideoRenderer")
log.setLevel(logging.DEBUG)


class Renderer(ABC):
    def __init__(self, device: str, width: int = 1280,
                 height: int = 720, fps: int = 30) -> None:
        super().__init__()
        if not os.path.exists(device):
            raise RuntimeError(
                f'Given video device ({device}) ' +
                'does not exist!')
        self._device = device
        self._width = width
        self._height = height
        self._fps = fps

    @abstractmethod
    def render(self, image: Any) -> bool:
        """Render image to target device."""

    @abstractmethod
    def close(self) -> None:
        """Close renderer."""


class V4L2Renderer(Renderer):
    def __init__(self, device: str, width: int = 1280,
                 height: int = 720, fps: int = 30) -> None:
        super().__init__(device, width, height, fps)
        v4l2 = importlib.import_module('v4l2')  # ImportError
        self._dev = open(device, 'wb')
        self._fmt = v4l2.v4l2_format()
        self._fmt.type = v4l2.V4L2_BUF_TYPE_VIDEO_OUTPUT
        if fcntl.ioctl(self._dev, v4l2.VIDIOC_G_FMT, self._fmt) < 0:
            raise RuntimeError('Cannot set v4l2 video format (VIDIOC_G_FMT).')
        self._fmt.fmt.pix.width = width
        self._fmt.fmt.pix.height = height
        self._fmt.fmt.pix.pixelformat = v4l2.V4L2_PIX_FMT_RGB24
        self._fmt.fmt.pix.sizeimage = width * height * 3
        self._fmt.fmt.pix.bytesperline = width * 3
        if fcntl.ioctl(self._dev, v4l2.VIDIOC_S_FMT, self._fmt) < 0:
            raise RuntimeError('Cannot set v4l2 video format (VIDIOC_S_FMT).')

    def render(self, img):
        # TODO Enable image compression?
        self._dev.write(cv2.cvtColor(
            img, cv2.COLOR_BGR2RGB))
        return True

    def close(self):
        self._dev.close()


class AvRenderer(Renderer):
    def __init__(self, device: str, width: int = 1280,
                 height: int = 720, fps: int = 30) -> None:
        super().__init__(device, width, height, fps)
        self.__av = importlib.import_module('av')  # ImportError
        self._dev = self.__av.open(
            device, mode="w", format="video4linux2,v4l2")
        self._stream = self._dev.add_stream("rawvideo", fps)
        self._stream.width = width
        self._stream.height = height
        self._stream.pix_fmt = 'rgb24'

    def render(self, img):
        frame = self.__av.VideoFrame.from_ndarray(
            img, format='bgr24')
        for packet in self._stream.encode(frame):
            self._dev.mux(packet)
        return True

    def close(self):
        self._stream = None
        if getattr(self, "_dev") is not None:
            self._dev.close()
        del self._dev
        self._dev = None


def make_renderer(args: Iterable = [],
                  kwargs: Mapping = {}) -> Renderer:
    for RendererCls in (V4L2Renderer, AvRenderer):
        try:
            return RendererCls(*args, **kwargs)
        except Exception as err:
            log.error('Cannot create renderer {}: {}'.format(
                RendererCls.__name__, err))
            continue
    raise RuntimeError('Could not create any renderer!')
