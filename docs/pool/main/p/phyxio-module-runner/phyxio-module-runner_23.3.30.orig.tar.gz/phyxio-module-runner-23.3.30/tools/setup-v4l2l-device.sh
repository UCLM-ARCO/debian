#!/bin/bash

set -e

# get settings for runner config
CONFIG=/etc/phyxio-module-runner.yaml
if [ ! -f "$CONFIG" ]; then
    echo "Missing configuration file ($CONFIG)"
    exit -1;
fi

DEVICE=$(grep video-sink $CONFIG | awk '{gsub(/"/, "", $2); print $2}')
WIDTH=$(grep video-width $CONFIG | awk '{print $2}')
HEIGHT=$(grep video-height $CONFIG | awk '{print $2}')
FPS=$(grep video-fps $CONFIG | awk '{print $2}')

# configure device to keep format
v4l2-ctl -d $DEVICE -c keep_format=1
v4l2-ctl -d $DEVICE -c sustain_framerate=1

# set device capabilities (using retrieved settings)
# NOTE: set-caps format has changed in latest versions of V4L2Loopback
# NOTE: there is a bug with set-caps, so do it using gst-launch (num-buffers=2)
# v4l2loopback-ctl set-caps \
#     "video/x-raw,format=RGB,width=$WIDTH,height=$HEIGHT,fps=$FPS/1" \
#     $DEVICE
gst-launch-1.0 videotestsrc num-buffers=2 ! \
	"video/x-raw,format=RGB,width=$WIDTH,height=$HEIGHT,fps=$FPS/1" ! \
	v4l2sink device=$DEVICE
