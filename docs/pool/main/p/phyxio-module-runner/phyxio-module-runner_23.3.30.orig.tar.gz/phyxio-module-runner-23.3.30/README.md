# Requirements

Some modules will provide a video feedback of the user actions. In order to do so, the module runner must load and configure a V4L2Loopback device. Run:

    make setup-devices


# TODO

* Update post-inst script to set the following settings:
    - lite-mode: true if we are using a RPi
    - has-coral: true if Google Coral is present

