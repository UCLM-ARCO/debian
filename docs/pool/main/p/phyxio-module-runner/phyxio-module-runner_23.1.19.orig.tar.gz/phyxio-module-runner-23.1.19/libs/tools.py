
import logging
from pathlib import Path
from argparse import ArgumentParser
import Ice


logging.basicConfig()

log = logging.getLogger("ModuleTools")
log.setLevel(logging.INFO)

SYSTEM_SLICE_DIR = "/usr/share/slice/phyxio"

# load common slices
runner_slice = (Path(__file__) / "../../module-runner.ice").resolve()
if not runner_slice.exists():
    log.debug(f" slice '{runner_slice}' missing, try system wide...")
    runner_slice = Path(f"{SYSTEM_SLICE_DIR}/module-runner.ice").resolve()
log.info(f" loading slice '{runner_slice}'...")
Ice.loadSlice(runner_slice.as_posix())
import Phyxio


# this function is to be called from inside a module, which follows the
# structure: modname/src/slicename.ice
# - loc: the __file__ object from modname/src/bin/modname.py
# - name: name of the slice file (usually modname.ice)
def load_slice(loc, name):
    # first, slice in local module folder
    slice_path = (Path(loc) / f"../../{name}").resolve()

    # then, slice in current folder
    if not slice_path.exists():
        log.debug(f" slice '{slice_path}' missing, try on current folder...")
        slice_path = (Path(loc) / f"../{name}").resolve()

    # lastly, slice on system folder
    if not slice_path.exists():
        log.debug(f" slice '{slice_path}' missing, try system wide...")
        slice_path = (Path(f"{SYSTEM_SLICE_DIR}/{name}")).resolve()
    log.info(f" loading slice '{slice_path}'...")
    pwd = Path(__file__).parent.resolve()
    Ice.loadSlice(f"{slice_path.as_posix()} -I{pwd} --all")


class AttrDict(dict):
    """Use keys as attributes."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__dict__ = self


def get_global_parser():
    parser = ArgumentParser()

    # options provided by phyxio, required by all modules
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--iterations", type=int, default=0,
        help="number of iterations for this exercise")
    group.add_argument("--runtime", type=int, default=0,
        help="time of exercise execution")
    parser.add_argument("--runner-prx", required=True,
        help="proxy for IPC with the runner")

    # common config options, defined in 'config:module-options'
    parser.add_argument("--lite-mode", action="store_true",
        help="enable lite mode (reduce resource usage)")
    parser.add_argument("--has-coral", action="store_true",
        help="set Google Coral device as available for inference")

    parser.add_argument("--camera-source", type=str, default="/dev/video0",
        help="camera device path (ie. /dev/video0)")
    parser.add_argument("--camera-opts", type=str,
        help="aditional v4l2 controls for the camera device " +
             "(only for GstVideoComponent)")
    parser.add_argument("--video-sink", type=str, default="/dev/video5",
        help="V4L2Loopback device as video sink (ie. /dev/video5)")
    parser.add_argument("--video-width", type=int, default=1280,
        help="input and output video width")
    parser.add_argument("--video-height", type=int, default=720,
        help="input and output video height")
    parser.add_argument("--video-fps", type=int, default=30,
        help="input and output video frames per second")
    parser.add_argument("--video-scale",
        help="scale output video to given resolution (i.e. 1280x720)")
    parser.add_argument("--no-threaded-video", action="store_true",
        help="do not use a threaded video source (only for Cv2VideoComponent)")

    # other optional arguments
    parser.add_argument("--calibrate", action="store_true", default=False,
        help="run exercise in calibration mode")
    parser.add_argument("--calibration-data", type=str,
        help="calibration data for this user/exercise pair")
    parser.add_argument("--debug-info", action="store_true", default=False,
        help="add debug information inside video feed or system logs")

    return parser
