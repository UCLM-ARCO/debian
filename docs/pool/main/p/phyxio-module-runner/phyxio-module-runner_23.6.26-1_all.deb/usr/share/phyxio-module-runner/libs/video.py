
import os
import fcntl
import time
import importlib
import logging
import collections
import numpy as np
from threading import Thread, Event, Condition
from abc import ABC, abstractmethod
from typing import Any


logging.basicConfig()
log = logging.getLogger("LibVideo")
log.setLevel(logging.DEBUG)


class Renderer(ABC):
    def __init__(self, device: str, width: int = 1280,
                 height: int = 720, fps: int = 30) -> None:
        super().__init__()
        if not os.path.exists(device):
            raise RuntimeError(
                f'Given video device ({device}) ' +
                'does not exist!')
        self._device = device
        self._width = width
        self._height = height
        self._fps = fps

    def get_fps_counter(self, window_size=30):
        """Get a generator that computes the FPS. Call next() only ONCE per frame."""
        self._fps_window = collections.deque(maxlen=window_size)
        self._fps_prev = time.monotonic()
        yield 0.0

        while True:
            self._fps_curr = time.monotonic()
            self._fps_window.append(self._fps_curr - self._fps_prev)
            self._fps_prev = self._fps_curr
            yield len(self._fps_window) / sum(self._fps_window)

    @abstractmethod
    def render(self, image: Any) -> bool:
        """Render image to target device."""

    @abstractmethod
    def close(self) -> None:
        """Close renderer."""


class V4L2Renderer(Renderer):
    def __init__(self, device: str, width: int = 1280,
                 height: int = 720, fps: int = 30) -> None:
        super().__init__(device, width, height, fps)

        global cv2
        cv2 = importlib.import_module('cv2')
        v4l2 = importlib.import_module('v4l2')

        self._dev = open(device, 'wb')
        self._fmt = v4l2.v4l2_format()
        self._fmt.type = v4l2.V4L2_BUF_TYPE_VIDEO_OUTPUT
        if fcntl.ioctl(self._dev, v4l2.VIDIOC_G_FMT, self._fmt) < 0:
            raise RuntimeError('Cannot set v4l2 video format (VIDIOC_G_FMT).')
        self._fmt.fmt.pix.width = width
        self._fmt.fmt.pix.height = height
        self._fmt.fmt.pix.pixelformat = v4l2.V4L2_PIX_FMT_RGB24
        self._fmt.fmt.pix.sizeimage = width * height * 3
        self._fmt.fmt.pix.bytesperline = width * 3
        if fcntl.ioctl(self._dev, v4l2.VIDIOC_S_FMT, self._fmt) < 0:
            raise RuntimeError('Cannot set v4l2 video format (VIDIOC_S_FMT).')

    def render(self, img):
        # TODO Enable image compression?
        self._dev.write(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        return True

    def close(self):
        self._dev.close()


class AvRenderer(Renderer):
    def __init__(self, device: str, width: int = 1280,
                 height: int = 720, fps: int = 30) -> None:
        super().__init__(device, width, height, fps)

        global av
        av = importlib.import_module('av')

        self._dev = av.open(
            device, mode="w", format="video4linux2,v4l2")
        self._stream = self._dev.add_stream("rawvideo", fps)
        self._stream.width = width
        self._stream.height = height
        self._stream.pix_fmt = 'rgb24'

    def render(self, img):
        frame = av.VideoFrame.from_ndarray(
            img, format='bgr24')
        for packet in self._stream.encode(frame):
            self._dev.mux(packet)
        return True

    def close(self):
        self._stream = None
        if getattr(self, "_dev") is not None:
            self._dev.close()
        del self._dev
        self._dev = None


class WindowRenderer(Renderer):
    def __init__(self):
        """Overwrite parent constructor to avoid checking device."""
        # FIXME: get this variable from system, as it may change
        os.environ["DISPLAY"] = ":0"

        global cv2
        cv2 = importlib.import_module('cv2')

    def render(self, img):
        cv2.imshow("WindowRenderer", img)
        key = cv2.waitKey(1)
        if key == ord('q') or key == ord('Q'):
            return False
        return True

    def close(self):
        cv2.destroyAllWindows()


def make_renderer(device, *args, **kwargs) -> Renderer:
    msg = " video renderer created: {}"
    if device == "direct-draw":
        log.info(msg.format(WindowRenderer.__name__))
        return WindowRenderer()

    for RendererCls in (V4L2Renderer, AvRenderer):
        try:
            retval = RendererCls(device, *args, **kwargs)
            log.info(msg.format(RendererCls.__name__))
            return retval
        except Exception as err:
            log.error('Cannot create renderer {}: {}'.format(
                RendererCls.__name__, err))
            continue
    raise RuntimeError('Could not create any renderer!')


class VideoSource:
    def __init__(self, args):
        log.info(" using NOT threaded video source...")

        if not os.path.exists(args.camera_source):
            raise RuntimeError(f"Given video device ({args.camera_source}) does not exist!")

        cv2 = importlib.import_module('cv2')
        self._cap = cv2.VideoCapture(args.camera_source, cv2.CAP_V4L2)
        if not self._cap.isOpened():
            raise RuntimeError("Error opening video source!")

        self._cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.video_width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.video_height)
        self._cap.set(cv2.CAP_PROP_FPS, args.video_fps)

    def __del__(self):
        self._cap.release()

    def get_frames(self):
        while True:
            success, frame = self._cap.read()
            if not success:
                continue
            yield frame


class ThreadedVideoSource(Thread):
    def __init__(self, args):
        super().__init__()
        self.daemon = True

        log.info(" using threaded video source...")
        if not os.path.exists(args.camera_source):
            raise RuntimeError(f"Given video device ({args.camera_source}) does not exist!")

        cv2 = importlib.import_module('cv2')
        self._cap = cv2.VideoCapture(args.camera_source, cv2.CAP_V4L2)
        if not self._cap.isOpened():
            raise RuntimeError("Error opening video source!")

        self._cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.video_width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.video_height)
        self._cap.set(cv2.CAP_PROP_FPS, args.video_fps)

        self._running = True
        self._frame = None
        self._ev = Event()
        self.start()

    def __del__(self):
        self._cap.release()

    def run(self):
        while self._running:
            if self._ev.is_set():
                time.sleep(0.01)
                continue
            success, image = self._cap.read()
            if not success:
                continue
            self._frame = image
            self._ev.set()

    def get_frames(self):
        while True:
            self._ev.wait()
            self._ev.clear()
            yield self._frame


class VideoPipeline:
    def __init__(self, args, frame_size=(1024, 576), use_ndarray=False):
        log.info(" using GStreamer pipeline...")
        if not os.path.exists(args.camera_source):
            raise RuntimeError(f"Given video device ({args.camera_source}) does not exist!")

        direct_draw = False
        if not args.video_sink.startswith("/dev/"):
            # FIXME: get this variable from system, as it may change
            if os.environ.get("DISPLAY") is None:
                os.environ["DISPLAY"] = ":0"
            direct_draw = True

        # os.environ["GST_DEBUG"] = "3"

        # NOTE: do not import these modules in global imports, because they may not be
        # needed nor installed
        gi = importlib.import_module("gi")
        gi.require_version('Gst', '1.0')

        global GLib, Gst
        Gst = importlib.import_module(".Gst", "gi.repository")
        GLib = importlib.import_module(".GLib", "gi.repository")
        Gst.init(None)

        self._requested_frame_size = frame_size
        self._src_size = (args.video_width, args.video_height)
        self._sink_size = None
        self._gstbuffer = None
        self._result = None
        self._condition = Condition()
        self._video_cb = None
        self._overlay_cb = None
        self._debug = args.debug_info
        self._use_ndarray = use_ndarray

        self._inf_worker = None
        self._render_worker = None
        self._gst_pipeline = Gst.parse_launch(self._get_str_pipeline(args))

        self._overlay = self._gst_pipeline.get_by_name('pre-scale-overlay')
        appsink = self._gst_pipeline.get_by_name('appsink')
        appsink.connect('new-sample', self._on_new_sample)

        bus = self._gst_pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect('message', self._on_bus_message)

        if direct_draw:
            self._setup_render_window()

    def _setup_render_window(self):
        gi = importlib.import_module("gi")
        gi.require_version('Gtk', '3.0')
        gi.require_version('Gdk', '3.0')
        gi.require_version('GstVideo', '1.0')
        Gtk = importlib.import_module(".Gtk", "gi.repository")
        Gdk = importlib.import_module(".Gdk", "gi.repository")
        # NOTE: do not remove, otherwise 'rendersink' does not have 'set_window_handle'
        importlib.import_module(".GstVideo", "gi.repository")
        Gtk.init()

        def on_delete_event(window, event):
            window.hide()
            self._gst_pipeline.set_state(Gst.State.NULL)
            Gtk.main_quit()

        window = Gtk.Window()
        window.set_title("Phyxio Exercise Panel")
        window.connect("delete-event", on_delete_event)
        screen = Gdk.Screen.get_default()
        window.set_default_size(screen.get_width(), screen.get_height())
        window.fullscreen()

        drawing_area = Gtk.DrawingArea()
        drawing_area.set_double_buffered(False)
        window.add(drawing_area)
        window.show_all()
        window.realize()

        xid = drawing_area.get_window().get_xid()
        rendersink = self._gst_pipeline.get_by_name('rendersink')
        rendersink.set_window_handle(xid)

    def _get_str_pipeline(self, args):
        src_caps = f"image/jpeg,width={args.video_width},height={args.video_height}," +\
            f"framerate={args.video_fps}/1"
        leaky_queue = 'queue max-size-buffers=1 leaky=downstream'

        # options for render branch (to v4l2loopback, direct draw, etc)
        render_scale = ""
        if args.video_scale:
            w, h = map(int, args.video_scale.split("x"))
            render_scale = f"! videoscale ! video/x-raw,width={w},height={h}"

        render_sink_element = "xvimagesink"
        if args.video_sink and args.video_sink.startswith("/dev/"):
            # NOTE: add a tee here because there is a bug in v4l2loopback with
            # the buffer manipulation that produces a segfault (in some versions)
            render_sink_element = f"tee ! v4l2sink device={args.video_sink}"

        # options for inference branch (for ML algs, pose estimators, etc)
        infer_scale = ""
        sink_w, sink_h = self._requested_frame_size
        if self._requested_frame_size != (args.video_width, args.video_height):
            # keep aspect ratio by reducing dimension of largest axis
            scale = min(sink_w / args.video_width, sink_h / args.video_height)
            sink_w, sink_h = int(args.video_width * scale), int(args.video_height * scale)
            infer_scale = f"! videoscale ! video/x-raw,width={sink_w},height={sink_h}"

        infer_sink_caps = f'video/x-raw,format=RGB,width={sink_w},height={sink_h}'
        infer_sink_element = 'appsink name=appsink emit-signals=true max-buffers=1 drop=true'

        cam_controls = ""
        if args.camera_opts:
            cam_controls = f"extra-controls=c,{args.camera_opts}"

        # for mirror-mode, no video feedback required (but allow other type of feedback)
        if args.mirror_mode:
            pipeline = f"""
                v4l2src device={args.camera_source} {cam_controls}
                ! {src_caps}
                ! decodebin
                ! videoflip video-direction=horiz
                ! {leaky_queue} {infer_scale}
                ! videoconvert
                ! {infer_sink_caps}
                ! {infer_sink_element}

                videotestsrc pattern=black
                ! videoconvert
                ! rsvgoverlay name=pre-scale-overlay
                ! videoconvert {render_scale}
                ! {render_sink_element} name=rendersink sync=false qos=false
            """

        # otherwise, full video feedback rendered
        else:
            pipeline = f"""
                v4l2src device={args.camera_source} {cam_controls}
                ! {src_caps}
                ! decodebin
                ! videoflip video-direction=horiz
                ! tee name=t

                t. ! {leaky_queue}
                ! videoconvert
                ! rsvgoverlay name=pre-scale-overlay
                ! videoconvert {render_scale}
                ! {render_sink_element} name=rendersink sync=false qos=false

                t. ! {leaky_queue} {infer_scale}
                ! videoconvert
                ! {infer_sink_caps}
                ! {infer_sink_element}
            """

        # still = "/home/pi/test-frame.jpeg"
        # pipeline = f"""
        #     filesrc location={still} ! jpegdec ! videoconvert ! imagefreeze is-live=true
        #     ! tee name=t
        #     t. ! {leaky_queue} ! videoconvert ! rsvgoverlay name=pre-scale-overlay
        #        ! videoconvert {render_scale}
        #        ! {render_sink_element} name=rendersink sync=false qos=false

        #     t. ! {leaky_queue} {infer_scale}
        #        ! {infer_sink_caps} ! videoconvert ! {infer_sink_element}
        # """

        if self._debug:
            log.debug(" - pipeline definition:\n" + pipeline)
        return pipeline

    def _on_new_sample(self, sink):
        sample = sink.emit('pull-sample')
        if not self._sink_size:
            s = sample.get_caps().get_structure(0)
            self._sink_size = (s.get_value('width'), s.get_value('height'))

        with self._condition:
            self._gstbuffer = sample.get_buffer()
            self._condition.notify_all()

        return Gst.FlowReturn.OK

    def _on_bus_message(self, bus, message):
        t = message.type
        if t == Gst.MessageType.EOS:
            # FIXME: stop pipeline and show error to user
            pass
        elif t == Gst.MessageType.WARNING:
            err, msg = message.parse_warning()
            log.warning(f' {err}: {msg}')
        elif t == Gst.MessageType.ERROR:
            err, msg = message.parse_error()
            log.error(f' {err}: {msg}')
            # FIXME: stop pipeline and show error to user
        return True

    def _process_loop(self):
        while True:
            with self._condition:
                while not self._gstbuffer:
                    self._condition.wait()
                gstbuffer = self._gstbuffer
                self._gstbuffer = None

            result = None
            if self._video_cb is not None:
                frame = gstbuffer
                if self._use_ndarray:
                    frame = self.gstbuffer_to_ndarray(frame)
                result = self._video_cb(frame)
            with self._condition:
                # store result as it will be used by draw_overlay, i.e. to
                # draw the skeleton of an infered pose
                self._result = result
                self._condition.notify_all()

    def _render_loop(self):
        while True:
            with self._condition:
                while self._result is None:
                    self._condition.wait()
                _result = self._result
                self._result = None

            if self._overlay_cb is not None and self._overlay:
                svg_canvas = self._overlay_cb(_result)
                if svg_canvas is not None:
                    self._overlay.set_property('data', svg_canvas)

    def start(self):
        # start inference workers
        if self._inf_worker is None:
            self._inf_worker = Thread(target=self._process_loop, daemon=True)
            self._inf_worker.start()
        if self._render_worker is None:
            self._render_worker = Thread(target=self._render_loop, daemon=True)
            self._render_worker.start()

        # run pipeline
        self._gst_pipeline.set_state(Gst.State.PLAYING)
        self._gst_pipeline.get_state(Gst.CLOCK_TIME_NONE)

    def loop_iteration(self):
        ctx = GLib.MainContext.default()
        while ctx.pending():
            ctx.iteration(False)

    def stop(self):
        self._gst_pipeline.set_state(Gst.State.NULL)
        while GLib.MainContext.default().iteration(False):
            pass

    def connect(self, element, cb):
        assert callable(cb), "Invalid callback provided!"
        if element == "video":
            self._video_cb = cb
        elif element == "overlay":
            self._overlay_cb = cb
        else:
            raise ValueError(f"Unknown element to connect: {element}")

    def gstbuffer_to_ndarray(self, gstbuffer, transpose=False):
        success, map_info = gstbuffer.map(Gst.MapFlags.READ)
        if not success:
            raise RuntimeError("Could not map buffer data!")

        # remember, shape must be (height, size, depth)
        shape = (self._sink_size[1], self._sink_size[0], 3)
        numpy_frame = np.ndarray(
            shape=shape, dtype=np.uint8, buffer=map_info.data)
        gstbuffer.unmap(map_info)

        # WARNING: this is an expensive operation!!
        if transpose:
            return np.transpose(numpy_frame, axes=(1, 0, 2))

        return numpy_frame
