#!/bin/bash

# In case of SEGFAULT, or 'non-negotiated' , this may help you catch it.

# PIPELINE="
#  v4l2src device=/dev/video0 extra-controls=c,exposure_auto=1,exposure_absolute=250
#  ! image/jpeg,width=1280,height=720,framerate=30/1
#  ! decodebin
#  ! videoflip video-direction=horiz
#  ! tee name=t

#  t. ! queue max-size-buffers=1 leaky=downstream
#     ! videoconvert
#     ! rsvgoverlay name=pre-scale-overlay
#     ! videoconvert
#     ! v4l2sink device=/dev/video5 name=rendersink sync=false qos=false

#  t. ! queue max-size-buffers=1 leaky=downstream
#     ! video/x-raw,format=RGB,width=1280,height=720
#     ! videoconvert
#     ! appsink name=appsink emit-signals=true max-buffers=1 drop=true
# "

# PIPELINE="
#    v4l2src device=/dev/video0
#    ! image/jpeg,width=1280,height=720,framerate=30/1
#    ! decodebin
#    ! videoflip video-direction=horiz
#    ! tee name=t

#    t. ! queue max-size-buffers=1 leaky=downstream
#       ! videoconvert
#       ! rsvgoverlay name=pre-scale-overlay
#       ! videoconvert
#       ! xvimagesink name=rendersink sync=false qos=false

#    t. ! queue max-size-buffers=1 leaky=downstream
#       ! video/x-raw,format=RGB,width=1280,height=720
#       ! videoconvert
#       ! appsink name=appsink emit-signals=true max-buffers=1 drop=true
# "

# PIPELINE="
#    videotestsrc

# ! v4l2sink device=/dev/video5 name=rendersink sync=false qos=false

PIPELINE="
   v4l2src device=/dev/video0
   ! image/jpeg,width=1280,height=720,framerate=30/1
   ! decodebin
   ! videoflip video-direction=horiz
   ! tee name=t

   t. ! queue max-size-buffers=1 leaky=downstream
      ! videoconvert
      ! rsvgoverlay name=pre-scale-overlay
      ! videoconvert
      ! tee ! v4l2sink device=/dev/video5 name=rendersink sync=false qos=false

   t. ! queue max-size-buffers=1 leaky=downstream
      ! videoconvert
      ! video/x-raw,format=RGB,width=1280,height=720
      ! appsink name=appsink emit-signals=true max-buffers=1 drop=true
"

# To see a v4l2loopback device:
# gst-launch-1.0 v4l2src device=/dev/video5 ! decodebin ! videoconvert ! xvimagesink

# In case of SEGFAULT...
# gdb -ex r --args gst-launch-1.0 $PIPELINE

# Otherwise...
gst-launch-1.0 -f $PIPELINE
