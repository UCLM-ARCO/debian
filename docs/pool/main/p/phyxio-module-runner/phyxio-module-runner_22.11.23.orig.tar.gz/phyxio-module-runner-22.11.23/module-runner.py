#!/usr/bin/env python3

import os
import sys
import logging
import json
import yaml
import ssl
import base64
from urllib.parse import urljoin, urlparse
from subprocess import Popen, TimeoutExpired, signal, PIPE, STDOUT
from pathlib import Path
from threading import Thread, Event
from http.server import HTTPServer, BaseHTTPRequestHandler
from argparse import ArgumentParser
import requests
import Ice

from libs import Phyxio

logging.basicConfig()
log = logging.getLogger("ModuleRunner")
log.setLevel(logging.INFO)


class TemplateAsset:
    TEMPLATE_DIR = Path("shared/")
    context = {}

    def __init__(self, req):
        self._req = req
        self._asset = self.TEMPLATE_DIR / self._req.relative_to("/")

        self.suffix = self._asset.suffix
        self.is_file = self._asset.is_file

    def __repr__(self):
        return str(self._asset)

    def open(self, mode=None):
        return self

    def read(self):
        template = self._load_asset()
        ctx = self.context.copy()
        while True:
            try:
                return template.format(**ctx).encode("utf-8")
            except KeyError as err:
                log.debug(f" - '{err.args[0]}' missing in template '{self._asset}'")
                ctx[err.args[0]] = ""

    def _load_asset(self):
        return self._asset.open("rb").read().decode()


class HTTPResquestHandler(BaseHTTPRequestHandler):
    DEFAULT_FILE = "index.html"
    DEFAULT_DIR = "."

    def do_GET(self):
        asset = self._get_requested_asset()
        if asset is None:
            log.info(f" HTTP GET {self.path}, ret: 404")
            return self._response_404()

        log.info(f" HTTP GET {asset}, ret: 200")
        mimetype = self._get_mime_type(asset)
        self._copy_file(asset, mimetype)

    def log_message(self, format, *args):
        return

    def _get_requested_asset(self):
        path = urlparse(self.path).path
        req = Path(path)
        resource_path = None

        # if it is an api request, handle it
        if len(req.parts) > 1 and req.parts[1] == "api":
            resource_path = TemplateAsset(req)

        # otherwise, try to retrieve a file from static paths
        else:
            for p in self.server.static_paths:
                absp = Path("/") / p
                try:
                    remain = req.relative_to(absp)
                    if p.is_absolute():
                        resource_path = req
                    else:
                        resource_path = Path(self.DEFAULT_DIR) / req.relative_to("/")
                    if remain == Path("."):
                        resource_path /= self.DEFAULT_FILE
                    break
                except ValueError:
                    continue

        if resource_path is None or not resource_path.is_file():
            return None
        return resource_path

    def _get_mime_type(self, asset):
        return {
            ".html": "text/html",
            ".css": "text/css",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".js": "text/javascript",
        }.get(asset.suffix.lower(), "application/octet-stream")

    def _response_404(self):
        self.send_response(404)
        self.end_headers()

    def _copy_file(self, asset, mimetype):
        self.send_response(200)
        self.send_header('Content-type', mimetype)

        # allow CORS only for localhost and phyx.io
        origin = path = urlparse(self.headers.get('Origin', "")).netloc
        host = origin.split(":")[0]
        if host in self.server.cors_whitelist:
            origin = self.headers['Origin']
            self.send_header('Access-Control-Allow-Origin', origin)

        self.end_headers()
        self.wfile.write(asset.open("rb").read())


class HTTPServerDaemon(Thread):
    def __init__(self, settings, args):
        super().__init__()
        host = settings.get("http-server-host", "127.0.0.1")
        port = settings.get("http-server-port", 7502)
        cert_path = settings.get("ssl-cert", "localhost-cert.pem")
        key_path = settings.get("ssl-key", "localhost-key.pem")

        self._static_paths = set()
        self._httpd = HTTPServer((host, port), HTTPResquestHandler)
        self._httpd.static_paths = self._static_paths
        self._httpd.cors_whitelist = settings.get(
            "cors-whitelist", "127.0.0.1,localhost,phyx.io").split(",")
        log.info(f'CORS-whitelist: {self._httpd.cors_whitelist}')

        if not args.force_insecure_mode:
            sslctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            sslctx.load_cert_chain(cert_path, key_path)
            self._httpd.socket = sslctx.wrap_socket(self._httpd.socket, server_side = True)
            self._base_url = f"https://{host}:{port}"
        else:
            self._base_url = f"http://{host}:{port}"

        self.daemon = True
        self.start()

    def run(self):
        self._httpd.serve_forever()

    def add_static_path(self, path):
        self._static_paths.add(Path(path))
        return urljoin(self._base_url, path.as_posix())

    def remove_static_path(self, path):
        self._static_paths.remove(Path(path))


class ModuleHandlerI(Phyxio.ModuleHandler):
    def __init__(self, modname, adapter, runner):
        self._proxy = None

        self._modname = modname
        self._adapter = adapter
        self._runner = runner
        self._ready = Event()

    def enable(self):
        self._ready.clear()
        if self._proxy is None:
            self._proxy = self._adapter.addWithUUID(self)

    def disable(self):
        if self._proxy is not None:
            self._adapter.remove(self._proxy.ice_getIdentity())
            self._proxy = None

    def wait_for_ready(self, tout=1):
        return self._ready.wait(tout)

    def ready(self, current):
        self._ready.set()

    def finished(self, report, current):
        self._runner.notify_finished(self._modname, report)


class ModuleDef:
    NO_MODULE_URL = "/module/not-running"

    def __init__(self, runner, httpserver, adapter, opts, settings):
        # public fields
        self.is_running = False
        self.name = opts["codename"]
        self.exec = opts["exec"]
        self.eci_url = self.NO_MODULE_URL
        self.eci_path = opts["module_dir"] / "eci"
        self.info = json.dumps(opts.get("eci_params", "{}"))
        self.last_error = ""

        # private parts
        self._settings = settings
        self._httpserver = httpserver
        self._process = None
        self._mh = ModuleHandlerI(self.name, adapter, runner)

        assert self.eci_path.is_dir(), f"missing directory: {self.eci_path}"

    def reset(self):
        log.info(f" resetting module '{self.name}'...")
        if self._process:
            self._stop_process()

        self._process = None
        self.eci_url = self.NO_MODULE_URL
        self.last_error = ""
        self.is_running = False

    def run(self, params):
        if self.is_running:
            return False

        if self._process is not None:
            log.error(" this module is already running!")
            self.is_running = True
            return False

        if not self._run_process(params):
            self.last_error = f"module '{self.name}' could not start"
            log.error(f" {self.last_error}!!")
            self._stop_process()
            return False

        self.eci_url = self._httpserver.add_static_path(self.eci_path)
        self.is_running = True
        log.info(f" module '{self.name}' successfully started.")
        return True

    def _run_process(self, params):
        if not os.access(self.exec, os.X_OK):
            self.last_error = f"module path '{self.exec}' is not executable!"
            log.error(f" {self.last_error}")
            return False

        self._mh.enable()
        cmd = [self.exec.as_posix(), "--runner-prx", str(self._mh._proxy)]

        # update args with common module options
        for name, value in self._settings.get("module-options", {}).items():
            cmd += [f"--{name}", str(value)]

        # add user defined options
        if params.runtime:
            cmd += ["--runtime", f"{params.runtime}"]
        elif params.iterations:
            cmd += ["--iterations", f"{params.iterations}"]

        if params.calibration:
            cdata = base64.b64encode(f"{params.calibration}".encode())
            cmd += ["--calibration-data", cdata.decode()]

        # FIXME: WARNING, sanity check this option (config), as it is user defined
        cmd += params.config.split()

        str_cmd = " ".join(cmd)
        log.info(f" running module as: '{str_cmd}'")
        try:
            # note: PYTHONPATH is changed to a system wide path, using a patch
            self._process = Popen(cmd,
                env={"PYTHONPATH": Path(__file__).parent.resolve()})
        except OSError as ex:
            self.last_error = f"module binary could not run: {ex}"
            log.error(f" {self.last_error}")
            return False

        return self.wait_for_ready()

    def wait_for_ready(self):
        count = 20  # wait up to 10 seconds
        while self._process.poll() is None and count != 0:
            if self._mh.wait_for_ready(0.5):
                return True
            count -= 1
        return False

    def stop(self):
        if not self.is_running or self._process is None:
            return False
        if not self._stop_process():
            return False

        self._mh.disable()
        self._httpserver.remove_static_path(self.eci_path)
        self.eci_url = self.NO_MODULE_URL
        self.is_running = False
        log.info(f" module '{self.name}' successfully stopped.")
        return True

    def _stop_process(self):
        if self._process is None:
            return False
        if self._process.poll() is not None:
            return False

        log.info(f" module '{self.name}', stopping process...")

        # first: try to gracefully quit process
        for sig in [signal.SIGINT, signal.SIGQUIT]:
            try:
                self._process.send_signal(sig)
                log.info(f" - {signal.strsignal(sig)} sent...")
                self._process.wait(1)
                self._process = None
                return True
            except TimeoutExpired:
                pass

        # otherwise: force to terminate
        try:
            self._process.terminate()
            log.info(f" - Terminate sent...")
            self._process.wait(1)
        except TimeoutExpired:
            log.info(f" - Kill sent...")
            self._process.kill()

        self._process = None
        return True


class ModuleRunnerI(Phyxio.ModuleRunner):
    def __init__(self, settings, adapter, args):
        super().__init__()
        self._httpserver = HTTPServerDaemon(settings, args)
        self._httpserver.add_static_path(Path("shared"))
        self._modules = {}

        # update context for API rest calls
        self._load_api_context()

        # there is only one observer because there is only one user interface
        self._observer = None
        self._running = None

        self._settings = settings
        self._adapter = adapter
        self._load_modules(settings.get("module-dir", "modules"))

    def start(self, modname, modparams, current):
        log.info(f" start called, '{modname}'...")
        mod = None

        if self._running is not None:
            log.warning(f" there is already a module running ({self._running.name})...")
            if self._running.name != modname:
                log.info(" - module is different, I'll stop the former...")
                self.stop()
            else:
                log.info(" - try to resync module with client...")
                if not self._running.wait_for_ready():
                    log.info(" - could not resync, stopping it...")
                    self.stop()
            mod = self._running

        if mod is None:
            mod = self._get_module(modname)
            if mod.run(modparams):
                self._running = mod
            else:
                # on error, send observer what happend and return
                status = {
                    "modname": modname,
                    "status": "error",
                    "error": mod.last_error,
                }
                self._observer.sendStatusAsync(json.dumps(status))
                mod.reset()
                return

        # notify observer about this module status
        if self._observer is not None and mod.eci_url:
            info = Phyxio.ModuleInfo(mod.eci_url, mod.info)
            self._observer.sendModuleInfoAsync(info)

    def stop(self, current=None):
        if self._running is None:
            log.info(" stop called, but no module running")
            return

        self._running.stop()
        self._running = None

    def getReport(self, modname, current):
        log.info(f" getReport called, '{modname}'")

    def setObserver(self, observer, current):
        log.info(f" setObserver called, '{observer}'")
        self._observer = observer.ice_fixed(current.con)

    def getPreauthToken(self, user, current):
        token = "invalid_token"

        # retrieve the totem key from system settings
        settings = self._get_deploy_settings() or {}
        api_key = settings.get("totem", {}).get("api-key")
        url = settings.get("server", {}).get("url")
        if api_key is None or url is None:
            return token

        # call to phyxio API and get token for user
        url += "/api/auth/token/"
        resp = requests.post(url, data={'user': user, 'api-token': api_key})
        resp = json.loads(resp.content)
        if resp.get("status") == "ok":
            return resp.get('token')

        return token

    def notify_finished(self, modname, report):
        if self._observer is None:
            return

        info = {
            "modname": modname,
            "status": "finished",
            "report": json.loads(report),
        }
        self._observer.sendStatusAsync(json.dumps(info))

    def _get_module(self, modname):
        try:
            return self._modules[modname]
        except KeyError:
            log.error(f" No such module: '{modname}'")
            raise Phyxio.NoSuchModule(modname)

    def _load_modules(self, module_dir):
        module_dir = Path(module_dir)
        if not module_dir.is_dir():
            raise RuntimeError(f"Invalid module dir: {module_dir}")

        for d in module_dir.iterdir():
            if not d.is_dir():
                continue
            mod_def = d / "module.json"
            if not mod_def.is_file():
                log.warning(f" Invalid module {d}, discarded")
                continue
            self._load_module(mod_def)

    def _load_module(self, mod_def):
        log.info(f" Loading module {mod_def}")
        try:
            mod_props = json.load(mod_def.open())
            for k in ["codename", "name", "exec"]:
                assert k in mod_props, f"missing key: {k}"

            codename = mod_props['codename']
            if codename in self._modules:
                log.error(f" Invalid module '{codename}', already registered!")
                return

            mod_dir = mod_props.get("module_dir", ".")
            mod_props["module_dir"] = mod_def.parent / mod_dir
            mod_props["exec"] = mod_props["module_dir"] / mod_props["exec"]

            self._modules[codename] = ModuleDef(self,
                self._httpserver, self._adapter, mod_props, self._settings)
            log.info(f" - module named '{codename}' correctly loaded!")

        except (json.JSONDecodeError, KeyError, AssertionError) as err:
            log.warning(f" Invalid module '{mod_def}'")
            if isinstance(err, KeyError):
                err = f"missing key: {err}"
            log.warning(f"  - {err}")

    def _load_api_context(self):
        # set some valid defaults
        totem_name = "Phyxio Totem"

        # load settings from totem-setup configuration file
        settings = self._get_deploy_settings()
        if settings is not None:
            try:
                totem_name = settings.get("totem", {}).get("name", totem_name)
            except Exception as err:
                log.warning(f" Invalid totem settings, using default values!")

        TemplateAsset.context["totem-name"] = totem_name

    def _get_deploy_settings(self):
        config = Path("/etc/phyxio-deploy.yaml")
        if config.is_file():
            try:
                return yaml.safe_load(config.open())
            except Exception as err:
                pass
        log.warning(f" Could not load totem settings from '{config}'!")


class ModuleRunnerService(Ice.Application):
    def run(self, args):
        if not self._check_args(args):
            return -1

        if not os.path.exists(self.args.config):
            log.error(f" configuration file ({self.args.config}) does not exist!")
            return -1

        ic = self.communicator()
        adapter = ic.createObjectAdapter("ModuleRunner.Adapter")
        adapter.activate()

        settings = yaml.safe_load(open(self.args.config))
        prx = adapter.add(
            ModuleRunnerI(settings, adapter, self.args),
            Ice.stringToIdentity("ModuleRunner"))
        log.info(f" Service ready: {prx}")
        log.info(" Waiting events....")

        self.shutdownOnInterrupt()
        try:
            ic.waitForShutdown()
        except KeyboardInterrupt:
            log.info(" Exiting...")

    def _check_args(self, args):
        parser = ArgumentParser()
        parser.add_argument("--config", required=True,
            help="configuration file path with service settings")
        parser.add_argument("--force-insecure-mode", action="store_true",
            help="use HTTP instead of HTTPS (for devel only!)")

        try:
            self.args = parser.parse_args(args[1:])
            return True
        except SystemExit:
            return False


if __name__ == "__main__":
    ModuleRunnerService().main(sys.argv)
