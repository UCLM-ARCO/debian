
import os
import time
import json
import logging
import base64
import cv2

from libs.video import make_renderer
from libs.tools import load_slice

load_slice(__file__, "client-iface.ice")
import Phyxio


# mixin class for Phyxio.ECIObserver
class ECIObserverMixin:
    def __init__(self, args, runner):
        self._eci_client = None
        self._args = args
        self._runner = runner
        self._report_details = {}

        # validate and reset calibration callbacks
        self._validate_cb = None
        self._restart_cal_cb = None

        if self._args.calibrate:
            self._calib_data = {}

        # NOTE: fallback logger, build a proper one inside children class
        self._log = logging.getLogger("ECIObserverMixin")
        self._log.setLevel(logging.INFO)

    def get_report(self):
        # when calibrating, report needs only calibration data
        if self._args.calibrate:
            return {"calibration": self._calib_data}

        # otherwise, return a full report
        return {
            "goal":
                {"iterations": self._args.iterations} if self._args.iterations else
                {"runtime": self._args.runtime},
            "done": {"iterations": 0},
            "details": self._report_details,
            "custom": None,
        }

    def add_report_details(self, details):
        self._report_details.update(details)

    def finish(self, elapsed_time, iter_done):
        report = self.get_report()
        if not self._args.calibrate:
            report["elapsed"] = elapsed_time
            report["done"]["iterations"] = iter_done
        report = json.dumps(report)
        if self._eci_client is not None:
            self._eci_client.setFinished(report)
        self._runner.finished(report)

    # NOTE: make sure this returns as soon as posible (use Async calls)
    def update_iters(self, done, goal):
        if self._eci_client is not None:
            self._eci_client.setIterationsAsync(done, goal)

    # NOTE: make sure this returns as soon as posible (use Async calls)
    def sync_calibration(self, data=None):
        if self._eci_client is not None:
            if data is None:
                data = self._calib_data
            self._eci_client.syncCalibrationAsync(json.dumps(data))

    def record_calibration(self, **kwargs):
        self._calib_data.update(kwargs)

    def on_validate(self, cb):
        self._validate_cb = cb

    def on_restart_cal(self, cb):
        self._restart_cal_cb = cb

    # to be implemented on derived class
    def _cast_client(self, prx):
        return Phyxio.ECIClientPrx.uncheckedCast(prx)

    def _sync_client(self):
        if self._args.calibrate:
            self.sync_calibration()
        else:
            self.update_iters(0, self._args.iterations)
            if self._args.runtime:
                self._eci_client.setTimeLimit(self._args.runtime)


class PhyxioECIObserverI(Phyxio.ECIObserver, ECIObserverMixin):
    # ice method from Phyxio.ECIObserver
    def setClientProxy(self, client, current):
        self._log.info(f" set client proxy to: {client}")
        self._eci_client = self._cast_client(client.ice_fixed(current.con))
        self._sync_client()

    # ice method from Phyxio.ECIObserver
    def validateCalibration(self, current):
        if self._validate_cb is not None:
            self._validate_cb()

    # ice method from Phyxio.ECIObserver
    def restartCalibration(self, current):
        if self._restart_cal_cb is not None:
            self._restart_cal_cb()


class ModuleComponent:
    def __init__(self, args, observer=None):
        self._args = args
        self._is_debug = args.debug_info

        self._event_observer = observer
        self._is_stopped = False
        self._deinit_on_stop = False

        self._calibration = None
        if args.calibration_data:
            data = base64.b64decode(args.calibration_data.encode()).decode()
            self._calibration = json.loads(data)

        if args.calibrate:
            observer.on_validate(self.validate_calibration)
            observer.on_restart_cal(self.restart_calibration)

        self._iter_goal = args.iterations
        self._time_goal = args.runtime
        self._iter_curr = 0
        self._start_ts = time.time()

    def validate_calibration(self):
        self.stop(allow_deinit=True)

    # to be implemented on delegated component
    def restart_calibration(self):
        print("-- Warning: restart_calibration() not overriden!! ")

    def deinit(self):
        if (not self._is_stopped or self._deinit_on_stop) and self._event_observer:
            self._event_observer.finish(
                time.time() - self._start_ts,
                self._iter_curr)
            self._event_observer = None

    def set_observer(self, obs):
        self._event_observer = obs

    def iter_add(self):
        self._iter_curr += 1
        self.notify("iter_change")

    # NOTE: make sure this returns as soon as posible (use Async calls)
    def notify(self, event):
        if self._event_observer is None:
            return True
        if event == "iter_change":
            self._event_observer.update_iters(
                self._iter_curr, self._iter_goal)
            return True
        return False

    @property
    def elapsed_time(self):
        return time.time() - self._start_ts

    def run(self):
        # first notification to set initial values
        self.notify("iter_change")
        self.deinit()

    def stop(self, allow_deinit=False):
        self._is_stopped = True
        self._deinit_on_stop = allow_deinit

    def _should_finish(self):
        if self._is_stopped:
            return True
        if self._time_goal:
            return time.time() - self._start_ts >= self._time_goal
        return self._iter_curr >= self._iter_goal


class VideoComponent(ModuleComponent):
    def __init__(self, args, has_video_out=True, observer=None):
        super().__init__(args, observer=observer)

        if not os.path.exists(args.camera_source):
            raise RuntimeError(f"Given video device ({args.camera_source}) does not exist!")

        self._cap = cv2.VideoCapture(args.camera_source, cv2.CAP_V4L2)
        if not self._cap.isOpened():
            raise RuntimeError("Error opening video source!")

        self._cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.video_width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.video_height)
        self._cap.set(cv2.CAP_PROP_FPS, args.video_fps)

        self._out = None
        if has_video_out:
            self._out = make_renderer(
                (args.video_sink, args.video_width, 
                 args.video_height, args.video_fps))

    def deinit(self):
        super().deinit()
        if self._cap is not None:
            self._cap.release()
            self._cap = None
        if self._out is not None:
            self._out.close()
            self._out = None

    def on_frame(self, image):
        return image

    def run(self):
        # first notification to set initial values
        self.notify("iter_change")

        while not self._should_finish():
            image = self.grab_image(True)
            if image is None:
                continue
            image = self.on_frame(image)
            self.render_image(image)
        self.deinit()

    def grab_image(self, flip=False):
        while not self._is_stopped:
            # grab image from video source
            success, image = self._cap.read()
            if not success:
                time.sleep(0.05)
                continue

            if flip:
                return cv2.flip(image, 1)
            return image

    def render_image(self, image):
        if self._out is not None:
            if not self._out.render(image):
                raise RuntimeError("Could not write to output video device!")
