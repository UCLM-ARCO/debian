# -*- mode: python; coding: utf-8 -*-

from unittest import TestCase


class OutputFixture(TestCase):
    def test_print_text(self):
        print("OutputFixture printed this")
