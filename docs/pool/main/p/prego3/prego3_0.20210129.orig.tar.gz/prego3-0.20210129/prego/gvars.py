# -*- coding:utf-8; tab-width:4; mode:python -*-

from commodity.pattern import TemplateBunch

tasks = []
context = TemplateBunch()
testpath = ''
