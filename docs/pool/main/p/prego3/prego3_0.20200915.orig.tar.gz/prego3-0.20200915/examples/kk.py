#!/usr/bin/python3
# -*- coding:utf-8; mode:python -*-

import hamcrest
import prego

class ServantIntegrationTest(prego.TestCase):
   def test_switch_on_with_servant(self):
       servant = prego.Task(desc='servant with the objects', detach=True)
