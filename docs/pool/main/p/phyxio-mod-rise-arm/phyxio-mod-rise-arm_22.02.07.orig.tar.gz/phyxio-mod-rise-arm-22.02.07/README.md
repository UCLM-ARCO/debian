# Description

This module monitors a user that needs to raise and lower his right arm.

