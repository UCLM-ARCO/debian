
class RiseArmClientI extends Phyxio.RiseArmClient {
   constructor() {
      super();
      this.total_iters = 1;
      this.current_iter = 1;
      this.time_limit = null;

      this._start_ts = null;
      this._timer = null;
   }

   // FIXME: get elapsed time from back-end module
   _update_elapsed() {
      // count time upwards
      if (!this.time_limit) {
         let elapsed = new Date(Date.now() - this._start_ts);
         let width = lerp(elapsed.getSeconds(), 0, 60, 5, 100);
         this._update_timer_ui(
            elapsed.getMinutes(), elapsed.getSeconds(), width);
      }
      // count time downwards
      else {
         let elapsed = Math.floor((Date.now() - this._start_ts) / 1000);
         let remain = Math.max(0, this.time_limit - elapsed);
         let mins = Math.floor(remain / 60);
         let secs = remain % 60;
         let width = lerp(remain, 0, this.time_limit, 5, 100);
         this._update_timer_ui(mins, secs, width);
         if (remain == 0) {
            clearInterval(this._timer);
         }
      }
   }

   _start_timer() {
      if (!this._start_ts) {
         this._start_ts = Date.now();
         this._timer = setInterval(this._update_elapsed.bind(this), 1000);
      }
   }

   _update_timer_ui(mins, secs, width) {
      $('#elapsed-s').text(secs);
      $('#elapsed-m').text(mins);
      $('#elapsed-per').css({"width": `${width}%`});
   }

   // this is an RMI invocation
   setTimeLimit(time) {
      _(`RiseArmClientI: setTimeLimit: ${time}`);

      this.time_limit = time;

      // update expected counter and timeout
      $('#iter-counter .expected h1').text("Max.");
      let mins = Math.floor(time / 60);
      let secs = time % 60;
      this._update_timer_ui(mins, secs, 100);

      // start timer (if not started) to update timeout
      if (!this._start_ts) {
         this._start_timer();
      }
   }

   // this is an RMI invocation
   setIterations(current, total) {
      _(`RiseArmClientI: setIterations: ${current} / ${total}`);

      this.total_iters = total;
      this.current_iter = current;

      if (total) {
         $('#iter-counter .expected h1').text(`${total}`.padStart(2, "0"));

         // start timer (if not started) to update timeout
         if (!this._start_ts)
            this._start_timer();
      }
      $('#iter-counter .current h1').text(`${current}`.padStart(2, "0"));
   }

   // this is an RMI invocation
   setFinished(results) {
      _('RiseArmClientI: setFinished');
      $('.hide-on-results').hide();
   }
};

class RiseArmApp {
   constructor(ic) {
      this.ic = ic;
      this._check_and_connect_video();
   }

   async setup(proxy) {
      _("RiseArmApp: setup...");

      this.mod_observer = Phyxio.ObserverPrx.uncheckedCast(
         this.ic.stringToProxy(proxy)
      );

      this.adapter = await this.ic.createObjectAdapter("");
      this.client_prx = Phyxio.RiseArmClientPrx.uncheckedCast(
         this.adapter.addWithUUID(new RiseArmClientI())
      );
      return await this.connect();
   }

   async connect() {
      _("RiseArmApp: connect...");

      try {
         var conn = this.mod_observer.ice_getCachedConnection()
         if (!conn) {
            await this.mod_observer.ice_ping();
            conn = this.mod_observer.ice_getCachedConnection();
         }
         conn.setAdapter(this.adapter);
         await this.mod_observer.setClientProxy(this.client_prx);
         return true;
      }
      catch (err) {
         var reason = err;
         if (err.ice_id)
            reason = err.ice_id();
         console.error("RiseArmApp: could not register servant, reason: " + reason);
         return false;
      }
   }

   async _check_and_connect_video() {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
         show_error("<h2>Sorry, mediaDevices not supported here!</h2>");
         return;
      }

      var retry_count = 7;
      async function _check_devid() {
         // check if phyxio camera is found
         const devices = await navigator.mediaDevices.enumerateDevices();
         let device_id = null;
         devices.some(dev => {
            if (dev.label == "phyxio") {
               device_id = dev.deviceId;
               return true;
            }
         });

         // if not found, retry
         if (device_id == null) {
            if (--retry_count) {
               setTimeout(_check_devid.bind(this), 500);
               return;
            }
            show_error("Could not open video device (not found).");
         }

         this._connect_video(device_id);
      };

      // force to show ask-permission-dialog to use video devices
      navigator.mediaDevices.getUserMedia({video: true})
         .then(_check_devid.bind(this)).catch(_check_devid.bind(this));
   }

   async _connect_video(device_id) {
      _(`RiseArmApp: video device found: ${device_id}`);

      let video = $('#play-area video')[0];
      let constraints = {video: {deviceId: {exact: device_id}}};
      try {
         const stream = await navigator.mediaDevices.getUserMedia(constraints);
         video.srcObject = stream;
         video.play();
      } catch(err) {
         show_error(`ERROR: ${err} `);
      }
   }
};

function create_ice_comm() {
   var idata = new Ice.InitializationData();
   idata.properties = Ice.createProperties();
   idata.properties.setProperty("Ice.ACM.Client.Heartbeat", "3");
   return Ice.initialize(idata);
}

function show_error(msg) {
   // $('#play-area').hide();
   // $('#error-msg').append(msg).show();
}

window.addEventListener("load", async function() {
   let params = get_eci_params();

   try {
      var ic = create_ice_comm();
      var server = new RiseArmApp(ic, params);
      if (!await server.setup(params.proxy)) {
         // FIXME: translate this
         show_error("There were some problem, can not contact with service.");
         return;
      }
    }
    catch (err) {
        if (err.ice_id)
           err = err.ice_id();
        console.error("Error on initialization: " + err);
    }
});

