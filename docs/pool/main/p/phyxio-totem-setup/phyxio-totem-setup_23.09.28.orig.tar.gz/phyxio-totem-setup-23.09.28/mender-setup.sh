#!/bin/bash

set -e

# define variables and check tokens
MC_CONF="/etc/mender/mender-connect.conf"
TOKENS="./tokens"

[ ! -f "$TOKENS" ] && (
    echo "Please, create the file '$TOKENS' with the following variables:"
    echo " - JWT_TOKEN and TENANT_TOKEN"
    exit 1
)

has_coral_usb() {
    local cmd="udevadm info -q all -p /sys/bus/usb/devices/*"
    local retval="0"
    for regex in "PRODUCT=1a6e/89a" "PRODUCT=18d1/9302"
    do
        if [ "$(${cmd} | grep ${regex})" != "" ]; then
            retval="1"
        fi
    done
    echo "${retval}"
}

get_dev_type() {
    local retval="$(uname -m)"
    if [ "$(grep "Raspberry Pi 4" /proc/cpuinfo)" != "" ]; then
        retval="RPi4"
    elif [ "$(grep "Raspberry" /proc/cpuinfo)" != "" ]; then
        retval="RPi"
    fi
    if [ "$(has_coral_usb)" != "0" ]; then
        retval="${retval}-Coral"
    fi
    echo "${retval}"
}

echo "What user do you want to use for remote terminal with mender? "
echo -n "Note: it must exist! Examples: pi, jonhdoe, admin... > "
read username

# check that mender-client is installed
which mender > /dev/null || (
    echo "Please, install mender-client first."
    echo "Visit https://docs.mender.io/downloads#mender-client for detailed instructions"
    exit 1
)

# setup mender device
source tokens

mender setup \
    --device-type $(get_dev_type) \
    --hosted-mender \
    --tenant-token $TENANT_TOKEN \
    --update-poll 120 \
    --inventory-poll 3600 \
    --retry-poll 300

# update configuration
contents="$(jq ".User = \"$username\"" $MC_CONF)" && echo "${contents}" > "$MC_CONF"

# restart services
systemctl restart mender-client.service
systemctl restart mender-connect.service

exit 0
