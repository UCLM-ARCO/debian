# Overview

This is an Update Module for mender that handles the installation of Phyxio modules inside a totem. For more information, visit the referenced links.

The installer will use a phyxio Totem auth token to notify phyxio server of a successfull installation. Thus, the module-deployer will not try to generate new deployments for this module.

If encryption is implemented, it will also use another phyxio API token to retrieve the encryption key and decrypt the provisioned package before installation.


# References

* https://docs.mender.io/client-installation/use-an-updatemodule
* https://docs.mender.io/artifact-creation/create-a-custom-update-module


