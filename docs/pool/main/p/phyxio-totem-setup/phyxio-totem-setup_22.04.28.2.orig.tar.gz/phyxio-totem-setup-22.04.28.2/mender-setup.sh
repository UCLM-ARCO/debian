#!/bin/bash

set -e

# define variables and check tokens
MC_CONF="/etc/mender/mender-connect.conf"
TOKENS="./tokens"

[ ! -f "$TOKENS" ] && (
    echo "Please, create the file '$TOKENS' with the following variables:"
    echo " - JWT_TOKEN and TENANT_TOKEN"
    exit 1
)

get_dev_type() {
    if [ "$(grep "Raspberry Pi 4" /proc/cpuinfo)" != "" ]; then
        echo "RPi4"
    elif [ "$(grep "Raspberry" /proc/cpuinfo)" != "" ]; then
        echo "RPi"
    else
        echo "$(uname -m)"
    fi
}

# check that mender-client is installed
which mender > /dev/null || (
    echo "Please, install mender-client first."
    echo "Visit https://docs.mender.io/downloads#mender-client for detailed instructions"
    exit 1
)

# setup mender device
source tokens

mender setup \
    --device-type $(get_dev_type) \
    --hosted-mender \
    --tenant-token $TENANT_TOKEN \
    --update-poll 120 \
    --inventory-poll 3600 \
    --retry-poll 300

# update configuration
echo "What user do you want to use for remote terminal with mender? "
echo -n "Note: it must exist! Examples: pi, jonhdoe, admin... > "
read username

contents="$(jq ".User = \"$username\"" $MC_CONF)" && echo "${contents}" > "$MC_CONF"

# restart services
systemctl restart mender-client.service
systemctl restart mender-connect.service

exit 0
