#!/bin/bash

set -e

# define variables and check tokens
MC_CONF="/etc/mender/mender-connect.conf"
TOKENS="./tokens"

[ ! -f "$TOKENS" ] && (
    echo "Please, create the file '$TOKENS' with the following variables:"
    echo " - JWT_TOKEN and TENANT_TOKEN"
    exit 1
)

# check that mender-client is installed
which mender-client > /dev/null || (
    echo "Please, install mender-client first."
    echo "Visit https://docs.mender.io/downloads#mender-client for detailed instructions"
    exit 1
)

# setup mender device
source tokens

mender setup \
    --device-type "RPi4" \
    --hosted-mender \
    --tenant-token $TENANT_TOKEN \
    --update-poll 120 \
    --inventory-poll 3600 \
    --retry-poll 300

# update configuration
contents="$(jq '.User = "pi"' $MC_CONF)" && echo "${contents}" > "$MC_CONF"

# restart services
systemctl restart mender-client.service
systemctl restart mender-connect.service

exit 0
