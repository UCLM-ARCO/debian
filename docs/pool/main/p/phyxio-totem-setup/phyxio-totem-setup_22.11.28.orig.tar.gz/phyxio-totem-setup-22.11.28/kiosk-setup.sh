#!/bin/bash

# NOTE: run this script as the user that will be launched in kiosk
# mode, NOT as root or using sudo.

CHROME_DEB="google-chrome-stable_current_amd64.deb"
RD="\033[37;1;41m"
RT="\033[0m"

echo -e "${RD}WARNING!${RT} This script will change user's configuration heavily!"
echo -n "- Are you sure? (y/N)"
read iamsure
if [ $iamsure != "y" ]; then
    echo "You are not sure, so nothing to do.";
    exit 1
fi

# install required dependencies
wget -q https://dl.google.com/linux/direct/${CHROME_DEB}
sudo apt -y install ./${CHROME_DEB}
rm -f ./${CHROME_DEB}

# remove apport (to disable 'error report' popups)
sudo apt -y remove apport*

# change wallpaper
gsettings set org.gnome.desktop.background picture-uri \
    "file:///usr/share/phyxio-totem-setup/assets/totem-bg.png"

# set automatic user login
sudo sed -i 's/^AutomaticLogin=.*/AutomaticLogin='${USER}'/g' /etc/gdm3/custom.conf
sudo sed -i 's/^AutomaticLoginEnable=.*/AutomaticLoginEnable=true/g' /etc/gdm3/custom.conf

# disable automatic screen lock
gsettings set org.gnome.desktop.screensaver lock-enabled false

# update power-saving delay to 10 minutes
gsettings set org.gnome.desktop.session idle-delay 600

# set dark mode
gsettings set org.gnome.desktop.interface gtk-theme "Yaru-dark"

# configure dock: move to bottom and reduce size...
gsettings set org.gnome.shell.extensions.dash-to-dock dock-position BOTTOM
gsettings set org.gnome.shell.extensions.dash-to-dock dash-max-icon-size 32

# ...or even better, remove all visible icons on dock
gsettings set org.gnome.shell.extensions.dash-to-dock show-trash false
gsettings set org.gnome.shell.extensions.dash-to-dock show-favorites false
gsettings set org.gnome.shell.extensions.dash-to-dock show-show-apps-button false
gsettings set org.gnome.shell.extensions.dash-to-dock show-running false

# remove desktop icons
gsettings set org.gnome.shell.extensions.ding show-home false
gsettings set org.gnome.shell.extensions.ding show-trash false
gsettings set org.gnome.shell.extensions.ding show-volumes false

# disable some notifications
gsettings set org.gnome.desktop.notifications show-banners false
gsettings set com.ubuntu.update-notifier no-show-notifications true

# launch google-chrome on kiosk mode at startup
mkdir -p ~/.config/autostart
cp /usr/share/phyxio-totem-setup/assets/phyxio.desktop ~/.config/autostart/

echo -e "\nReady! Please, restart the computer to check that all changes are made correctly."
