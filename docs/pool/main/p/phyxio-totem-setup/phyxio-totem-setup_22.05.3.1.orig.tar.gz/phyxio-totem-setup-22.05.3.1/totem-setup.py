#!/usr/bin/env python3

import os
import sys
import json
import subprocess
from uuid import uuid4
from argparse import ArgumentParser
import yaml
import requests


class TotemSetup:
    def __init__(self, args):
        print("Welcome to this device setup for Phyxio.")
        print("NOTE: if you will be using mender-client, please install and configure it FIRST!")

        if args.server_url.startswith("http://") and not args.force_insecure:
            print("ERROR: HTTP not recommended, please provide an HTTPS url (or force insecure mode)")
            return

        print(f"We will use the following server url: '{args.server_url}'")
        provide_msg = "Please, provide the following fields:\n"
        request_msgs = {
            'facility_token': "Facility API token",
            'totem_name': "Totem Name",
            'totem_model': "Totem Model",
            'totem_version': "Totem Hardware Version",
            'totem_serial': "Totem Serial Number",
        }
        for name, msg in request_msgs.items():
            if getattr(args, name) is None:
                if provide_msg:
                    print(provide_msg)
                    provide_msg = None
                setattr(args, name, self._request(msg))

        # get device type
        if args.device_type is None:
            args.device_type = self._get_device_type()

        # register totem (if token not provided)
        if args.totem_token is not None:
            print("Totem API token provided, skip registering")

        else:
            setattr(args, "device_identity", self._get_device_identity())
            ttoken = self._register_totem(args)
            if ttoken is None:
                return
            setattr(args, "totem_token", ttoken)
        self._save_config(args)

    def _request(self, msg):
        try:
            return input(f"- {msg}: ")
        except KeyboardInterrupt:
            sys.exit("\nSetup cancelled!")

    def _get_device_identity(self):
        print("- Getting device identity...")
        id_cmd = "/usr/share/mender/identity/mender-device-identity"
        if os.path.exists(id_cmd):
            return subprocess.check_output(
                [id_cmd], stderr=subprocess.DEVNULL).decode()
        else:
            print("  - WARNING: script not found, using generated uuid!")
            return uuid4().hex

    def _get_device_type(self):
        print("- Getting device type...")
        type_file = "/var/lib/mender/device_type"
        try:
            if os.path.exists(type_file):
                with open(type_file) as src:
                    return src.read().split("=")[1]
            raise RuntimeError(f"file '{type_file}' not found")
        except Exception as err:
            print(f"  - WARNING: error retrieving device type: {err}")
            print("             using default value (uname -m)")
            return os.uname()[4]

    def _register_totem(self, args):
        print("- Registering totem...")
        url = f"{args.server_url}/api/totem/add/"
        data = {
            'facility-api-token': args.facility_token,
            'name': args.totem_name,
            'model_name': args.totem_model,
            'version': args.totem_version,
            'serial_number': args.totem_serial,
            'device_identity': args.device_identity,
            'device_type': args.device_type,
        }

        reason = "<server did not provide a reason>"
        try:
            resp = requests.post(url, data=data)
            resp = json.loads(resp.content)
            if resp.get("status") == "ok":
                return resp.get('totem-api-token')

            reason = resp.get("reason", reason)
        except json.decoder.JSONDecodeError:
            reason = "<unknown, invalid response from server>"
        except requests.exceptions.ConnectionError:
            reason = "could not connect to remote server"

        print(f"  - ERROR from server: {reason}")
        return None

    def _save_config(self, args):
        print(f"- Saving configuration (file: {args.config_file})...")
        if os.path.exists(args.config_file) and not args.force_overwrite:
            res = input("  - Configuration file exits, overwrite it? (y/N) ")
            if res != "y":
                print("  - Nothing done.")
                return

        settings = {
            "totem": {
                "api-key": args.totem_token,
                "name": args.totem_name,
                "model": args.totem_model,
                "version": args.totem_version,
                "serial-number": args.totem_serial,
                "device-type": args.device_type,
            },
            "server": {
                "url": args.server_url,
            }
        }
        yaml.dump(settings, open(args.config_file, "w"))
        print("  - Configuration file saved!")


if __name__ == "__main__":
    def fmt_url(url):
        if url.startswith("http://"):
            return url
        if not url.startswith("https://"):
            url = f"https://{url}"
        return url

    parser = ArgumentParser()
    parser.add_argument("-u", "--server-url", default='https://phyx.io', type=fmt_url,
        help="main server url")

    parser.add_argument("-t", "--facility-token",
        help="facility API token")
    parser.add_argument("-k", "--totem-token",
        help="totem API token")

    parser.add_argument("-n", "--totem-name",
        help="name of this totem")
    parser.add_argument("-m", "--totem-model",
        help="model of this totem")
    parser.add_argument("-v", "--totem-version",
        help="hardware version of this totem")
    parser.add_argument("-s", "--totem-serial",
        help="serial number of this totem")
    parser.add_argument("-d", "--device-type",
        help="type of thid device (ie. x86_64, RPi4...")

    parser.add_argument("-c", "--config-file", default="/etc/phyxio-deploy.yaml",
        help="path of configuration file to save")

    parser.add_argument("--force-overwrite", action="store_true",
        help="force settings file overwrite (do not ask)")
    parser.add_argument("--force-insecure", action="store_true",
        help="disable HTTPS requirement (do not use on real deployments)")

    TotemSetup(parser.parse_args())
