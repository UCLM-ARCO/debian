#!/usr/bin/python
# -*- mode: python; coding: utf-8 -*-

from gamepadpy import Observer, EventListener, KEY_NAMES


class MyObserver(Observer):
    def on_event(self, event):
        if not event.key in KEY_NAMES:
            return

        print event


if __name__ == '__main__':
    observer = MyObserver()
    listener = EventListener("/dev/input/js0", observer)
    listener.start()

    import time
    while True:
        time.sleep(2)

