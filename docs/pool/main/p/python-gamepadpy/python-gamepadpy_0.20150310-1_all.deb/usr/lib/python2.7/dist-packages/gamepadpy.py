# -*- mode: python; coding: utf-8 -*-

from threading import Thread

FIELD_STATUS_L  = 4
FIELD_STATUS_H  = 5
FIELD_TYPE      = 6
FIELD_KEY       = 7

TYPE_INFO1      = 129
TYPE_INFO2      = 130
TYPE_MOD1       = 1
TYPE_MOD2       = 2

STATUS_PRESSED  = 1
STATUS_RELEASED = 0

KEY_1           = 256 + 0
KEY_2           = 256 + 1
KEY_3           = 256 + 2
KEY_4           = 256 + 3
KEY_L1          = 256 + 4
KEY_R1          = 256 + 5
KEY_L2          = 256 + 6
KEY_R2          = 256 + 7
KEY_SELECT      = 256 + 8
KEY_START       = 256 + 9
KEY_L_JOY_PRESS = 256 + 10
KEY_R_JOY_PRESS = 256 + 11
KEY_RIGHT       = 1024
KEY_LEFT        = 1025
KEY_UP          = 1026
KEY_DOWN        = 1027

locals_ = locals().copy()
KEY_NAMES = dict([(y, x) for x, y in locals_.items()
                  if x.startswith("KEY_")])


class Event(object):
    def __init__(self, fields, current):
        self.fields = fields
        self.current = current

        self.analog_value = (
            fields[FIELD_STATUS_L]
            + fields[FIELD_STATUS_H] << 8)
        self.status = int(bool(self.analog_value))
        self.key = fields[FIELD_KEY] + (fields[FIELD_TYPE] << 8)

        if self.key in KEY_NAMES:
            return

        if self.key == 512:
            if self.analog_value == 97792:
                self.key = KEY_RIGHT
            elif self.analog_value == 33024:
                self.key = KEY_LEFT
            elif self.analog_value == 0:
                if KEY_RIGHT in current:
                    self.key = KEY_RIGHT
                elif KEY_LEFT in current:
                    self.key = KEY_LEFT

        if self.key == 513:
            if self.analog_value == 97792:
                self.key = KEY_DOWN
            elif self.analog_value == 33024:
                self.key = KEY_UP
            elif self.analog_value == 0:
                if KEY_UP in current:
                    self.key = KEY_UP
                elif KEY_DOWN in current:
                    self.key = KEY_DOWN

    def __repr__(self):
        retval = "<Event - key: "
        retval += "{}, {}".format(
            self.key,
            KEY_NAMES.get(self.key, "<unknown>"))
        retval += ", status: "
        retval += "PRESS" if self.status else "RELEASE"
        retval += ", analog: " + str(self.analog_value)
        retval += "> " + " " * (65 - len(retval))
        retval += str(map(lambda x: "{:02x}".format(x), self.fields))
        return retval


class Observer(object):
    def on_event(self, event):
        if event.key not in KEY_NAMES:
            return

        print event


class EventListener(Thread):
    def __init__(self, filename, observer):
        Thread.__init__(self)

        self.daemon = True
        self.filename = filename
        self.observer = observer

    def run(self):
        src = open(self.filename, "r")
        current = {}

        while True:
            d = src.read(8)
            fields = map(ord, d)

            # filter first events at openning time
            if fields[FIELD_TYPE] in [TYPE_INFO1, TYPE_INFO2]:
                continue

            # store current events
            ev = Event(fields, current)
            if ev.status == STATUS_PRESSED:
                current[ev.key] = ev
            elif ev.key in current:
                current.pop(ev.key)

            self.observer.on_event(ev)
