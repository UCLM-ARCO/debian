#!/usr/bin/python
# -*- coding:utf-8; tab-width:4; mode:python -*-

import sys
import time

for i in range(int(sys.argv[1]) + 1):
    print "hi"
    time.sleep(0.1)
