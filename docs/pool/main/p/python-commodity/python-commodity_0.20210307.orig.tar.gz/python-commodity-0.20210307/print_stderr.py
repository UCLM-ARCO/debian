#!/usr/bin/python3

import sys

sys.stderr.write("hello error")
sys.stderr.flush()
