# -*- coding:utf-8; tab-width:4; mode:python -*-
"""
.. module:: exceptions
   :synopsis: Pythonic methods to work with exceptions

.. moduleauthor:: Miguel Angel Garcia <miguelangel.garcia@gmail.com>
"""
