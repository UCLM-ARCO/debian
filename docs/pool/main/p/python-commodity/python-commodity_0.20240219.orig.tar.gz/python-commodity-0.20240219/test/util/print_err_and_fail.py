#!/usr/bin/python -u
# -*- coding:utf-8; tab-width:4; mode:python -*-

import sys

sys.stdout.write('wrong->out')
sys.stderr.write('wrong->err')
sys.exit(1)
