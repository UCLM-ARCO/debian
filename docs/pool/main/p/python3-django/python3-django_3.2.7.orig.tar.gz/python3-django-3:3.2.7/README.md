This repository holds a Debian package for PyPi project 'Django'.

