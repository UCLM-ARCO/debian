#!/usr/bin/python3
# -*- mode: python; coding: utf-8 -*-

from distutils.core import setup
from setuptools import find_packages


def get_version():
    with open('debian/changelog', errors="ignore") as chlog:
        return chlog.readline().split()[1][1:-1].split("-")[0]

setup(
    name            = 'django',
    version         =  get_version(),
    author          = "The Django Software Foundation",
    description     = ("Django is a high-level Python web framework that encourages "
                       "rapid development and clean, pragmatic design."),
    url             = "https://www.djangoproject.com/",


    python_requires = ">=3.6",
    packages        = ["django"] + [f"django/{x}" for x in find_packages(where="django")],
    scripts         = ['django/bin/django-admin'],
)
