#!/usr/bin/python3

from distutils.core import setup
# from setuptools import setup

def get_version():
    with open('debian/changelog', errors="ignore") as chlog:
        return chlog.readline().split()[1][1:-1]

setup(
    name          = 'tflite_runtime',
    version       =  get_version(),
    description   = "TensorFlow Lite runtime for Python3",
    author        = "Google, LLC",
    url           = "https://www.tensorflow.org/lite/",
    packages      = [
        "tflite_runtime",
    ],
    package_data  = {
        "": [
            "_pywrap_tensorflow_interpreter_wrapper.so",
        ],
    },
)
