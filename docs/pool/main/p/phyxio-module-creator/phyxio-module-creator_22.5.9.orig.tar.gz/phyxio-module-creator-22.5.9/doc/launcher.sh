#!/bin/bash

set -e

PORT=8978
DOCS_DIR="/usr/share/doc/phyxio-module-creator/manual/"
TMP_DIR="/tmp/pmc-docs/"

rm -fr "$TMP_DIR"

# get browser binary
if which google-chrome > /dev/null; then
    BROWSER="google-chrome --no-first-run --user-data-dir=$TMP_DIR --app=";
elif which chromium-browser > /dev/null; then
    BROWSER="chromium-browser --no-first-run --user-data-dir=$TMP_DIR --app=";
elif which firefox > /dev/null; then
    BROWSER="firefox -new-instance ";
fi

if [ -z "$BROWSER" ]; then
    echo "ERROR: I can't find a suitable web browser. Please, install google-chrome."
    exit 1
fi

# run local server for docs
python3 -m http.server -d "$DOCS_DIR" $PORT &
SERVER_PID=$!

# run browser and wait
URL="http://127.0.0.1:$PORT"
${BROWSER}${URL}

# stop web server
kill -TERM $SERVER_PID
