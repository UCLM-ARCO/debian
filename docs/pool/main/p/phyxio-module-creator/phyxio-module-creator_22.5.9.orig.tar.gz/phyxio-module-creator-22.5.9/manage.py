#!/usr/bin/env python3

# pylint: disable = logging-fstring-interpolation

# This script is used to create a new module, using 'template' as
# boilerplate.

import os
import re
import shutil
from argparse import ArgumentParser


RUNNER_MODS_DIR = "/usr/share/phyxio-module-runner/modules/"


def sed(oldexp, newexp, filename):
    expr = re.compile(oldexp, re.MULTILINE)
    content = open(filename, "r").read()
    with open(filename, "w") as dst:
        dst.write(expr.sub(newexp, content))


def create_new_module(name):
    if os.path.exists(name):
        print("ERROR: Invalid module name, directory already exists!")
        return
    print(f"Creating module: {name}...")

    # copy template skeleton
    shutil.copytree("template", name)

    # change some file names
    os.replace(f"{name}/src/bin/my-module.py", f"{name}/src/bin/{name}.py")
    os.replace(f"{name}/src/my-ice-interface.ice", f"{name}/src/{name}.ice")
    os.replace(f"{name}/module.json.in", f"{name}/module.json")

    # rename some symbols
    cc_name = "".join([x.capitalize() for x in name.split("-")])
    sed("MyModule", cc_name, f"{name}/src/bin/{name}.py")
    sed("MyModule", cc_name, f"{name}/src/eci/js/app.js")
    sed("MyModule", cc_name, f"{name}/module.json")
    sed("MyModule", cc_name, f"{name}/src/module.conf")
    sed("MyModuleClient", f"{cc_name}Client", f"{name}/src/{name}.ice")
    sed("my-module", name, f"{name}/module.json")
    sed("my-module", name, f"{name}/Makefile")
    sed("my-ice-interface.ice", f"{name}.ice", f"{name}/src/bin/{name}.py")
    sed("my-ice-interface.ice", f"{name}.ice", f"{name}/Makefile")
    sed("my-ice-interface.js", f"{name}.js", f"{name}/src/eci/index.html")

    print(f"Module named '{name}' created successfully!")


def install_module(name, soft=False):
    src_path = os.path.abspath(name)
    dst_path = RUNNER_MODS_DIR + name

    if not os.path.exists(RUNNER_MODS_DIR):
        print("WARN: Please note that 'phyxio-module-runner' is not installed.")
        print("WARN: This module will be installed anyway.")
        os.makedirs(RUNNER_MODS_DIR)

    if os.path.exists(dst_path):
        print("ERROR: This module is already installed. Uninstall it first.")
        return

    if soft:
        os.symlink(src_path, dst_path)
    else:
        shutil.copytree(src_path, dst_path)
    print(f"Module successfully installed on '{dst_path}'.")


def uninstall_module(name):
    dst_path = RUNNER_MODS_DIR + name
    if not os.path.exists(dst_path):
        print("ERROR: This module is not installed, nothing to do.")
        return

    print("NOTE: this action will remove the following path:")
    iamsure = input(f" - {dst_path}\nAre you sure? (y/N) ")
    if iamsure != "y":
        print("Aborted.")
        return

    if os.path.islink(dst_path):
        os.unlink(dst_path)
    else:
        shutil.rmtree(dst_path)
    print("Module successfully removed.")


def check_name(s):
    if s[0] in "0123456789":
        print("ERROR: Invalid name (may not start with a number).")
        exit(-1)
    for c in " _":
        if c in s:
            print("ERROR: Invalid name (may only contain letters, numbers and '-').")
            exit(-1)
    return s


def check_root_perms():
    if os.geteuid() != 0:
        print("ERROR: This action needs root permissions. Please, run it again with 'sudo'.")
        exit(-1)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-c", "--create", action="store_true",
        help="create a new module with given name")
    parser.add_argument("-i", "--install", action="store_true",
        help="install module inside module-runner")
    parser.add_argument("-u", "--uninstall", action="store_true",
        help="uninstall module from module-runner")
    parser.add_argument("-s", "--soft-install", action="store_true",
        help="performs a soft installation (ie. use symlinks, do not copy files)")
    parser.add_argument("name", type=check_name,
        help="module name")

    args = parser.parse_args()
    if args.install:
        check_root_perms()
        install_module(args.name, args.soft_install)
    elif args.uninstall:
        check_root_perms()
        uninstall_module(args.name)
    elif args.create:
        create_new_module(args.name)
    else:
        print("ERROR: No action given, nothing to do. Use -h to see more options.")
