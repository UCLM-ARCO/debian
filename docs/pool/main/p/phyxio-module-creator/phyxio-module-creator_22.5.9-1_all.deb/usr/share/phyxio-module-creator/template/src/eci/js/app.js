
class MyModuleClientI extends Phyxio.MyModuleClient {
   constructor() {
      super();

      // FIXME: get elapsed time from back-end module
      this._timer = new TimerCtrl(null);
      this._iters = new IterCtrl();
   }

   // this is an RMI invocation (common iface)
   setTimeLimit(time) {
      _(`MyModuleClientI: setTimeLimit: ${time}`);
      this._timer.set_limit(time);
      this._iters.set_no_limit();
      this._timer.start();
   }

   // this is an RMI invocation (common iface)
   setIterations(current, total) {
      _(`MyModuleClientI: setIterations: ${current} / ${total}`);
      this._iters.update(current, total);

      // start timer (if not started) to update timeout
      if (!this._timer.is_running())
         this._timer.start();
   }

   // this is an RMI invocation (common iface)
   setFinished(results) {
      _('MyModuleClientI: setFinished');
      $('.hide-on-results').hide();
   }
};

class MyModuleApp extends ModuleApp {
   _register_servants(adapter) {
      this.client_prx = Phyxio.MyModuleClientPrx.uncheckedCast(
         adapter.addWithUUID(new MyModuleClientI())
      );
   }
}

window.addEventListener("load", async function() {
   create_module_app(MyModuleApp, "MyModuleApp");
});

