
To clone/update themes, run the follwing command:

    git submodule update --init --recursive

