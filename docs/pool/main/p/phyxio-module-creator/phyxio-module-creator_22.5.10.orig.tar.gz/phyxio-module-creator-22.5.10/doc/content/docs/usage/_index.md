---
title: "Manual de Usuario"
weight: 1

---


## Introducción

Phyxio es una aplicación distribuida formada por dos componentes clave: el servicio web y los módulos del
*runner*. Estos últimos se encargan de utilizar el **hardware de la máquina** (GPU, TPU, cámaras, etc) para ofrecer
servicios de reconocimiento de un ejercicio en concreto.

Este manual explica el proceso de **desarrollo** de un módulo de Phyxio.


## Requisitos

Para poder seguir con este manual, se asume que los siguientes **paquetes Debian** están correctamente instalados:

* `phyxio-module-runner`: se encarga de **lanzar/parar** los módulos que Phyxio necesite para la realización
  de cierto ejercicio. Será necesario para probar el módulo que estemos desarrollando.

* `phyxio-module-creator`: herramienta de gestión para la **creación de módulos** Phyxio. Si estás leyendo esta
  documentación, es posible que ya tengas ese paquete instalado.


## Arquitectura de los módulos

Un módulo es básicamente una aplicación que corre dentro del hardware del Totem, y que se **comunica con Phyxio**
por medio de una o varias interfaces Ice. Puede ser un programa binario escrito en C++, C#, un script en Python, o
cualquier otro lenguaje para el que existan bindings de [ZeroC Ice](https://zeroc.com/products/ice). La herramienta
 `phyxio-module-creator` y, por ende, este manual asumen que el módulo será escrito en **Python**.

Un módulo se compone básicamente de las siguientes partes:

* **Binario**: este es el programa principal que se ejecutará cuando Phyxio lo indique. Se encarga de procesar
  el vídeo, de la lectura del hardware, las comunicaciones con el *runner* y con phyx.io, etc.

* **Interfaz ECI**: forma la interfaz web que se mostrará *durante* la realización del ejercicio. La ECI (
  *Embedded Controller Interface*) está formada por un fichero HTML, que cargará una guía de estilos en CSS
  y una aplicación en Javascript.

![](/images/basic-architecture.png)

La herramienta `phyxio-module-creator` genera la jerarquía y el **código mínimo necesario** para un módulo básico.
A partir de ahí, el desarrollador podrá aportar la funcionalidad que necesite.


## Creación de un módulo

> **Nota:** este manual explicará el proceso de creación de un módulo que analizará la **posición de las manos**
> del usuario y detectará cuando coloca una de ellas en un punto determinado de la pantalla. Se empleará OpenCV y/o
> mediapipe, aunque los detalles técnicos del proceso de detección no se discutirán aquí.

Para **crear un módulo** de Phyxio, llamado `move-to-point`, ejecuta el siguiente comando en una terminal:

```shell
phyxio-mod-admin -c move-to-point
```

El anterior comando **generará un directorio**, del mismo nombre que el módulo, con la estructura básica necesaria.
Algo similar a lo siguiente:

```shell
$ tree
move-to-point
├── Makefile
├── module.json
└── src
    ├── bin
    │   └── move-to-point.py
    ├── eci
    │   ├── css
    │   │   └── style.css
    │   ├── index.html
    │   └── js
    │       └── app.js
    ├── module.conf
    └── move-to-point.ice
```

La **función** de cada uno de esos archivos se detalla a continuación:

* El fichero `Makefile` contiene las reglas necesarias para algunas tareas rutinarias. En particular, permite
**compilar las interfaces** Slice a Javascript, para ser usadas dentro de la aplicación JS. También tiene algunas
otras reglas específicas para la creación de paquetes Debian y de artefactos de mender, pero no se usarán en este
 manual. **No es necesario editar este fichero**.

* `module.json` sirve para especificar la **configuración básica** del módulo. Se indica el nombre del módulo,
`name`; su nombre en clave, o `codename`, cuyo valor se empleará al registrar el módulo dentro de Phyxio; la ruta
relativa (`module_dir`) donde se encuentran el binario y la interfaz ECI; el nombre del binario (`exec`); y
una serie de parámetros de configuración para la ECI (en especial, el `proxy` que deberá usar para comunicarse
con el binario). Los valores por defecto suelen ser adecuados, y **no es necesario cambiar nada** (al menos de
momento).

* `src/bin/move-to-point.py` es el binario del módulo, que será **lo que se ejecute** cuando Phyxio lo indique.
Este fichero contiene el código mínimo necesario para un módulo Python, pero es posible reescribirlo por
completo, usando cualquier otro lenguaje compatible. Más adelante comentaremos su contenido paso a paso.

* El directorio `src/eci` contiene la **interfaz web** que se empotrará dentro de phyx.io cuando se esté realizando
un ejercicio que use este módulo. También hablaremos después de su contenido más detalladamente.

* `src/module.conf` especifica la configuración de ZeroC Ice que usará el binario para crear su *Communicator* y
el adaptador de objectos. Los valores especificados por defecto son suficiente, por lo que **tampoco es necesario
cambiar nada** (salvo requisitos muy concretos).

* `src/move-to-point.ice` define la interfaz ZeroC Ice que se empleará en la comunicación entre el binario y la
interfaz ECI (aplicación web). Por defecto, la interfaz hereda de `ECIClient`, pero está pensada para **ser extendida
con nuevos métodos**, según sea necesario. Comentaremos su uso más adelante.


### Instalación

Para que el módulo recién creado pueda usarse, debe **instalarse en el sistema**. La aplicación
`phyxio-mod-admin` también se encarga de ello. Basta con indicarle el nombre del módulo (desde el directorio
en dónde esté), con la opción `-i`. Esto **copiará el módulo completo** a su ruta correspondiente. A veces, sin
embargo y sobre todo durante el desarrollo, es conveniente tener el módulo instalado (para probarlo) y a su
vez, poder seguir realizando modificaciones en él. A tal efecto existe la opción `-s`, que le indica a
`phyxio-mod-admin` que debe realizar un enlace simbólico (en vez de una copia completa).

Por tanto, si queremos instalar nuestro módulo, y seguir trabajando con él, ejecutaremos el siguiente
comando:

> **Nota:** es necesario ejecutarla con `sudo`, pues la aplicación modificará rutas del sistema.

```shell
sudo phyxio-mod-admin -i -s move-to-point
```

Si deseas desinstalar, usa la opción `-u` de la misma forma:

```shell
sudo phyxio-mod-admin -u move-to-point
```

Al instalar un nuevo módulo (o desinstalarlo), es necesario **reiniciar el servicio** que lo usa (para que
actualice sus registros). Así pues, ejecuta el siguiente comando después de la (des)instalación:

```shell
sudo systemctl restart phyxio-module-runner.service
```

Y, para comprobar que la instalación (y la carga) se han realizado satisfactoriamente, puedes ver el log
del servicio con el siguiente comando:

```shell
journalctl -f -u phyxio-module-runner.service

...
INFO:ModuleRunner: Loading module /usr/share/phyxio-module-runner/modules/move-to-point/module.json
INFO:ModuleRunner: - module named 'move-to-point' correctly loaded!
...
```


## Ejecución de un módulo

Cuando el usuario visita la web de [phyx.io](https://phyx.io?fmode=totem), en la **vista de totem**, entra en una
rutina y pulsa sobre *Comenzar*, se abre una página de **carga** para el primer ejercicio de la rutina. Esta
página corre una aplicación en JavaScript que contacta con un servicio llamado `module-runner` (usando ZeroC Ice),
y le indica que ejecute el binario del módulo específico para ese ejercicio.

El `module-runner`, al iniciar, registra todos los módulos instalados (leyendo el fichero `module.json` de cada
uno). Cuando la página de carga le indica el nombre del módulo (usando su `codename`), este lo busca
en su registro, obtiene la ruta al binario, y **lo ejecuta**. Además, lanza un servidor web con la interfaz ECI
del módulo, y **notifica** a la página de carga que está disponible.

La página de carga (también llamada cliente), al recibir la notificación del *runner*, **carga la web ECI** del
módulo y se queda esperando más eventos desde el *runner*. A partir de este momento, el control lo toma el módulo
del ejercicio, tanto la aplicación que corre en la ECI, como el binario que ha ejecutado el *runner*.


## Flujo de ejecución del binario

> **Nota:** si bien es cierto que llamamos *binario* a la aplicación principal del módulo, no tiene porqué ser un
> binario como tal (algo compilado). De hecho, **la mayoría de las veces**, hablamos de un script en Python. No
> obstante, seguiremos usando esta notación en aras de la simplicidad.

El binario del módulo que se ha generado (el fichero `src/bin/move-to-point.py`) consta de una aplicación Ice
(`Ice.Application`), con su *communicator* correspondiente, y un adaptador de objetos:

```python
class MoveToPoint(Ice.Application):
    def run(self, args):
        if not self._check_args(args):
            return -1

        # create communicator and adapter
        ic = self.communicator()
        adapter = ic.createObjectAdapter("MoveToPoint.Adapter")
        adapter.activate()
```

Además, **se crea un proxy** a un objeto que reside en el *runner* y que sirve para notificarle cambios en el
estado del módulo:

```python
        # get proxy to runner service
        runner = Phyxio.ModuleHandlerPrx.checkedCast(
            ic.stringToProxy(self.args.runner_prx))
```

En concreto, se usará el método `ready()` para indicar al *runner* que el módulo ha arrancado
correctamente y está activo, y `finish()` para notificar la finalización del ejercicio, y mandar un reporte
de resultados.

Por otro lado, también se crea **un sirviente** que será registrado en el adaptador de objetos, y estará a
disposición de la ECI. La interfaz de ese sirviente es `Phyxio.Observer`, y tiene como único objetivo permitir
a la ECI notificar al módulo el proxy de un **observador**, que se empleará en la comunicación entre el módulo y
la ECI. La interfaz de ese observador está definida en el fichero slice que se ha generado (en este caso,
`move-to-point.ice`) y se puede modificar según sea necesario.

```python
        # add observer servant, to receive client proxy
        servant = PhyxioObserverI(self.args, runner)
        prx = adapter.add(servant, Ice.stringToIdentity("MoveToPoint"))
        log.info(f" Module proxy: {prx}")
```

Por último, la aplicación **notifica su estado** y ejecuta el **bucle de eventos** del *communicator*. De
ser necesario, es posible reemplazar este por otro bucle de eventos (lo veremos más tarde). El código
relacionado es el siguiente:

```python
        # notify runner that we are ready, and wait events
        runner.readyAsync()
        self.callbackOnInterrupt()
        ic.waitForShutdown()
        ic.destroy()
```

Todo el código discutido hasta ahora ha sido generado por la herramienta `phyxio-mod-admin`, y **no es necesario
realizar modificaciones** en él. También existen algunos puntos, marcados con sendos comentarios, donde es
probable que necesites realizar cambios. Según progresemos en el ejemplo, los iremos viendo.


### Argumentos del ejercicio

La clase principal del binario que estamos analizando contiene un método llamado `_check_args()`, que se encarga
de parsear los argumentos de la línea de órdenes. Estos argumentos (que los aporta el *runner*) se obtienen
de dos sitios diferentes: 1) la **configuración interna** del runner (parámetros comunes) y 2) las opciones de
**configuración del ejercicio** (determinada por el *trainer* al crearlo).

Utilizando la función `get_global_parser()` de la librería *tools*, se crea un parser (en concreto, un
[ArgumentParser](https://docs.python.org/3/library/argparse.html#argumentparser-objects)) que ya tiene
configuradas las opciones comunes. En el método `_check_args()` puedes añadir cualquier opción particular que
tu módulo necesite. A modo de ejemplo, vamos a hacer que `move-to-point` acepte un argumento
opcional para indicar si limitamos el punto dónde el usuario debe mover la mano a una parte del espacio: derecha,
izquierda, arriba o abajo. Para ello, añadimos un argumento al parser, `--limit-area`, de la siguiente forma:

```python
    def _check_args(self, args):
        parser = get_global_parser()

        parser.add_argument("--limit-area",
            choices=["left", "right", "top", "bottom"],
            help="limit area to specified section")
```

A partir de ese momento, la aplicación podrá acceder al valor de ese parámetro opcional desde
`self.args.limit_area`.


### Tracker de manos

El módulo que genera `phyxio-mod-admin` por defecto está orientado al **análisis de vídeo** mediante
técnicas de visión por computador. Esto implica que está pensado para ser usado con un componente de vídeo
que procese los frames de entrada, realice las operaciones pertinentes, y escriba los frames resultantes a
un sumidero de vídeo. Y esa es precisamente la funcionalidad que aporta la clase `VideoComponent` de la librería
de componentes.

`VideoComponent` se encarga de **inicializar los dispositivos de vídeo**, tanto de entrada como de salida. Además,
implementa un **bucle de eventos** específico, que realiza las siguientes acciones:

* **Captura un frame** del dispositivo de vídeo de entrada.
* Lo **invierte** horizontalmente (para obtener una imagen especular).
* Llama al método `on_frame()`, pasando el frame como argumento.
* **Escribe** en el dispositivo de vídeo de salida el frame retornado por `on_frame()`.

> **Nota:** `VideoComponent` también implementa otros métodos de soporte para notificar cambios a la
> ECI, detener el bucle de eventos, etc. Los iremos viendo según sea necesario.

Para usar el `VideoComponent`, es necesario definir un nuevo componente que herede de él. Por ejemplo,
para el módulo `move-to-point`, definiremos la clase `HandPositionDetector`, en cuyo constructor crearemos los
objetos necesarios para realizar el tracking de las manos:

```python
class HandPositionDetector(VideoComponent):
    def __init__(self, args, servant):
        super().__init__(args, observer=servant)
        self._target_pos = TargetPositionIterator(args)

        # more info for hand tracking here:
        # https://google.github.io/mediapipe/solutions/hands.html
        self._hands = mp_hands.Hands(
            max_num_hands=1,
            model_complexity=0,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5)
```

Como parámetros del constructor, tenemos los argumentos que procesó el parser de la línea de órdenes (`args`),
y el sirviente que creamos en la aplicación principal (la instancia de `PhyxioObserver`, `servant`). El
constructor de la clase `VideoComponent` acepta un parámetro opcional más llamado `has_video_out` que indica si
deseamos proporcionar feedback de vídeo al usuario o no. Por defecto es `True`, pero si le pasamos `False`, **no
se creará** el dispositivo de vídeo de salida (lo cual podría ser útil para módulos que procesan el vídeo pero
no necesitan mostrarlo al usuario).

En el código anterior, también he instanciado una clase encargada de determinar la posición objetivo a la que el
usuario tendrá que mover la mano (el `TargetPositionIterator`). Por razones de completitud, he aquí su código:

```python
import random
import cv2

ORANGE  = (0, 95, 253)    # BGR
GRAY    = (100, 100, 100) # BGR
WHITE   = (255, 255, 255) # BGR

class TargetPositionIterator:
    def __init__(self, args, radius=64):
        self._w = args.video_width
        self._h = args.video_height
        self._r = radius
        self._limit = args.limit_area

        self._current = (0, 0)
        self.next()

    def draw(self, image):
        x, y = self._current
        cv2.circle(image, (x+1, y+1), self._r, GRAY, 3, cv2.LINE_AA)
        cv2.circle(image, (x, y), self._r, WHITE, 3, cv2.LINE_AA)

    def match(self, position):
        dx = abs(position[0] - self._current[0])
        dy = abs(position[1] - self._current[1])
        return dx < self._r and dy < self._r

    def next(self):
        # (0,0) is at top-left corner
        x1, y1 = self._r, self._r
        x2, y2 = self._w - self._r, self._h - self._r

        if self._limit == "top":
            y2 = self._h / 2
        elif self._limit == "bottom":
            y1 = self._h / 2
        elif self._limit == "left":
            x2 = self._w / 2
        elif self._limit == "right":
            x1 = self._w / 2

        x = random.randrange(x1, x2)
        y = random.randrange(y1, y2)
        self._current = (x, y)
```

NOTAS:

* no olvidar de compilar el slice a JS.
* al probar por primera vez (o de incognito), pedirá acceso a la cámara
* en `on_frame()`, vital retornar el frame