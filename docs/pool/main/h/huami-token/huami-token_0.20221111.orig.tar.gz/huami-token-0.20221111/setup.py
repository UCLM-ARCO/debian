from setuptools import setup

with open('README.md') as fr:
    LONG_DESC = fr.read()
with open('debian/changelog') as fr:
    VERSION = fr.readline().split('(')[
        1].split('-')[0]
with open('requirements.txt') as fr:
    REQUIRES = []
    for line in fr:
        _line = line.strip(' \n')
        if _line.startswith('#') or _line.isspace():
            continue
        REQUIRES.append(_line)

setup(
    name='huami-token',
    version=VERSION,
    description='Huami Token package',
    long_description=LONG_DESC,
    long_description_content_type="text/markdown",
    author='Kirill Snezhko (argrento)',
    maintainer='Cristina Bolaños Peño',
    maintainer_email='Cristina.Bolanos@uclm.es',
    url='https://github.com/argrento/huami-token',
    packages=['huami_token'],
    scripts=['huami-token'],
    install_requires=REQUIRES)
