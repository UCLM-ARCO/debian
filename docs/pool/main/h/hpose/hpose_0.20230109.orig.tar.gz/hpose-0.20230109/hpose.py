import importlib
import os
from typing import Any

import numpy as np
import pycoral.utils.edgetpu as _pycoral


def get_device_id(preferred: str = None) -> str:
    """Return target device for running inference.

    :param str preferred: prefered device id.
    If not found, use CPU. If not specified, use any.
    Choices are: "usb", "pci", "none".
    """
    available = _pycoral.list_edge_tpus()
    if len(available) == 0 or preferred == 'none':
        return 'none'  # No Coral available
    elif preferred is None:
        return preferred  # Select any device
    for dev in available:
        if dev['type'] == preferred:
            # Preferred is available
            return dev['type']
    return 'none'


def make_interpreter(model_path: str,
                     device: str = None) -> Any:
    """Create a TFLite interpreter for model.

    :param str model_path: path to model.
    :param str device: specify device to use (for Coral devices).
        Choices are: "usb", "pci", "none". If not specified,
        select any, if available. Defaults to None.
    """
    if get_device_id(device) != 'none':
        # Force using pycoral
        i = _pycoral.make_interpreter(model_path)
    else:
        # Use normal tflite Interpreter
        tflite = importlib.import_module(  # ImportError
            'tflite_runtime.interpreter')
        i = tflite.Interpreter(model_path)
    print(f'Using model from {model_path}')
    i.allocate_tensors()
    return i


class MovenetDetector:
    """MovenetDetector

    It wraps a tflite.Interpreter loaded
    with a MoveNet model.
    """

    def __init__(self, lightning: bool = True,
                 device: str = None) -> None:
        """Create a MoveNet interpreter

        :param bool lightning: use lightning variant, defaults to True
        :param str device: specify device to use (for Coral devices).
            Choices are: "usb", "pci", "none". If not specified,
            select any, if available. Defaults to None.
        """
        self.model_path = self.get_model(
            lightning, device)
        self.interpreter = make_interpreter(
            self.model_path, device)

        self._input_idx = self.__get_detail_by_idx('index')
        self._output_idx = self.__get_detail_by_idx(
            'index', is_input=False)
        self._input_height, self._input_width = self.__get_detail_by_idx(
            'shape')[1:3]
        self._input_dtype = self.__get_detail_by_idx('dtype')

    def __get_detail_by_idx(self, key: str, idx: int = 0,
                            is_input: bool = True) -> Any:
        if is_input:
            return self.interpreter.get_input_details()[idx][key]
        return self.interpreter.get_output_details()[idx][key]

    def _preinvoke(self, image: np.ndarray) -> np.ndarray:
        """Transform input into tensor."""
        # need a new array because source image keeps aspect ratio, so
        # a 16:9 frame must be put inside a 1:1; we need to add
        # padding with zeroes (i.e a black border)
        h, w = (int(x) for x in image.shape[:2])
        retval = np.zeros((1, self._input_height, self._input_width, 3))
        retval[0, :h, :w] = image
        return retval.astype(self._input_dtype)

    def _invoke(self, data_in: np.ndarray) -> np.ndarray:
        """Invoke interpreter."""
        self.interpreter.set_tensor(
            self._input_idx, data_in)
        self.interpreter.invoke()
        return self.interpreter.get_tensor(
            self._output_idx)

    def _postinvoke(self, data_out: np.ndarray,
                    ratio: float) -> list:
        """Transform output tensor data to a
        list of keypoints (x, y, score)."""
        ret = []
        for y, x, score in data_out[0][0]:
            ret.append((int(x*ratio), int(y*ratio),
                        float(score)))
        return ret

    def run(self, image: np.ndarray, target_size: tuple) -> list:
        """Run detector over image and return result."""
        data_in = self._preinvoke(image)
        data_out = self._invoke(data_in)
        return self._postinvoke(
            data_out, ratio=max(target_size))

    @staticmethod
    def get_model(lightning: bool = True,
                  device: str = None) -> str:
        """Get MoveNet model file.
        If device is a Coral Dev Board, it is forced to
        look up for the Coral modified version of MoveNet.

        :param bool lightning: use lightning variant, defaults to True
        :param str device: specify device to use (for Coral devices).
            Choices are: "usb", "pci", "none". If not specified,
            select any, if available. Defaults to None.
        """
        variant = 'lightning' if lightning else 'thunder'
        filename = 'movenet_{}{}.tflite'.format(
            variant, '' if get_device_id(device) == 'none' else '_coral')
        local_uri = os.path.join(
            '/usr/share/hpose', filename)
        if not os.path.exists(local_uri):
            raise FileNotFoundError(
                f'File {local_uri} not found. Reinstall package!')
        return local_uri
