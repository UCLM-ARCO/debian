#!/usr/bin/python3

import os
import math
import copy
import pickle
import collections
import threading
import time
import dropbox
import datetime
from enum import Enum
from metamotion import MetaMotion, ConnectionError
import statistics
from scipy.fftpack import fft
import logging


class STATUS(Enum):
    SAMPLING = 0
    POST_PEAK = 1
    POST_FALL = 2
    FALL_DETECTED = 3

class Features:
    __slots__ = (
        'acc_mean',
        'acc_stdev',
        'acc_y_mean',
        'acc_z_mean',
        'rot_y_mean',
        'rot_z_mean',
        'fall_time',
        'pitch',
        'roll',
        'yaw',
        'acc_y_stdev',
        'acc_z_stdev',
        'rot_y_stdev',
        'rot_z_stdev',
        'acc_max_coef_fourier',
        'rot_max_coef_fourier',
    )
 

RawData = collections.namedtuple('RawData', 'acceleration rotation orientation')

class Algorithm:
    def __init__(self, collector, fsm, extractor, predictor, dropbox, file_writer):
        self.collector = collector
        self.fsm = fsm
        self.extractor = extractor
        self.predictor = predictor
        self.dropbox = dropbox
        self.file_writer = file_writer

    def loop(self):
        self.collector.connect()
        self.collector.configure_fsm(self.fsm)
        while True:
            try:
                self.fsm.wait_for_movement()
                data = self.fsm.get_data()
                logging.info("A possible fall has been detected")
                features = self.extractor.extract_features(data.acceleration, data.rotation, data.orientation)
                prediction = self.predictor.predict(features)
                self.file_writer.save_data_on_file(data, prediction, self.collector.get_mac_sensor())
                try:
                    self.dropbox.sync_with_remote()
                except Exception:
                    logging.info("Error connecting to dropbox")
            except KeyboardInterrupt:
                break


class Utilities:
    @staticmethod
    def module(data):
        return math.sqrt(
            math.pow(data.x, 2) + math.pow(data.y, 2) + math.pow(data.z, 2))
    
    @staticmethod
    def module_components(x, y, z):
        return math.sqrt(
            math.pow(x, 2) + math.pow(y, 2) + math.pow(z, 2))


class DataCollector:
    def __init__(self):
        self.sensor = MetaMotion(MetaMotion.scan_metamotion_sensor()[0])

        self.acceleration = 0
        self.rotation = 0
        self.orientation = 0
        self.timestamp = 0
        self.new_data = False
        self.fsm = None

    def connect(self):
        logging.info("Connecting to sensor...")
        self.sensor.on_disconnect(self.connect)
        not_connected = True
        while not_connected:
            try:
                self.sensor.connect()
                self.sensor.setup_accelerometer(freq=100)
                self.sensor.setup_gyroscope(freq=100)
                self.sensor.setup_fusion_sensor()
                self.sensor.accelerometer.on_acceleration(self.acc_handler)
                self.sensor.gyroscope.on_rotation(self.gyro_handler)
                self.sensor.fusion_sensor.on_orientation(self.orientation_handler)
                logging.info("Connected to sensor ", self.sensor.mac)
                not_connected = False
            except ConnectionError:
                time.sleep(2)
                print("Retrying connection") 

    def configure_fsm(self, fsm):
        self.fsm = fsm

    # def subscribe_data(self):
    #     self.sensor.accelerometer.on_acceleration(
    #         self.acc_handler)
    #     self.sensor.gyroscope.on_rotation(
    #         self.gyro_handler)
    #     self.sensor.fusion_sensor.on_orientation(self.orientation_handler)

    def disconnect(self):
        self.sensor.disconnect()

    def wait(self):
        self.sensor.wait_until_break()

    def gyro_handler(self, data, timestamp):
        self.rotation = (copy.copy(data), timestamp)
        self.timestamp = timestamp

        if self.fsm is not None:
            self.fsm.main(self.acc_module, self.get_data(), timestamp)

    def acc_handler(self, data, timestamp):
        self.acc_module = Utilities.module(data)
        self.acceleration = (copy.copy(data), timestamp)
    
    def orientation_handler(self, data):
        self.orientation = copy.copy(data)

    def data_is_updated(self):
        return self.new_data

    def get_acc_module(self):
        return self.acc_module

    def get_data(self):
        return RawData(
            acceleration=self.acceleration, 
            rotation=self.rotation, 
            orientation=self.orientation)

    def get_timestamp(self):
        return self.timestamp

    def get_mac_sensor(self):
        return self.sensor.mac

class FSM:
    def __init__(self):
        self.status = STATUS.SAMPLING 
        self.threshold = 2.5
        self.timer = 0
        self.accelerations = []
        self.rotations = []
        self.orientations = []
        self.movement_detected = threading.Event()  

    def main(self, acc_module, raw_data, timestamp):

        if self.status == STATUS.SAMPLING:
            self.sampling_state(acc_module, timestamp)

        if self.status == STATUS.POST_PEAK:
            self.post_peak_state(acc_module, raw_data, timestamp)

        if self.status == STATUS.POST_FALL:
            self.post_fall_state(acc_module, timestamp)
        
    def sampling_state(self, acc_module, timestamp):
        if acc_module > self.threshold:
            self.status = STATUS.POST_PEAK
            self.timer = timestamp + 1000

    def post_peak_state(self, acc_module, raw_data, timestamp):
        self.accelerations.append(raw_data.acceleration)
        self.rotations.append(raw_data.rotation)
        self.orientations.append(raw_data.orientation)

        if timestamp > self.timer:
            self.timer = timestamp + 1500
            self.status = STATUS.POST_FALL

    def post_fall_state(self, acc_module, timestamp):
        if acc_module > self.threshold:
            self.status = STATUS.POST_PEAK
            self.clean_saved_data()

        if timestamp > self.timer:
            #Check is ADL
            self.status = STATUS.SAMPLING
            self.movement_detected.set()

    def wait_for_movement(self):
        self.movement_detected.wait()
        self.movement_detected.clear()

    def get_data(self):
        data = RawData(
            acceleration=copy.copy(self.accelerations), 
            rotation=copy.copy(self.rotations), 
            orientation=copy.copy(self.orientations))
        self.clean_saved_data()
        return data

    def clean_saved_data(self):
        del self.accelerations[:]
        del self.rotations[:]
        del self.orientations[:]


class FeatureExtractor:
    def __init__(self):
        self.index_1_5 = 0

    def extract_features(self, accelerations, rotations, orientations):
        features = Features()

        acc_measures = [a[0] for a in accelerations]
        rot_measures = [a[0] for a in rotations]
        rot_timestamps = [a[1] for a in rotations]

        accs_y = [a[0].y for a in accelerations]
        accs_z = [a[0].z for a in accelerations]
        rots_y = [a[0].y for a in rotations]
        rots_z = [a[0].z for a in rotations]

        acc_modules = list(map(Utilities.module, acc_measures))
        rot_modules = list(map(Utilities.module, rot_measures))

        self.update_acceleration_related_features(
            acc_modules, accs_y, accs_z, rot_timestamps, features)
        self.update_rotations_related_features(
            rot_modules, rots_y, rots_z, features)

        features.pitch = orientations[-1].pitch
        features.roll = orientations[-1].roll
        features.yaw = orientations[-1].yaw
    
        return features

    def update_acceleration_related_features(self, acc_modules, accs_y, accs_z, rot_timestamps, features):
        features.acc_mean = sum(acc_modules)/len(acc_modules)
        # self.max_acc = max(acc_modules)
        features.acc_stdev = statistics.stdev(acc_modules)
        features.acc_y_mean = sum(accs_y)/len(accs_y)
        features.acc_z_mean = sum(accs_z)/len(accs_z)
        features.acc_y_stdev = statistics.stdev(accs_y)
        features.acc_z_stdev = statistics.stdev(accs_z)
        last_acc_greater_1_5 = self.get_last_1_5_acc(acc_modules)
        t1 = rot_timestamps[self.index_1_5]
        t0 =  rot_timestamps[0]
        features.fall_time = t1 - t0
        fourier_accs = fft(acc_modules)
        features.acc_max_coef_fourier = max([Utilities.module_components(coef.real, coef.imag, 0) for coef in fourier_accs])

    def update_rotations_related_features(self, rot_modules, rots_y, rots_z, features):
        features.rot_y_mean = sum(rots_y)/len(rots_y)
        features.rot_z_mean = sum(rots_z)/len(rots_z)
        features.rot_y_stdev = statistics.stdev(rots_y)
        features.rot_z_stdev = statistics.stdev(rots_z)
        fourier_rots = fft(rot_modules)
        features.rot_max_coef_fourier = max([Utilities.module_components(coef.real, coef.imag, 0) for coef in fourier_rots])

    def get_last_1_5_acc(self, accelerations):
        self.index_1_5 = 0
        accelerations.reverse()
        last_acc = None
        for a in accelerations:
            self.index_1_5 += 1
            if a >= 1.5:
                last_acc = a
                break
        accelerations.reverse()
        self.index_1_5 = len(accelerations) - self.index_1_5
        return last_acc


class Predictor:
    def __init__(self, model_file, scaler):
        self.model = pickle.load(open(model_file, 'rb'))
        self.scaler = pickle.load(open(scaler, 'rb'))    

    def predict(self, features):
        data = self.package_features(features)
        data_scaled = self.scaler.transform(data)
        self.fall_detected = self.model.predict(data_scaled)[0]
        print("La predicción es ", self.fall_detected) 
        return self.fall_detected

    def package_features(self, features):
        data = [[
            features.acc_mean,
            features.acc_stdev,
            features.acc_y_mean,
            features.acc_z_mean,
            features.rot_y_mean,
            features.rot_z_mean,
            features.fall_time,
            features.pitch,
            features.roll,
            features.yaw,
            features.acc_y_stdev,
            features.acc_z_stdev,
            features.rot_y_stdev,
            features.rot_z_stdev,
            features.acc_max_coef_fourier,
            features.rot_max_coef_fourier,
        ]]
        return data


class DataParser:
    def get_features_stringified(self, features, prediction):
        keys = ', '.join(features.__slots__)
        keys = keys.replace(' ', '')
        keys += ',fall'
        
        values = ""
        values += str(features.acc_mean) + ','
        values += str(features.acc_stdev) + ','
        values += str(features.acc_y_mean) + ','
        values += str(features.acc_z_mean) + ','
        values += str(features.rot_y_mean) + ','
        values += str(features.rot_z_mean) + ','
        values += str(features.fall_time) + ','
        values += str(features.pitch) + ','
        values += str(features.roll) + ','
        values += str(features.yaw) + ','
        values += str(features.acc_y_stdev) + ','
        values += str(features.acc_z_stdev) + ','
        values += str(features.rot_y_stdev) + ','
        values += str(features.rot_z_stdev) + ','
        values += str(features.acc_max_coef_fourier) + ','
        values += str(features.rot_max_coef_fourier) + ','
        values += str(prediction)

        features_str = keys + '\n' + values

        return features_str

    def get_data_stringified(self, data, prediction):
        data_str = ""
        data_str += "acceleration_x" + ","
        data_str += "acceleration_y" + ","
        data_str += "acceleration_z" + ","
        data_str += "rotation_x" + ","
        data_str += "rotation_y" + ","
        data_str += "rotation_z" + ","
        data_str += "pitch" + ","
        data_str += "roll" + ","
        data_str += "yaw" + ","
        data_str += "timestamp" + ","
        data_str += "fall"
        data_str += '\n'

        for i in range(len(data.acceleration)):
            data_str += str(data.acceleration[i][0].x) + ","
            data_str += str(data.acceleration[i][0].y) + ","
            data_str += str(data.acceleration[i][0].z) + ","
            data_str += str(data.rotation[i][0].x) + ","
            data_str += str(data.rotation[i][0].y) + ","
            data_str += str(data.rotation[i][0].z) + ","
            data_str += str(data.orientation[i].pitch) + ","
            data_str += str(data.orientation[i].roll) + ","
            data_str += str(data.orientation[i].yaw) + ","
            data_str += str(data.rotation[i][1]) + ","
            data_str += str(prediction)
            data_str += "\n"

        return data_str    


class DropboxUpdater:
    def __init__(self, parser, path):
        self.token = "5ytwqpdlA4UAAAAAAAAAAXI2WA5DelWmh59RC1Brt3FAYyfNVmJY4eio_MvGCbfd"
        self.dbx = dropbox.Dropbox(oauth2_access_token=self.token)
        self.parser = parser
        self.path = path

    def publish_features(self, features, prediction, sensor_mac):
        file_content = self.parser.get_features_stringified(features, prediction)
        self.update_string_to_file(file_content, sensor_mac)

    def publish_data(self, data, sensor_mac):
        file_content = self.parser.get_data_stringified(data)
        self.update_string_to_file(file_content, sensor_mac)

    def update_string_to_file(self, file_content, sensor_mac):
        if not self.folder_exist(sensor_mac):
            self.create_folder(sensor_mac)

        date = datetime.datetime.now()
        name_file = "/" + sensor_mac + "/" + date.strftime("%Y-%b-%d_%H:%M:%S") + ".csv"
        self.dbx.files_upload(file_content.encode(), name_file)

    def sync_with_remote(self):
        abs_path = os.path.expanduser(self.path)

        sensors_dirs = os.listdir(abs_path)

        for data_dir in sensors_dirs:
            if not self.folder_exist(data_dir):
                self.create_folder(data_dir)
            self.publish_dir(data_dir, abs_path + data_dir)

    def publish_dir(self, dir_name, dir_path):
        data_files_list = os.listdir(dir_path) 
        
        for file in data_files_list:
            file_path = dir_path + "/" + file
            fd = open(file_path, 'r')
            content = fd.read()
            self.dbx.files_upload(content.encode(), "/" + dir_name + "/" + file)

    def create_folder(self, directory):
        self.dbx.files_create_folder("/" + directory)

    def folder_exist(self, directory):
        folder_list = self.dbx.files_list_folder("")
        folder_list = list(map(lambda item: item.name, folder_list.entries))
        return directory in folder_list
        

class FileWriter:
    def __init__(self, parser, path):
        self.parser = parser
        self.files_dir = path
    
    def save_data_on_file(self, data, prediction, sensor_mac):
        path = self.files_dir + sensor_mac
        full_path = os.path.expanduser(path)

        if not self.folder_exist(full_path):
            self.create_folder(full_path)

        date = datetime.datetime.now()
        name_file = "/" + date.strftime("%Y-%b-%d_%H:%M:%S") + ".csv"
        filename = full_path + name_file
        file_content = self.parser.get_data_stringified(data, prediction)

        with open(filename, mode='a+') as file:
            file.write(file_content)

    def folder_exist(self, path):
        return os.path.exists(path)

    def create_folder(self, path):
        os.makedirs(path)


if __name__ == '__main__':
    collector = DataCollector()
    fsm = FSM()
    alg = Algorithm(
        collector, 
        fsm, 
        FeatureExtractor(), 
        Predictor("/usr/share/fall-detector/model.sav", "/usr/share/fall-detector/scaler"), 
        DropboxUpdater(DataParser(), "~/fall-detector/"),
        FileWriter(DataParser(),"~/fall-detector/"))

    alg.loop()