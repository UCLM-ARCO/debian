# fall-detection-service

This is a real time service for monitoring the movements of a user in order to detect falls

## Installation

```shell
$ sudo apt-get install fall-detection-service
```

## Use

In order to use this service you need to meet the following requirements:

1. Install the python3 packages scikit-learn(0.23.2), bleak and metawear.
2. Install the package metamotion.
3. Having a MetamotionR sensor, device which is used for this service to detect falls. This device must be located in the waist of the user.
