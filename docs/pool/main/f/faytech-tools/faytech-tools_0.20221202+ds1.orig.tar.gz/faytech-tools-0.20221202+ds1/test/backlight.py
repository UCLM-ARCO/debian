#!/usr/bin/env python3

import sys
import serial

s = serial.Serial("/dev/ttyUSB0", 19200) 

cmd = 0xb0 + int(sys.argv[1])
s.write([cmd])
s.flush()
