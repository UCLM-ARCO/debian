"""
File: faytech-backlight-manager.py
Description:
 Control Faytech mirror backlight to turn off when 
 screen blanking is activated, and do otherwise 
 if is deactivated.
"""
import logging
import os
import signal
import sys
from shutil import which
from subprocess import Popen, TimeoutExpired
from time import sleep

logging.basicConfig(format='%(name)s %(levelname)s: %(message)s')
LOG = logging.getLogger('MANAGER')
LOG.setLevel(logging.INFO)


class BacklightManager:
    def __init__(self) -> None:
        # Initial checks
        for prog in ('xsshook', 'backlight-on', 'backlight-off'):
            if which(prog) is None:
                raise RuntimeError(
                    f'Script {prog} not found. Exit.')

        # Get arguments from environment
        #   passed to the running service
        self.cmd_kwargs = {}
        for key in ('device_dir', 'device_id', 'baudrate'):
            value = os.environ.get(
                f'faytech_default_{key}'.upper(), None)
            if value is not None:
                self.cmd_kwargs[f'--{key}'] = value

        # Set children arguments
        self.children_args = []
        self.children_env = {'DISPLAY': os.environ.get('DISPLAY')}
        for status in ('on', 'off'):
            cmd = '{xsshook} {event} {script}'.format(
                xsshook=which('xsshook'),
                event='start' if status == 'off' else 'stop',
                script=which(f'backlight-{status}'))
            if len(self.cmd_kwargs.keys()) > 0:
                cmd += ' ' + ' '.join(
                    f'{k} {v}' for k, v in self.cmd_kwargs.items())
            self.children_args.append(cmd.split())

        LOG.debug('DISPLAY={}'.format(os.environ.get('DISPLAY')))
        LOG.debug(' '.join(self.children_args[0]))
        LOG.debug(' '.join(self.children_args[1]))

        self.children = [None, None]  # Children (on, off)
        self.__is_alive = True

    def is_alive(self) -> bool:
        return self.__is_alive

    def stop(self) -> None:
        LOG.warning('Stopping...')
        self.__is_alive = False

    def stop_with_signal(self, signum, _) -> None:
        LOG.warning(f'Signal received: {signum}')
        self.stop()

    def set_child(self, is_on: bool = True) -> None:
        idx = 0 if is_on else 1
        self.children[idx] = Popen(
            args=self.children_args[idx],
            env=self.children_env)

    def get_child(self, is_on: bool = True) -> Popen:
        idx = 0 if is_on else 1
        c = self.children[idx]
        if c is None:
            # Create child
            self.set_child(is_on)
        elif c.poll() is not None:
            # Restart child if terminated
            self.set_child(is_on)
        return self.children[idx]

    def finish(self) -> None:
        LOG.warning('Finishing...')
        for c in self.children:
            if c.poll() is not None:  # Has terminated
                continue
            for sig in (signal.SIGINT, signal.SIGQUIT):
                # Try gracefull exit
                try:
                    c.send_signal(sig)
                    c.wait(1)
                except TimeoutExpired:
                    pass
            try:  # Force
                c.terminate()
                c.wait(1)
            except TimeoutExpired:
                c.kill()  # Kill

    def run(self, timeout: int = 10) -> int:
        LOG.info('Running...')
        errcnt = 0
        while self.__is_alive and errcnt < 10:
            try:
                LOG.debug('Checking children status...')
                self.get_child(is_on=True)
                self.get_child(is_on=False)
                LOG.debug('Done.')
                sleep(timeout)
            except Exception as err:
                LOG.warning(err)
                LOG.warning(
                    f'Stopping in {10-errcnt} more errors...')
                errcnt += 1
        self.finish()


if __name__ == '__main__':
    retcode = 0
    try:
        m = BacklightManager()
        # Set signal traps (systemctl normal kills)
        signal.signal(signal.SIGTERM, m.stop_with_signal)
        # Run
        m.run()
    except KeyboardInterrupt:
        pass
    except Exception as err:
        LOG.critical(err)
        retcode = 1
    finally:
        sys.exit(retcode)
