import logging
import os.path
import sys
from argparse import ArgumentParser
from glob import glob

from serial import Serial

logging.basicConfig(format='%(name)s %(levelname)s: %(message)s')
LOG = logging.getLogger('BACKLIGHT DEVICE')
LOG.setLevel(logging.INFO)


def search_device(device_dir: str = '/dev/serial/by-id',
                  device_id: str = 'FTDI_FT230X') -> str:
    matches = glob(os.path.join(device_dir, f'*{device_id}*'))
    if len(matches) == 0:
        raise RuntimeError(
            f'Could not find backlight device in {device_dir}')
    elif len(matches) > 1:
        LOG.warning(
            'Found more than one backlight devices ' +
            f'in {device_dir} when searching for "{device_id}"')
    return matches[0]


def main(device_dir: str, device_id: str,
         baudrate: int, turn_on: bool) -> int:
    err = None
    comm = None
    try:
        device_path = search_device(device_dir, device_id)
        comm = Serial(device_path, baudrate, timeout=1)
        comm.write([0xb7 if turn_on else 0xb0])
        comm.flush()
    except Exception as _err:
        err = _err
    finally:
        if comm is not None:
            comm.close()
    if err is not None:  # Delegate
        raise err


if __name__ == '__main__':
    p = ArgumentParser(
        description='Control Faytech mirror backlight.')
    p.add_argument(
        '-D', '--device-dir', default='/dev/serial/by-id',
        help='Directory where it is the backlight serial device. ' +
        'Defaults to /dev/serial/by-id')
    p.add_argument(
        '-d', '--device-id', default='FTDI_FT230X',
        help='Device identification string. ' +
        'Default is FTDI_FT230X.')
    p.add_argument(
        '-b', '--baudrate', type=int, default=19200,
        help='Serial communication baudrate. ' +
        f'Default is 19200.')
    state_grp = p.add_mutually_exclusive_group(required=True)
    state_grp.add_argument(
        '--on', dest='turn_on', action='store_true',
        help='Turn on the backlight.')
    state_grp.add_argument(
        '--off', dest='turn_on', action='store_false',
        help='Turn off the backlight.')

    args = p.parse_args()
    try:
        retcode = main(**vars(args))
    except Exception as err:
        LOG.critical(err)
        retcode = 1
    else:
        LOG.info('Backlight is now: {}'.format(
            'on' if args.turn_on else 'off'))
    finally:
        sys.exit(retcode)
