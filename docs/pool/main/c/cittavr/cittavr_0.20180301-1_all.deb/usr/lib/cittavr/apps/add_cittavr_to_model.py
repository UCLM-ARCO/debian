# -*- mode: python; coding: utf-8 -*-

import os
import bpy

from cittavr import logger


def model_is_cittavr_ready(scene):
    return bpy.data.objects.get("CittaVRApp") is not None


def add_cittavr_support(scene, prj_dir):
    add_server(scene)
    save_scene(scene, prj_dir)


def add_server(scene):
    pwd = os.path.abspath(os.path.dirname(__file__))
    assets_dir = os.path.join(pwd, "../assets")
    if not os.path.isdir(assets_dir):
        assets_dir = "/usr/share/cittavr/assets"

    asset_blend = os.path.join(assets_dir, "constructor.blend")
    if not os.path.exists(asset_blend):
        logger.error("Could not find asset: '{}'".format(asset_blend))

    logger.info("Loading assets from '{}'".format(asset_blend))
    with bpy.data.libraries.load(asset_blend) as (data_from, data_to):
        data_to.objects = ['CittaVRApp']

    scene.objects.link(data_to.objects[0])
    scene.update()


def save_scene(scene, prj_dir):
    path = os.path.join(prj_dir, "model.blend")
    logger.info("Saving model to '{}'".format(path))

    scene.game_settings.material_mode = 'GLSL'
    bpy.ops.wm.save_as_mainfile(filepath=path, relative_remap=False)


if __name__ == "__main__":
    prj_dir = os.environ.get("CITTA_PROJECT_DIR", ".")
    scene = bpy.context.scene

    if model_is_cittavr_ready(scene):
        logger.info("Support for CittaVR already added.")
    else:
        add_cittavr_support(scene, prj_dir)
