# -*- mode: python; coding: utf-8; tab-width: 4 -*-

import sys
import os
import Ice
import bpy
import bge
import math
import itertools
from importlib import import_module

from cittavr import PLUGINS_DIR, logger
from cittavr.transverse_mercator import TransverseMercator
from cittavr.work_queue import WorkQueue
from cittavr.qr_codes import generate_qr
from cittavr.slice import CittaVRSlice, IDM


# list of already registered plugins
plugins = {}


def get_router(ic):
    router_proxy = ic.propertyToProxy("IDM.Router.Proxy")
    try:
        return IDM.NeighborDiscovery.ListenerPrx.checkedCast(router_proxy)
    except Ice.Exception as e:
        logger.error("IDM router is not available ({})".format(e))
        return None


class CittaVRServiceI(CittaVRSlice.CittaVRService):
    def __init__(self, ic, adapter):
        self.ic = ic
        self.adapter = adapter

        self.work_queue = WorkQueue()

        starting_addr = int(ic.getProperties().getProperty("CittaVR.Id"), 16) + 1
        self.address_gen = iter(itertools.count(starting_addr))
        self.objects = {}
        self.router = get_router(self.ic)

    def placePhysicalMeters_async(
            self, cb, name, prototype, location, rotation, current):

        args = (name, prototype, location, rotation)
        self.work_queue.add(cb, self._place_physical_meters, *args)

    def placePhysicalCoordinates_async(
            self, cb, name, prototype, location, rotation, current):

        args = (name, prototype, location, rotation)
        self.work_queue.add(cb, self._place_physical_coordinates, *args)

    # FIXME: get from citisim_id property
    def getPhysicalObjectNames(self, current):
        return [str(name) for name in self.objects.keys()]

    # FIXME: to implement!
    def moveObject(self, name, location, rotation, current):
        pass

    # FIXME: to implement!
    def deleteObject(self, name, current):
        pass

    def _place_physical_coordinates(self, name, prototype, location, rotation):
        scene = bpy.context.scene
        projection = TransverseMercator(lat=scene["latitude"], lon=scene["longitude"])
        location.x, location.y = projection.fromGeographic(
            float(location.x), float(location.y))

        self._place_physical_meters(name, prototype, location, rotation)

    def _place_physical_meters(self, name, prototype, location, rotation):
        if name in self.objects:
            logger.warning("Physical with id '{}' already added!".format(name))
            return

        idm_address = hex(self.address_gen.__next__()).upper()[2:]
        scene = bge.logic.getCurrentScene()

        # load asset from external file (if not already loaded)
        blend_path = os.path.join(PLUGINS_DIR, prototype, 'model.blend')
        if blend_path not in bge.logic.LibList():
            bge.logic.LibLoad(blend_path, "Scene", async=False)

            plugin = import_module(prototype)
            try:
                plugin.register()
            except AttributeError:
                logger.error("Invalid plugin for asset '{}'".format(prototype))
                return

        # add object from template and set it up
        obj = scene.addObject(prototype)
        obj['citisim_id'] = name
        self.objects[name] = obj

        # create a QR code for this object
        qr_codes = bpy.path.abspath("//qr_codes")
        generate_qr(idm_address, dir=qr_codes)
        obj['idm_address'] = idm_address

        # set new object position and rotation
        orientation = obj.worldOrientation.to_euler()
        orientation.z = -(float(rotation) * (math.pi / 180.0))
        obj.worldOrientation = orientation
        obj.worldPosition = [location.x, location.y, location.z]

        # add Ice servant for this object
        self._create_physical_servant(obj, prototype, self.work_queue)

        logger.info("Physical '{}' added".format(name))

    def _create_physical_servant(self, obj, prototype, work_queue):
        servant_class = plugins[prototype]
        servant = servant_class(obj, self.router, work_queue)
        oid = self.ic.stringToIdentity(obj['idm_address'])
        proxy = self.adapter.add(servant, oid)

        logger.info("Servant proxy: '{}'".format(proxy))
        if self.router:
            self.router.adv(self.ic.proxyToString(proxy))
        obj['servant'] = servant


class Server:
    def __init__(self):
        config_file = bpy.path.abspath("//cittavr.config")
        args = [sys.argv[0], '--Ice.Config=' + config_file]

        ic = Ice.initialize(args)
        adapter = ic.createObjectAdapter("CittaVR.Adapter")
        adapter.activate()

        self.servant = CittaVRServiceI(ic, adapter)
        oid = ic.getProperties().getProperty("CittaVR.Id")
        oid = ic.stringToIdentity(oid)
        proxy = adapter.add(self.servant, oid)

        router = get_router(ic)
        if router:
            router.adv(ic.proxyToString(proxy))
        logger.info("CittaVR Service proxy: " + str(proxy))

        # add a handler to destroy this communicator when BGE stops
        def on_bge_stop(scene):
            ic.shutdown()
            ic.destroy()
            bpy.app.handlers.game_post.remove(on_bge_stop)

        bpy.app.handlers.game_post.append(on_bge_stop)
