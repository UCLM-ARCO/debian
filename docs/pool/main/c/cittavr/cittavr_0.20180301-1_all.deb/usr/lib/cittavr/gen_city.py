#!/usr/bin/python3 -u
# -*- mode:python; coding:utf-8; tab-width:4 -*-

import sys
import os
import argparse
import bpy
import bmesh
from mathutils import Vector

from cittavr.import_objects import appendQRCamera, add_constructor, add_assets
from cittavr.materials import addMaterials


def saveBlend(scene, blend_path):
    scene.game_settings.material_mode = 'GLSL'
    setViewportShading()
    bpy.ops.wm.save_as_mainfile(filepath=blend_path)


def setViewportShading():
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    space.viewport_shade = 'MATERIAL'


def clean_scene(scene):
    for ob in scene.objects:
        if ob.type == 'CAMERA' or ob.type == 'LAMP' or ob.type == 'MESH':
            ob.select = True
    bpy.ops.object.delete()


def importOSMFile(osm_file, scene):
    bpy.ops.import_scene.osm(filepath=osm_file,
                             ignoreGeoreferencing=False,
                             singleMesh=False,
                             importBuildings=False,
                             importHighways=True,
                             thickness=14)

    highways = bpy.context.object
    highways.name = 'highways'

    bpy.ops.import_scene.osm(filepath=osm_file,
                             ignoreGeoreferencing=False,
                             singleMesh=True,
                             importBuildings=True,
                             importHighways=False,
                             thickness=14)

    buildings = bpy.context.object
    buildings.name = 'buildings'
    return buildings


def scaleCity(scene):
    scale = 1

    for ob in scene.objects:
        if ob.type == 'MESH':
            ob.select = True

            if ob.name == 'buildings':
                scale = getRenderScale(ob.dimensions.xyz)

    bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')

    con = bpy.context
    obs_sel = con.selected_objects

    if len(obs_sel) > 0:
        bpy.ops.transform.resize(
            value=(scale, scale, scale),
            constraint_axis=(True, True, True),
            constraint_orientation='GLOBAL',
            mirror=False, proportional='DISABLED',
            proportional_edit_falloff='SMOOTH',
            proportional_size=1)


def getRenderScale(dimensions):
    finalDimensions = Vector((79, 60, 0))
    axis = 0

    if (dimensions[0] > finalDimensions[0] or
            dimensions[1] > finalDimensions[1]):
        if dimensions[0] < dimensions[1]:
            axis = 1

        scale = finalDimensions[axis] / dimensions[axis]
        return scale


def createLamp(name, lamptype, location, scene):
    lamp_data = bpy.data.lamps.new(name=name, type=lamptype)
    lamp = bpy.data.objects.new(name=name, object_data=lamp_data)
    lamp.location = location
    scene.objects.link(lamp)


def addTrackToConstraint(ob, name, target):
    cns = ob.constraints.new('TRACK_TO')
    cns.name = name
    cns.target = target
    cns.track_axis = 'TRACK_NEGATIVE_Z'
    cns.up_axis = 'UP_Y'
    cns.owner_space = 'WORLD'
    cns.target_space = 'WORLD'
    return


def addCamera(origin, target, scene):
    appendQRCamera()
    camera = bpy.data.objects["cittavr_camera"]
    QR_plane = bpy.data.objects["qr_plane"]
    camera_data = camera.data

    addTrackToConstraint(camera, 'TrackMiddle', target)
    camera.location = origin
    QR_plane.location = Vector((-0.15097, -0.07094, -0.40309))

    camera_data.clip_start = 0.001
    camera_data.clip_end = 3000.0

    scn = bpy.context.scene
    scn.camera = camera

    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            area.spaces[0].region_3d.view_perspective = 'CAMERA'
            break


def renderImages(scene, resolution, renders_directory):
    scene.render.filepath = renders_directory
    scene.render.resolution_percentage = int(resolution)
    bpy.ops.render.render(write_still=True)


def createHighways(highways_hierarchy, scene):
    bpy.ops.object.select_all(action='DESELECT')

    for highway in highways_hierarchy.children:
        highway.select = True
        bpy.context.scene.objects.active = highway

        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.mode_set(mode='EDIT')

        mesh = bmesh.from_edit_mesh(bpy.context.object.data)
        for vertex in mesh.edges:
            vertex.select = True

        bpy.ops.mesh.offset_edges(geometry_mode='extrude', width=5.3,
                                  caches_valid=False)
        bpy.ops.object.origin_set(type='GEOMETRY_ORIGIN')
        bpy.ops.object.mode_set(mode='OBJECT')

        highway.select = False


def addRoute(path, scene):
    bpy.ops.import_scene.osm(filepath=path,
                             ignoreGeoreferencing=False,
                             singleMesh=False,
                             importBuildings=False,
                             importHighways=True,
                             thickness=14)

    route = bpy.context.object
    route.name = 'route'
    route.location.z = route.location.z + 1

    createHighways(bpy.data.objects['route'], scene)


def get_parser():
    parser = argparse.ArgumentParser(
        prog="blender --background --python {} --".format(__file__),
        description="Generate a 3D city model, with some objects, to" +
                    "validate Smart City services")

    parser.add_argument('file', help="Map file name")
    parser.add_argument('mode', choices=["simulator", "monitor"],
                        help="Execution mode")
    parser.add_argument('-a', '--auto-start', action='store_true',
                        help="Start simulation automatically when the" +
                        "generates .blend is opened")
    parser.add_argument('--route', dest="route", default=None,
                        help="OSM with route data")
    parser.add_argument('--output', dest="output_name",
                        default="./model.blend",
                        help="Directory where save generated files")
    return parser


def build_model(osm_file):
    scene = bpy.context.scene
    clean_scene(scene)

    # Model construction code
    importOSMFile(args.file, scene)
    createHighways(bpy.data.objects['highways'], scene)
    addMaterials()
    createLamp('sun', 'SUN', Vector((0, 0, 8)), scene)


def is_a_osm_file(file_path):
    return (file_path.endswith('.osm') and os.path.isfile(file_path))


def is_a_blend_file(file_path):
    return (file_path.endswith('.blend') and os.path.isfile(file_path))


def open_blend_file(blend_file):
    bpy.ops.wm.open_mainfile(filepath=blend_file)


def constructor_in_scene():
    return bpy.data.objects.get("Empty")


def model_ready(scene_name):
    ready = False
    try:
        bpy.data.scenes[bpy.context.scene.name]["model_ready"]
        ready = True
    except Exception:
        print("Property 'model_ready' not found")
    return ready


def georeferencing_ready():
    ready = False
    try:
        bpy.data.scenes[bpy.context.scene.name]["latitude"]
        bpy.data.scenes[bpy.context.scene.name]["longitude"]
        ready = True
    except Exception:
        print("Georeferencing not ready. 'latitude'/'longitude' custom" +
              "property not found.")
    return ready


if __name__ == "__main__":
    argv = sys.argv[sys.argv.index("--") + 1:]
    parser = get_parser()
    args = parser.parse_args(argv)

    if is_a_osm_file(args.file):
        build_model(args.file)
    elif is_a_blend_file(args.file):
        open_blend_file(args.file)

    scene = bpy.context.scene
    if not model_ready(scene):
        add_constructor()
        add_assets()
        bpy.data.scenes[scene.name]["model_ready"] = True
    if not georeferencing_ready():
        bpy.data.scenes[scene.name]["latitude"] = 0.0
        bpy.data.scenes[scene.name]["longitude"] = 0.0

    scene.render.engine = 'BLENDER_GAME'
    target = bpy.context.object

    # FIXME: camera is added always in same place
    addCamera(Vector((23.25659, 49.86515, 13.8693)), target, scene)

    if args.auto_start:
        scene.game_settings.use_auto_start = True

    saveBlend(scene, './model.blend')
