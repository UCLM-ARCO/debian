#!/usr/bin/python3
# -*- coding: utf-8 -*-
"usage: set_bool <router> <idm_address> [true | false]"

import sys
import Ice

Ice.loadSlice('-I /usr/share/slice /usr/share/slice/duo/duo_idm.ice --all')
import DUO.IDM
import IDM


class Client(Ice.Application):
    def run(self, argv):
        if len(argv) != 4:
            print(__doc__)
            return 1

        ic = self.communicator()

        router = ic.stringToProxy(argv[1])
        router = IDM.NeighborDiscovery.ListenerPrx.uncheckedCast(router)

        proxy = router.ice_identity(ic.stringToIdentity(sys.argv[2]))
        proxy = DUO.IDM.IBool.WPrx.uncheckedCast(proxy)

        if not proxy:
            raise RuntimeError('Invalid proxy')

        if argv[3] == "true":
            proxy.set(True, "")
            print("Sending TRUE to {}".format(sys.argv[2]))
        else:
            proxy.set(False, "")
            print("Sending FALSE to {}".format(sys.argv[2]))

        return 0


sys.exit(Client().main(sys.argv))
