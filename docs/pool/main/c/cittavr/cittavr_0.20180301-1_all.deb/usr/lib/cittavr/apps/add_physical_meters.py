#!/usr/bin/python3 -u
# -*- mode:python; coding:utf-8; tab-width:4 -*-
"usage: add_physical <router_proxy> <citta_address> <prototype> <name> <latitude> <longitude> <north_angle>"

import sys
import Ice
from xml.etree import ElementTree

from cittavr import CITISIM_SLICE
Ice.loadSlice('-I /usr/share/slice {} --all'.format(CITISIM_SLICE))
import CitisimSlice
import DUO.IDM
import IDM


class Client(Ice.Application):
    def run(self, args):
        if len(args) != 9:
            print(__doc__)
            return 1

        broker = self.communicator()

        router = broker.stringToProxy(args[1])
        router = IDM.NeighborDiscovery.ListenerPrx.uncheckedCast(router)

        proxy = router.ice_identity(broker.stringToIdentity(args[2]))
        prototype = args[3]
        name = prototype + '-' + args[4]
        point_3d = CitisimSlice.Point3D(float(args[5]), float(args[6]),
                                        float(args[7]))
        north_angle = float(args[8])

        cittavr = CitisimSlice.CittaVRServicePrx.uncheckedCast(proxy)
        cittavr.placePhysicalMeters(name, prototype, point_3d, north_angle)


Client().main(sys.argv)
