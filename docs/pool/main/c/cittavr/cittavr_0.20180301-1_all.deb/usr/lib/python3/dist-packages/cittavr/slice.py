# -*- coding: utf-8; mode: python -*-

import os
import Ice
from commodity import path
from . import project_dir


slice_dir = os.path.join(project_dir, 'slice')
cittavr_slice = path.resolve_path(
    'cittavr.ice', [slice_dir, '/usr/share/slice/citisim'])[0]

Ice.loadSlice('-I /usr/share/slice {} --all'.format(cittavr_slice))
import CittaVRSlice
import SmartObject

Ice.loadSlice('/usr/share/slice/idm/idm.ice')
import IDM
