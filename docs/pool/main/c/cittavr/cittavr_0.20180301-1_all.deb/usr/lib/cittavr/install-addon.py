#!/usr/bin/python3
# -*- coding: utf-8; mode: python -*-

__doc__ = "blender -b -P install_addon.py -- addon.py"

import os
import sys
import bpy

addon_path = sys.argv[sys.argv.index("--") + 1:][0]
print("-- installing addon: '{}'".format(addon_path))

bpy.ops.wm.addon_install(overwrite=True, filepath=addon_path)

addon_file = os.path.split(addon_path)[1]
addon_module = os.path.splitext(addon_file)[0]
print("-- enabling addon: '{}'".format(addon_module))
bpy.ops.wm.addon_enable(module=addon_module)
