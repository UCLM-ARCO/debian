# -*- mode: python; coding: utf-8 -*-

import bge

textures = []


def change_texture(obj, path, material_id=None):
    ID = 0
    if material_id:
        ID = bge.texture.materialID(obj, material_id)

    tex = bge.texture.Texture(obj, ID)
    image = bge.texture.ImageFFmpeg(path)
    textures.append(tex)

    tex.source = image
    tex.refresh(True)
