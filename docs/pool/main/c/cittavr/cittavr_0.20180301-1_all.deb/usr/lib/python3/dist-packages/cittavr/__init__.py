# -*- coding: utf-8; mode: python -*-

import os
import logging
from copy import copy
from commodity import path


# taken (and adapted) from: https://stackoverflow.com/a/46482050/870503
class ColoredFormatter(logging.Formatter):
    def format(self, record):
        mapping = {
            'DEBUG': 37,     # white
            'INFO': 32,      # cyan
            'WARNING': 33,   # yellow
            'ERROR': 31,     # red
            'CRITICAL': 41,  # white on red bg
        }

        colored_record = copy(record)
        levelname = colored_record.levelname
        color = mapping.get(levelname, 37)
        colored_levelname = "\033[{0}m{1}\033[0m".format(color, levelname)
        colored_record.levelname = colored_levelname
        return logging.Formatter.format(self, colored_record)


# basic setup of logging
logger = logging.getLogger('CittaVR')
logger.setLevel(logging.INFO)

# add a file logger
formatter = logging.Formatter('[%(levelname)s] %(message)s')
file_handler = logging.FileHandler('/tmp/cittaVR.log', mode='w')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# add a coloured logger for console
color_formatter = ColoredFormatter("[%(levelname)s] %(message)s")
color_handler = logging.StreamHandler()
color_handler.setFormatter(color_formatter)
logger.addHandler(color_handler)

# cittavr paths and other vars
if os.path.abspath(__file__).startswith("/usr/"):
    project_dir = ''
    ASSETS_DIR = '/usr/share/cittavr/assets'
    PLUGINS_DIR = '/usr/share/cittavr/plugins'
else:
    project_dir = path.get_project_dir(__file__) or ''
    ASSETS_DIR = path.resolve_path('assets', [project_dir, '/usr/share/cittavr'])[0]
    PLUGINS_DIR = path.resolve_path('plugins', [project_dir, '/usr/share/cittavr'])[0]
