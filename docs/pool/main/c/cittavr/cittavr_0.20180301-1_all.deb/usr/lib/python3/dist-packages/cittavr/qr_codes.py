# -*- mode: python; coding: utf-8 -*-

import os
import qrcode


def generate_qr(idm_address, dir='./qr_codes'):
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(str(idm_address))
    qr.make(fit=True)
    img = qr.make_image()

    if not os.path.isdir(dir):
        os.makedirs(dir)

    img.save('{}/{}.png'.format(dir, idm_address))
