#!/usr/bin/python3 -u
# -*- mode:python; coding:utf-8; tab-width:4 -*-
"usage: add_physicals <router_proxy> <citta_address>"

import sys
import Ice
from xml.etree import ElementTree

from cittavr import CITISIM_SLICE
Ice.loadSlice('-I /usr/share/slice {} --all'.format(CITISIM_SLICE))
import CitisimSlice


def osm_node_is(node, prototype):
    return node.find('tag[@k="highway"][@v="' + prototype + '"]')


def get_north_angle(node):
    osm_direction = node.find('tag[@k="osm_direction"]')

    if osm_direction is None:
        return 0.0

    return osm_direction.attrib['v']


class Client(Ice.Application):
    def run(self, args):
        broker = self.communicator()

        router = broker.stringToProxy(args[1])
        router = IDM.NeighborDiscovery.ListenerPrx.uncheckedCast(router)

        proxy = router.ice_identity(broker.stringToIdentity(args[2]))
        self.cittavr = CitisimSlice.CittaVRServicePrx.uncheckedCast(proxy)

        self.add_physicals('street_lamp',
                           project_dir + '/examples/campus-cr/campus-cr.osm')
        self.add_physicals('loop_detector',
                           project_dir + '/examples/campus-cr/campus-cr.osm')

    def add_physicals(self, prototype, osm_path):
        tree = ElementTree.parse(osm_path)
        for node in tree.iterfind('node'):
            if osm_node_is(node, prototype) is None:
                continue

            name = '{}-{}'.format(prototype, node.attrib['id'])
            north_angle = get_north_angle(node)
            point_3d = CitisimSlice.Point3D(float(node.attrib['lat']),
                                            float(node.attrib['lon']))
            print(name)
            self.cittavr.placePhysicalObject(name, prototype, point_3d,
                                             north_angle)


Client().main(sys.argv)
