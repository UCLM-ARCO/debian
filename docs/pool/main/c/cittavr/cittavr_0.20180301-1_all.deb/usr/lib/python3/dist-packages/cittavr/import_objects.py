#!/usr/bin/python -u
# -*- mode:python; coding:utf-8; tab-width:4 -*-

import os
import bpy
import xml.etree.ElementTree as ET
import math
from cittavr.transverse_mercator import TransverseMercator
from cittavr.materials import renameMaterials
from cittavr import ASSETS_DIR, PLUGINS_DIR

SIMULATOR_OBJECTS_PATH = ASSETS_DIR + '/simulator.blend/'
MONITOR_OBJECTS_PATH = ASSETS_DIR + '/monitor.blend/'
CAMERA_PATH = ASSETS_DIR + '/camera.blend/'


def addObjects(osm_object, data, execution_mode, scene, object_num):
    tree = ET.parse(data)

    for node in tree.iterfind('node'):
        tag = None
        direction = 0.0
        if node.find('tag[@k="highway"][@v="' + osm_object + '"]') is not None:
            name = "citisim-{}-{}".format(osm_object, node.attrib['id'])
            lat = node.attrib['lat']
            lon = node.attrib['lon']
            tag = node.find('tag[@k="direction"]')

            if tag is not None:
                direction = tag.attrib['v']

            appendObject(scene, name, lat, lon, direction, osm_object,
                         execution_mode, object_num)
            object_num += 1

    appendScript(osm_object + '_simulator.py', execution_mode)
    appendScript(osm_object + '_monitor.py', execution_mode)
    appendScript(osm_object + '_presence_source.py', execution_mode)
    return object_num


def add_constructor():
    filepath = 'constructor.blend'
    dirname = ASSETS_DIR + "/{}/".format(filepath)

    bpy.ops.wm.append(
        directory=dirname + "Object",
        filepath=filepath,
        filename='Empty',
        link=False)

    bpy.ops.wm.append(
        directory=dirname + "Text",
        filepath=filepath,
        filename='setup.py',
        link=False)


def appendScript(script_name, execution_mode):
    if execution_mode == "monitor":
        directory = MONITOR_OBJECTS_PATH
        filepath = 'monitor.blend'

    elif execution_mode == "simulator":
        directory = SIMULATOR_OBJECTS_PATH
        filepath = 'simulator.blend'

    else:
        print("You must specify the execution mode.")
        return

    bpy.ops.wm.append(
        directory=directory + "Text",
        filepath=filepath,
        filename=script_name,
        link=False)


def appendQRCamera():
    bpy.ops.wm.append(
        directory=CAMERA_PATH + "Object",
        filepath='camera.blend',
        filename='cittavr_camera',
        link=False)

    bpy.ops.wm.append(
        directory=CAMERA_PATH + "Object",
        filepath='camera.blend',
        filename='qr_plane',
        link=False)

    camera = bpy.data.objects["cittavr_camera"]
    qr_plane = bpy.data.objects["qr_plane"]
    qr_plane.parent = camera


def add_assets():
    def layers(l):
        all = [False] * 20
        all[l] = True
        return all

    def add_asset(name):
        added_physical = None
        filepath = 'model.blend'
        dirname = os.path.join(PLUGINS_DIR, name, filepath)

        added_physical = name
        bpy.ops.wm.append(
            directory=os.path.join(dirname, 'Object'),
            filepath=filepath,
            filename=added_physical,
            link=False)

        o = bpy.data.objects[added_physical]
        o.layers = layers(9)

        bpy.ops.wm.append(
            directory=os.path.join(dirname, 'Text'),
            filepath=filepath,
            filename=name + '.py',
            link=False)

        bpy.ops.wm.append(
            directory=os.path.join(dirname, 'Object'),
            filepath=filepath,
            filename="Empty." + name,
            link=False)

    for plugin in os.listdir(PLUGINS_DIR):
        add_asset(plugin)


def appendObject(scene, name, lat, lon, direction, object_name, execution_mode,
                 object_num):
    ob = None
    identity_string = '60{:02}'.format(object_num)

    if execution_mode == "monitor":
        directory = MONITOR_OBJECTS_PATH
        filepath = 'monitor.blend'

    elif execution_mode == "simulator":
        directory = SIMULATOR_OBJECTS_PATH
        filepath = 'simulator.blend'

    bpy.ops.wm.append(
        directory=directory + "Object",
        filepath=filepath,
        filename=object_name,
        link=False)

    projection = TransverseMercator(lat=scene["latitude"],
                                    lon=scene["longitude"])
    (x, y) = projection.fromGeographic(float(lat), float(lon))
    ob = bpy.data.objects[object_name]
    ob.name = name
    direction = -(float(direction) * (math.pi / 180.0))
    ob.rotation_euler[2] = direction
    ob.location = (x, y, 0)
    ob['identity'] = identity_string

    renameMaterials(ob, object_name, name)
