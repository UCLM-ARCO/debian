# -*- mode: python; coding: utf-8 -*-

import os
import time
import bge
import bpy
from cittavr import logger
from cittavr.service import Server

cittavr_servant = None


def start():
    config_file = os.path.join(bpy.path.abspath("//"), "cittavr.config")

    if not os.path.isfile(config_file):
        logger.error(
            "CittaVR server config file not found " +
            "(path: '{}')".format(config_file))
        controller = bge.logic.getCurrentController()
        end_game = controller.actuators['exitGame']
        controller.activate(end_game)
        return

    global cittavr_servant
    bge.render.showMouse(True)
    cittavr_servant = Server().servant
    logger.info("CittaVR server started...")


def pulse():
    # time.sleep(0.001)
    if cittavr_servant:
        cittavr_servant.work_queue.step()
