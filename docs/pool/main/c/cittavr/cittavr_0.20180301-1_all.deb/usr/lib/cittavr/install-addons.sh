#!/bin/bash --
# -*- coding: utf-8; mode: shell-script; tab-width: 4 -*-

CITISIM_ROOT=$(get-project-dir)
INSTALLER="/usr/lib/cittavr/install-addon.py"
blender_bin=${CITISIM_BLENDER:-blender}

for addon in $(find "/usr/lib/cittavr/blender-addons/" -type f); do
    $blender_bin --background --python $INSTALLER -- $addon
done
