#!/usr/bin/python3 -u
# -*- mode: python; coding: utf-8 -*-

import sys
import Ice
import argparse

from cittavr.slice import CittaVRSlice


class Client(Ice.Application):
    def run(self, args):
        if not self.parse_args(args):
            return 1

        name = self.args.asset + '-' + str(self.args.id)
        position = CittaVRSlice.Point3D(self.args.x, self.args.y, self.args.z)

        ic = self.communicator()
        service = ic.stringToProxy(args[1])
        service = CittaVRSlice.CittaVRServicePrx.uncheckedCast(service)

        if self.args.type == 'meters':
            service.placePhysicalMeters(
                name, self.args.asset, position, self.args.angle)
        else:
            service.placePhysicalCoordinates(
                name, self.args.asset, position, self.args.angle)

    def parse_args(self, args):
        parser = argparse.ArgumentParser()
        parser.add_argument("proxy", help="Proxy to CittaVR service")
        parser.add_argument("asset", help="Name of asset to include on project")
        parser.add_argument("id", type=int, help="Suffix for created object")
        parser.add_argument("x", type=float, help="The x coordinate of object's position")
        parser.add_argument("y", type=float, help="The y coordinate of object's position")
        parser.add_argument("z", type=float, help="The z coordinate of object's position")
        parser.add_argument("angle", type=float, help="North angle of object")

        parser.add_argument(
            "-t", dest='type', choices=('meters', 'coordinates'), default='meters',
            help="Set meters (default) or coordinates for position values")

        try:
            self.args = parser.parse_args(args[1:])
            return True
        except SystemExit:
            return False


exit(Client().main(sys.argv))
