#!/usr/bin/python3 -u
# -*- mode:python; coding:utf-8; tab-width:4 -*-
"usage: set_observer <router_proxy> <observer_address> <observable_address>"

import sys
import Ice

from cittavr import CITISIM_SLICE
Ice.loadSlice('-I /usr/share/slice {} --all'.format(CITISIM_SLICE))
import CitisimSlice
import DUO.IDM
import IDM


class Server(Ice.Application):
    def run(self, args):
        if len(args) != 4:
            print(__doc__)
            return 1

        broker = self.communicator()

        router = broker.stringToProxy(args[1])
        router = IDM.NeighborDiscovery.ListenerPrx.uncheckedCast(router)

        observable_address = args[2]
        observer_address = args[3]

        observable_proxy = router.ice_identity(broker.stringToIdentity(observable_address))
        observable_proxy = DUO.IDM.Active.WPrx.uncheckedCast(observable_proxy)
        binary_address = self.identityToAddress(observer_address)

        observable_proxy.setObserver(binary_address)
        print("{}.setObserver({})".format(observable_address, observer_address))

        broker.destroy()

    def identityToAddress(self, identity_str):
        return int(identity_str, 16).to_bytes(2, byteorder='big')


if __name__ == "__main__":
    Server().main(sys.argv)
