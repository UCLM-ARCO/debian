import sys
import bge
import bpy

# FIXME: replace CitisimSlice with CittaVRSlice
# from cittavr import CITISIM_SLICE
import Ice
# Ice.loadSlice('-I /usr/share/slice {} --all'.format(CITISIM_SLICE))
# import CitisimSlice

from cittavr.service import plugins
from cittavr.textures import change_texture
from cittavr.slice import CittaVRSlice, SmartObject
from setup import cittavr_servant


class Servant(CittaVRSlice.DigitalSink):
    def __init__(self, physical, router, work_queue):
        pass
#         self.physical = physical
#         self.citisim_id = citisim_id
#         self.router = router
#         self.observer = None
#
#     def set(self, value, source, current=None):
#         set_state(self.physical, value)
#
#     # address will be a "string" in future DUO releases
#     def setObserver(self, address, current=None):
#         address = self.addressToString(address)
#         print("Set Observer to " + address)
#         self.observer = self.router.ice_identity(Ice.stringToIdentity(address))
#         self.observer = DUO.IDM.IBool.WPrx.uncheckedCast(self.observer)
#
#     def addressToString(self, address):
#         return "".join("{:02X}".format(c) for c in address)
#
#     def update(self, state):
#         self.state = state
#         if self.observer is None:
#             print("[!] Missing observer")
#             return
#
#         self.observer.set(self.state, "")
#
#
# def on_event():
#     controller = bge.logic.getCurrentController()
#     owner = controller.owner
#     mouse_over = controller.sensors['mouse_over']
#     mouse_button = controller.sensors['mouse_button']
#     collision = controller.sensors['collision']
#
#     if ((mouse_over.positive and mouse_button.positive or collision.positive)
#             or (not (mouse_over.positive and mouse_button.positive)
#                 and not collision.positive and owner['current_state'])):
#         state = not owner['current_state']
#         set_state(owner, state)
#         owner['current_state'] = state
#
#
# def set_state(owner, state):
#     texture = 'red' if state else 'blue'
#     change_texture(owner, "//../../assets/textures/{}.png".format(texture))
#     cittavr_servant.get_servant(owner).update(state)
#
#
# def register():
#     if 'loop_detector' in plugins:
#         return
#
#     plugins['loop_detector'] = Servant
#     print("Plugin 'loop_detector' added.")
