# -*- mode: python; coding: utf-8 -*-

import os
import bge
import bpy
import Ice

from cittavr import logger, ASSETS_DIR
from cittavr.service import plugins
from cittavr.slice import CittaVRSlice, SmartObject
from cittavr.textures import change_texture


class Servant(CittaVRSlice.DigitalSink):
    def __init__(self, physical, router, work_queue):
        self.physical = physical
        self.router = router
        self.work_queue = work_queue

        self.citisim_id = physical['citisim_id']
        self.observer = None

    def notify(self, value, source, meta, current):
        self.work_queue.add(None, set_state, self.physical, value)

    def setObserver(self, observer, current):
        if self.router:
            observer = self.router.ice_identity(Ice.stringToIdentity(observer))
        else:
            ic = current.adapter.getCommunicator()
            observer = ic.stringToProxy(observer)

        observer = observer.ice_encodingVersion(Ice.Encoding_1_0)
        logger.info("Set Observer to '{}'".format(observer))
        self.observer = SmartObject.DigitalSinkPrx.uncheckedCast(observer)

    def update(self, state):
        logger.info("Physical '{}' state changed to '{}'".format(self.citisim_id, state))

        if self.observer is None:
            logger.info("[!] Missing observer")
            return

        self.observer.notify(state, "CittaVR", {})


def on_left_click():
    controller = bge.logic.getCurrentController()
    mouse_over = controller.sensors['mouse_over']
    mouse_button = controller.sensors['mouse_left_button']

    if mouse_over.positive and mouse_button.positive:
        owner = controller.owner
        state = not owner['current_state']
        set_state(owner, state)


def on_right_click():
    controller = bge.logic.getCurrentController()
    mouse_over = controller.sensors['mouse_over']
    mouse_button = controller.sensors['mouse_right_button']

    if mouse_over.positive and mouse_button.positive:
        hud = [s for s in bge.logic.getSceneList() if s.name == "CittaVR-HUD"][0]
        owner = controller.owner
        idm_address = owner['idm_address']
        qr_dir = bpy.path.abspath("//qr_codes")
        qr_image = "{}/{}.png".format(qr_dir, idm_address)
        qr_plane = hud.objects["CittaVR-QRView"]

        if os.path.exists(qr_image):
            change_texture(qr_plane, "/{}".format(qr_image))


def set_state(owner, state):
    # set state
    owner['servant'].update(state)
    owner['current_state'] = state

    # change appearance
    texture = 'yellow' if state else 'grey'
    texture = os.path.join(ASSETS_DIR, "textures/{}.png".format(texture))
    if not os.path.exists(texture):
        logger.error("Could not find asset: '{}'".format(texture))
        return

    change_texture(owner, texture)


def register():
    if 'street_lamp' in plugins:
        return

    plugins['street_lamp'] = Servant
    logger.info("Plugin 'street_lamp' added")
