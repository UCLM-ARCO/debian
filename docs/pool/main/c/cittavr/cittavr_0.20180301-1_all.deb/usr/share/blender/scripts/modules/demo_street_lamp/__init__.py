# -*- mode: python; coding: utf-8 -*-

import bge

from cittavr import logger
from cittavr.service import plugins

import street_lamp


class Servant(street_lamp.Servant):
    def notify(self, value, source, meta, current):
        self.work_queue.add(None, set_state, self.physical, value)


def on_left_click():
    controller = bge.logic.getCurrentController()
    mouse_over = controller.sensors['mouse_over']
    mouse_button = controller.sensors['mouse_left_button']

    if mouse_over.positive and mouse_button.positive:
        owner = controller.owner
        state = not owner['current_state']
        set_state(owner, state)


def on_right_click():
    return street_lamp.on_right_click()


def set_state(owner, state):
    # set state
    owner['servant'].update(state)
    owner['current_state'] = state

    # change appearance
    light = owner.children[0]
    light.setVisible(state)


def register():
    if 'demo_street_lamp' in plugins:
        return

    plugins['demo_street_lamp'] = Servant
    logger.info("Plugin 'demo_street_lamp' added")
