# -*- mode: python; coding: utf-8 -*-

import os
import bge
import bpy
import Ice

from cittavr import logger
from cittavr.service import plugins
from cittavr.slice import CittaVRSlice, SmartObject
from cittavr.textures import change_texture


# NOTE: this Observable is multi-observer


class Servant(CittaVRSlice.DigitalSink):
    def __init__(self, physical, router, work_queue):
        self.physical = physical
        self.router = router
        self.work_queue = work_queue

        self.citisim_id = physical['citisim_id']
        self.observers = []

    def notify(self, value, source, meta, current):

        def set_show_event(owner, state):
            owner['show_event'] = True

        self.work_queue.add(None, set_show_event, self.physical, value)

    def setObserver(self, observer, current):
        if self.router:
            observer = self.router.ice_identity(Ice.stringToIdentity(observer))
        else:
            ic = current.adapter.getCommunicator()
            observer = ic.stringToProxy(observer)

        logger.info("Add observer: '{}'".format(observer))
        self.observers.append(SmartObject.DigitalSinkPrx.uncheckedCast(observer))

    def update(self, state=True):
        logger.info("Physical '{}' state changed to '{}'".format(self.citisim_id, state))

        if not self.observers:
            logger.info("[!] Missing observers")
            return

        for o in self.observers:
            o.notify(state, "CittaVR", {})


# Python controller callback
def show_qr_code():
    controller = bge.logic.getCurrentController()
    mouse_over = controller.sensors['over']
    mouse_button = controller.sensors['right_button']
    if not mouse_over.positive or not mouse_button.positive:
        return

    hud = [s for s in bge.logic.getSceneList() if s.name == "CittaVR-HUD"][0]
    owner = controller.owner
    idm_address = owner['idm_address']
    qr_dir = bpy.path.abspath("//qr_codes")
    qr_image = "{}/{}.png".format(qr_dir, idm_address)
    qr_plane = hud.objects["CittaVR-QRView"]

    if os.path.exists(qr_image):
        change_texture(qr_plane, "/{}".format(qr_image))


# Python controller callback
def notify_event():
    controller = bge.logic.getCurrentController()
    if not controller.sensors['show_event'].positive:
        return

    owner = bge.logic.getCurrentController().owner
    owner['servant'].update()


def register():
    if 'demo_sensor' in plugins:
        return

    plugins['demo_sensor'] = Servant
    logger.info("Plugin 'demo_sensor' added")
