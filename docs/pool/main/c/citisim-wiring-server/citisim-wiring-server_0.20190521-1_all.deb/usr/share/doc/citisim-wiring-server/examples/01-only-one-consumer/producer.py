#!/usr/bin/python3
# -*- mode: python; coding: utf-8 -*-

import os
import sys
import Ice

pwd = os.path.abspath(os.path.dirname(__file__))
slice_path = os.path.join(pwd, "wiring.ice")
slice_dir = "/usr/share/slice"
if not os.path.exists(slice_path):
    slice_path = "{}/citisim/wiring.ice".format(slice_dir)

Ice.loadSlice("{} -I{} --all".format(slice_path, slice_dir))
import SmartObject  # noqa


class ObservableI(SmartObject.Observable):
    def __init__(self):
        self.observer = None

    def setObserver(self, observer, current):
        ic = current.adapter.getCommunicator()
        self.observer = ic.stringToProxy(observer)
        print("PRODUCER: set observer to '{}'".format(self.observer))

    def ice_ping(self, current):
        self.observer.ice_ping()


class Server(Ice.Application):
    def run(self, args):
        ic = self.communicator()

        adapter = ic.createObjectAdapter("Adapter")
        adapter.activate()

        oid = Ice.stringToIdentity("Producer")
        proxy = adapter.add(ObservableI(), oid)

        print("PRODUCER: Proxy: '{}'".format(proxy))
        print("PRODUCER: Waiting events...")
        self.shutdownOnInterrupt()
        ic.waitForShutdown()


if __name__ == "__main__":
    Server().main(sys.argv)
