#!/usr/bin/python3
# -*- mode: python; coding: utf-8 -*-

import sys
import Ice


class ObjectI(Ice.Object):
    def __init__(self, number):
        self.number = number

    def ice_ping(self, current):
        print("CONSUMER[{}]: ice_ping() called!".format(self.number))


class Server(Ice.Application):
    def run(self, args):
        if len(args) != 2:
            print("Usage: {} <num-of-servants>".format(args[0]))
            return -1

        num_of_servants = int(args[1])
        ic = self.communicator()

        adapter = ic.createObjectAdapter("Adapter")
        adapter.activate()

        for i in range(num_of_servants):
            oid = "Consumer_{}".format(i)
            proxy = adapter.add(ObjectI(i), ic.stringToIdentity(oid))
            print("CONSUMER: Proxy: '{}'".format(proxy))

        print("CONSUMER: Waiting events...")
        self.shutdownOnInterrupt()
        ic.waitForShutdown()


if __name__ == "__main__":
    Server().main(sys.argv)
