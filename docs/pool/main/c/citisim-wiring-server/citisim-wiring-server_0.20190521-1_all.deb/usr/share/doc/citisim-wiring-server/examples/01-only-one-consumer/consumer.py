#!/usr/bin/python3
# -*- mode: python; coding: utf-8 -*-

import sys
import Ice


class ObjectI(Ice.Object):
    def ice_ping(self, current):
        print("CONSUMER: ice_ping() called!")


class Server(Ice.Application):
    def run(self, args):
        ic = self.communicator()

        adapter = ic.createObjectAdapter("Adapter")
        adapter.activate()

        oid = Ice.stringToIdentity("Consumer")
        proxy = adapter.add(ObjectI(), oid)

        print("CONSUMER: Proxy: '{}'".format(proxy))
        print("CONSUMER: Waiting events...")
        self.shutdownOnInterrupt()
        ic.waitForShutdown()


if __name__ == "__main__":
    Server().main(sys.argv)
