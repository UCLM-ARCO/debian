#!/usr/bin/python3
# -*- mode: python; coding: utf-8 -*-

import os
import sys
import Ice

pwd = os.path.abspath(os.path.dirname(__file__))
slice_path = os.path.join(pwd, "wiring.ice")
slice_dir = "/usr/share/slice"
if not os.path.exists(slice_path):
    slice_path = "{}/citisim/wiring.ice".format(slice_dir)

Ice.loadSlice("{} -I{} --all".format(slice_path, slice_dir))
import SmartObject  # noqa


class Server(Ice.Application):
    def run(self, args):
        ic = self.communicator()

        wiring_service = ic.propertyToProxy("Citisim.WiringServer.Proxy")
        wiring_service = SmartObject.WiringServicePrx.uncheckedCast(wiring_service)

        # connect objects
        producer = "Producer -t:tcp -h 127.0.0.1 -p 1111"
        consumer = "Consumer -t:tcp -h 127.0.0.1 -p 1112"
        wiring_service.addObserver(producer, consumer)

        # produce an event
        producer = ic.stringToProxy(producer)
        producer.ice_ping()


if __name__ == "__main__":
    Server().main(sys.argv)
