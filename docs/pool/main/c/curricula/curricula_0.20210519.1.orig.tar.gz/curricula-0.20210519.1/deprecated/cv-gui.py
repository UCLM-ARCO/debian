#!/usr/bin/python

import inspect

import gtk

import cv


class Label(gtk.Label):
    def __init__(self, text):
        gtk.Label.__init__(self, text)
        self.set_alignment(0, 0.5)

class Button(gtk.Button):
    def __init__(self, text):
        gtk.Button.__init__(self, text)
        self.set_relief(gtk.RELIEF_HALF)

class ScrolledWindow(gtk.Window):
    def __init__(self, widget):
        gtk.Window.__init__(self)
        self.set_default_size(200, 300)
        scrollwindow = gtk.ScrolledWindow()
        scrollwindow.add_with_viewport(widget)
        scrollwindow.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        self.add(scrollwindow)


def insert_button_row(table, pos, text, actions=[]):
    label = Label(text)
    table.attach(label, 0, 1, pos, pos+1)

    i = 1
    for text, cb, data in actions:
        button = Button(text)
        if cb: button.connect("clicked", cb, data)
        table.attach(button, i, i+1, pos, pos+1)
        i += 1


class ModelView:
    def __init__(self, model):
        table = gtk.Table(1, 2, False)
        table.set_col_spacing(0, 4)
        self.win = ScrolledWindow(table)

        for n, (key,cls) in enumerate(model.cls_meta().items()):

            value = getattr(model, key)
            if isinstance(value, cv.Model):
                widget = Button("view '%s'" % key)
            else:
#                if not value: continue

                print key, type(value)
                if isinstance(cls, cv.MLis):
                    value = str.join('\n', value)

                widget = Label(str(value))


            label = Label(key)
            table.attach(label, 1,2, n, n+1)
            table.attach(widget, 2,3, n, n+1)


        self.win.show_all()


class ModelList:
    def __init__(self, name):
        self.name = name
        table = gtk.Table(1, 2, False)
        table.set_col_spacing(0, 4)
        self.win = ScrolledWindow(table)

        for n, item in enumerate(context[name]):
            insert_button_row(table, n, item, [
                    ('view', self.on_button_view, item)
                    ])

        self.win.show_all()


    def on_button_view(self, button, model):
        print model
        ModelView(model)


class App:

    def __init__(self):

        table = gtk.Table(1, 3, False)
        table.set_col_spacing(0, 4)

        self.win = ScrolledWindow(table)
        self.win.set_default_size(200, 300)
        self.win.connect('delete_event', lambda x,y:gtk.main_quit())

        for n, (name, cls) in enumerate(cv.list_models().items()):
            if not issubclass(cls, cv.FileModel): continue

            insert_button_row(table, n, name, [
                    ('list', self.on_button_list, name)
                    ])

        self.win.show_all()

    def on_button_list(self, button, clsname):
        ModelList(clsname)


cv.load_config(['--check'])
context = cv.Content()
print "loading database... ",
context.mark_all()
print "ready"

App()
gtk.main()
