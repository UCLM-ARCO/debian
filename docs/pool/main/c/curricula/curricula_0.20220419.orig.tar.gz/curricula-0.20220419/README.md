# curricula-code

Curricula `cv` processor program. 

To use it, install package `curricula` from https://uclm-arco.github.io/debian/

Read https://github.com/UCLM-ARCO/curricula/blob/master/README.md for more info.
