curricula-fake$ cv --paper papers/3000-fixture/ -i "<<paper.title>>" -o-
Fixture example for testing purposes
