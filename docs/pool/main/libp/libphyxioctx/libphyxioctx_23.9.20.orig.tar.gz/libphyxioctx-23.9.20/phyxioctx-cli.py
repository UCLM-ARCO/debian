#!/usr/bin/env python3

import time
import logging
import json
from argparse import ArgumentParser

from libphyxioctx import PhyxioContext


logging.basicConfig(level=logging.INFO)
log = logging.getLogger("PCC")


class PhyxioCtxClient:
    def __init__(self, args):
        self._args = args
        self._ctx = PhyxioContext(
            args.storage_dir, args.host, args.port, args.keep_open)

    def run(self):
        if self._args.set:
            self._cmd_set(self._args.set)
        if self._args.get:
            self._cmd_get(self._args.get)
        if self._args.show:
            self._cmd_show()

        if self._args.keep_open:
            log.info(" 'keep open' mode requested, presss Ctrl+C to finish.")
            while True:
                time.sleep(1)

    def _cmd_show(self):
        contents = self._ctx.to_json()
        log.info(f" phxio context contents:\n{contents}")

    def _cmd_set(self, input):
        try:
            path, value = input.split("=")
        except ValueError:
            log.error(" invalid syntax on --set argument!")
            return
        log.info(f" setting path: '{path}' to value: '{value}'")
        self._ctx.update(path, value)

    def _cmd_get(self, path):
        value = json.dumps(self._ctx.get(path), ensure_ascii=False, indent=4)
        log.info(f" value at '{path}': {value}")


if __name__ == "__main__":
    parser = ArgumentParser()

    # actions
    actions = parser.add_argument_group("actions")
    actions.add_argument("-l", "--show", action="store_true",
        help="show current phyxio context")
    actions.add_argument("-s", "--set",
        help="set key to given value (ie. -s 'key.subkey=\"some value\"')")
    actions.add_argument("-g", "--get",
        help="get the value at given path (ie. -g 'key.subkey')")

    # options
    parser.add_argument("-m", "--host", default="127.0.0.1",
        help="host where API service will listen")
    parser.add_argument("-p", "--port", type=int, default=14758,
        help="port where API service will listen")
    parser.add_argument("-k", "--keep-open", action="store_true",
        help="do not close client after running commands")
    parser.add_argument("-d", "--storage-dir", default="/var/lib/libphyxioctx/",
        help="directory where context will be held")

    args = parser.parse_args()
    cli = PhyxioCtxClient(args)
    try:
        cli.run()
    except KeyboardInterrupt:
        print("\rBye!")
