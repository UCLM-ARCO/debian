import os
import logging
import json
import socket
from pathlib import Path
from threading import Thread, Event
from contextlib import closing
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler, HTTPServer
from peewee import SqliteDatabase, Model, TextField


log = logging.getLogger("LPC")
db = SqliteDatabase(None)


class Record(Model):
    path = TextField(null=False, unique=True)
    value = TextField(null=True)

    class Meta:
        database = db


class RestServer(Thread):
    def __init__(self, ctx, host="127.0.0.1", port=0):
        super().__init__()
        self._host = host
        self._port = port
        self._ctx = ctx
        self._ready_ev = Event()

        self.daemon = True
        self.endpoint = None
        if not self._port_is_available(host=host, port=port):
            log.warning(" RestServer not running, port is not available!")
            return
        self.start()

    def _port_is_available(self, port, host="127.0.0.1"):
        with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
            return sock.connect_ex((host, port)) != 0

    def wait_ready(self):
        self._ready_ev.wait()

    def do_set(self, path, value):
        self._ctx.update(path, value)
        return dict(status="ok")

    def do_get(self, path):
        return dict(value=self._ctx.get(path))

    def run(self):
        handler = self
        cors_whitelist = "127.0.0.1,localhost,phyx.io".split(",")

        class RequestHandler(BaseHTTPRequestHandler):
            def log_message(self, *args, **kwargs):
                pass

            def do_OPTIONS(self):
                self.send_response(200)
                if self._check_cors():
                    self.send_header('Access-Control-Allow-Methods', 'PUT')
                self.end_headers()

            def do_GET(self):
                log.info(" [RestAPI] GET received")
                url = urlparse(self.path)
                req = parse_qs(url.query)

                code = 404
                resp = {"status": "not found"}
                if url.path == "/get":
                    try:
                        path = req["path"][0]
                        resp = handler.do_get(path)
                        code = 200
                    except (KeyError, IndexError):
                        code = 500
                        resp = {"status": "invalid query"}

                self._end_request(code, resp)

            def do_PUT(self):
                size = int(self.headers["Content-Length"])
                req = self.rfile.read(size)
                req = json.loads(req)

                code = 404
                resp = {"status": "not found"}
                if self.path == "/set":
                    try:
                        path = req["path"]
                        value = req["value"]
                        resp = handler.do_set(path, value)
                        code = 200
                        log.info(f" [RestAPI] PUT received, {path} = {value}")
                    except KeyError:
                        code = 500
                        resp = {"status": "invalid query"}

                self._end_request(code, resp)

            def _end_request(self, code, resp):
                self.send_response(code)
                self.send_header('Content-type', 'application/json')
                self._check_cors()
                self.end_headers()
                self.wfile.write(json.dumps(resp).encode())

            def _check_cors(self):
                origin = urlparse(self.headers.get('Origin', "")).netloc
                host = origin.split(":")[0]
                if host in cors_whitelist:
                    origin = self.headers['Origin']
                    self.send_header('Access-Control-Allow-Origin', origin)
                    return True
                return False

        with HTTPServer((self._host, self._port), RequestHandler) as server:
            port = server.socket.getsockname()[1]
            self.endpoint = f"http://{self._host}:{port}"
            log.info(f" [RestAPI] listening on {self.endpoint}")
            self._ready_ev.set()
            server.serve_forever()


class PhyxioContext:
    def __init__(self, storage_dir="/var/lib/libphyxioctx/", host="127.0.0.1", port=14758, enable_rest=True):
        if db.database is None:
            self._init_database(storage_dir)
        if enable_rest:
            RestServer(self, host, port)

    def _init_database(self, dirname):
        log.info(" initializing database...")
        path = Path(dirname)
        if not path.exists():
            os.makedirs(path.as_posix())

        db_name = (path / "context.db").as_posix()
        db.init(db_name)
        db.create_tables([Record])

    def update(self, path, value):
        try:
            record = Record.get(path=path)
        except Record.DoesNotExist:
            record = Record.create(path=path)
        record.value = value
        record.save()

    def get(self, path, default=None):
        try:
            # direct key
            return self._parse_value(Record.get(path=path).value)
        except Record.DoesNotExist:
            pass

        # relative key
        q = Record.select().where(Record.path.startswith(path))
        if len(q) == 0:
            return default

        retval = {}
        for r in q:
            self._update_dict(retval, r.path, r.value)
        for k in path.split("."):
            retval = retval[k]
        return retval

    def to_json(self):
        records = {}
        for r in Record.select():
            self._update_dict(records, r.path, r.value)
        return json.dumps(records, indent=3)

    def _update_dict(self, leaf, path, value):
        parents = path.split(".")[:-1]
        for p in parents:
            next = leaf.get(p)
            if next is None:
                next = {}
                leaf[p] = next
            leaf = next
        leaf[path.split(".")[-1]] = self._parse_value(value)

    def _parse_value(self, value):
        if not isinstance(value, str): return value
        if value == "True": return True
        if value == "False": return False
        if "." in value:
            if value.replace(".", "").isnumeric():
                return float(value)
        elif value.isnumeric():
            return int(value)
        return value
