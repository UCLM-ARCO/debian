
void buffer_path_simplify(char *dest, const char *src);
