- rework logging - the debug level is not mapped towards syslog level.
- commit: 1a9420043b54 ndsctl: prevent deadlock with multiple concurrent instances
  commit: 0329c2763f17 ndsctl: clean up FILE pointer (connected to 1a9420043b54)
- commit: 17de36487bf6 decide if we should take nodogsplash part
- commit: baf495ce3c7f fix: NDS uptime if NTP client enabled
- commit: 0608c37151ab Fix deb package build error
- commit: b04082040731 Fix: Memory corruption at high loads. (contains multiple changesm preferable 503 with 403 replacement)
- commit: 271f823b3cd0 Preauth: Add  missing "=" and add utf-8 to header (add charset=utf-8)
- commit: consider htmlentityencode() functions
- commit: 197f7e1e49fc Tidy up main_loop, removing namespace pollution
