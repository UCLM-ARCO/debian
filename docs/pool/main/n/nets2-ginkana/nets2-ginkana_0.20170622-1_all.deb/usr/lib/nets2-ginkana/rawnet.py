# -*- coding:utf-8; tab-width:4; mode:python -*-

import socket
import struct


def icmp_checksum(data):

    def sum16(data):
        "sum all the the 16-bit words in data"
        if len(data) % 2:
            data += '\0'

        return sum(struct.unpack("!%sH" % (len(data) / 2), data))

    retval = sum16(data)                       # sum
    retval = sum16(struct.pack('!L', retval))  # one's complement sum
    retval = (retval & 0xFFFF) ^ 0xFFFF        # one's complement
    return retval


class DisectionError(Exception):
    pass


class IP_Dissector:
    def __init__(self, data):
        self.ihl = ord(data[0]) & 0x0F
        self.payload = data[self.ihl * 4:]

        self.src = socket.inet_ntoa(data[12:16])
        self.dst = socket.inet_ntoa(data[16:20])


class ICMP_ECHO:
    def __init__(self):
        self._cksum = None

    @property
    def header(self):
        return struct.pack('!2b3H', self.type, self.code, 0, self.id, self.seq)

    @property
    def cksum(self):
        if self._cksum is None:
            self._cksum = icmp_checksum(self.header + self.payload)
        return self._cksum

    def render(self):
        pkt = self.header + self.payload
        retval = pkt[:2] + struct.pack('!H', self.cksum) + pkt[4:]
        return retval

    def __str__(self):
        return "<{0} cksum:{1} id:{2} seq:{3}>".format(
            self.__class__.__name__,
            self.cksum, self.id, self.seq)


class ICMP_ECHO_Request(ICMP_ECHO):
    def __init__(self, id_, seq, payload, cksum=None):
        ICMP_ECHO.__init__(self)
        self.type = 8
        self.code = 0
        self.id = id_
        self.seq = seq
        self.payload = payload
        self._cksum = cksum

    @classmethod
    def dissect(cls, data):
        type, code, cksum, id, seq = \
            struct.unpack('!2b3H', data[:8])

        if not (type == 8 and code == 0):
            raise DisectionError

        payload = data[8:]

        return ICMP_ECHO_Request(id, seq, payload, cksum)

    def validate_cksum(self):
        copy = ICMP_ECHO_Request(self.id, self.seq, self.payload)
        print self.cksum, copy.cksum
        return self.cksum == copy.cksum


class ICMP_ECHO_Reply(ICMP_ECHO):
    def __init__(self, id_, seq, payload):
        ICMP_ECHO.__init__(self)
        self.type = 0
        self.code = 0
        self.id = id_
        self.seq = seq
        self.payload = payload
