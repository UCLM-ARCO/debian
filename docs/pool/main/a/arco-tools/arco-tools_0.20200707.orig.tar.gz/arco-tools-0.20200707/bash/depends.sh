
source /usr/share/arco/shell-commodity.sh

#set -o pipefail  # trace ERR through pipes
#set -o errtrace  # trace ERR through 'time command' and other functions
DEPENDS=./DEPENDS

function depends-deb-install {
    (
    sc-assert-files-exist $DEPENDS
    sudo aptitude install $(cat $DEPENDS | _depends-filter-deb)
    )
}

function _depends-filter-deb {
    grep "^deb:" | cut -d: -f2
}

function _depends-filter-bin {
    grep "^bin:" | cut -d: -f2
}

function depends-check-deb {
    while read pkg; do
	sc-log-info "checking deb pkg: $pkg"
	sc-assert-deb-pkgs-installed $pkg
    done
}

function depends-check-bin {
    while read bin; do
	sc-log-info "checking binary: $bin"
	sc-assert-binaries-exist $bin
    done
}

function depends-missing-advice {
    sc-log-error "Unsatisfied dependencies"
    exit 1
}

function _depends-check-deb-from-file {
    cat $DEPENDS | _depends-filter-deb | depends-check-deb
}

function _depends-check-bin-from-file {
    cat $DEPENDS | _depends-filter-bin | depends-check-bin
}

function depends-check {
    (
    sc-set-trap depends-missing-advice
    sc-assert-files-exist $DEPENDS
    sc-assert _depends-check-deb-from-file
    sc-assert _depends-check-bin-from-file
    sc-clear-trap
    )
}
