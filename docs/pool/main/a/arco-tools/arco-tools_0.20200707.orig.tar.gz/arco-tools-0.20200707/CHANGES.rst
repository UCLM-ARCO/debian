0.20140321
==========

* ian-debvars-luser command

0.20130621
==========

* ian commands as symbolic links

0.20130204
==========

* dav-cmd

0.20130115
==========

* ian aliases: ian-cbi

0.20121210
==========

* _ian-assure-builddeps

0.20121129
==========

* Deactivate Kerberos authentication in arco-auth:remote_pam_auth()

0.20121116
==========

* slice.mk uses g++-4.6

0.20120913
==========

* ian-help-variable-examples exit fixed.

0.20120910
==========

* ian: ian-version-to-pysetup
* ian: orig is not build if exists

0.20120905
==========

* ian: better _ian-uses-quilt

0.20120903
==========

* typo in (sc-)retcode2bool

0.20120605
==========

* ian: ignore whole commented debian/watch

0.20120601
==========

* common: arco-step-trap/arco-clear/trap functions
* common: logging colors
* ian: refactoring
* ian: get-orig-source sample (need test)
* ian: remove .diff.gz on ian-clean
* ian: ian-orig does not remove previous orig
* ian: DEBREPO_URL replaces DEBREPOACCOUNT and DEBREPOPATH env variables
* ian: DEBSIGN_KEYID replaces GPGKEYID
* ian: [NEW] ian-new-release-date-version
* ian: [NEW] _ian-build-dir
* ian: [NEW] _ian-orig-dir
* ian: [NEW] _ian-quilt-pop

0.20120418
==========

* new (simpler) slice.mk
* config.mk -> project.mk

0.20120416
==========

* odp2pdf put aux file on /tmp
* odp2pdf may be used recursively and store .pdf file in the same directory as sources.

0.20120412
==========

* arco.cls.tmpl -> arco.cls.in

0.20120326
==========

* /usr/share/arco-tools -> /usr/share/arco
* acronym and other improvements in arco.cls.tmpl
* odg->pdf in figures.mk

0.20120223
==========

* make/dav-deploy.mk fixed
* new tex/arco-exercise.cls
* new tex/arco-listings.sty

0.20120213
==========

* slide.mk -> odp2pdf.mk
* latex.mk: discover master tex documents

0.20120117
==========

* minimal.cfg: Automatically create missing parent directories when you 'open' a new file
  http://atomized.org/2008/12/emacs-create-directory-before-saving/

0.20120101
==========

* improvements in subdirs.mk (directories that contain a Makefile)

0.20111215
==========

* Bug fix in latex.mk. SOURCE -> TEX_SOURCE

0.20110901
==========

* develock removed

0.20110617
==========

* parts-tex.sh list \input tex files recursively.
* better geometry for arco-pfc class.
* more formats in logos.mk
* error in citation grep fixed (latex.mk)


0.20100711
==========

* New snippet: emacs/yasnippet/text-mode/flyspell-vars.yasnippet


.. Local Variables:
..  mode: rest
..  coding: utf-8
..  mode: flyspell
..  ispell-local-dictionary: "american"
.. End:
