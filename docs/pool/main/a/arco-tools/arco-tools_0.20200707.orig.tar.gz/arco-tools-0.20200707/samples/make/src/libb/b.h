// -*- mode: c++ -*-

int b(int v);

