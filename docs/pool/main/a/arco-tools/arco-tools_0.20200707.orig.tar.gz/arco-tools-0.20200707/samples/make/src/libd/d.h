// -*- mode: c++ -*-

int c(int v);

