// -*- mode: c++ -*-

int a(int v);

