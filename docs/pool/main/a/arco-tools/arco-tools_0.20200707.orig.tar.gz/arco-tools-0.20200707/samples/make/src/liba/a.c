// -*- mode:c++ -*-

#include "a.h"

int a(int v) {
	return 4;
}
