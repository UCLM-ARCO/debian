#include <stdio.h>

#include <libd/d.h>

int main () {
	c(4);
	return 0;
}
