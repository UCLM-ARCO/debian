// -*- mode:c++ -*-

#include <stdio.h>

#include "b.h"

int b(int v) {
	printf("%d\n", v);
}
