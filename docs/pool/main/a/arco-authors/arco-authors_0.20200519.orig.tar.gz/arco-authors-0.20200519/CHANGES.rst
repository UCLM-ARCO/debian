0.20131114
==========

* arco-admonition-xelatex integrated again in arco-admonition

0.20131113
==========

* arco-admonition and arco-admonition-xelatex
* arco-book-utils -> arco-book-basics

0.20130522
==========

* more result sanity checks

0.20120924
==========

* bugfix in latex-parts.sh

0.20120713
==========

* customizable FIGDIR

0.20120420
==========

* arco-authors as individual package

0.20120416
==========

* odp2pdf put aux file on /tmp
* odp2pdf may be used recursively and store .pdf file in the same directory as sources.

0.20120412
==========

* arco.cls.tmpl -> arco.cls.in

0.20120326
==========

* /usr/share/arco-tools -> /usr/share/arco
* acronym and other improvements in arco.cls.tmpl
* odg->pdf in figures.mk

0.20120223
==========

* make/dav-deploy.mk fixed
* new tex/arco-exercise.cls
* new tex/arco-listings.sty

0.20120213
==========

* slide.mk -> odp2pdf.mk
* latex.mk: discover master tex documents

0.20111215
==========

* Bug fix in latex.mk. SOURCE -> TEX_SOURCE

0.20110617
==========

* parts-tex.sh list \input tex files recursively.
* better geometry for arco-pfc class.
* more formats in logos.mk
* error in citation grep fixed (latex.mk)


.. Local Variables:
..  coding: utf-8
..  mode: flyspell
..  ispell-local-dictionary: "american"
.. End:
