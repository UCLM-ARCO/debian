# -*- mode: python; coding: utf-8 -*-

import time
import logging
from bluetooth.ble import DiscoveryService, GATTRequester
from queue import SimpleQueue, Empty
from threading import Thread, Event
from Crypto import Random
from Crypto.Cipher import AES

logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(level=logging.INFO)


class GATTNotifier:
    def __init__(self, dispatcher, handle):
        self.dispatcher = dispatcher
        self.handle = handle
        self.event = Event()
        self.data = None

    def __enter__(self):
        self.dispatcher.on(self.handle, self.on_notification)
        return self

    def __exit__(self, *args, **kwargs):
        self.dispatcher.remove_cb(self.handle, self.on_notification)

    def on_notification(self, data):
        self.data = data[3:]
        self.event.set()
        self.event.clear()

    def wait_notify(self):
        self.event.wait(timeout=10)
        return self.data


class GATTRequesterI(GATTRequester):
    def __init__(self, dispatcher, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.dispatcher = dispatcher

    def on_notification(self, handle, data):
        self.dispatcher.awake(handle, data)

    def enable_notify(self, handle):
        self.write_by_handle(handle + 1, bytes([1, 0]))

    def disable_notify(self, handle):
        self.write_by_handle(handle + 1, bytes([0, 0]))

    # helper method to wait for an async result (notification)
    def wait_notify(self, handle):
        with GATTNotifier(self.dispatcher, handle) as notifier:
            return notifier.wait_notify()


class EventDispatcher(Thread):
    def __init__(self):
        super().__init__()
        self.daemon = True
        self.queue = SimpleQueue()
        self.callbacks = {}
        self.start()

    def on(self, handle, cb):
        cbset = self.callbacks.get(handle)
        if cbset is None:
            cbset = set()
            self.callbacks[handle] = cbset
        cbset.add(cb)

    def remove_cb(self, handle, cb):
        cbset = self.callbacks.get(handle)
        if cbset is None:
            return
        cbset.remove(cb)

    def awake(self, handle, data):
        self.queue.put((handle, data))

    def run(self):
        while True:
            handle, data = self.queue.get()
            cbset = self.callbacks.get(handle)
            if cbset is not None:
                self.dispatch(cbset, data)

    def dispatch(self, cbs, data):
        for cb in cbs:
            try:
                cb(data)
            except Exception as e:
                logger.error(" Exception on callback")
                logger.error(" - {}: {}".format(type(e), e))


class Core2:

    class UUID:
        DEVICE_NAME       = "00002a00-0000-1000-8000-00805f9b34fb"
        APPEARANCE        = "00002a01-0000-1000-8000-00805f9b34fb"
        PRIVACY_FLAG      = "00002a02-0000-1000-8000-00805f9b34fb"
        CONNECTION_PARAMS = "00002a04-0000-1000-8000-00805f9b34fb"
        SERVICE_CHANGED   = "00002a05-0000-1000-8000-00805f9b34fb"
        SYSTEM_ID         = "00002a23-0000-1000-8000-00805f9b34fb"
        SERIAL_NUMBER     = "00002a25-0000-1000-8000-00805f9b34fb"
        HARDWARE_REV      = "00002a27-0000-1000-8000-00805f9b34fb"
        SOFTWARE_REV      = "00002a28-0000-1000-8000-00805f9b34fb"
        PNP_ID            = "00002a50-0000-1000-8000-00805f9b34fb"
        CURRENT_TIME      = "00002a2b-0000-1000-8000-00805f9b34fb"
        STEP_COUNTER      = "00000007-0000-3512-2118-0009af100700"
        ORIENTATION       = "00000003-0000-3512-2118-0009af100700"
        BATTERY_LEVEL     = "00002a19-0000-1000-8000-00805f9b34fb"
        SYNC              = "00000004-0000-3512-2118-0009af100700"
        UNKNOWN_1         = "00000005-0000-3512-2118-0009af100700"
        PAIRING           = "00000009-0000-3512-2118-0009af100700"
        UNKNOWN_2         = "00001531-0000-3512-2118-0009af100700"
        UNKNOWN_3         = "00001532-0000-3512-2118-0009af100700"

    class HANDLE:
        # NOTE: handles may change over updates, use them sparingly
        DEVICE_NAME       = 0x0003
        APPEARANCE        = 0x0005
        PRIVACY_FLAG      = 0x0007
        CONNECTION_PARAMS = 0x0009
        SERVICE_CHANGED   = 0x000e
        SYSTEM_ID         = 0x0012
        SERIAL_NUMBER     = 0x0014
        HARDWARE_REV      = 0x0016
        SOFTWARE_REV      = 0x0018
        PNP_ID            = 0x001a
        CURRENT_TIME      = 0x001d
        STEP_COUNTER      = 0x001f
        ORIENTATION       = 0x0022
        BATTERY_LEVEL     = 0x0025
        SYNC              = 0x0028
        UNKNOWN_1         = 0x002b
        PAIRING           = 0x002e
        UNKNOWN_2         = 0x0032
        UNKNOWN_3         = 0x0035

    def __init__(self, address, name="", key=None):
        self.enabled_notifications = set()
        self.address = address
        self.name = name
        self.key = key if key is not None else Random.get_random_bytes(16)
        self.dispatcher = EventDispatcher()
        self.requester = GATTRequesterI(self.dispatcher, self.address, False)

    def __repr__(self):
        return f"<amazfit.Core2, name: '{self.name}', address: {self.address}>"

    def connect(self):
        logger.info(f" Connecting to {self}...")
        self.requester.connect(True, channel_type="random")

    def pair(self):
        logger.info(f" Pairing...")
        logger.info(f" Please, shake the device when the LED starts to blink.")
        self.requester.enable_notify(self.HANDLE.PAIRING)

        # start pairing
        self._send_command(
            self.HANDLE.PAIRING,
            bytes([1, 0]),
            bytes([16, 1, 4])
        )

        # set client random key
        self._send_command(
            self.HANDLE.PAIRING,
            bytes([1, 0]) + self.key,
            bytes([16, 1, 1])
        )

        # ask device for a random value
        self.requester.write_cmd(self.HANDLE.PAIRING, bytes([2, 0]))
        value = self.requester.wait_notify(self.HANDLE.PAIRING)[3:]

        # encript value and send it back
        cipher = AES.new(self.key, AES.MODE_ECB)
        cvalue = cipher.encrypt(value)
        self._send_command(
            self.HANDLE.PAIRING,
            bytes([3, 0]) + cvalue,
            bytes([16, 3, 1])
        )

        self.requester.disable_notify(self.HANDLE.PAIRING)

    def wait_until_break(self):
        while True:
            try:
                time.sleep(0.1)
            except KeyboardInterrupt:
                break

    def read_info(self):
        self.name = self.requester.read_by_uuid(self.UUID.DEVICE_NAME)[0]\
            .partition(b'\0')[0].decode()

        self.appearance = \
            self.requester.read_by_uuid(self.UUID.APPEARANCE)[0].hex()
        if self.appearance == '0000':
            self.appearance += " (unknown)"

        self.privacy_flag = \
            self.requester.read_by_uuid(self.UUID.PRIVACY_FLAG)[0] != '\x00'

        conn = self.requester.read_by_uuid(self.UUID.CONNECTION_PARAMS)[0]
        self.min_connection_int = (conn[0] + (conn[1] << 8)) * 1.25
        self.max_connection_int = (conn[2] + (conn[3] << 8)) * 1.25
        self.slave_latency = conn[4] + (conn[5] << 8)
        self.timeout_mult = conn[6] + (conn[7] << 8)

        chgs = self.requester.read_by_uuid(self.UUID.SERVICE_CHANGED)[0]
        self.service_changed_start = chgs[0] + (chgs[1] << 8)
        self.service_changed_end = chgs[2] + (chgs[3] << 8)

        self.system_id = "0x{}".format(
            self.requester.read_by_uuid(self.UUID.SYSTEM_ID)[0].hex())

        self.serial_number = \
            self.requester.read_by_uuid(self.UUID.SERIAL_NUMBER)[0].decode()
        self.hardware_rev = \
            self.requester.read_by_uuid(self.UUID.HARDWARE_REV)[0].decode()
        self.software_rev = \
            self.requester.read_by_uuid(self.UUID.SOFTWARE_REV)[0].decode()

        pnp = self.requester.read_by_uuid(self.UUID.PNP_ID)[0]
        self.vendor_src = "Bluetooth SIG assigned Identifier" if \
            pnp[0] == 1 else "USB Implementer’s Forum assigned Identifier"
        self.vendor_id = "0x{:04x}".format(pnp[1] + (pnp[2] << 8))
        self.product_id = "0x{:04x}".format(pnp[3] + (pnp[4] << 8))
        self.product_ver = "0x{:04x}".format(pnp[5] + (pnp[6] << 8))

    @property
    def steps(self):
        steps = self.requester.read_by_uuid(self.UUID.STEP_COUNTER)[0]
        return self._convert_steps(steps)

    def on_steps(self, cb):
        self.requester.enable_notify(self.HANDLE.STEP_COUNTER)

        def deco(data):
            return cb(self._convert_steps(data[3:]))

        self.dispatcher.on(self.HANDLE.STEP_COUNTER, deco)

    def _convert_steps(self, data):
        retval = 0
        for i in range(1, 9):
            retval += (data[i] << (i-1))
        return retval

    @property
    def current_time(self):
        # NOTE: tm[10] usage is unknown
        tm = self.requester.read_by_uuid(self.UUID.CURRENT_TIME)[0]
        year = tm[0] + (tm[1] << 8)
        return f"{year}-{tm[2]:02}-{tm[3]:02} " \
               f"{tm[4]:02}:{tm[5]:02}:{tm[6]:02}.{int(tm[8]*100/256):02} " \
               f"(week day: {tm[7]}, adjust: 0x{tm[9]:02x})"

    @property
    def battery(self):
        try:
            return self.requester.read_by_uuid(self.UUID.BATTERY_LEVEL)[0]
        except RuntimeError:
            # NOTE: There is a bug in current firmware: battery message returns
            # with no payload
            logger.error(" There were an error while receiving data from battery level")
            return 0

    @property
    def orientation(self):
        if self.HANDLE.ORIENTATION not in self.enabled_notifications:
            self.requester.enable_notify(self.HANDLE.ORIENTATION)

        self.fire_orientation_read()
        data = self.requester.wait_notify(self.HANDLE.ORIENTATION)
        if data is None:
            raise RuntimeError("Invalid response when reading orientation!")

        if self.HANDLE.ORIENTATION not in self.enabled_notifications:
            self.requester.disable_notify(self.HANDLE.ORIENTATION)

        return self._convert_orientation(data)

    def on_orientation(self, cb):
        self.requester.enable_notify(self.HANDLE.ORIENTATION)
        self.enabled_notifications.add(self.HANDLE.ORIENTATION)

        def deco(data):
            return cb(self._convert_orientation(data[3:]))

        self.dispatcher.on(self.HANDLE.ORIENTATION, deco)

    def fire_orientation_read(self):
        self.requester.write_cmd(self.HANDLE.ORIENTATION, bytes([7, 1]))

    def _convert_orientation(self, data):
        v1 = data[3] + (data[4] << 8)
        v2 = data[5] + (data[6] << 8)
        return v1, v2

    def _send_command(self, handle, data, expected_response=None):
        self.requester.write_cmd(handle, data)
        response = self.requester.wait_notify(handle)
        if expected_response is not None and response != expected_response:
            raise RuntimeError("Invalid response when writing command!")

    @classmethod
    def find(cls, timeout=5):
        devices = cls.find_all()
        return devices[0] if devices else None

    @classmethod
    def find_all(cls, timeout=5):
        devices = []
        logger.info(f" Starting discovery (wait {timeout} seconds...)")
        service = DiscoveryService("hci0")

        result = service.discover(timeout)
        for address, name in result.items():
            if cls._is_candidate(address, name):
                devices.append(Core2(address, name))
        return devices

    @classmethod
    def _is_candidate(cls, address, name):
        # NOTE: don't know if every chip has the same name...
        return (
            name.lower() in ["hm0d"] or
            address.lower().startswith("f1:4f:bb")
        )
