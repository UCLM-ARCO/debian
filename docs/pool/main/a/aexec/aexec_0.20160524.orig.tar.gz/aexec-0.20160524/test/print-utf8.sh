#!/bin/bash --
# -*- coding:utf-8; tab-width:4; mode:shell-script -*-

echo Ñandú
