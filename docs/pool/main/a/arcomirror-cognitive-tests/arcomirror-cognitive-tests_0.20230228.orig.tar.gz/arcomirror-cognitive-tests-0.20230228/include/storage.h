#ifndef STORAGE_H
#define STORAGE_H

#include <qqml.h>

#include <QDir>
#include <QObject>

#include "exercise.h"

class Storage : public QObject
{
        Q_OBJECT
        Q_PROPERTY(qint64 size READ getSize NOTIFY sizeChanged)
        QML_ELEMENT
        QML_SINGLETON

    public:
        explicit Storage(QObject *parent = nullptr);

        static QDir RootDir;

        qint64 getSize() const;

        Q_INVOKABLE QString generateSaveKey(QString testKey) const;
        Q_INVOKABLE bool saveExercise(QString saveKey, Exercise *exercise);

    signals:
        void sizeChanged();
};

#endif // STORAGE_H
