#ifndef TEST_H
#define TEST_H

#include <qqml.h>

#include <QObject>

#include "exercise.h"

class Test : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString key READ getKey CONSTANT)
    Q_PROPERTY(QList<Exercise *> exercises READ getExercises CONSTANT)
    QML_ELEMENT

public:
    explicit Test(QString key, QObject *parent = nullptr);
    ~Test();

    QString getKey();
    QList<Exercise *> getExercises();
    void addExercise(Exercise *e);

private:
    QString key;
    QList<Exercise *> exercises = QList<Exercise *>();
};

#endif // TEST_H
