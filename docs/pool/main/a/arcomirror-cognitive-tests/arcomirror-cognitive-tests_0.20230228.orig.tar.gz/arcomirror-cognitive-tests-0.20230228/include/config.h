#ifndef CONFIGURATION_H
#define CONFIGURATION_H

#include <qqml.h>

#include <QObject>
#include <QQmlEngine>
#include <QSettings>
#include <QTranslator>

#include "test.h"

class Configuration : public QObject
{
        Q_OBJECT
        Q_PROPERTY(
            QString locale READ getLocale WRITE setLocale NOTIFY localeChanged)
        Q_PROPERTY(QStringList supportedLocales READ getSupportedLocales CONSTANT)
        Q_PROPERTY(int fontSize READ getFontSize WRITE setFontSize NOTIFY
                       fontSizeChanged)
        Q_PROPERTY(QList<Test *> tests READ getTests CONSTANT)
        QML_ELEMENT
        QML_SINGLETON

    public:
        explicit Configuration(QObject *parent = nullptr);
        ~Configuration();

        Q_INVOKABLE bool isRelease() const;

        QString getLocale();
        QStringList getSupportedLocales();
        void setLocale(QString value);

        int getFontSize();
        void setFontSize(int value);

        QList<Test *> getTests();

        Q_INVOKABLE bool setExerciseProperty(Exercise *exercise,
                                             QString property,
                                             QVariant value);

    signals:
        void localeChanged();
        void fontSizeChanged();

    private:
        QList<Test *> tests = QList<Test *>();
        QSettings *settings = new QSettings(QSettings::IniFormat,
                                            QSettings::UserScope,
                                            "arcoresearch",
                                            "cognitive-tests");

        QTranslator translator;
        // NOTE Add here if any supported new language
        QStringList supportedLocales = QStringList() << "en_GB"
                                                     << "es_ES";

        bool loadTests();
        void loadConfiguration();
        void loadLocales();
};

#endif // CONFIGURATION_H
