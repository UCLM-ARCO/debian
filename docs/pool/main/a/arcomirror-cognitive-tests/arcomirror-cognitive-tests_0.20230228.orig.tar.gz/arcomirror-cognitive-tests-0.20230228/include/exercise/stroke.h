#ifndef STROKE_EXERCISE_H
#define STROKE_EXERCISE_H

#include <qqml.h>

#include <QObject>

#include "exercise.h"

class StrokeExercise : public Exercise
{
        Q_OBJECT
        Q_PROPERTY(int numItems READ getNumItems WRITE setNumItems NOTIFY
                       numItemsChanged)
        Q_PROPERTY(bool alphanumeric READ isAlphanumeric CONSTANT)
        QML_ELEMENT

    public:
        explicit StrokeExercise(QString key,
                                int numItems,
                                bool alphanumeric,
                                QObject *parent = nullptr);

        QString getDisplayName() const override;

        int getNumItems();
        void setNumItems(int value);

        bool isAlphanumeric();

        Q_INVOKABLE void reset() override;
        QJsonObject toJSON() override;

    signals:
        void numItemsChanged();

    private:
        int numItems;
        bool alphanumeric;
};

#endif // STROKE_EXERCISE_H
