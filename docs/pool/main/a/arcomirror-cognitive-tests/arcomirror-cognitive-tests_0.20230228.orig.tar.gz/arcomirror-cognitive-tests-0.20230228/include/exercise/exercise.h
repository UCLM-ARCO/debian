#ifndef EXERCISE_H
#define EXERCISE_H

#include <qqml.h>

#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>
#include <QObject>
#include <QPoint>

class Exercise : public QObject
{
        Q_OBJECT
        Q_PROPERTY(QString type READ getType CONSTANT)
        Q_PROPERTY(QString key READ getKey CONSTANT)
        Q_PROPERTY(QString displayName READ getDisplayName CONSTANT)
        Q_PROPERTY(int time READ getTime NOTIFY timeChanged)
        Q_PROPERTY(int numError READ getNumError CONSTANT)
        Q_PROPERTY(QList<QPointF> touches READ getTouches CONSTANT)
        QML_ELEMENT

    public:
        explicit Exercise(QString key, QObject *parent = nullptr);

        Q_INVOKABLE bool isWritable(QString property);
        Q_INVOKABLE bool setProperty(QString property, QVariant value);

        QString getType() const;
        QString virtual getDisplayName() const;
        QString getKey();

        int getTime();
        Q_INVOKABLE void updateTime();

        int getNumError();
        Q_INVOKABLE void addError();

        QList<QPointF> getTouches();
        Q_INVOKABLE void addTouch(int x, int y);
        Q_INVOKABLE void setAreaSize(int width, int height);

        Q_INVOKABLE void virtual reset();

        QJsonObject virtual toJSON();
        QList<QPair<QString, QByteArray> > getData();
        void addData(QPair<QString, QByteArray> data);

    signals:
        void timeChanged();

    private:
        QString key;
        QString displayName;
        int time = 0;
        int numError = 0;
        int areaWidth = 0;
        int areaHeight = 0;
        QList<QPointF> touches = QList<QPointF>();

        // extension, data
        QList<QPair<QString, QByteArray> > data
            = QList<QPair<QString, QByteArray> >();
};

#endif // EXERCISE_H
