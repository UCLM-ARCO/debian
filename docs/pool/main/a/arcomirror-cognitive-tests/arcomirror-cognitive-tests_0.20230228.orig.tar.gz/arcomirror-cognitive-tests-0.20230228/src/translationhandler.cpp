#include "translationhandler.h"

TranslationHandler::TranslationHandler(QQmlEngine *engine, QObject *parent)
    : QObject{parent}
{
        QObject::connect(this,
                         &TranslationHandler::retranslationRequested,
                         engine,
                         &QQmlEngine::retranslate);
}

void TranslationHandler::retranslate()
{
        qDebug() << "Translation requested!";
        emit retranslationRequested();
}
