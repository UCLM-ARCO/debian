﻿#include "storage.h"
#include <QDateTime>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QString>

Storage::Storage(QObject *parent) : QObject{parent}
{
        if (!Storage::RootDir.exists()) {
                qDebug() << "Creating storage directory"
                         << Storage::RootDir.path();
                QDir().mkpath(Storage::RootDir.path());
        }
}

QDir Storage::RootDir = QDir(
    QDir::homePath() + "/.local/share/arcoresearch/cognitive-tests/results");

qint64 Storage::getSize() const
{
        return QFileInfo(Storage::RootDir.path()).size();
}

QString Storage::generateSaveKey(QString testKey) const
{
        return testKey + "/"
               + QString::number(QDateTime::currentMSecsSinceEpoch());
}

bool Storage::saveExercise(QString saveKey, Exercise *exercise)
{
        QDir testDir = QDir(Storage::RootDir.filePath(saveKey));
        if (!testDir.exists()) {
                qDebug() << "Creating test results directory" << testDir.path();
                QDir().mkpath(testDir.path());
        }
        QString exercisePath = testDir.filePath(
            QString("%1-%2.json").arg(exercise->getKey(), exercise->getType()));
        if (QFileInfo::exists(exercisePath)) {
                qWarning() << "Exercise" << exercise->getKey() << "-"
                           << exercise->getType() << "already saved";
                return false;
        }
        QFile file(exercisePath);
        if (!file.open(QIODevice::WriteOnly)) {
                qCritical() << "Could not open file" << exercisePath
                            << "so results not saved!";
                return false;
        }
        QJsonDocument fileContent(exercise->toJSON());
        file.write(fileContent.toJson(QJsonDocument::Compact));
        file.close();
        int i = 1;
        for (QPair<QString, QByteArray> exerciseData : exercise->getData()) {
                QString dataPath = testDir.filePath(
                    QString("%1-%2-data%3.%4")
                        .arg(exercise->getKey(),
                             exercise->getType(),
                             QString::number(i),
                             exerciseData.first));
                QFile dataFile(dataPath);
                if (!dataFile.open(QIODevice::WriteOnly)) {
                        qWarning() << "Could not open file" << dataPath;
                        continue;
                }
                dataFile.write(exerciseData.second);
                dataFile.close();
                ++i;
        }
        emit sizeChanged();
        return true;
}
