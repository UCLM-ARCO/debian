<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>ClockExercise</name>
    <message>
        <location filename="../src/exercise/clock.cpp" line="17"/>
        <source>Clock Exercise</source>
        <translation>Ejercicio del reloj</translation>
    </message>
</context>
<context>
    <name>ClockExerciseView</name>
    <message>
        <location filename="../ui/FrontEnd/views/ClockExerciseView.qml" line="72"/>
        <source>Mode: Erase</source>
        <translation>Modo: Borrar</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/ClockExerciseView.qml" line="73"/>
        <source>Mode: Paint</source>
        <translation>Modo: Pintar</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/ClockExerciseView.qml" line="88"/>
        <source>Finish</source>
        <translation>Terminar</translation>
    </message>
</context>
<context>
    <name>ConfigurationDialog</name>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="15"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="16"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="57"/>
        <source>Application</source>
        <translation>Aplicación</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="76"/>
        <source>Trail Making Test</source>
        <translation>Test del trazo</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="78"/>
        <source>MOCA</source>
        <translation>MOCA</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="110"/>
        <source>Language:</source>
        <translation>Idioma:</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="130"/>
        <source>Font size:</source>
        <translation>Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="142"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="143"/>
        <source>Big</source>
        <translation>Grande</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="206"/>
        <source>Number of items:</source>
        <translation>Número de elementos:</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="227"/>
        <source>Alphanumeric:</source>
        <translation>Alfanumérico:</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="272"/>
        <source>Points for outline:</source>
        <translation>Puntos del contorno:</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="293"/>
        <source>Points for numbers:</source>
        <translation>Puntos de los números:</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/ConfigurationDialog.qml" line="314"/>
        <source>Points for needles:</source>
        <translation>Puntos de las agujas:</translation>
    </message>
</context>
<context>
    <name>Exercise</name>
    <message>
        <location filename="../src/exercise/exercise.cpp" line="50"/>
        <source>Exercise</source>
        <translation>Ejercicio</translation>
    </message>
</context>
<context>
    <name>ExerciseView</name>
    <message>
        <location filename="../ui/FrontEnd/views/ExerciseView.qml" line="100"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/ExerciseView.qml" line="137"/>
        <location filename="../ui/FrontEnd/views/ExerciseView.qml" line="143"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/ExerciseView.qml" line="144"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/ExerciseView.qml" line="145"/>
        <source>Are you sure you want to finish the test? Any results will be deleted.</source>
        <translation>¿Está seguro de finalizar el test? Cualquier resultado será eliminado.</translation>
    </message>
</context>
<context>
    <name>StrokeExercise</name>
    <message>
        <location filename="../src/exercise/stroke.cpp" line="15"/>
        <source>Stroke Exercise</source>
        <translation>Ejercicio del trazo</translation>
    </message>
</context>
<context>
    <name>StrokeExerciseView</name>
    <message>
        <location filename="../ui/FrontEnd/views/StrokeExerciseView.qml" line="118"/>
        <source>Continue the sequence. Start from item %1.</source>
        <translation>Continúe la sequencia. Empiece desde el elemento %1.</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/StrokeExerciseView.qml" line="122"/>
        <source>Item %1 cannot be connected to item %2.</source>
        <translation>El elemento %1 no puede conectarse con el %2.</translation>
    </message>
</context>
<context>
    <name>TestListView</name>
    <message>
        <location filename="../ui/FrontEnd/controls/TestListView.qml" line="57"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/TestListView.qml" line="67"/>
        <source>Trail Making Test</source>
        <translation>Test del trazo</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/TestListView.qml" line="69"/>
        <source>MOCA</source>
        <translation>MOCA</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/TestListView.qml" line="85"/>
        <source>Several numbers will appear on screen. With your finger or a pen, draw lines to join them together in ascending order.</source>
        <translation>Varios números aparecerán por pantalla. Con su dedo o un lápiz, dibuje líneas que unan dichos números en orden ascendente.</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/controls/TestListView.qml" line="88"/>
        <source>Montreal Cognitive Assessment</source>
        <translation>Evaluación Cognitiva Montreal</translation>
    </message>
</context>
<context>
    <name>TestView</name>
    <message>
        <location filename="../ui/FrontEnd/views/TestView.qml" line="75"/>
        <source>Congratulations!</source>
        <translation>¡Enhorabuena!</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/TestView.qml" line="72"/>
        <source>You have successfully completed this exercise. Your results will be saved for further analysis!</source>
        <translation>Has completado el ejercicio. ¡Tus resultados serán almacenados para analizarlos!</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/TestView.qml" line="71"/>
        <source>Finish</source>
        <translation>Terminar</translation>
    </message>
    <message>
        <location filename="../ui/FrontEnd/views/TestView.qml" line="71"/>
        <source>Next</source>
        <translation>Siguente</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../ui/main.qml" line="113"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../ui/main.qml" line="57"/>
        <source>Congnitive tests</source>
        <translation>Tests cognitivos</translation>
    </message>
    <message>
        <location filename="../ui/main.qml" line="33"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../ui/main.qml" line="35"/>
        <source>Results storage has grew up to %1 %2. Free some storage before continue!</source>
        <translation>El almacenamiento de resultados ha ascendido a %1 %2. ¡Libere algo de espacio antes de continuar!</translation>
    </message>
    <message>
        <location filename="../ui/main.qml" line="149"/>
        <source>Configure</source>
        <translation>Configuración</translation>
    </message>
</context>
</TS>
