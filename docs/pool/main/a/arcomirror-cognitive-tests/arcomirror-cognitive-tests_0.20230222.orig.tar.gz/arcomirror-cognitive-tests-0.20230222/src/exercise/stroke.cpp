#include "stroke.h"

StrokeExercise::StrokeExercise(QString key,
                               int numItems,
                               bool alphanumeric,
                               QObject *parent)
    : Exercise{key, parent}
{
        this->numItems = numItems;
        this->alphanumeric = alphanumeric;
}

QString StrokeExercise::getDisplayName() const
{
        return tr("Stroke Exercise");
}

int StrokeExercise::getNumItems()
{
        return numItems;
}

void StrokeExercise::setNumItems(int value)
{
        if (value == numItems)
                return;
        numItems = value;
        emit numItemsChanged();
}

bool StrokeExercise::isAlphanumeric()
{
        return alphanumeric;
}

void StrokeExercise::reset()
{
        Exercise::reset();
}

QJsonObject StrokeExercise::toJSON()
{
        return Exercise::toJSON();
}
