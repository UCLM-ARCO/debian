#include "config.h"

#include <QFile>
#include <QGuiApplication>
#include <QQmlEngine>

#include "clock.h"
#include "stroke.h"

Configuration::Configuration(QObject *parent) : QObject(parent)
{
        loadTests();
        loadConfiguration();
        loadLocales();
}

Configuration::~Configuration()
{
        qDeleteAll(tests);
        tests.clear();
        delete settings;
}

bool Configuration::loadTests()
{
        // NOTE They have to be hardcoded to enable translation
        // TrailMakingTest
        Test *trailMakingTest = new Test("TrailMakingTest");
        trailMakingTest->addExercise(
            new StrokeExercise("1", 15, false, trailMakingTest));
        trailMakingTest->addExercise(
            new StrokeExercise("2", 15, true, trailMakingTest));
        tests.append(trailMakingTest);

        // MOCA
        Test *mocaTest = new Test("MOCA");
        mocaTest->addExercise(new StrokeExercise("1", 10, true, mocaTest));
        mocaTest->addExercise(new ClockExercise("2", 1, 1, 1, mocaTest));
        tests.append(mocaTest);

        qInfo() << "All tests loaded!";
        return true;
}

void Configuration::loadConfiguration()
{
        qInfo() << "Loading configuration from" << settings->fileName()
                << "...";
        for (Test *test : tests) {
                settings->beginGroup(test->getKey());
                for (Exercise *exercise : test->getExercises()) {
                        settings->beginGroup(exercise->getKey());
                        for (QString property : settings->childKeys()) {
                                if (exercise->setProperty(property,
                                                          QVariant(
                                                              settings->value(
                                                                  property)))) {
                                        ;
                                } else {
                                        qWarning()
                                            << test->getKey()
                                            << exercise->getKey()
                                            << ": Could not set property"
                                            << property << "by configuration";
                                }
                        }
                        settings->endGroup();
                }
                settings->endGroup();
        }
        qInfo() << "Configuration loaded!";
}

void Configuration::loadLocales()
{
        if (getLocale() != "en_GB") { // FIXME Could not be a "supported" locale
                qInfo() << "Loading" << getLocale() << "translation...";
                // Load initial translator, if needed
                if (translator.load(":/i18n/" + getLocale()))
                        qApp->installTranslator(&translator);
                else {
                        qWarning() << "Could not load locale" << getLocale();
                        setLocale("en_GB");
                }
        }
}

bool Configuration::isRelease() const
{
#ifdef QT_NO_DEBUG
        return true;
#else
        return false;
#endif
}

QString Configuration::getLocale()
{
        QString retval;
        settings->beginGroup("Application");
        retval = settings->value("Locale", "en_GB").toString();
        settings->endGroup();
        return retval;
}

QStringList Configuration::getSupportedLocales()
{
        return supportedLocales;
}

void Configuration::setLocale(QString value)
{
        if (!supportedLocales.contains(value)) {
                qWarning() << "Unknown locale" << value;
                return;
        } else if (value == getLocale()) {
                qDebug() << "No changes in locale";
                return;
        } else if (value == "en_GB") {
                qDebug() << "Removing translator" << getLocale();
                qApp->removeTranslator((&translator));
        } else {
                qDebug() << "Loading locale" << value;
                translator.load(":/i18n/" + value);
                if (getLocale() == "en_GB") {
                        qApp->installTranslator(&translator);
                }
        }
        settings->beginGroup("Application");
        settings->setValue("Locale", value);
        settings->endGroup();
        emit localeChanged();
}

int Configuration::getFontSize()
{
        int retval;
        settings->beginGroup("Application");
        retval = settings->value("FontSize", 25).toInt();
        settings->endGroup();
        return retval;
}

void Configuration::setFontSize(int value)
{
        if (value == getFontSize())
                return;
        settings->beginGroup("Application");
        settings->setValue("FontSize", value);
        settings->endGroup();
        emit fontSizeChanged();
}

QList<Test *> Configuration::getTests()
{
        return tests;
}

bool Configuration::setExerciseProperty(Exercise *exercise,
                                        QString property,
                                        QVariant value)
{
        if (!exercise->setProperty(property, value))
                return false;
        settings->beginGroup(qobject_cast<Test *>(exercise->parent())->getKey());
        settings->beginGroup(exercise->getKey());
        settings->setValue(property, value);
        settings->endGroup();
        settings->endGroup();
        return true;
}
