#include "test.h"

Test::Test(QString key, QObject *parent) : QObject{parent}
{
        this->key = key;
}

Test::~Test()
{
        qDeleteAll(exercises);
        exercises.clear();
}

QString Test::getKey()
{
        return key;
}

QList<Exercise *> Test::getExercises()
{
        return exercises;
}

void Test::addExercise(Exercise *e)
{
        exercises.append(e);
}
