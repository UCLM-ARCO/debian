#include "translationhandler.h"
#include <QDir>
#include <QGuiApplication>
#include <QLocale>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QSettings>

#define VERSION "0.20230222-1" // TODO Define version at compilation time

int main(int argc, char *argv[])
{
        // TODO Make tests for application
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
        QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
        QCoreApplication::setApplicationVersion(VERSION);
        QGuiApplication app(argc, argv);

        QQmlApplicationEngine engine;
        engine.addImportPath("qrc:/");

        QSettings::setDefaultFormat(QSettings::IniFormat);
        QSettings::setPath(QSettings::IniFormat,
                           QSettings::UserScope,
                           QDir::homePath() + "/.config");
        QSettings::setPath(QSettings::IniFormat, QSettings::SystemScope, "/etc");

        TranslationHandler trHandler(&engine);
        engine.rootContext()->setContextProperty("TranslationHandler",
                                                 &trHandler);

        const QUrl url(QStringLiteral("qrc:/main.qml"));
        QObject::connect(
            &engine,
            &QQmlApplicationEngine::objectCreated,
            &app,
            [url](QObject *obj, const QUrl &objUrl) {
                    if (!obj && url == objUrl)
                            QCoreApplication::exit(-1);
            },
            Qt::QueuedConnection);
        engine.load(url);

        return app.exec();
}
