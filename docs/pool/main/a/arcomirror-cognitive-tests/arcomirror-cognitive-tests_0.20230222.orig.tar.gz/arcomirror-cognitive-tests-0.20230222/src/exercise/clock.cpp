#include "clock.h"

ClockExercise::ClockExercise(QString key,
                             int outlinePoints,
                             int numbersPoints,
                             int needlesPoints,
                             QObject *parent)
    : Exercise{key, parent}
{
        this->outlinePoints = outlinePoints;
        this->numbersPoints = numbersPoints;
        this->needlesPoints = needlesPoints;
}

QString ClockExercise::getDisplayName() const
{
        return tr("Clock Exercise");
}

int ClockExercise::getOutlinePoints()
{
        return outlinePoints;
}

int ClockExercise::getNumbersPoints()
{
        return numbersPoints;
}

int ClockExercise::getNeedlesPoints()
{
        return needlesPoints;
}

void ClockExercise::setImage(QString base64Url)
{
        addData(QPair<QString, QByteArray>(
            "png",
            QByteArray::fromBase64(
                base64Url.replace("data:image/png;base64,", "").toLocal8Bit())));
}

void ClockExercise::reset()
{
        Exercise::reset();
}

QJsonObject ClockExercise::toJSON()
{
        QJsonObject retval = Exercise::toJSON();
        return retval;
}
