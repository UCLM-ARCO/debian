#include "exercise.h"

Exercise::Exercise(QString key, QObject *parent) : QObject{parent}
{
        this->key = key;
}

bool Exercise::isWritable(QString property)
{
        bool retval = false;
        for (int i = metaObject()->propertyOffset();
             i < metaObject()->propertyCount();
             ++i) {
                QMetaProperty propertyObj = metaObject()->property(i);
                if (property.toLower() != QString(propertyObj.name()).toLower())
                        continue;
                else if (propertyObj.isWritable()) {
                        retval = true;
                        break;
                }
        }
        return retval;
}

bool Exercise::setProperty(QString property, QVariant value)
{
        bool retval = false;
        for (int i = metaObject()->propertyOffset();
             i < metaObject()->propertyCount();
             ++i) {
                QMetaProperty propertyObj = metaObject()->property(i);
                if (property.toLower() != QString(propertyObj.name()).toLower())
                        continue;
                else if (propertyObj.isWritable()) {
                        propertyObj.write(this, value);
                        retval = true;
                        break;
                }
        }
        return retval;
}

QString Exercise::getType() const
{
        return metaObject()->className();
}

QString Exercise::getDisplayName() const
{
        return tr("Exercise");
}

QString Exercise::getKey()
{
        return key;
}

int Exercise::getTime()
{
        return time;
}

void Exercise::updateTime()
{
        ++time;
        emit timeChanged();
}

int Exercise::getNumError()
{
        return numError;
}

void Exercise::addError()
{
        ++numError;
}

QList<QPointF> Exercise::getTouches()
{
        return touches;
}

void Exercise::addTouch(int x, int y)
{
        //        qDebug() << x << y << areaWidth << areaHeight
        //                 << (qMax(0, qMin(areaWidth, x)) / float(areaWidth))
        //                 << (qMax(0, qMin(areaHeight, y)) / float(areaHeight));
        touches.append(
            QPointF(qMax(0, qMin(areaWidth, x)) / float(areaWidth),
                    qMax(0, qMin(areaHeight, y)) / float(areaHeight)));
}

void Exercise::setAreaSize(int width, int height)
{
        areaWidth = width;
        areaHeight = height;
}

void Exercise::reset()
{
        time = 0;
        numError = 0;
        touches.clear();
        data.clear();
}

QJsonObject Exercise::toJSON()
{
        QJsonObject retval;
        retval["key"] = getKey();
        retval["type"] = getType();
        retval["time"] = getTime();
        retval["errors"] = getNumError();
        retval["areaWidth"] = areaWidth;
        retval["areaHeight"] = areaHeight;
        QJsonArray touchesJson;
        for (QPointF t : getTouches()) {
                QJsonObject pt;
                pt["x"] = t.x();
                pt["y"] = t.y();
                touchesJson.append(pt);
        }
        retval["touches"] = touchesJson;
        return retval;
}

QList<QPair<QString, QByteArray> > Exercise::getData()
{
        return data;
}

void Exercise::addData(QPair<QString, QByteArray> data)
{
        this->data.append(data);
}
