#ifndef CLOCKEXERCISE_H
#define CLOCKEXERCISE_H

#include <qqml.h>

#include <QObject>

#include "exercise.h"

class ClockExercise : public Exercise
{
        Q_OBJECT
        Q_PROPERTY(int outlinePoints READ getOutlinePoints CONSTANT)
        Q_PROPERTY(int numbersPoints READ getNumbersPoints CONSTANT)
        Q_PROPERTY(int needlesPoints READ getNeedlesPoints CONSTANT)
        QML_ELEMENT

    public:
        explicit ClockExercise(QString key,
                               int outlinePoints = 1,
                               int numbersPoints = 1,
                               int needlesPoints = 1,
                               QObject *parent = nullptr);

        QString getDisplayName() const override;

        int getOutlinePoints();
        int getNumbersPoints();
        int getNeedlesPoints();

        Q_INVOKABLE void setImage(QString base64Url);

        Q_INVOKABLE void reset() override;
        QJsonObject toJSON() override;

    private:
        int outlinePoints;
        int numbersPoints;
        int needlesPoints;
};

#endif // CLOCKEXERCISE_H
