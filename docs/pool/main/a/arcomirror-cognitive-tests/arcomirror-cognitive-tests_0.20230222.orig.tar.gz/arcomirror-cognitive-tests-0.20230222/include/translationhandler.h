#ifndef TRANSLATIONHANDLER_H
#define TRANSLATIONHANDLER_H

#include <QObject>
#include <QQmlEngine>

class TranslationHandler : public QObject
{
        Q_OBJECT

    public:
        explicit TranslationHandler(QQmlEngine *engine,
                                    QObject *parent = nullptr);

    public slots:
        Q_INVOKABLE void retranslate();

    signals:
        void retranslationRequested();
};

#endif // TRANSLATIONHANDLER_H
