import time
import logging
import requests
import json
from threading import Thread, Event
from http.server import BaseHTTPRequestHandler, HTTPServer
from contextlib import AbstractContextManager

from libavatar.utils import LoggingCustomFormatter, Timer

ch = logging.StreamHandler()
ch.setFormatter(LoggingCustomFormatter())

log = logging.getLogger("LibAvatar")
log.setLevel(logging.DEBUG)
log.propagate = False
log.addHandler(ch)


class AvatarError(RuntimeError):
    pass


class AvatarNotAvailable(AvatarError):
    def __str__(self):
        return "Avatar not available, it may be in use by others."


class AvatarSession(AbstractContextManager):
    def __init__(self, proxy, callback=None, keep=False, timeout=30):
        self._proxy = proxy
        self._callback = callback
        self._session_timeout = timeout
        self._last_check = None
        self._token = None
        self._timer = None

        if keep:
            self._timer = Timer(timeout * 0.8, self._update_token)

    def __del__(self):
        # NOTE: If timer is created, it holds a reference to this object,
        # so this destructor will not be called automatically. Better use
        # the 'with' statement instead.
        self.release()

    def __exit__(self, *args, **kwargs):
        self.release()

    def release(self):
        if self._token is not None:
            self._proxy.release_session(self._token)
            self._token = None
        if self._timer is not None:
            self._timer.stop()

    @property
    def token(self):
        if self._token is None or self._elapsed > self._session_timeout:
            self._token = self._get_token()
        return self._token

    @property
    def _elapsed(self):
        if self._last_check is None:
            return self._session_timeout + 1
        return time.time() - self._last_check

    def _get_token(self):
        self._last_check = time.time()
        return self._proxy.get_session(callback=self._callback)

    def _update_token(self):
        if self._token is None:
            self._token = self._get_token()
        else:
            self._proxy.update_session(self._token)
            self._last_check = time.time()


class WebHookHandler(Thread):
    def __init__(self, host="127.0.0.1", port=0):
        super().__init__()
        self._host = host
        self._port = port
        self._status = None
        self._response_ev = Event()
        self._ready_ev = Event()

        self.daemon = True
        self.endpoint = None
        self.start()

    def wait_ready(self):
        self._ready_ev.wait()

    def wait_respose(self, timeout=None):
        if not self._response_ev.wait(timeout):
            raise AvatarError("the Avatar did not respond")

        try:
            return self._status
        finally:
            self._status = None
            self._response_ev.clear()

    def run(self):
        handler = self

        class RequestHandler(BaseHTTPRequestHandler):
            def log_message(self, *args, **kwargs):
                pass

            def do_POST(self):
                log.info(" [WebHook] post received")
                size = int(self.headers["Content-Length"])
                body = self.rfile.read(size)
                body = json.loads(body)
                handler._status = body.get("status", "invalid response from server")
                handler._response_ev.set()

                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(b'{"status":"ok"}')

        with HTTPServer((self._host, self._port), RequestHandler) as server:
            port = server.socket.getsockname()[1]
            self.endpoint = f"{self._host}:{port}"
            log.info(f" [WebHook] listening on {self.endpoint}")
            self._ready_ev.set()
            server.serve_forever()


class AvatarPrx:
    def __init__(self, url, object_path):
        self._base_url = url + "/remote/object/call"
        self._object_path = object_path

    def get_session(self, callback):
        log.debug(" [AvatarPrx] get session")
        resp = self._call_function("GetSession", cbhook=callback)
        return resp.get("token")

    def update_session(self, session):
        log.debug(" [AvatarPrx] update session")
        self._call_function("UpdateSession", token=session)

    def release_session(self, session):
        log.debug(" [AvatarPrx] release session")
        resp = self._call_function("ReleaseSession", False, session=session)
        status = resp.get("status")
        if status not in ["ok", "pending"]:
            raise AvatarError(f"could not release session (response: {status})")

    def talk(self, text, session):
        log.debug(f" [AvatarPrx] talk, text: '{text}'")
        self._call_function("Talk", text=text, session=session)

    def stop(self, session):
        log.debug(f" [AvatarPrx] stop")
        resp = self._call_function("Stop", False, session=session)
        status = resp.get("status")
        if status not in ["ok", "not talking"]:
            raise AvatarError(f"could not release session (response: {status})")
        if status == "not talking":
            log.info(" Avatar was not talking, nothing done.")

    def _call_function(self, name, check_status=True, **kwargs):
        body = dict(
            objectPath = self._object_path,
            functionName = name,
            parameters = kwargs)

        try:
            resp = requests.put(self._base_url, json=body)
            resp.raise_for_status()
        except requests.exceptions.ConnectionError:
            raise AvatarError("could not connect to server")
        except requests.exceptions.HTTPError as err:
            resp = err.response.json()
            raise AvatarError(resp.get("errorMessage", "Invalid response from server"))

        resp = resp.json()
        if check_status:
            status = resp.get("status")
            if status == "not available":
                raise AvatarNotAvailable()
            if status != "ok":
                raise AvatarError(f"[Avatar] {status}")
        return resp

