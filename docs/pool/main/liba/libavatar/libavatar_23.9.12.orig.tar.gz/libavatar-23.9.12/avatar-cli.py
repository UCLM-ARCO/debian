#!/usr/bin/env python3

import logging
from argparse import ArgumentParser

from libavatar import AvatarPrx, AvatarSession, WebHookHandler, AvatarError

log = logging.getLogger("CLI")
log.setLevel(logging.DEBUG)


class AvatarClient:
    def __init__(self, args):
        self._args = args

        objpath = args.object_path
        if args.in_pie:
            p = objpath.rfind("/") + 1
            objpath = objpath[:p] + "UEDPIE_0_" + objpath[p:]

        self._avatar = AvatarPrx(f"http://{args.endpoint}", objpath)

    def run(self):
        if self._args.speak:
            self._cmd_speak(self._args.speak)
        elif self._args.stop:
            self._cmd_stop()
        else:
            log.warning(" No command given, nothing to do. Give -h for more info.")

    def _cmd_speak(self, text):
        try:
            callback = None
            if not self._args.no_wait:
                webhook = WebHookHandler()
                webhook.wait_ready()
                callback = webhook.endpoint

            if self._args.keep_timeout == -1:
                session = AvatarSession(
                    self._avatar, callback=callback)
            else:
                session = AvatarSession(
                    self._avatar, keep=True, callback=callback, timeout=self._args.keep_timeout)

            with session:
                self._avatar.talk(text, session.token)
                if not self._args.no_wait:
                    response = webhook.wait_respose(self._args.wait_timeout)
                    if response != "finished":
                        raise AvatarError(f"there were an error on Avatar ({response})")
        except AvatarError as err:
            log.error(f" Could not run that command! ({err})")

    def _cmd_stop(self):
        try:
            # With keep=False, it uses RTTI to do the session release, no need for 'with'
            session = AvatarSession(self._avatar)
            self._avatar.stop(session.token)
        except AvatarError as err:
            log.error(f" Could not run that command! ({err})")


if __name__ == "__main__":
    parser = ArgumentParser()
    actions = parser.add_argument_group('actions')

    # Actions
    actions.add_argument("-s", "--speak",
        help="tell the avatar to say the given text")
    actions.add_argument("-p", "--stop", action="store_true",
        help="tell the avatar to stop talking")

    # Options
    parser.add_argument("-e", "--endpoint", default="127.0.0.1:30010",
        help="web endpoint where the Avatar exposes its REST API")
    parser.add_argument("--object-path",
        default="/Game/Maps/Main.Main:PersistentLevel.RCIface_C_1",
        help="object path that implements the REST API")
    parser.add_argument("--in-pie", action="store_true", default=False,
        help="add this flag if the Avatar is running inside the UE Editor")
    parser.add_argument("--no-wait", action="store_true", default=False,
        help="do not wait for Avatar to finish the request")
    parser.add_argument("--wait-timeout", type=int, default=30,
        help="maximum time to wait for Avatar response (in seconds)")
    parser.add_argument("--keep-timeout", type=int, default=-1,
        help="Avatar's session timeout, used to keep the session open (in seconds)")

    args = parser.parse_args()
    cli = AvatarClient(args)
    cli.run()
